# [![](Images/CesiumLogo.png)](index.html) EllipseOutlineGeometry 

#### [](#EllipseOutlineGeometry) new Cesium.EllipseOutlineGeometry(options) 

[engine/Source/Core/EllipseOutlineGeometry.js 213](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipseOutlineGeometry.js#L213) 

 A description of the outline of an ellipse on an ellipsoid.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description center [Cartesian3](Cartesian3.html)  The ellipse's center point in the fixed frame. semiMajorAxis number  The length of the ellipse's semi-major axis in meters. semiMinorAxis number  The length of the ellipse's semi-minor axis in meters. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid the ellipse will be on. height number 0.0 optional The distance in meters between the ellipse and the ellipsoid surface. extrudedHeight number optional The distance in meters between the ellipse's extruded face and the ellipsoid surface. rotation number 0.0 optional The angle from north (counter-clockwise) in radians. granularity number 0.02 optional The angular distance between points on the ellipse in radians. numberOfVerticalLines number 16 optional Number of lines to draw between the top and bottom surface of an extruded ellipse. |

##### Throws:

* [DeveloperError](DeveloperError.html): semiMajorAxis and semiMinorAxis must be greater than zero.
* [DeveloperError](DeveloperError.html): semiMajorAxis must be greater than or equal to the semiMinorAxis.
* [DeveloperError](DeveloperError.html): granularity must be greater than zero.

##### Example:

```javascript
const ellipse = new Cesium.EllipseOutlineGeometry({
  center : Cesium.Cartesian3.fromDegrees(-75.59777, 40.03883),
  semiMajorAxis : 500000.0,
  semiMinorAxis : 300000.0,
  rotation : Cesium.Math.toRadians(60.0)
});
const geometry = Cesium.EllipseOutlineGeometry.createGeometry(ellipse);
```

##### See:

* [EllipseOutlineGeometry.createGeometry](EllipseOutlineGeometry.html#.createGeometry)

### Members

#### [](#.packedLength) static Cesium.EllipseOutlineGeometry.packedLength : number 

[engine/Source/Core/EllipseOutlineGeometry.js 268](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipseOutlineGeometry.js#L268) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.EllipseOutlineGeometry.createGeometry(ellipseGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/EllipseOutlineGeometry.js 392](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipseOutlineGeometry.js#L392) 

 Computes the geometric representation of an outline of an ellipse on an ellipsoid, including its vertices, indices, and a bounding sphere.

| Name            | Type                                                  | Description                   |
| --------------- | ----------------------------------------------------- | ----------------------------- |
| ellipseGeometry | [EllipseOutlineGeometry](EllipseOutlineGeometry.html) | A description of the ellipse. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.EllipseOutlineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/EllipseOutlineGeometry.js 280](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipseOutlineGeometry.js#L280) 

 Stores the provided instance into the provided array.

| Name          | Type                                                  | Default | Description                                                               |
| ------------- | ----------------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [EllipseOutlineGeometry](EllipseOutlineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                        |         | The array to pack into.                                                   |
| startingIndex | number                                                | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.EllipseOutlineGeometry.unpack(array, startingIndex, result) → [EllipseOutlineGeometry](EllipseOutlineGeometry.html) 

[engine/Source/Core/EllipseOutlineGeometry.js 333](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipseOutlineGeometry.js#L333) 

 Retrieves an instance from a packed array.

| Name          | Type                                                  | Default | Description                                                |
| ------------- | ----------------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                        |         | The packed array.                                          |
| startingIndex | number                                                | 0       | optional The starting index of the element to be unpacked. |
| result        | [EllipseOutlineGeometry](EllipseOutlineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new EllipseOutlineGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

