# [![](Images/CesiumLogo.png)](index.html) CorridorGraphics 

#### [](#CorridorGraphics) new Cesium.CorridorGraphics(options) 

[engine/Source/DataSources/CorridorGraphics.js 46](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L46) 

 Describes a corridor, which is a shape defined by a centerline and width that conforms to the curvature of the globe. It can be placed on the surface or at altitude and can optionally be extruded into a volume.

| Name    | Type                                                                             | Description                                       |
| ------- | -------------------------------------------------------------------------------- | ------------------------------------------------- |
| options | [CorridorGraphics.ConstructorOptions](CorridorGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle Corridor Demo](https://sandcastle.cesium.com/index.html?src=Corridor.html)

##### See:

* [Entity](Entity.html)

### Members

#### [](#classificationType) classificationType : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 239](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L239) 

 Gets or sets the [ClassificationType](global.html#ClassificationType) Property specifying whether this corridor will classify terrain, 3D Tiles, or both when on the ground.

Default Value: `ClassificationType.BOTH` 

#### [](#cornerType) cornerType : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 162](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L162) 

 Gets or sets the [CornerType](global.html#CornerType) Property specifying how corners are styled.

Default Value: `CornerType.ROUNDED` 

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/CorridorGraphics.js 95](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L95) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 229](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L229) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this corridor will be displayed.

#### [](#extrudedHeight) extrudedHeight : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 146](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L146) 

 Gets or sets the numeric Property specifying the altitude of the corridor extrusion. Setting this property creates a corridor shaped volume starting at height and ending at this altitude.

#### [](#extrudedHeightReference) extrudedHeightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 154](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L154) 

 Gets or sets the Property specifying the extruded [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#fill) fill : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 178](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L178) 

 Gets or sets the boolean Property specifying whether the corridor is filled with the provided material.

Default Value: `true` 

#### [](#granularity) granularity : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 170](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L170) 

 Gets or sets the numeric Property specifying the sampling distance between each latitude and longitude point.

Default Value: `{CesiumMath.RADIANS_PER_DEGREE}` 

#### [](#height) height : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 129](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L129) 

 Gets or sets the numeric Property specifying the altitude of the corridor.

Default Value: `0.0` 

#### [](#heightReference) heightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 137](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L137) 

 Gets or sets the Property specifying the [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#material) material : [MaterialProperty](MaterialProperty.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 186](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L186) 

 Gets or sets the Property specifying the material used to fill the corridor.

Default Value: `Color.WHITE` 

#### [](#outline) outline : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 194](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L194) 

 Gets or sets the Property specifying whether the corridor is outlined.

Default Value: `false` 

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 202](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L202) 

 Gets or sets the Property specifying the [Color](Color.html) of the outline.

Default Value: `Color.BLACK` 

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 213](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L213) 

 Gets or sets the numeric Property specifying the width of the outline.

Note: This property will be ignored on all major browsers on Windows platforms. For details, see (@link https://github.com/CesiumGS/cesium/issues/40}.

Default Value: `1.0` 

#### [](#positions) positions : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L114) 

 Gets or sets a Property specifying the array of [Cartesian3](Cartesian3.html) positions that define the centerline of the corridor.

#### [](#shadows) shadows : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 222](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L222) 

 Get or sets the enum Property specifying whether the corridor casts or receives shadows from light sources.

Default Value: `ShadowMode.DISABLED` 

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L107) 

 Gets or sets the boolean Property specifying the visibility of the corridor.

Default Value: `true` 

#### [](#width) width : [Property](Property.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L121) 

 Gets or sets the numeric Property specifying the width of the outline.

#### [](#zIndex) zIndex : [ConstantProperty](ConstantProperty.html)|undefined 

[engine/Source/DataSources/CorridorGraphics.js 247](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L247) 

 Gets or sets the zIndex Property specifying the ordering of the corridor. Only has an effect if the coridor is static and neither height or exturdedHeight are specified.

Default Value: `0` 

### Methods

#### [](#clone) clone(result) → [CorridorGraphics](CorridorGraphics.html) 

[engine/Source/DataSources/CorridorGraphics.js 256](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L256) 

 Duplicates this instance.

| Name   | Type                                      | Description                                         |
| ------ | ----------------------------------------- | --------------------------------------------------- |
| result | [CorridorGraphics](CorridorGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/CorridorGraphics.js 287](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L287) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                      | Description                               |
| ------ | ----------------------------------------- | ----------------------------------------- |
| source | [CorridorGraphics](CorridorGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.CorridorGraphics.ConstructorOptions

[engine/Source/DataSources/CorridorGraphics.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CorridorGraphics.js#L8) 

 Initialization options for the CorridorGraphics constructor

##### Properties:

| Name                     | Type                                                                                 | Attributes | Default                          | Description                                                                                                                                                        |
| ------------------------ | ------------------------------------------------------------------------------------ | ---------- | -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| show                     | [Property](Property.html)\|boolean                                                   | <optional> | true                             | A boolean Property specifying the visibility of the corridor.                                                                                                      |
| positions                | [Property](Property.html)\|Array.<[Cartesian3](Cartesian3.html)\>                    | <optional> |                                  | A Property specifying the array of [Cartesian3](Cartesian3.html) positions that define the centerline of the corridor.                                             |
| width                    | [Property](Property.html)\|number                                                    | <optional> |                                  | A numeric Property specifying the distance between the edges of the corridor.                                                                                      |
| height                   | [Property](Property.html)\|number                                                    | <optional> | 0                                | A numeric Property specifying the altitude of the corridor relative to the ellipsoid surface.                                                                      |
| heightReference          | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE             | A Property specifying what the height is relative to.                                                                                                              |
| extrudedHeight           | [Property](Property.html)\|number                                                    | <optional> |                                  | A numeric Property specifying the altitude of the corridor's extruded face relative to the ellipsoid surface.                                                      |
| extrudedHeightReference  | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE             | A Property specifying what the extrudedHeight is relative to.                                                                                                      |
| cornerType               | [Property](Property.html)\|[CornerType](global.html#CornerType)                      | <optional> | CornerType.ROUNDED               | A [CornerType](global.html#CornerType) Property specifying the style of the corners.                                                                               |
| granularity              | [Property](Property.html)\|number                                                    | <optional> | Cesium.Math.RADIANS\_PER\_DEGREE | A numeric Property specifying the distance between each latitude and longitude.                                                                                    |
| fill                     | [Property](Property.html)\|boolean                                                   | <optional> | true                             | A boolean Property specifying whether the corridor is filled with the provided material.                                                                           |
| material                 | [MaterialProperty](MaterialProperty.html)\|[Color](Color.html)                       | <optional> | Color.WHITE                      | A Property specifying the material used to fill the corridor.                                                                                                      |
| outline                  | [Property](Property.html)\|boolean                                                   | <optional> | false                            | A boolean Property specifying whether the corridor is outlined.                                                                                                    |
| outlineColor             | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.BLACK                      | A Property specifying the [Color](Color.html) of the outline.                                                                                                      |
| outlineWidth             | [Property](Property.html)\|number                                                    | <optional> | 1.0                              | A numeric Property specifying the width of the outline.                                                                                                            |
| shadows                  | [Property](Property.html)\|[ShadowMode](global.html#ShadowMode)                      | <optional> | ShadowMode.DISABLED              | An enum Property specifying whether the corridor casts or receives shadows from light sources.                                                                     |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                                  | A Property specifying at what distance from the camera that this corridor will be displayed.                                                                       |
| classificationType       | [Property](Property.html)\|[ClassificationType](global.html#ClassificationType)      | <optional> | ClassificationType.BOTH          | An enum Property specifying whether this corridor will classify terrain, 3D Tiles, or both when on the ground.                                                     |
| zIndex                   | [ConstantProperty](ConstantProperty.html)\|number                                    | <optional> |                                  | A Property specifying the zIndex of the corridor, used for ordering. Only has an effect if height and extrudedHeight are undefined, and if the corridor is static. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

