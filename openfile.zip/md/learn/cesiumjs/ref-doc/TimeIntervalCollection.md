# [![](Images/CesiumLogo.png)](index.html) TimeIntervalCollection 

#### [](#TimeIntervalCollection) new Cesium.TimeIntervalCollection(intervals) 

[engine/Source/Core/TimeIntervalCollection.js 23](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L23) 

 A non-overlapping collection of [TimeInterval](TimeInterval.html) instances sorted by start time.

| Name      | Type                                       | Description                                              |
| --------- | ------------------------------------------ | -------------------------------------------------------- |
| intervals | Array.<[TimeInterval](TimeInterval.html)\> | optional An array of intervals to add to the collection. |

### Members

#### [](#changedEvent) readonly changedEvent : [Event](Event.html) 

[engine/Source/Core/TimeIntervalCollection.js 42](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L42) 

 Gets an event that is raised whenever the collection of intervals change.

#### [](#isEmpty) readonly isEmpty : boolean 

[engine/Source/Core/TimeIntervalCollection.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L120) 

 Gets whether or not the collection is empty.

#### [](#isStartIncluded) readonly isStartIncluded : boolean 

[engine/Source/Core/TimeIntervalCollection.js 67](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L67) 

 Gets whether or not the start time is included in the collection.

#### [](#isStopIncluded) readonly isStopIncluded : boolean 

[engine/Source/Core/TimeIntervalCollection.js 94](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L94) 

 Gets whether or not the stop time is included in the collection.

#### [](#length) readonly length : number 

[engine/Source/Core/TimeIntervalCollection.js 108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L108) 

 Gets the number of intervals in the collection.

#### [](#start) readonly start : [JulianDate](JulianDate.html) 

[engine/Source/Core/TimeIntervalCollection.js 54](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L54) 

 Gets the start time of the collection.

#### [](#stop) readonly stop : [JulianDate](JulianDate.html) 

[engine/Source/Core/TimeIntervalCollection.js 80](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L80) 

 Gets the stop time of the collection.

### Methods

#### [](#.fromIso8601) static Cesium.TimeIntervalCollection.fromIso8601(options, result) → [TimeIntervalCollection](TimeIntervalCollection.html) 

[engine/Source/Core/TimeIntervalCollection.js 995](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L995) 

 Creates a new instance from an [ISO 8601](http://en.wikipedia.org/wiki/ISO%5F8601) time interval (start/end/duration).

| Name    | Type                                                  | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| ------- | ----------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object                                                | Object with the following properties: Name Type Default Description iso8601 string  An ISO 8601 interval. isStartIncluded boolean true optional true if start time is included in the interval, false otherwise. isStopIncluded boolean true optional true if stop time is included in the interval, false otherwise. leadingInterval boolean false optional true if you want to add a interval from Iso8601.MINIMUM\_VALUE to start time, false otherwise. trailingInterval boolean false optional true if you want to add a interval from stop time to Iso8601.MAXIMUM\_VALUE, false otherwise. dataCallback function optional A function that will be return the data that is called with each interval before it is added to the collection. If unspecified, the data will be the index in the collection. |
| result  | [TimeIntervalCollection](TimeIntervalCollection.html) | optional An existing instance to use for the result.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |

##### Returns:

 The modified result parameter or a new instance if none was provided.

#### [](#.fromIso8601DateArray) static Cesium.TimeIntervalCollection.fromIso8601DateArray(options, result) → [TimeIntervalCollection](TimeIntervalCollection.html) 

[engine/Source/Core/TimeIntervalCollection.js 1052](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L1052) 

 Creates a new instance from a [ISO 8601](http://en.wikipedia.org/wiki/ISO%5F8601) date array.

| Name    | Type                                                  | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ------- | ----------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object                                                | Object with the following properties: Name Type Default Description iso8601Dates Array.<string>  An array of ISO 8601 dates. isStartIncluded boolean true optional true if start time is included in the interval, false otherwise. isStopIncluded boolean true optional true if stop time is included in the interval, false otherwise. leadingInterval boolean false optional true if you want to add a interval from Iso8601.MINIMUM\_VALUE to start time, false otherwise. trailingInterval boolean false optional true if you want to add a interval from stop time to Iso8601.MAXIMUM\_VALUE, false otherwise. dataCallback function optional A function that will be return the data that is called with each interval before it is added to the collection. If unspecified, the data will be the index in the collection. |
| result  | [TimeIntervalCollection](TimeIntervalCollection.html) | optional An existing instance to use for the result.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |

##### Returns:

 The modified result parameter or a new instance if none was provided.

#### [](#.fromIso8601DurationArray) static Cesium.TimeIntervalCollection.fromIso8601DurationArray(options, result) → [TimeIntervalCollection](TimeIntervalCollection.html) 

[engine/Source/Core/TimeIntervalCollection.js 1092](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L1092) 

 Creates a new instance from a [ISO 8601](http://en.wikipedia.org/wiki/ISO%5F8601) duration array.

| Name    | Type                                                  | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ------- | ----------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object                                                | Object with the following properties: Name Type Default Description epoch [JulianDate](JulianDate.html)  An date that the durations are relative to. iso8601Durations string  An array of ISO 8601 durations. relativeToPrevious boolean false optional true if durations are relative to previous date, false if always relative to the epoch. isStartIncluded boolean true optional true if start time is included in the interval, false otherwise. isStopIncluded boolean true optional true if stop time is included in the interval, false otherwise. leadingInterval boolean false optional true if you want to add a interval from Iso8601.MINIMUM\_VALUE to start time, false otherwise. trailingInterval boolean false optional true if you want to add a interval from stop time to Iso8601.MAXIMUM\_VALUE, false otherwise. dataCallback function optional A function that will be return the data that is called with each interval before it is added to the collection. If unspecified, the data will be the index in the collection. |
| result  | [TimeIntervalCollection](TimeIntervalCollection.html) | optional An existing instance to use for the result.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |

##### Returns:

 The modified result parameter or a new instance if none was provided.

#### [](#.fromJulianDateArray) static Cesium.TimeIntervalCollection.fromJulianDateArray(options, result) → [TimeIntervalCollection](TimeIntervalCollection.html) 

[engine/Source/Core/TimeIntervalCollection.js 744](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L744) 

 Creates a new instance from a JulianDate array.

| Name    | Type                                                  | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| ------- | ----------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object                                                | Object with the following properties: Name Type Default Description julianDates Array.<[JulianDate](JulianDate.html)\>  An array of ISO 8601 dates. isStartIncluded boolean true optional true if start time is included in the interval, false otherwise. isStopIncluded boolean true optional true if stop time is included in the interval, false otherwise. leadingInterval boolean false optional true if you want to add a interval from Iso8601.MINIMUM\_VALUE to start time, false otherwise. trailingInterval boolean false optional true if you want to add a interval from stop time to Iso8601.MAXIMUM\_VALUE, false otherwise. dataCallback function optional A function that will be return the data that is called with each interval before it is added to the collection. If unspecified, the data will be the index in the collection. |
| result  | [TimeIntervalCollection](TimeIntervalCollection.html) | optional An existing instance to use for the result.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |

##### Returns:

 The modified result parameter or a new instance if none was provided.

#### [](#addInterval) addInterval(interval, dataComparer) 

[engine/Source/Core/TimeIntervalCollection.js 310](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L310) 

 Adds an interval to the collection, merging intervals that contain the same data and splitting intervals of different data as needed in order to maintain a non-overlapping collection. The data in the new interval takes precedence over any existing intervals in the collection.

| Name         | Type                                                         | Description                                                                                               |
| ------------ | ------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------- |
| interval     | [TimeInterval](TimeInterval.html)                            | The interval to add.                                                                                      |
| dataComparer | [TimeInterval.DataComparer](TimeInterval.html#.DataComparer) | optional A function which compares the data of the two intervals. If omitted, reference equality is used. |

#### [](#contains) contains(julianDate) → boolean 

[engine/Source/Core/TimeIntervalCollection.js 212](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L212) 

 Checks if the specified date is inside this collection.

| Name       | Type                          | Description        |
| ---------- | ----------------------------- | ------------------ |
| julianDate | [JulianDate](JulianDate.html) | The date to check. |

##### Returns:

`true` if the collection contains the specified date, `false` otherwise.

#### [](#equals) equals(right, dataComparer) → boolean 

[engine/Source/Core/TimeIntervalCollection.js 135](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L135) 

 Compares this instance against the provided instance componentwise and returns`true` if they are equal, `false` otherwise.

| Name         | Type                                                         | Description                                                                                               |
| ------------ | ------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------- |
| right        | [TimeIntervalCollection](TimeIntervalCollection.html)        | optional The right hand side collection.                                                                  |
| dataComparer | [TimeInterval.DataComparer](TimeInterval.html#.DataComparer) | optional A function which compares the data of the two intervals. If omitted, reference equality is used. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#findDataForIntervalContainingDate) findDataForIntervalContainingDate(date) → object 

[engine/Source/Core/TimeIntervalCollection.js 199](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L199) 

 Finds and returns the data for the interval that contains the specified date.

| Name | Type                          | Description             |
| ---- | ----------------------------- | ----------------------- |
| date | [JulianDate](JulianDate.html) | The date to search for. |

##### Returns:

 The data for the interval containing the specified date, or `undefined` if no such interval exists.

#### [](#findInterval) findInterval(options) → [TimeInterval](TimeInterval.html)|undefined 

[engine/Source/Core/TimeIntervalCollection.js 279](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L279) 

 Returns the first interval in the collection that matches the specified parameters. All parameters are optional and `undefined` parameters are treated as a don't care condition.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | optional Object with the following properties: Name Type Description start [JulianDate](JulianDate.html) optional The start time of the interval. stop [JulianDate](JulianDate.html) optional The stop time of the interval. isStartIncluded boolean optional true if options.start is included in the interval, false otherwise. isStopIncluded boolean optional true if options.stop is included in the interval, false otherwise. |

##### Returns:

 The first interval in the collection that matches the specified parameters.

#### [](#findIntervalContainingDate) findIntervalContainingDate(date) → [TimeInterval](TimeInterval.html)|undefined 

[engine/Source/Core/TimeIntervalCollection.js 188](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L188) 

 Finds and returns the interval that contains the specified date.

| Name | Type                          | Description             |
| ---- | ----------------------------- | ----------------------- |
| date | [JulianDate](JulianDate.html) | The date to search for. |

##### Returns:

 The interval containing the specified date, `undefined` if no such interval exists.

#### [](#get) get(index) → [TimeInterval](TimeInterval.html)|undefined 

[engine/Source/Core/TimeIntervalCollection.js 162](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L162) 

 Gets the interval at the specified index.

| Name  | Type   | Description                            |
| ----- | ------ | -------------------------------------- |
| index | number | The index of the interval to retrieve. |

##### Returns:

 The interval at the specified index, or `undefined` if no interval exists as that index.

#### [](#indexOf) indexOf(date) → number 

[engine/Source/Core/TimeIntervalCollection.js 227](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L227) 

 Finds and returns the index of the interval in the collection that contains the specified date.

| Name | Type                          | Description             |
| ---- | ----------------------------- | ----------------------- |
| date | [JulianDate](JulianDate.html) | The date to search for. |

##### Returns:

 The index of the interval that contains the specified date, if no such interval exists, it returns a negative number which is the bitwise complement of the index of the next interval that starts after the date, or if no interval starts after the specified date, the bitwise complement of the length of the collection.

#### [](#intersect) intersect(other, dataComparer, mergeCallback) → [TimeIntervalCollection](TimeIntervalCollection.html) 

[engine/Source/Core/TimeIntervalCollection.js 671](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L671) 

 Creates a new instance that is the intersection of this collection and the provided collection.

| Name          | Type                                                           | Description                                                                                                               |
| ------------- | -------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| other         | [TimeIntervalCollection](TimeIntervalCollection.html)          | The collection to intersect with.                                                                                         |
| dataComparer  | [TimeInterval.DataComparer](TimeInterval.html#.DataComparer)   | optional A function which compares the data of the two intervals. If omitted, reference equality is used.                 |
| mergeCallback | [TimeInterval.MergeCallback](TimeInterval.html#.MergeCallback) | optional A function which merges the data of the two intervals. If omitted, the data from the left interval will be used. |

##### Returns:

 A new TimeIntervalCollection which is the intersection of this collection and the provided collection.

#### [](#removeAll) removeAll() 

[engine/Source/Core/TimeIntervalCollection.js 175](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L175) 

 Removes all intervals from the collection.

#### [](#removeInterval) removeInterval(interval) → boolean 

[engine/Source/Core/TimeIntervalCollection.js 510](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeIntervalCollection.js#L510) 

 Removes the specified interval from this interval collection, creating a hole over the specified interval. The data property of the input interval is ignored.

| Name     | Type                              | Description             |
| -------- | --------------------------------- | ----------------------- |
| interval | [TimeInterval](TimeInterval.html) | The interval to remove. |

##### Returns:

`true` if the interval was removed, `false` if no part of the interval was in the collection.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

