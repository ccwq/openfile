# [![](Images/CesiumLogo.png)](index.html) ParticleSystem 

#### [](#ParticleSystem) new Cesium.ParticleSystem(options) 

[engine/Source/Scene/ParticleSystem.js 58](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L58) 

 A ParticleSystem manages the updating and display of a collection of particles.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description show boolean true optional Whether to display the particle system. updateCallback [ParticleSystem.updateCallback](ParticleSystem.html#.updateCallback) optional The callback function to be called each frame to update a particle. emitter [ParticleEmitter](ParticleEmitter.html) new CircleEmitter(0.5) optional The particle emitter for this system. modelMatrix [Matrix4](Matrix4.html) Matrix4.IDENTITY optional The 4x4 transformation matrix that transforms the particle system from model to world coordinates. emitterModelMatrix [Matrix4](Matrix4.html) Matrix4.IDENTITY optional The 4x4 transformation matrix that transforms the particle system emitter within the particle systems local coordinate system. emissionRate number 5 optional The number of particles to emit per second. bursts Array.<[ParticleBurst](ParticleBurst.html)\> optional An array of [ParticleBurst](ParticleBurst.html), emitting bursts of particles at periodic times. loop boolean true optional Whether the particle system should loop its bursts when it is complete. scale number 1.0 optional Sets the scale to apply to the image of the particle for the duration of its particleLife. startScale number optional The initial scale to apply to the image of the particle at the beginning of its life. endScale number optional The final scale to apply to the image of the particle at the end of its life. color [Color](Color.html) Color.WHITE optional Sets the color of a particle for the duration of its particleLife. startColor [Color](Color.html) optional The color of the particle at the beginning of its life. endColor [Color](Color.html) optional The color of the particle at the end of its life. image object optional The URI, HTMLImageElement, or HTMLCanvasElement to use for the billboard. imageSize [Cartesian2](Cartesian2.html) new Cartesian2(1.0, 1.0) optional If set, overrides the minimumImageSize and maximumImageSize inputs that scale the particle image's dimensions in pixels. minimumImageSize [Cartesian2](Cartesian2.html) optional Sets the minimum bound, width by height, above which to randomly scale the particle image's dimensions in pixels. maximumImageSize [Cartesian2](Cartesian2.html) optional Sets the maximum bound, width by height, below which to randomly scale the particle image's dimensions in pixels. sizeInMeters boolean optional Sets if the size of particles is in meters or pixels. true to size the particles in meters; otherwise, the size is in pixels. speed number 1.0 optional If set, overrides the minimumSpeed and maximumSpeed inputs with this value. minimumSpeed number optional Sets the minimum bound in meters per second above which a particle's actual speed will be randomly chosen. maximumSpeed number optional Sets the maximum bound in meters per second below which a particle's actual speed will be randomly chosen. lifetime number Number.MAX\_VALUE optional How long the particle system will emit particles, in seconds. particleLife number 5.0 optional If set, overrides the minimumParticleLife and maximumParticleLife inputs with this value. minimumParticleLife number optional Sets the minimum bound in seconds for the possible duration of a particle's life above which a particle's actual life will be randomly chosen. maximumParticleLife number optional Sets the maximum bound in seconds for the possible duration of a particle's life below which a particle's actual life will be randomly chosen. mass number 1.0 optional Sets the minimum and maximum mass of particles in kilograms. minimumMass number optional Sets the minimum bound for the mass of a particle in kilograms. A particle's actual mass will be chosen as a random amount above this value. maximumMass number optional Sets the maximum mass of particles in kilograms. A particle's actual mass will be chosen as a random amount below this value. |

##### Demo:

* [Particle Systems Tutorial](https://cesium.com/learn/cesiumjs-learn/cesiumjs-particle-systems/)
* [Particle Systems Tutorial Demo](https://sandcastle.cesium.com/?src=Particle%2520System.html&label=Showcases)
* [Particle Systems Fireworks Demo](https://sandcastle.cesium.com/?src=Particle%2520System%2520Fireworks.html&label=Showcases)

### Members

#### [](#bursts) bursts : Array.<[ParticleBurst](ParticleBurst.html)\> 

[engine/Source/Scene/ParticleSystem.js 209](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L209) 

 An array of [ParticleBurst](ParticleBurst.html), emitting bursts of particles at periodic times.

Default Value: `undefined` 

#### [](#complete) complete : [Event](Event.html) 

[engine/Source/Scene/ParticleSystem.js 522](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L522) 

 Fires an event when the particle system has reached the end of its lifetime.

#### [](#emissionRate) emissionRate : number 

[engine/Source/Scene/ParticleSystem.js 330](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L330) 

 The number of particles to emit per second.

Default Value: `5` 

#### [](#emitter) emitter : [ParticleEmitter](ParticleEmitter.html) 

[engine/Source/Scene/ParticleSystem.js 192](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L192) 

 The particle emitter for this

Default Value: `CircleEmitter` 

#### [](#emitterModelMatrix) emitterModelMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/ParticleSystem.js 243](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L243) 

 The 4x4 transformation matrix that transforms the particle system emitter within the particle systems local coordinate system.

Default Value: `Matrix4.IDENTITY` 

#### [](#endColor) endColor : [Color](Color.html) 

[engine/Source/Scene/ParticleSystem.js 279](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L279) 

 The color of the particle at the end of its life.

Default Value: `Color.WHITE` 

#### [](#endScale) endScale : number 

[engine/Source/Scene/ParticleSystem.js 313](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L313) 

 The final scale to apply to the image of the particle at the end of its life.

Default Value: `1.0` 

#### [](#image) image : object 

[engine/Source/Scene/ParticleSystem.js 87](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L87) 

 The URI, HTMLImageElement, or HTMLCanvasElement to use for the billboard.

Default Value: `undefined` 

#### [](#isComplete) isComplete : boolean 

[engine/Source/Scene/ParticleSystem.js 532](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L532) 

 When `true`, the particle system has reached the end of its lifetime; `false` otherwise.

#### [](#lifetime) lifetime : number 

[engine/Source/Scene/ParticleSystem.js 506](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L506) 

 How long the particle system will emit particles, in seconds.

Default Value: `Number.MAX_VALUE` 

#### [](#loop) loop : boolean 

[engine/Source/Scene/ParticleSystem.js 80](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L80) 

 Whether the particle system should loop it's bursts when it is complete.

Default Value: `true` 

#### [](#maximumImageSize) maximumImageSize : [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/ParticleSystem.js 470](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L470) 

 Sets the maximum bound, width by height, below which to randomly scale the particle image's dimensions in pixels.

Default Value: `new Cartesian2(1.0, 1.0)` 

#### [](#maximumMass) maximumMass : number 

[engine/Source/Scene/ParticleSystem.js 434](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L434) 

 Sets the maximum mass of particles in kilograms.

Default Value: `1.0` 

#### [](#maximumParticleLife) maximumParticleLife : number 

[engine/Source/Scene/ParticleSystem.js 399](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L399) 

 Sets the maximum bound in seconds for the possible duration of a particle's life below which a particle's actual life will be randomly chosen.

Default Value: `5.0` 

#### [](#maximumSpeed) maximumSpeed : number 

[engine/Source/Scene/ParticleSystem.js 365](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L365) 

 Sets the maximum bound in meters per second below which a particle's actual speed will be randomly chosen.

Default Value: `1.0` 

#### [](#minimumImageSize) minimumImageSize : [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/ParticleSystem.js 451](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L451) 

 Sets the minimum bound, width by height, above which to randomly scale the particle image's dimensions in pixels.

Default Value: `new Cartesian2(1.0, 1.0)` 

#### [](#minimumMass) minimumMass : number 

[engine/Source/Scene/ParticleSystem.js 417](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L417) 

 Sets the minimum mass of particles in kilograms.

Default Value: `1.0` 

#### [](#minimumParticleLife) minimumParticleLife : number 

[engine/Source/Scene/ParticleSystem.js 382](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L382) 

 Sets the minimum bound in seconds for the possible duration of a particle's life above which a particle's actual life will be randomly chosen.

Default Value: `5.0` 

#### [](#minimumSpeed) minimumSpeed : number 

[engine/Source/Scene/ParticleSystem.js 348](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L348) 

 Sets the minimum bound in meters per second above which a particle's actual speed will be randomly chosen.

Default Value: `1.0` 

#### [](#modelMatrix) modelMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/ParticleSystem.js 224](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L224) 

 The 4x4 transformation matrix that transforms the particle system from model to world coordinates.

Default Value: `Matrix4.IDENTITY` 

#### [](#show) show : boolean 

[engine/Source/Scene/ParticleSystem.js 66](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L66) 

 Whether to display the particle system.

Default Value: `true` 

#### [](#sizeInMeters) sizeInMeters : boolean 

[engine/Source/Scene/ParticleSystem.js 489](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L489) 

 Gets or sets if the particle size is in meters or pixels. `true` to size particles in meters; otherwise, the size is in pixels.

Default Value: `false` 

#### [](#startColor) startColor : [Color](Color.html) 

[engine/Source/Scene/ParticleSystem.js 262](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L262) 

 The color of the particle at the beginning of its life.

Default Value: `Color.WHITE` 

#### [](#startScale) startScale : number 

[engine/Source/Scene/ParticleSystem.js 296](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L296) 

 The initial scale to apply to the image of the particle at the beginning of its life.

Default Value: `1.0` 

#### [](#updateCallback) updateCallback : [ParticleSystem.updateCallback](ParticleSystem.html#.updateCallback) 

[engine/Source/Scene/ParticleSystem.js 73](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L73) 

 An array of force callbacks. The callback is passed a [Particle](Particle.html) and the difference from the last time

Default Value: `undefined` 

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/ParticleSystem.js 892](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L892) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### See:

* [ParticleSystem#isDestroyed](ParticleSystem.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/ParticleSystem.js 876](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L876) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [ParticleSystem#destroy](ParticleSystem.html#destroy)

### Type Definitions

#### [](#.updateCallback) Cesium.ParticleSystem.updateCallback(particle, dt) 

[engine/Source/Scene/ParticleSystem.js 898](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ParticleSystem.js#L898) 

 A function used to modify attributes of the particle at each time step. This can include force modifications, color, sizing, etc.

| Name     | Type                      | Description                                |
| -------- | ------------------------- | ------------------------------------------ |
| particle | [Particle](Particle.html) | The particle being updated.                |
| dt       | number                    | The time in seconds since the last update. |

##### Example:

```javascript
function applyGravity(particle, dt) {
   const position = particle.position;
   const gravityVector = Cesium.Cartesian3.normalize(position, new Cesium.Cartesian3());
   Cesium.Cartesian3.multiplyByScalar(gravityVector, GRAVITATIONAL_CONSTANT * dt, gravityVector);
   particle.velocity = Cesium.Cartesian3.add(particle.velocity, gravityVector, particle.velocity);
}
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

