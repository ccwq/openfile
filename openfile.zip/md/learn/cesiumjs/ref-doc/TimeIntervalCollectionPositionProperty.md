# [![](Images/CesiumLogo.png)](index.html) TimeIntervalCollectionPositionProperty 

#### [](#TimeIntervalCollectionPositionProperty) new Cesium.TimeIntervalCollectionPositionProperty(referenceFrame) 

[engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js 19](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js#L19) 

 A [TimeIntervalCollectionProperty](TimeIntervalCollectionProperty.html) which is also a [PositionProperty](PositionProperty.html).

| Name           | Type                                         | Default              | Description                                                    |
| -------------- | -------------------------------------------- | -------------------- | -------------------------------------------------------------- |
| referenceFrame | [ReferenceFrame](global.html#ReferenceFrame) | ReferenceFrame.FIXED | optional The reference frame in which the position is defined. |

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js 52](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js#L52) 

 Gets the event that is raised whenever the definition of this property changes. The definition is considered to have changed if a call to getValue would return a different result for the same time.

#### [](#intervals) readonly intervals : [TimeIntervalCollection](TimeIntervalCollection.html) 

[engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js 63](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js#L63) 

 Gets the interval collection.

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js 38](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js#L38) 

 Gets a value indicating if this property is constant. A property is considered constant if getValue always returns the same result for the current definition.

#### [](#referenceFrame) readonly referenceFrame : [ReferenceFrame](global.html#ReferenceFrame) 

[engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js 75](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js#L75) 

 Gets the reference frame in which the position is defined.

Default Value: `ReferenceFrame.FIXED;` 

### Methods

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js 140](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js#L140) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getValue) getValue(time, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js 91](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js#L91) 

 Gets the value of the property at the provided time in the fixed frame.

| Name   | Type                          | Default          | Description                                                                                      |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | object                        |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

#### [](#getValueInReferenceFrame) getValueInReferenceFrame(time, referenceFrame, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/TimeIntervalCollectionPositionProperty.js#L109) 

 Gets the value of the property at the provided time and in the provided reference frame.

| Name           | Type                                         | Description                                                                                      |
| -------------- | -------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| time           | [JulianDate](JulianDate.html)                | The time for which to retrieve the value.                                                        |
| referenceFrame | [ReferenceFrame](global.html#ReferenceFrame) | The desired referenceFrame of the result.                                                        |
| result         | [Cartesian3](Cartesian3.html)                | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

