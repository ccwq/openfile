# [![](Images/CesiumLogo.png)](index.html) Atmosphere 

#### [](#Atmosphere) new Cesium.Atmosphere() 

[engine/Source/Scene/Atmosphere.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L39) 

 Common atmosphere settings used by 3D Tiles and models for rendering sky atmosphere, ground atmosphere, and fog.

This class is not to be confused with [SkyAtmosphere](SkyAtmosphere.html), which is responsible for rendering the sky.

While the atmosphere settings affect the color of fog, see [Fog](Fog.html) to control how fog is rendered.

##### Examples:

```javascript
// Turn on dynamic atmosphere lighting using the sun direction
scene.atmosphere.dynamicLighting = Cesium.DynamicAtmosphereLightingType.SUNLIGHT;
```

```javascript
// Turn on dynamic lighting using whatever light source is in the scene
scene.light = new Cesium.DirectionalLight({
  direction: new Cesium.Cartesian3(1, 0, 0)
});
scene.atmosphere.dynamicLighting = Cesium.DynamicAtmosphereLightingType.SCENE_LIGHT;
```

```javascript
// Adjust the color of the atmosphere effects.
scene.atmosphere.hueShift = 0.4; // Cycle 40% around the color wheel
scene.atmosphere.brightnessShift = 0.25; // Increase the brightness
scene.atmosphere.saturationShift = -0.1; // Desaturate the colors
```

##### See:

* [SkyAtmosphere](SkyAtmosphere.html)
* [Globe](Globe.html)
* [Fog](Fog.html)

### Members

#### [](#brightnessShift) brightnessShift : number 

[engine/Source/Scene/Atmosphere.js 116](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L116) 

 The brightness shift to apply to the atmosphere. Defaults to 0.0 (no shift). A brightness shift of -1.0 is complete darkness, which will let space show through.

Default Value: `0.0` 

#### [](#dynamicLighting) dynamicLighting : [DynamicAtmosphereLightingType](global.html#DynamicAtmosphereLightingType) 

[engine/Source/Scene/Atmosphere.js 125](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L125) 

 When not DynamicAtmosphereLightingType.NONE, the selected light source will be used for dynamically lighting all atmosphere-related rendering effects.

Default Value: `DynamicAtmosphereLightingType.NONE` 

#### [](#hueShift) hueShift : number 

[engine/Source/Scene/Atmosphere.js 98](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L98) 

 The hue shift to apply to the atmosphere. Defaults to 0.0 (no shift). A hue shift of 1.0 indicates a complete rotation of the hues available.

Default Value: `0.0` 

#### [](#lightIntensity) lightIntensity : number 

[engine/Source/Scene/Atmosphere.js 46](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L46) 

 The intensity of the light that is used for computing the ground atmosphere color.

Default Value: `10.0` 

#### [](#mieAnisotropy) mieAnisotropy : number 

[engine/Source/Scene/Atmosphere.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L89) 

 The anisotropy of the medium to consider for Mie scattering.

Valid values are between -1.0 and 1.0.

Default Value: `0.9` 

#### [](#mieCoefficient) mieCoefficient : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Atmosphere.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L62) 

 The Mie scattering coefficient used in the atmospheric scattering equations for the ground atmosphere.

Default Value: `Cartesian3(21e-6, 21e-6, 21e-6)` 

#### [](#mieScaleHeight) mieScaleHeight : number 

[engine/Source/Scene/Atmosphere.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L78) 

 The Mie scale height used in the atmospheric scattering equations for the ground atmosphere, in meters.

Default Value: `3200.0` 

#### [](#rayleighCoefficient) rayleighCoefficient : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Atmosphere.js 54](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L54) 

 The Rayleigh scattering coefficient used in the atmospheric scattering equations for the ground atmosphere.

Default Value: `Cartesian3(5.5e-6, 13.0e-6, 28.4e-6)` 

#### [](#rayleighScaleHeight) rayleighScaleHeight : number 

[engine/Source/Scene/Atmosphere.js 70](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L70) 

 The Rayleigh scale height used in the atmospheric scattering equations for the ground atmosphere, in meters.

Default Value: `10000.0` 

#### [](#saturationShift) saturationShift : number 

[engine/Source/Scene/Atmosphere.js 107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L107) 

 The saturation shift to apply to the atmosphere. Defaults to 0.0 (no shift). A saturation shift of -1.0 is monochrome.

Default Value: `0.0` 

### Methods

#### [](#.requiresColorCorrect) static Cesium.Atmosphere.requiresColorCorrect(atmosphere) → boolean 

[engine/Source/Scene/Atmosphere.js 133](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Atmosphere.js#L133) 

 Returns `true` if the atmosphere shader requires a color correct step.

| Name       | Type                          | Description                      |
| ---------- | ----------------------------- | -------------------------------- |
| atmosphere | [Atmosphere](Atmosphere.html) | The atmosphere instance to check |

##### Returns:

 true if the atmosphere shader requires a color correct step

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

