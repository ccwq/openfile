# [![](Images/CesiumLogo.png)](index.html) DebugModelMatrixPrimitive 

#### [](#DebugModelMatrixPrimitive) new Cesium.DebugModelMatrixPrimitive(options) 

[engine/Source/Scene/DebugModelMatrixPrimitive.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugModelMatrixPrimitive.js#L41) 

 Draws the axes of a reference frame defined by a matrix that transforms to world coordinates, i.e., Earth's WGS84 coordinates. The most prominent example is a primitives `modelMatrix`.

The X axis is red; Y is green; and Z is blue.

This is for debugging only; it is not optimized for production use.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description length number 10000000.0 optional The length of the axes in meters. width number 2.0 optional The width of the axes in pixels. modelMatrix [Matrix4](Matrix4.html) Matrix4.IDENTITY optional The 4x4 matrix that defines the reference frame, i.e., origin plus axes, to visualize. show boolean true optional Determines if this primitive will be shown. id object optional A user-defined object to return when the instance is picked with [Scene#pick](Scene.html#pick) |

##### Example:

```javascript
primitives.add(new Cesium.DebugModelMatrixPrimitive({
  modelMatrix : primitive.modelMatrix,  // primitive to debug
  length : 100000.0,
  width : 10.0
}));
```

### Members

#### [](#id) id : \* 

[engine/Source/Scene/DebugModelMatrixPrimitive.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugModelMatrixPrimitive.js#L89) 

 User-defined value returned when the primitive is picked.

Default Value: `undefined` 

##### See:

* [Scene#pick](Scene.html#pick)

#### [](#length) length : number 

[engine/Source/Scene/DebugModelMatrixPrimitive.js 50](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugModelMatrixPrimitive.js#L50) 

 The length of the axes in meters.

Default Value: `10000000.0` 

#### [](#modelMatrix) modelMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/DebugModelMatrixPrimitive.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugModelMatrixPrimitive.js#L76) 

 The 4x4 matrix that defines the reference frame, i.e., origin plus axes, to visualize.

Default Value: `[Matrix4.IDENTITY](Matrix4.html#.IDENTITY)` 

#### [](#show) show : boolean 

[engine/Source/Scene/DebugModelMatrixPrimitive.js 68](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugModelMatrixPrimitive.js#L68) 

 Determines if this primitive will be shown.

Default Value: `true` 

#### [](#width) width : number 

[engine/Source/Scene/DebugModelMatrixPrimitive.js 59](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugModelMatrixPrimitive.js#L59) 

 The width of the axes in pixels.

Default Value: `2.0` 

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/DebugModelMatrixPrimitive.js 218](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugModelMatrixPrimitive.js#L218) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.

Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
p = p && p.destroy();
```

##### See:

* [DebugModelMatrixPrimitive#isDestroyed](DebugModelMatrixPrimitive.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/DebugModelMatrixPrimitive.js 198](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugModelMatrixPrimitive.js#L198) 

 Returns true if this object was destroyed; otherwise, false.

If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [DebugModelMatrixPrimitive#destroy](DebugModelMatrixPrimitive.html#destroy)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

