# [![](Images/CesiumLogo.png)](index.html) PropertyBag 

#### [](#PropertyBag) new Cesium.PropertyBag(value, createPropertyCallback) 

[engine/Source/DataSources/PropertyBag.js 20](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PropertyBag.js#L20) 

 A [Property](Property.html) whose value is a key-value mapping of property names to the computed value of other properties.

| Name                   | Type     | Description                                                                                                  |
| ---------------------- | -------- | ------------------------------------------------------------------------------------------------------------ |
| value                  | object   | optional An object, containing key-value mapping of property names to properties.                            |
| createPropertyCallback | function | optional A function that will be called when the value of any of the properties in value are not a Property. |

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/PropertyBag.js 68](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PropertyBag.js#L68) 

 Gets the event that is raised whenever the set of properties contained in this object changes, or one of the properties itself changes.

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/PropertyBag.js 48](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PropertyBag.js#L48) 

 Gets a value indicating if this property is constant. This property is considered constant if all property items in this object are constant.

#### [](#propertyNames) propertyNames : Array 

[engine/Source/DataSources/PropertyBag.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PropertyBag.js#L35) 

 Gets the names of all properties registered on this instance.

### Methods

#### [](#addProperty) addProperty(propertyName, value, createPropertyCallback) 

[engine/Source/DataSources/PropertyBag.js 99](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PropertyBag.js#L99) 

 Adds a property to this object.

| Name                   | Type     | Description                                                                                                           |
| ---------------------- | -------- | --------------------------------------------------------------------------------------------------------------------- |
| propertyName           | string   | The name of the property to add.                                                                                      |
| value                  | \*       | optional The value of the new property, if provided.                                                                  |
| createPropertyCallback | function | optional A function that will be called when the value of this new property is set to a value that is not a Property. |

##### Throws:

* [DeveloperError](DeveloperError.html): "propertyName" is already a registered property.

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/PropertyBag.js 269](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PropertyBag.js#L269) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getValue) getValue(time, result) → object 

[engine/Source/DataSources/PropertyBag.js 172](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PropertyBag.js#L172) 

 Gets the value of this property. Each contained property will be evaluated at the given time, and the overall result will be an object, mapping property names to those values.

| Name   | Type                          | Default          | Description                                                                                                                                                                                    |
| ------ | ----------------------------- | ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.                                                                                                |
| result | object                        |                  | optional The object to store the value into, if omitted, a new instance is created and returned. Note that any properties in result which are not part of this PropertyBag will be left as-is. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

#### [](#hasProperty) hasProperty(propertyName) → boolean 

[engine/Source/DataSources/PropertyBag.js 82](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PropertyBag.js#L82) 

 Determines if this object has defined a property with the given name.

| Name         | Type   | Description                            |
| ------------ | ------ | -------------------------------------- |
| propertyName | string | The name of the property to check for. |

##### Returns:

 True if this object has defined a property with the given name, false otherwise.

#### [](#merge) merge(source, createPropertyCallback) 

[engine/Source/DataSources/PropertyBag.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PropertyBag.js#L200) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name                   | Type     | Description                                                                                                  |
| ---------------------- | -------- | ------------------------------------------------------------------------------------------------------------ |
| source                 | object   | The object to be merged into this object.                                                                    |
| createPropertyCallback | function | optional A function that will be called when the value of any of the properties in value are not a Property. |

#### [](#removeProperty) removeProperty(propertyName) 

[engine/Source/DataSources/PropertyBag.js 142](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PropertyBag.js#L142) 

 Removed a property previously added with addProperty.

| Name         | Type   | Description                         |
| ------------ | ------ | ----------------------------------- |
| propertyName | string | The name of the property to remove. |

##### Throws:

* [DeveloperError](DeveloperError.html): "propertyName" is not a registered property.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

