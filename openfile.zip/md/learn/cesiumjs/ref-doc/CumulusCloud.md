# [![](Images/CesiumLogo.png)](index.html) CumulusCloud 

#### [](#CumulusCloud) internal constructor new Cesium.CumulusCloud() 

[engine/Source/Scene/CumulusCloud.js 36](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CumulusCloud.js#L36) 

A cloud is created and its initial properties are set by calling [CloudCollection#add](CloudCollection.html#add). and [CloudCollection#remove](CloudCollection.html#remove). Do not call the constructor directly.

A cumulus cloud billboard positioned in the 3D scene, that is created and rendered using a [CloudCollection](CloudCollection.html).  
  
![](Images/CumulusCloud.png)  
Example cumulus clouds

##### Performance:

Similar to [Billboard](Billboard.html), reading a property, e.g., [CumulusCloud#show](CumulusCloud.html#show), takes constant time. Assigning to a property is constant time but results in CPU to GPU traffic when `CloudCollection#update` is called. The per-cloud traffic is the same regardless of how many properties were updated. If most clouds in a collection need to be updated, it may be more efficient to clear the collection with [CloudCollection#removeAll](CloudCollection.html#removeAll)and add new clouds instead of modifying each one.

##### Demo:

* [Cesium Sandcastle Cloud Parameters Demo](https://sandcastle.cesium.com/index.html?src=Cloud%2520Parameters.html)

##### See:

* [CloudCollection](CloudCollection.html)
* [CloudCollection#add](CloudCollection.html#add)

### Members

#### [](#brightness) brightness : number 

[engine/Source/Scene/CumulusCloud.js 331](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CumulusCloud.js#L331) 

 Gets or sets the brightness of the cloud. This can be used to give clouds a darker, grayer appearance.  
  
| cloud.brightness = 1.0;![](Images/CumulusCloud.brightness1.png) | cloud.brightness = 0.6;![](Images/CumulusCloud.brightness0.6.png) | cloud.brightness = 0.0;![](Images/CumulusCloud.brightness0.png) |
| --------------------------------------------------------------- | ----------------------------------------------------------------- | --------------------------------------------------------------- |

Default Value: `1.0` 

#### [](#color) color : [Color](Color.html) 

[engine/Source/Scene/CumulusCloud.js 235](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CumulusCloud.js#L235) 

 Sets the color of the cloud

Default Value: `Color.WHITE` 

#### [](#maximumSize) maximumSize : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/CumulusCloud.js 213](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CumulusCloud.js#L213) 

Gets or sets the maximum size of the cumulus cloud rendered on the billboard. This defines a maximum ellipsoid volume that the cloud can appear in. Rather than guaranteeing a specific size, this specifies a boundary for the cloud to appear in, and changing it can affect the shape of the cloud.

Changing the z-value of `maximumSize` has the most dramatic effect on the cloud's appearance because it changes the depth of the cloud, and thus the positions at which the cloud-shaping texture is sampled.

| cloud.maximumSize = new Cesium.Cartesian3(14, 9, 10); ![](Images/CumulusCloud.maximumSizex14y9z10.png) | cloud.maximumSize.x = 25; ![](Images/CumulusCloud.maximumSizex25.png) |
| ------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------- |
| cloud.maximumSize.y = 5; ![](Images/CumulusCloud.maximumSizey5.png)                                    | cloud.maximumSize.z = 17; ![](Images/CumulusCloud.maximumSizez17.png) |

To modify the billboard's actual size, modify the cloud's `scale` property.

##### See:

* [CumulusCloud#scale](CumulusCloud.html#scale)

#### [](#position) position : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/CumulusCloud.js 115](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CumulusCloud.js#L115) 

 Gets or sets the Cartesian position of this cumulus cloud.

#### [](#scale) scale : [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/CumulusCloud.js 157](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CumulusCloud.js#L157) 

Gets or sets the scale of the cumulus cloud billboard in meters. The `scale` property will affect the size of the billboard, but not the cloud's actual appearance.

| cloud.scale = new Cesium.Cartesian2(12, 8); ![](Images/CumulusCloud.scalex12y8.png) | cloud.scale = new Cesium.Cartesian2(24, 10); ![](Images/CumulusCloud.scalex24y10.png) |
| ----------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------- |

To modify the cloud's appearance, modify its `maximumSize`and `slice` properties.

##### See:

* [CumulusCloud#maximumSize](CumulusCloud.html#maximumSize)
* [CumulusCloud#slice](CumulusCloud.html#slice)

#### [](#show) show : boolean 

[engine/Source/Scene/CumulusCloud.js 94](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CumulusCloud.js#L94) 

 Determines if this cumulus cloud will be shown. Use this to hide or show a cloud, instead of removing it and re-adding it to the collection.

Default Value: `true` 

#### [](#slice) slice : number 

[engine/Source/Scene/CumulusCloud.js 299](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CumulusCloud.js#L299) 

Gets or sets the "slice" of the cloud that is rendered on the billboard, i.e. the specific cross-section of the cloud chosen for the billboard's appearance. Given a value between 0 and 1, the slice specifies how deeply into the cloud to intersect based on its maximum size in the z-direction.

| cloud.slice = 0.32;![](Images/CumulusCloud.slice0.32.png) | cloud.slice = 0.5;![](Images/CumulusCloud.slice0.5.png) | cloud.slice = 0.6;![](Images/CumulusCloud.slice0.6.png) |
| --------------------------------------------------------- | ------------------------------------------------------- | ------------------------------------------------------- |

  
Due to the nature in which this slice is calculated, values below `0.2` may result in cross-sections that are too small, and the edge of the ellipsoid will be visible. Similarly, values above `0.7`will cause the cloud to appear smaller. Values outside the range `[0.1, 0.9]`should be avoided entirely because they do not produce desirable results.

| cloud.slice = 0.08;![](Images/CumulusCloud.slice0.08.png) | cloud.slice = 0.8;![](Images/CumulusCloud.slice0.8.png) |
| --------------------------------------------------------- | ------------------------------------------------------- |

If `slice` is set to a negative number, the cloud will not render a cross-section. Instead, it will render the outside of the ellipsoid that is visible. For clouds with small values of \`maximumSize.z\`, this can produce good-looking results, but for larger clouds, this can result in a cloud that is undesirably warped to the ellipsoid volume.

| cloud.slice = -1.0;cloud.maximumSize.z = 18; ![](Images/CumulusCloud.slice-1z18.png) | cloud.slice = -1.0;cloud.maximumSize.z = 30; ![](Images/CumulusCloud.slice-1z30.png) |
| ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ |

Default Value: `-1.0` 

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

