# [![](Images/CesiumLogo.png)](index.html) ColorGeometryInstanceAttribute 

#### [](#ColorGeometryInstanceAttribute) new Cesium.ColorGeometryInstanceAttribute(red, green, blue, alpha) 

[engine/Source/Core/ColorGeometryInstanceAttribute.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ColorGeometryInstanceAttribute.js#L35) 

 Value and type information for per-instance geometry color.

| Name  | Type   | Default | Description                   |
| ----- | ------ | ------- | ----------------------------- |
| red   | number | 1.0     | optional The red component.   |
| green | number | 1.0     | optional The green component. |
| blue  | number | 1.0     | optional The blue component.  |
| alpha | number | 1.0     | optional The alpha component. |

##### Example:

```javascript
const instance = new Cesium.GeometryInstance({
  geometry : Cesium.BoxGeometry.fromDimensions({
    dimensions : new Cesium.Cartesian3(1000000.0, 1000000.0, 500000.0)
  }),
  modelMatrix : Cesium.Matrix4.multiplyByTranslation(Cesium.Transforms.eastNorthUpToFixedFrame(
    Cesium.Cartesian3.fromDegrees(0.0, 0.0)), new Cesium.Cartesian3(0.0, 0.0, 1000000.0), new Cesium.Matrix4()),
  id : 'box',
  attributes : {
    color : new Cesium.ColorGeometryInstanceAttribute(red, green, blue, alpha)
  }
});
```

##### See:

* [GeometryInstance](GeometryInstance.html)
* [GeometryInstanceAttribute](GeometryInstanceAttribute.html)

### Members

#### [](#componentDatatype) readonly componentDatatype : [ComponentDatatype](global.html#ComponentDatatype) 

[engine/Source/Core/ColorGeometryInstanceAttribute.js 68](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ColorGeometryInstanceAttribute.js#L68) 

 The datatype of each component in the attribute, e.g., individual elements in[ColorGeometryInstanceAttribute#value](ColorGeometryInstanceAttribute.html#value).

Default Value: `[ComponentDatatype.UNSIGNED_BYTE](global.html#ComponentDatatype#.UNSIGNED%5FBYTE)` 

#### [](#componentsPerAttribute) readonly componentsPerAttribute : number 

[engine/Source/Core/ColorGeometryInstanceAttribute.js 84](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ColorGeometryInstanceAttribute.js#L84) 

 The number of components in the attributes, i.e., [ColorGeometryInstanceAttribute#value](ColorGeometryInstanceAttribute.html#value).

Default Value: `4` 

#### [](#normalize) readonly normalize : boolean 

[engine/Source/Core/ColorGeometryInstanceAttribute.js 102](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ColorGeometryInstanceAttribute.js#L102) 

 When `true` and `componentDatatype` is an integer format, indicate that the components should be mapped to the range \[0, 1\] (unsigned) or \[-1, 1\] (signed) when they are accessed as floating-point for rendering.

Default Value: `true` 

#### [](#value) value : Uint8Array 

[engine/Source/Core/ColorGeometryInstanceAttribute.js 48](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ColorGeometryInstanceAttribute.js#L48) 

 The values for the attributes stored in a typed array.

Default Value: `[255, 255, 255, 255]` 

### Methods

#### [](#.equals) static Cesium.ColorGeometryInstanceAttribute.equals(left, right) → boolean 

[engine/Source/Core/ColorGeometryInstanceAttribute.js 171](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ColorGeometryInstanceAttribute.js#L171) 

 Compares the provided ColorGeometryInstanceAttributes and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                                                  | Description                                         |
| ----- | --------------------------------------------------------------------- | --------------------------------------------------- |
| left  | [ColorGeometryInstanceAttribute](ColorGeometryInstanceAttribute.html) | optional The first ColorGeometryInstanceAttribute.  |
| right | [ColorGeometryInstanceAttribute](ColorGeometryInstanceAttribute.html) | optional The second ColorGeometryInstanceAttribute. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.fromColor) static Cesium.ColorGeometryInstanceAttribute.fromColor(color) → [ColorGeometryInstanceAttribute](ColorGeometryInstanceAttribute.html) 

[engine/Source/Core/ColorGeometryInstanceAttribute.js 123](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ColorGeometryInstanceAttribute.js#L123) 

 Creates a new [ColorGeometryInstanceAttribute](ColorGeometryInstanceAttribute.html) instance given the provided [Color](Color.html).

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| color | [Color](Color.html) | The color.  |

##### Returns:

 The new [ColorGeometryInstanceAttribute](ColorGeometryInstanceAttribute.html) instance.

##### Example:

```javascript
const instance = new Cesium.GeometryInstance({
  geometry : geometry,
  attributes : {
    color : Cesium.ColorGeometryInstanceAttribute.fromColor(Cesium.Color.CORNFLOWERBLUE),
  }
});
```

#### [](#.toValue) static Cesium.ColorGeometryInstanceAttribute.toValue(color, result) → Uint8Array 

[engine/Source/Core/ColorGeometryInstanceAttribute.js 150](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ColorGeometryInstanceAttribute.js#L150) 

 Converts a color to a typed array that can be used to assign a color attribute.

| Name   | Type                | Description                                                                             |
| ------ | ------------------- | --------------------------------------------------------------------------------------- |
| color  | [Color](Color.html) | The color.                                                                              |
| result | Uint8Array          | optional The array to store the result in, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter or a new instance if result was undefined.

##### Example:

```javascript
const attributes = primitive.getGeometryInstanceAttributes('an id');
attributes.color = Cesium.ColorGeometryInstanceAttribute.toValue(Cesium.Color.AQUA, attributes.color);
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

