# [![](Images/CesiumLogo.png)](index.html) GroundPolylineGeometry 

#### [](#GroundPolylineGeometry) new Cesium.GroundPolylineGeometry(options) 

[engine/Source/Core/GroundPolylineGeometry.js 74](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GroundPolylineGeometry.js#L74) 

 A description of a polyline on terrain or 3D Tiles. Only to be used with [GroundPolylinePrimitive](GroundPolylinePrimitive.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Options with the following properties: Name Type Default Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of [Cartesian3](Cartesian3.html) defining the polyline's points. Heights above the ellipsoid will be ignored. width number 1.0 optional The screen space width in pixels. granularity number 9999.0 optional The distance interval in meters used for interpolating options.points. Defaults to 9999.0 meters. Zero indicates no interpolation. loop boolean false optional Whether during geometry creation a line segment will be added between the last and first line positions to make this Polyline a loop. arcType [ArcType](global.html#ArcType) ArcType.GEODESIC optional The type of line the polyline segments must follow. Valid options are [ArcType.GEODESIC](global.html#ArcType#.GEODESIC) and [ArcType.RHUMB](global.html#ArcType#.RHUMB). |

##### Throws:

* [DeveloperError](DeveloperError.html): At least two positions are required.

##### Example:

```javascript
const positions = Cesium.Cartesian3.fromDegreesArray([
  -112.1340164450331, 36.05494287836128,
  -112.08821010582645, 36.097804071380715,
  -112.13296079730024, 36.168769146801104
]);

const geometry = new Cesium.GroundPolylineGeometry({
  positions : positions
});
```

##### See:

* [GroundPolylinePrimitive](GroundPolylinePrimitive.html)

### Members

#### [](#arcType) arcType : [ArcType](global.html#ArcType) 

[engine/Source/Core/GroundPolylineGeometry.js 122](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GroundPolylineGeometry.js#L122) 

 The type of path the polyline must follow. Valid options are [ArcType.GEODESIC](global.html#ArcType#.GEODESIC) and [ArcType.RHUMB](global.html#ArcType#.RHUMB).

Default Value: `ArcType.GEODESIC` 

#### [](#granularity) granularity : boolean 

[engine/Source/Core/GroundPolylineGeometry.js 107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GroundPolylineGeometry.js#L107) 

 The distance interval used for interpolating options.points. Zero indicates no interpolation. Default of 9999.0 allows centimeter accuracy with 32 bit floating point.

Default Value: `9999.0` 

#### [](#loop) loop : boolean 

[engine/Source/Core/GroundPolylineGeometry.js 115](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GroundPolylineGeometry.js#L115) 

 Whether during geometry creation a line segment will be added between the last and first line positions to make this Polyline a loop. If the geometry has two positions this parameter will be ignored.

Default Value: `false` 

#### [](#width) width : number 

[engine/Source/Core/GroundPolylineGeometry.js 97](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GroundPolylineGeometry.js#L97) 

 The screen space width in pixels.

### Methods

#### [](#.pack) static Cesium.GroundPolylineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/GroundPolylineGeometry.js 294](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GroundPolylineGeometry.js#L294) 

 Stores the provided instance into the provided array.

| Name          | Type                                    | Default | Description                                                               |
| ------------- | --------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [PolygonGeometry](PolygonGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                          |         | The array to pack into.                                                   |
| startingIndex | number                                  | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.GroundPolylineGeometry.unpack(array, startingIndex, result) 

[engine/Source/Core/GroundPolylineGeometry.js 333](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GroundPolylineGeometry.js#L333) 

 Retrieves an instance from a packed array.

| Name          | Type                                    | Default | Description                                                |
| ------------- | --------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                          |         | The packed array.                                          |
| startingIndex | number                                  | 0       | optional The starting index of the element to be unpacked. |
| result        | [PolygonGeometry](PolygonGeometry.html) |         | optional The object into which to store the result.        |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

