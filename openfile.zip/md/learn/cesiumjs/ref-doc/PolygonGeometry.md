# [![](Images/CesiumLogo.png)](index.html) PolygonGeometry 

#### [](#PolygonGeometry) new Cesium.PolygonGeometry(options) 

[engine/Source/Core/PolygonGeometry.js 668](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolygonGeometry.js#L668) 

 A description of a polygon on the ellipsoid. The polygon is defined by a polygon hierarchy. Polygon geometry can be rendered with both [Primitive](Primitive.html) and [GroundPrimitive](GroundPrimitive.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description polygonHierarchy [PolygonHierarchy](PolygonHierarchy.html)  A polygon hierarchy that can include holes. height number 0.0 optional The distance in meters between the polygon and the ellipsoid surface. extrudedHeight number optional The distance in meters between the polygon's extruded face and the ellipsoid surface. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. stRotation number 0.0 optional The rotation of the texture coordinates, in radians. A positive rotation is counter-clockwise. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid to be used as a reference. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The distance, in radians, between each latitude and longitude. Determines the number of positions in the buffer. perPositionHeight boolean false optional Use the height of options.positions for each position instead of using options.height to determine the height. closeTop boolean true optional When false, leaves off the top of an extruded polygon open. closeBottom boolean true optional When false, leaves off the bottom of an extruded polygon open. arcType [ArcType](global.html#ArcType) ArcType.GEODESIC optional The type of line the polygon edges must follow. Valid options are [ArcType.GEODESIC](global.html#ArcType#.GEODESIC) and [ArcType.RHUMB](global.html#ArcType#.RHUMB). textureCoordinates [PolygonHierarchy](PolygonHierarchy.html) optional Texture coordinates as a [PolygonHierarchy](PolygonHierarchy.html) of [Cartesian2](Cartesian2.html) points. Has no effect for ground primitives. |

##### Example:

```javascript
// 1. create a polygon from points
const polygon = new Cesium.PolygonGeometry({
  polygonHierarchy : new Cesium.PolygonHierarchy(
    Cesium.Cartesian3.fromDegreesArray([
      -72.0, 40.0,
      -70.0, 35.0,
      -75.0, 30.0,
      -70.0, 30.0,
      -68.0, 40.0
    ])
  )
});
const geometry = Cesium.PolygonGeometry.createGeometry(polygon);

// 2. create a nested polygon with holes
const polygonWithHole = new Cesium.PolygonGeometry({
  polygonHierarchy : new Cesium.PolygonHierarchy(
    Cesium.Cartesian3.fromDegreesArray([
      -109.0, 30.0,
      -95.0, 30.0,
      -95.0, 40.0,
      -109.0, 40.0
    ]),
    [new Cesium.PolygonHierarchy(
      Cesium.Cartesian3.fromDegreesArray([
        -107.0, 31.0,
        -107.0, 39.0,
        -97.0, 39.0,
        -97.0, 31.0
      ]),
      [new Cesium.PolygonHierarchy(
        Cesium.Cartesian3.fromDegreesArray([
          -105.0, 33.0,
          -99.0, 33.0,
          -99.0, 37.0,
          -105.0, 37.0
        ]),
        [new Cesium.PolygonHierarchy(
          Cesium.Cartesian3.fromDegreesArray([
            -103.0, 34.0,
            -101.0, 34.0,
            -101.0, 36.0,
            -103.0, 36.0
          ])
        )]
      )]
    )]
  )
});
const geometry = Cesium.PolygonGeometry.createGeometry(polygonWithHole);

// 3. create extruded polygon
const extrudedPolygon = new Cesium.PolygonGeometry({
  polygonHierarchy : new Cesium.PolygonHierarchy(
    Cesium.Cartesian3.fromDegreesArray([
      -72.0, 40.0,
      -70.0, 35.0,
      -75.0, 30.0,
      -70.0, 30.0,
      -68.0, 40.0
    ])
  ),
  extrudedHeight: 300000
});
const geometry = Cesium.PolygonGeometry.createGeometry(extrudedPolygon);
```

##### Demo:

* [Cesium Sandcastle Polygon Demo](https://sandcastle.cesium.com/index.html?src=Polygon.html)

##### See:

* PolygonGeometry#createGeometry
* PolygonGeometry#fromPositions

### Members

#### [](#packedLength) packedLength : number 

[engine/Source/Core/PolygonGeometry.js 737](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolygonGeometry.js#L737) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.computeRectangleFromPositions) static Cesium.PolygonGeometry.computeRectangleFromPositions(positions, ellipsoid, arcType, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/PolygonGeometry.js 1049](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolygonGeometry.js#L1049) 

 Computes a rectangle which encloses the polygon defined by the list of positions, including cases over the international date line and the poles.

| Name      | Type                                   | Default           | Description                                                                                                                                                                   |
| --------- | -------------------------------------- | ----------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| positions | Array.<[Cartesian3](Cartesian3.html)\> |                   | A linear ring defining the outer boundary of the polygon.                                                                                                                     |
| ellipsoid | [Ellipsoid](Ellipsoid.html)            | Ellipsoid.default | optional The ellipsoid to be used as a reference.                                                                                                                             |
| arcType   | [ArcType](global.html#ArcType)         | ArcType.GEODESIC  | optional The type of line the polygon edges must follow. Valid options are [ArcType.GEODESIC](global.html#ArcType#.GEODESIC) and [ArcType.RHUMB](global.html#ArcType#.RHUMB). |
| result    | [Rectangle](Rectangle.html)            |                   | optional An object in which to store the result.                                                                                                                              |

##### Returns:

 The result rectangle

#### [](#.createGeometry) static Cesium.PolygonGeometry.createGeometry(polygonGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/PolygonGeometry.js 1278](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolygonGeometry.js#L1278) 

 Computes the geometric representation of a polygon, including its vertices, indices, and a bounding sphere.

| Name            | Type                                    | Description                   |
| --------------- | --------------------------------------- | ----------------------------- |
| polygonGeometry | [PolygonGeometry](PolygonGeometry.html) | A description of the polygon. |

##### Returns:

 The computed vertices and indices.

#### [](#.fromPositions) static Cesium.PolygonGeometry.fromPositions(options) → [PolygonGeometry](PolygonGeometry.html) 

[engine/Source/Core/PolygonGeometry.js 786](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolygonGeometry.js#L786) 

 A description of a polygon from an array of positions. Polygon geometry can be rendered with both [Primitive](Primitive.html) and [GroundPrimitive](GroundPrimitive.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of positions that defined the corner points of the polygon. height number 0.0 optional The height of the polygon. extrudedHeight number optional The height of the polygon extrusion. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. stRotation number 0.0 optional The rotation of the texture coordinates, in radians. A positive rotation is counter-clockwise. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid to be used as a reference. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The distance, in radians, between each latitude and longitude. Determines the number of positions in the buffer. perPositionHeight boolean false optional Use the height of options.positions for each position instead of using options.height to determine the height. closeTop boolean true optional When false, leaves off the top of an extruded polygon open. closeBottom boolean true optional When false, leaves off the bottom of an extruded polygon open. arcType [ArcType](global.html#ArcType) ArcType.GEODESIC optional The type of line the polygon edges must follow. Valid options are [ArcType.GEODESIC](global.html#ArcType#.GEODESIC) and [ArcType.RHUMB](global.html#ArcType#.RHUMB). textureCoordinates [PolygonHierarchy](PolygonHierarchy.html) optional Texture coordinates as a [PolygonHierarchy](PolygonHierarchy.html) of [Cartesian2](Cartesian2.html) points. Has no effect for ground primitives. |

##### Returns:

##### Example:

```javascript
// create a polygon from points
const polygon = Cesium.PolygonGeometry.fromPositions({
  positions : Cesium.Cartesian3.fromDegreesArray([
    -72.0, 40.0,
    -70.0, 35.0,
    -75.0, 30.0,
    -70.0, 30.0,
    -68.0, 40.0
  ])
});
const geometry = Cesium.PolygonGeometry.createGeometry(polygon);
```

##### See:

* PolygonGeometry#createGeometry

#### [](#.pack) static Cesium.PolygonGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/PolygonGeometry.js 822](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolygonGeometry.js#L822) 

 Stores the provided instance into the provided array.

| Name          | Type                                    | Default | Description                                                               |
| ------------- | --------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [PolygonGeometry](PolygonGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                          |         | The array to pack into.                                                   |
| startingIndex | number                                  | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.PolygonGeometry.unpack(array, startingIndex, result) 

[engine/Source/Core/PolygonGeometry.js 883](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolygonGeometry.js#L883) 

 Retrieves an instance from a packed array.

| Name          | Type                                    | Default | Description                                                |
| ------------- | --------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                          |         | The packed array.                                          |
| startingIndex | number                                  | 0       | optional The starting index of the element to be unpacked. |
| result        | [PolygonGeometry](PolygonGeometry.html) |         | optional The object into which to store the result.        |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

