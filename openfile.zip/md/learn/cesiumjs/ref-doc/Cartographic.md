# [![](Images/CesiumLogo.png)](index.html) Cartographic 

#### [](#Cartographic) new Cesium.Cartographic(longitude, latitude, height) 

[engine/Source/Core/Cartographic.js 19](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L19) 

 A position defined by longitude, latitude, and height.

| Name      | Type   | Default | Description                                          |
| --------- | ------ | ------- | ---------------------------------------------------- |
| longitude | number | 0.0     | optional The longitude, in radians.                  |
| latitude  | number | 0.0     | optional The latitude, in radians.                   |
| height    | number | 0.0     | optional The height, in meters, above the ellipsoid. |

##### See:

* [Ellipsoid](Ellipsoid.html)

### Members

#### [](#.ZERO) static constant Cesium.Cartographic.ZERO : [Cartographic](Cartographic.html) 

[engine/Source/Core/Cartographic.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L261) 

 An immutable Cartographic instance initialized to (0.0, 0.0, 0.0).

#### [](#height) height : number 

[engine/Source/Core/Cartographic.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L39) 

 The height, in meters, above the ellipsoid.

Default Value: `0.0` 

#### [](#latitude) latitude : number 

[engine/Source/Core/Cartographic.js 32](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L32) 

 The latitude, in radians.

Default Value: `0.0` 

#### [](#longitude) longitude : number 

[engine/Source/Core/Cartographic.js 25](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L25) 

 The longitude, in radians.

Default Value: `0.0` 

### Methods

#### [](#.clone) static Cesium.Cartographic.clone(cartographic, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/Cartographic.js 196](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L196) 

 Duplicates a Cartographic instance.

| Name         | Type                              | Description                                         |
| ------------ | --------------------------------- | --------------------------------------------------- |
| cartographic | [Cartographic](Cartographic.html) | The cartographic to duplicate.                      |
| result       | [Cartographic](Cartographic.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartographic instance if one was not provided. (Returns undefined if cartographic is undefined)

#### [](#.equals) static Cesium.Cartographic.equals(left, right) → boolean 

[engine/Source/Core/Cartographic.js 221](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L221) 

 Compares the provided cartographics componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                              | Description                       |
| ----- | --------------------------------- | --------------------------------- |
| left  | [Cartographic](Cartographic.html) | optional The first cartographic.  |
| right | [Cartographic](Cartographic.html) | optional The second cartographic. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.equalsEpsilon) static Cesium.Cartographic.equalsEpsilon(left, right, epsilon) → boolean 

[engine/Source/Core/Cartographic.js 242](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L242) 

 Compares the provided cartographics componentwise and returns`true` if they are within the provided epsilon,`false` otherwise.

| Name    | Type                              | Default | Description                                       |
| ------- | --------------------------------- | ------- | ------------------------------------------------- |
| left    | [Cartographic](Cartographic.html) |         | optional The first cartographic.                  |
| right   | [Cartographic](Cartographic.html) |         | optional The second cartographic.                 |
| epsilon | number                            | 0       | optional The epsilon to use for equality testing. |

##### Returns:

`true` if left and right are within the provided epsilon, `false` otherwise.

#### [](#.fromCartesian) static Cesium.Cartographic.fromCartesian(cartesian, ellipsoid, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/Cartographic.js 119](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L119) 

 Creates a new Cartographic instance from a Cartesian position. The values in the resulting object will be in radians.

| Name      | Type                              | Default           | Description                                                       |
| --------- | --------------------------------- | ----------------- | ----------------------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html)     |                   | The Cartesian position to convert to cartographic representation. |
| ellipsoid | [Ellipsoid](Ellipsoid.html)       | Ellipsoid.default | optional The ellipsoid on which the position lies.                |
| result    | [Cartographic](Cartographic.html) |                   | optional The object onto which to store the result.               |

##### Returns:

 The modified result parameter, new Cartographic instance if none was provided, or undefined if the cartesian is at the center of the ellipsoid.

#### [](#.fromDegrees) static Cesium.Cartographic.fromDegrees(longitude, latitude, height, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/Cartographic.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L81) 

 Creates a new Cartographic instance from longitude and latitude specified in degrees. The values in the resulting object will be in radians.

| Name      | Type                              | Default | Description                                          |
| --------- | --------------------------------- | ------- | ---------------------------------------------------- |
| longitude | number                            |         | The longitude, in degrees.                           |
| latitude  | number                            |         | The latitude, in degrees.                            |
| height    | number                            | 0.0     | optional The height, in meters, above the ellipsoid. |
| result    | [Cartographic](Cartographic.html) |         | optional The object onto which to store the result.  |

##### Returns:

 The modified result parameter or a new Cartographic instance if one was not provided.

#### [](#.fromRadians) static Cesium.Cartographic.fromRadians(longitude, latitude, height, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/Cartographic.js 52](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L52) 

 Creates a new Cartographic instance from longitude and latitude specified in radians.

| Name      | Type                              | Default | Description                                          |
| --------- | --------------------------------- | ------- | ---------------------------------------------------- |
| longitude | number                            |         | The longitude, in radians.                           |
| latitude  | number                            |         | The latitude, in radians.                            |
| height    | number                            | 0.0     | optional The height, in meters, above the ellipsoid. |
| result    | [Cartographic](Cartographic.html) |         | optional The object onto which to store the result.  |

##### Returns:

 The modified result parameter or a new Cartographic instance if one was not provided.

#### [](#.toCartesian) static Cesium.Cartographic.toCartesian(cartographic, ellipsoid, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartographic.js 175](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L175) 

 Creates a new Cartesian3 instance from a Cartographic input. The values in the inputted object should be in radians.

| Name         | Type                              | Default           | Description                                         |
| ------------ | --------------------------------- | ----------------- | --------------------------------------------------- |
| cartographic | [Cartographic](Cartographic.html) |                   | Input to be converted into a Cartesian3 output.     |
| ellipsoid    | [Ellipsoid](Ellipsoid.html)       | Ellipsoid.default | optional The ellipsoid on which the position lies.  |
| result       | [Cartesian3](Cartesian3.html)     |                   | optional The object onto which to store the result. |

##### Returns:

 The position

#### [](#clone) clone(result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/Cartographic.js 269](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L269) 

 Duplicates this instance.

| Name   | Type                              | Description                                         |
| ------ | --------------------------------- | --------------------------------------------------- |
| result | [Cartographic](Cartographic.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartographic instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/Cartographic.js 280](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L280) 

 Compares the provided against this cartographic componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                              | Description                       |
| ----- | --------------------------------- | --------------------------------- |
| right | [Cartographic](Cartographic.html) | optional The second cartographic. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(right, epsilon) → boolean 

[engine/Source/Core/Cartographic.js 293](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L293) 

 Compares the provided against this cartographic componentwise and returns`true` if they are within the provided epsilon,`false` otherwise.

| Name    | Type                              | Default | Description                                       |
| ------- | --------------------------------- | ------- | ------------------------------------------------- |
| right   | [Cartographic](Cartographic.html) |         | optional The second cartographic.                 |
| epsilon | number                            | 0       | optional The epsilon to use for equality testing. |

##### Returns:

`true` if left and right are within the provided epsilon, `false` otherwise.

#### [](#toString) toString() → string 

[engine/Source/Core/Cartographic.js 302](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartographic.js#L302) 

 Creates a string representing this cartographic in the format '(longitude, latitude, height)'.

##### Returns:

 A string representing the provided cartographic in the format '(longitude, latitude, height)'.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

