# [![](Images/CesiumLogo.png)](index.html) GroundPolylinePrimitive 

#### [](#GroundPolylinePrimitive) new Cesium.GroundPolylinePrimitive(options) 

[engine/Source/Scene/GroundPolylinePrimitive.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L96) 

 A GroundPolylinePrimitive represents a polyline draped over the terrain or 3D Tiles in the [Scene](Scene.html).

Only to be used with GeometryInstances containing [GroundPolylineGeometry](GroundPolylineGeometry.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | optional Object with the following properties: Name Type Default Description geometryInstances Array\|[GeometryInstance](GeometryInstance.html) optional GeometryInstances containing GroundPolylineGeometry appearance [Appearance](Appearance.html) optional The Appearance used to render the polyline. Defaults to a white color [Material](Material.html) on a [PolylineMaterialAppearance](PolylineMaterialAppearance.html). show boolean true optional Determines if this primitive will be shown. interleave boolean false optional When true, geometry vertex attributes are interleaved, which can slightly improve rendering performance but increases load time. releaseGeometryInstances boolean true optional When true, the primitive does not keep a reference to the input geometryInstances to save memory. allowPicking boolean true optional When true, each geometry instance will only be pickable with [Scene#pick](Scene.html#pick). When false, GPU memory is saved. asynchronous boolean true optional Determines if the primitive will be created asynchronously or block until ready. If false initializeTerrainHeights() must be called first. classificationType [ClassificationType](global.html#ClassificationType) ClassificationType.BOTH optional Determines whether terrain, 3D Tiles or both will be classified. debugShowBoundingVolume boolean false optional For debugging only. Determines if this primitive's commands' bounding spheres are shown. debugShowShadowVolume boolean false optional For debugging only. Determines if the shadow volume for each geometry in the primitive is drawn. Must be true on creation to have effect. |

##### Example:

```javascript
// 1. Draw a polyline on terrain with a basic color material

const instance = new Cesium.GeometryInstance({
  geometry : new Cesium.GroundPolylineGeometry({
     positions : Cesium.Cartesian3.fromDegreesArray([
         -112.1340164450331, 36.05494287836128,
         -112.08821010582645, 36.097804071380715
     ]),
     width : 4.0
  }),
  id : 'object returned when this instance is picked and to get/set per-instance attributes'
});

scene.groundPrimitives.add(new Cesium.GroundPolylinePrimitive({
  geometryInstances : instance,
  appearance : new Cesium.PolylineMaterialAppearance()
}));

// 2. Draw a looped polyline on terrain with per-instance color and a distance display condition.
// Distance display conditions for polylines on terrain are based on an approximate terrain height
// instead of true terrain height.

const instance2 = new Cesium.GeometryInstance({
  geometry : new Cesium.GroundPolylineGeometry({
     positions : Cesium.Cartesian3.fromDegreesArray([
         -112.1340164450331, 36.05494287836128,
         -112.08821010582645, 36.097804071380715,
         -112.13296079730024, 36.168769146801104
     ]),
     loop : true,
     width : 4.0
  }),
  attributes : {
     color : Cesium.ColorGeometryInstanceAttribute.fromColor(Cesium.Color.fromCssColorString('green').withAlpha(0.7)),
     distanceDisplayCondition : new Cesium.DistanceDisplayConditionGeometryInstanceAttribute(1000, 30000)
  },
  id : 'object returned when this instance is picked and to get/set per-instance attributes'
});

scene.groundPrimitives.add(new Cesium.GroundPolylinePrimitive({
  geometryInstances : instance2,
  appearance : new Cesium.PolylineColorAppearance()
}));
```

### Members

#### [](#allowPicking) readonly allowPicking : boolean 

[engine/Source/Scene/GroundPolylinePrimitive.js 260](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L260) 

 When `true`, each geometry instance will only be pickable with [Scene#pick](Scene.html#pick). When `false`, GPU memory is saved.

Default Value: `true` 

#### [](#appearance) appearance : [Appearance](Appearance.html) 

[engine/Source/Scene/GroundPolylinePrimitive.js 129](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L129) 

 The [Appearance](Appearance.html) used to shade this primitive. Each geometry instance is shaded with the same appearance. Some appearances, like[PolylineColorAppearance](PolylineColorAppearance.html) allow giving each instance unique properties.

Default Value: `undefined` 

#### [](#asynchronous) readonly asynchronous : boolean 

[engine/Source/Scene/GroundPolylinePrimitive.js 276](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L276) 

 Determines if the geometry instances will be created and batched on a web worker.

Default Value: `true` 

#### [](#classificationType) classificationType : [ClassificationType](global.html#ClassificationType) 

[engine/Source/Scene/GroundPolylinePrimitive.js 148](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L148) 

 Determines whether terrain, 3D Tiles or both will be classified.

Default Value: `ClassificationType.BOTH` 

#### [](#debugShowBoundingVolume) debugShowBoundingVolume : boolean 

[engine/Source/Scene/GroundPolylinePrimitive.js 163](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L163) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the bounding sphere for each draw command in the primitive.

Default Value: `false` 

#### [](#debugShowShadowVolume) readonly debugShowShadowVolume : boolean 

[engine/Source/Scene/GroundPolylinePrimitive.js 311](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L311) 

 This property is for debugging only; it is not for production use nor is it optimized.

If true, draws the shadow volume for each geometry in the primitive.

Default Value: `false` 

#### [](#geometryInstances) readonly geometryInstances : Array|[GeometryInstance](GeometryInstance.html) 

[engine/Source/Scene/GroundPolylinePrimitive.js 112](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L112) 

 The geometry instances rendered with this primitive. This may be `undefined` if `options.releaseGeometryInstances`is `true` when the primitive is constructed.

Changing this property after the primitive is rendered has no effect.

Default Value: `undefined` 

#### [](#interleave) readonly interleave : boolean 

[engine/Source/Scene/GroundPolylinePrimitive.js 228](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L228) 

 Determines if geometry vertex attributes are interleaved, which can slightly improve rendering performance.

Default Value: `false` 

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/GroundPolylinePrimitive.js 292](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L292) 

 Determines if the primitive is complete and ready to render. If this property is true, the primitive will be rendered the next time that [GroundPolylinePrimitive#update](GroundPolylinePrimitive.html#update)is called.

#### [](#releaseGeometryInstances) readonly releaseGeometryInstances : boolean 

[engine/Source/Scene/GroundPolylinePrimitive.js 244](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L244) 

 When `true`, the primitive does not keep a reference to the input `geometryInstances` to save memory.

Default Value: `true` 

#### [](#show) show : boolean 

[engine/Source/Scene/GroundPolylinePrimitive.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L139) 

 Determines if the primitive will be shown. This affects all geometry instances in the primitive.

Default Value: `true` 

### Methods

#### [](#.initializeTerrainHeights) static Cesium.GroundPolylinePrimitive.initializeTerrainHeights() → Promise.<void> 

[engine/Source/Scene/GroundPolylinePrimitive.js 324](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L324) 

 Initializes the minimum and maximum terrain heights. This only needs to be called if you are creating the GroundPolylinePrimitive synchronously.

##### Returns:

 A promise that will resolve once the terrain heights have been loaded.

#### [](#.isSupported) static Cesium.GroundPolylinePrimitive.isSupported(scene) → boolean 

[engine/Source/Scene/GroundPolylinePrimitive.js 856](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L856) 

 Checks if the given Scene supports GroundPolylinePrimitives. GroundPolylinePrimitives require support for the WEBGL\_depth\_texture extension.

| Name  | Type                | Description        |
| ----- | ------------------- | ------------------ |
| scene | [Scene](Scene.html) | The current scene. |

##### Returns:

 Whether or not the current scene supports GroundPolylinePrimitives.

#### [](#destroy) destroy() 

[engine/Source/Scene/GroundPolylinePrimitive.js 891](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L891) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.

Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
e = e && e.destroy();
```

##### See:

* [GroundPolylinePrimitive#isDestroyed](GroundPolylinePrimitive.html#isDestroyed)

#### [](#getGeometryInstanceAttributes) getGeometryInstanceAttributes(id) → object 

[engine/Source/Scene/GroundPolylinePrimitive.js 836](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L836) 

 Returns the modifiable per-instance attributes for a [GeometryInstance](GeometryInstance.html).

| Name | Type | Description                                              |
| ---- | ---- | -------------------------------------------------------- |
| id   | \*   | The id of the [GeometryInstance](GeometryInstance.html). |

##### Returns:

 The typed array in the attribute's format or undefined if the is no instance with id.

##### Throws:

* [DeveloperError](DeveloperError.html): must call update before calling getGeometryInstanceAttributes.

##### Example:

```javascript
const attributes = primitive.getGeometryInstanceAttributes('an id');
attributes.color = Cesium.ColorGeometryInstanceAttribute.toValue(Cesium.Color.AQUA);
attributes.show = Cesium.ShowGeometryInstanceAttribute.toValue(true);
```

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/GroundPolylinePrimitive.js 871](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L871) 

 Returns true if this object was destroyed; otherwise, false.

If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [GroundPolylinePrimitive#destroy](GroundPolylinePrimitive.html#destroy)

#### [](#update) update() 

[engine/Source/Scene/GroundPolylinePrimitive.js 673](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPolylinePrimitive.js#L673) 

 Called when [Viewer](Viewer.html) or [CesiumWidget](CesiumWidget.html) render the scene to get the draw commands needed to render this primitive.

Do not call this function directly. This is documented just to list the exceptions that may be propagated when the scene is rendered:

##### Throws:

* [DeveloperError](DeveloperError.html): For synchronous GroundPolylinePrimitives, you must call GroundPolylinePrimitives.initializeTerrainHeights() and wait for the returned promise to resolve.
* [DeveloperError](DeveloperError.html): All GeometryInstances must have color attributes to use PolylineColorAppearance with GroundPolylinePrimitive.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

