# [![](Images/CesiumLogo.png)](index.html) FrameRateMonitor 

#### [](#FrameRateMonitor) new Cesium.FrameRateMonitor(options) 

[engine/Source/Scene/FrameRateMonitor.js 32](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L32) 

 Monitors the frame rate (frames per second) in a [Scene](Scene.html) and raises an event if the frame rate is lower than a threshold. Later, if the frame rate returns to the required level, a separate event is raised. To avoid creating multiple FrameRateMonitors for a single [Scene](Scene.html), use [FrameRateMonitor.fromScene](FrameRateMonitor.html#.fromScene)instead of constructing an instance explicitly.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description scene [Scene](Scene.html)  The Scene instance for which to monitor performance. samplingWindow number 5.0 optional The length of the sliding window over which to compute the average frame rate, in seconds. quietPeriod number 2.0 optional The length of time to wait at startup and each time the page becomes visible (i.e. when the user switches back to the tab) before starting to measure performance, in seconds. warmupPeriod number 5.0 optional The length of the warmup period, in seconds. During the warmup period, a separate (usually lower) frame rate is required. minimumFrameRateDuringWarmup number 4 optional The minimum frames-per-second that are required for acceptable performance during the warmup period. If the frame rate averages less than this during any samplingWindow during the warmupPeriod, the lowFrameRate event will be raised and the page will redirect to the redirectOnLowFrameRateUrl, if any. minimumFrameRateAfterWarmup number 8 optional The minimum frames-per-second that are required for acceptable performance after the end of the warmup period. If the frame rate averages less than this during any samplingWindow after the warmupPeriod, the lowFrameRate event will be raised and the page will redirect to the redirectOnLowFrameRateUrl, if any. |

### Members

#### [](#.defaultSettings) static Cesium.FrameRateMonitor.defaultSettings : object 

[engine/Source/Scene/FrameRateMonitor.js 162](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L162) 

 The default frame rate monitoring settings. These settings are used when [FrameRateMonitor.fromScene](FrameRateMonitor.html#.fromScene)needs to create a new frame rate monitor, and for any settings that are not passed to the[FrameRateMonitor](FrameRateMonitor.html) constructor.

#### [](#lastFramesPerSecond) lastFramesPerSecond : number 

[engine/Source/Scene/FrameRateMonitor.js 240](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L240) 

 Gets the most recently computed average frames-per-second over the last `samplingWindow`. This property may be undefined if the frame rate has not been computed.

#### [](#lowFrameRate) lowFrameRate : [Event](Event.html) 

[engine/Source/Scene/FrameRateMonitor.js 215](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L215) 

 Gets the event that is raised when a low frame rate is detected. The function will be passed the [Scene](Scene.html) instance as its first parameter and the average number of frames per second over the sampling window as its second parameter.

#### [](#minimumFrameRateAfterWarmup) minimumFrameRateAfterWarmup : number 

[engine/Source/Scene/FrameRateMonitor.js 87](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L87) 

 Gets or sets the minimum frames-per-second that are required for acceptable performance after the end of the warmup period. If the frame rate averages less than this during any `samplingWindow` after the `warmupPeriod`, the`lowFrameRate` event will be raised and the page will redirect to the `redirectOnLowFrameRateUrl`, if any.

#### [](#minimumFrameRateDuringWarmup) minimumFrameRateDuringWarmup : number 

[engine/Source/Scene/FrameRateMonitor.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L76) 

 Gets or sets the minimum frames-per-second that are required for acceptable performance during the warmup period. If the frame rate averages less than this during any `samplingWindow` during the `warmupPeriod`, the`lowFrameRate` event will be raised and the page will redirect to the `redirectOnLowFrameRateUrl`, if any.

#### [](#nominalFrameRate) nominalFrameRate : [Event](Event.html) 

[engine/Source/Scene/FrameRateMonitor.js 228](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L228) 

 Gets the event that is raised when the frame rate returns to a normal level after having been low. The function will be passed the [Scene](Scene.html) instance as its first parameter and the average number of frames per second over the sampling window as its second parameter.

#### [](#quietPeriod) quietPeriod : number 

[engine/Source/Scene/FrameRateMonitor.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L55) 

 Gets or sets the length of time to wait at startup and each time the page becomes visible (i.e. when the user switches back to the tab) before starting to measure performance, in seconds.

#### [](#samplingWindow) samplingWindow : number 

[engine/Source/Scene/FrameRateMonitor.js 45](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L45) 

 Gets or sets the length of the sliding window over which to compute the average frame rate, in seconds.

#### [](#scene) scene : [Scene](Scene.html) 

[engine/Source/Scene/FrameRateMonitor.js 202](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L202) 

 Gets the [Scene](Scene.html) instance for which to monitor performance.

#### [](#warmupPeriod) warmupPeriod : number 

[engine/Source/Scene/FrameRateMonitor.js 65](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L65) 

 Gets or sets the length of the warmup period, in seconds. During the warmup period, a separate (usually lower) frame rate is required.

### Methods

#### [](#.fromScene) static Cesium.FrameRateMonitor.fromScene(scene) → [FrameRateMonitor](FrameRateMonitor.html) 

[engine/Source/Scene/FrameRateMonitor.js 177](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L177) 

 Gets the [FrameRateMonitor](FrameRateMonitor.html) for a given scene. If the scene does not yet have a [FrameRateMonitor](FrameRateMonitor.html), one is created with the [FrameRateMonitor.defaultSettings](FrameRateMonitor.html#.defaultSettings).

| Name  | Type                | Description                                                               |
| ----- | ------------------- | ------------------------------------------------------------------------- |
| scene | [Scene](Scene.html) | The scene for which to get the [FrameRateMonitor](FrameRateMonitor.html). |

##### Returns:

 The scene's [FrameRateMonitor](FrameRateMonitor.html).

#### [](#destroy) destroy() 

[engine/Source/Scene/FrameRateMonitor.js 302](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L302) 

 Unsubscribes this instance from all events it is listening to. Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### See:

* [FrameRateMonitor#isDestroyed](FrameRateMonitor.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/FrameRateMonitor.js 286](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L286) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

 True if this object was destroyed; otherwise, false.

##### See:

* [FrameRateMonitor#destroy](FrameRateMonitor.html#destroy)

#### [](#pause) pause() 

[engine/Source/Scene/FrameRateMonitor.js 252](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L252) 

 Pauses monitoring of the frame rate. To resume monitoring, [FrameRateMonitor#unpause](FrameRateMonitor.html#unpause)must be called once for each time this function is called.

#### [](#unpause) unpause() 

[engine/Source/Scene/FrameRateMonitor.js 266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/FrameRateMonitor.js#L266) 

 Resumes monitoring of the frame rate. If [FrameRateMonitor#pause](FrameRateMonitor.html#pause) was called multiple times, this function must be called the same number of times in order to actually resume monitoring.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

