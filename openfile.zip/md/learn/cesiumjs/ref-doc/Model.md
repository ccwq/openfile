# [![](Images/CesiumLogo.png)](index.html) Model 

#### [](#Model) internal constructor new Cesium.Model() 

[engine/Source/Scene/Model/Model.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L176) 

To construct a Model, call [Model.fromGltfAsync](Model.html#.fromGltfAsync). Do not call the constructor directly.

A 3D model based on glTF, the runtime asset format for WebGL, OpenGL ES, and OpenGL.

Cesium supports glTF assets with the following extensions:
* [AGI\_articulations](https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Vendor/AGI%5Farticulations/README.md)
* [CESIUM\_primitive\_outline](https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Vendor/CESIUM%5Fprimitive%5Foutline)
* [CESIUM\_RTC](https://github.com/KhronosGroup/glTF/blob/master/extensions/1.0/Vendor/CESIUM%5FRTC/README.md)
* [EXT\_instance\_features](https://github.com/CesiumGS/glTF/tree/3d-tiles-next/extensions/2.0/Vendor/EXT%5Finstance%5Ffeatures)
* [EXT\_mesh\_features](https://github.com/CesiumGS/glTF/tree/3d-tiles-next/extensions/2.0/Vendor/EXT%5Fmesh%5Ffeatures)
* [EXT\_mesh\_gpu\_instancing](https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Vendor/EXT%5Fmesh%5Fgpu%5Finstancing)
* [EXT\_meshopt\_compression](https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Vendor/EXT%5Fmeshopt%5Fcompression)
* [EXT\_structural\_metadata](https://github.com/CesiumGS/glTF/tree/3d-tiles-next/extensions/2.0/Vendor/EXT%5Fstructural%5Fmetadata)
* [EXT\_texture\_webp](https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Vendor/EXT%5Ftexture%5Fwebp)
* [KHR\_draco\_mesh\_compression](https://github.com/KhronosGroup/glTF/blob/master/extensions/2.0/Khronos/KHR%5Fdraco%5Fmesh%5Fcompression/README.md)
* [KHR\_techniques\_webgl](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Archived/KHR%5Ftechniques%5Fwebgl/README.md)
* [KHR\_materials\_common](https://github.com/KhronosGroup/glTF/blob/main/extensions/1.0/Khronos/KHR%5Fmaterials%5Fcommon/README.md)
* [KHR\_materials\_pbrSpecularGlossiness](https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Archived/KHR%5Fmaterials%5FpbrSpecularGlossiness)
* [KHR\_materials\_unlit](https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR%5Fmaterials%5Funlit/README.md)
* [KHR\_mesh\_quantization](https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Khronos/KHR%5Fmesh%5Fquantization)
* [KHR\_texture\_basisu](https://github.com/KhronosGroup/glTF/blob/master/extensions/2.0/Khronos/KHR%5Ftexture%5Fbasisu)
* [KHR\_texture\_transform](https://github.com/KhronosGroup/glTF/blob/master/extensions/2.0/Khronos/KHR%5Ftexture%5Ftransform/README.md)
* [WEB3D\_quantized\_attributes](https://github.com/KhronosGroup/glTF/blob/main/extensions/1.0/Vendor/WEB3D%5Fquantized%5Fattributes/README.md)
* [NGA\_gpm\_local (experimental)](https://nsgreg.nga.mil/csmwg.jsp)

Note: for models with compressed textures using the KHR\_texture\_basisu extension, we recommend power of 2 textures in both dimensions for maximum compatibility. This is because some samplers require power of 2 textures ([Using textures in WebGL](https://developer.mozilla.org/en-US/docs/Web/API/WebGL%5FAPI/Tutorial/Using%5Ftextures%5Fin%5FWebGL)) and KHR\_texture\_basisu requires multiple of 4 dimensions ([KHR\_texture\_basisu additional requirements](https://github.com/KhronosGroup/glTF/blob/master/extensions/2.0/Khronos/KHR%5Ftexture%5Fbasisu/README.md#additional-requirements)).

##### Demo:

* [Cesium Sandcastle Models Demo](https://sandcastle.cesium.com/index.html?src=3D%2520Models.html)

##### See:

* [Model.fromGltfAsync](Model.html#.fromGltfAsync)

### Members

#### [](#activeAnimations) readonly activeAnimations : [ModelAnimationCollection](ModelAnimationCollection.html) 

[engine/Source/Scene/Model/Model.js 733](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L733) 

 The currently playing glTF animations.

#### [](#backFaceCulling) backFaceCulling : boolean 

[engine/Source/Scene/Model/Model.js 1500](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1500) 

 Whether to cull back-facing geometry. When true, back face culling is determined by the material's doubleSided property; when false, back face culling is disabled. Back faces are not culled if [Model#color](Model.html#color)is translucent or [Model#silhouetteSize](Model.html#silhouetteSize) is greater than 0.0.

Default Value: `true` 

#### [](#boundingSphere) readonly boundingSphere : [BoundingSphere](BoundingSphere.html) 

[engine/Source/Scene/Model/Model.js 1144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1144) 

 Gets the model's bounding sphere in world space. This does not take into account glTF animations, skins, or morph targets. It also does not account for[Model#minimumPixelSize](Model.html#minimumPixelSize).

#### [](#clampAnimations) clampAnimations : boolean 

[engine/Source/Scene/Model/Model.js 747](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L747) 

 Determines if the model's animations should hold a pose over frames where no keyframes are specified.

Default Value: `true` 

#### [](#classificationType) readonly classificationType : [ClassificationType](global.html#ClassificationType) 

[engine/Source/Scene/Model/Model.js 1704](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1704) 

 Gets the model's classification type. This determines whether terrain, 3D Tiles, or both will be classified by this model.

Additionally, there are a few requirements/limitations:
* The glTF cannot contain morph targets, skins, or animations.
* The glTF cannot contain the `EXT_mesh_gpu_instancing` extension.
* Only meshes with TRIANGLES can be used to classify other assets.
* The meshes must be watertight.
* The POSITION attribute is required.
* If feature IDs and an index buffer are both present, all indices with the same feature id must occupy contiguous sections of the index buffer.
* If feature IDs are present without an index buffer, all positions with the same feature id must occupy contiguous sections of the position buffer.

The 3D Tiles or terrain receiving the classification must be opaque.

Default Value: `undefined` 

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#clippingPlanes) clippingPlanes : [ClippingPlaneCollection](ClippingPlaneCollection.html) 

[engine/Source/Scene/Model/Model.js 1328](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1328) 

 The [ClippingPlaneCollection](ClippingPlaneCollection.html) used to selectively disable rendering the model.

#### [](#clippingPolygons) clippingPolygons : [ClippingPolygonCollection](ClippingPolygonCollection.html) 

[engine/Source/Scene/Model/Model.js 1348](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1348) 

 The [ClippingPolygonCollection](ClippingPolygonCollection.html) used to selectively disable rendering the model.

#### [](#color) color : [Color](Color.html) 

[engine/Source/Scene/Model/Model.js 1033](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1033) 

 The color to blend with the model's rendered color.

Default Value: `undefined` 

#### [](#colorBlendAmount) colorBlendAmount : number 

[engine/Source/Scene/Model/Model.js 1072](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1072) 

 Value used to determine the color strength when the `colorBlendMode` is `MIX`. A value of 0.0 results in the model's rendered color while a value of 1.0 results in a solid color, with any value in-between resulting in a mix of the two.

Default Value: `0.5` 

#### [](#colorBlendMode) colorBlendMode : [Cesium3DTileColorBlendMode](global.html#Cesium3DTileColorBlendMode)|[ColorBlendMode](global.html#ColorBlendMode) 

[engine/Source/Scene/Model/Model.js 1054](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1054) 

 Defines how the color blends with the model.

Default Value: `ColorBlendMode.HIGHLIGHT` 

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/Model/Model.js 1627](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1627) 

 Gets the credit that will be displayed for the model.

#### [](#customShader) customShader : [CustomShader](CustomShader.html) 

[engine/Source/Scene/Model/Model.js 822](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L822) 

 The model's custom shader, if it exists. Using custom shaders with a [Cesium3DTileStyle](Cesium3DTileStyle.html)may lead to undefined behavior.

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#debugShowBoundingVolume) debugShowBoundingVolume : boolean 

[engine/Source/Scene/Model/Model.js 1175](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1175) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the bounding sphere for each draw command in the model.

Default Value: `false` 

#### [](#debugWireframe) debugWireframe : boolean 

[engine/Source/Scene/Model/Model.js 1199](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1199) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the model in wireframe.

Default Value: `false` 

#### [](#distanceDisplayCondition) distanceDisplayCondition : [DistanceDisplayCondition](DistanceDisplayCondition.html) 

[engine/Source/Scene/Model/Model.js 897](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L897) 

 Gets or sets the distance display condition, which specifies at what distance from the camera this model will be displayed.

Default Value: `undefined` 

#### [](#enableVerticalExaggeration) enableVerticalExaggeration : boolean 

[engine/Source/Scene/Model/Model.js 1373](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1373) 

 If `true`, the model is exaggerated along the ellipsoid normal when `Scene.verticalExaggeration` is set to a value other than `1.0`.

Default Value: `true` 

##### Example:

```javascript
// Exaggerate terrain by a factor of 2, but prevent model exaggeration
scene.verticalExaggeration = 2.0;
model.enableVerticalExaggeration = false;
```

#### [](#environmentMapManager) readonly environmentMapManager : [DynamicEnvironmentMapManager](DynamicEnvironmentMapManager.html) 

[engine/Source/Scene/Model/Model.js 1468](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1468) 

 The properties for managing dynamic environment maps on this model. Affects lighting.

##### Example:

```javascript
// Change the ground color used for a model's environment map to a forest green
const environmentMapManager = model.environmentMapManager;
environmentMapManager.groundColor = Cesium.Color.fromCssColorString("#203b34");
```

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/Model/Model.js 645](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L645) 

 Gets an event that is raised when the model encounters an asynchronous rendering error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of `ModelError`.

#### [](#featureIdLabel) featureIdLabel : string 

[engine/Source/Scene/Model/Model.js 1263](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1263) 

 Label of the feature ID set to use for picking and styling.

For EXT\_mesh\_features, this is the feature ID's label property, or "featureId\_N" (where N is the index in the featureIds array) when not specified. EXT\_feature\_metadata did not have a label field, so such feature ID sets are always labeled "featureId\_N" where N is the index in the list of all feature Ids, where feature ID attributes are listed before feature ID textures.

If featureIdLabel is set to an integer N, it is converted to the string "featureId\_N" automatically. If both per-primitive and per-instance feature IDs are present, the instance feature IDs take priority.

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#heightReference) heightReference : [HeightReference](global.html#HeightReference) 

[engine/Source/Scene/Model/Model.js 874](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L874) 

 The height reference of the model, which determines how the model is drawn relative to terrain.

Default Value: `{HeightReference.NONE}` 

#### [](#id) id : object 

[engine/Source/Scene/Model/Model.js 978](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L978) 

 A user-defined object that is returned when the model is picked.

Default Value: `undefined` 

##### See:

* [Scene#pick](Scene.html#pick)

#### [](#imageBasedLighting) imageBasedLighting : [ImageBasedLighting](ImageBasedLighting.html) 

[engine/Source/Scene/Model/Model.js 1433](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1433) 

 The properties for managing image-based lighting on this model.

#### [](#instanceFeatureIdLabel) instanceFeatureIdLabel : string 

[engine/Source/Scene/Model/Model.js 1299](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1299) 

 Label of the instance feature ID set used for picking and styling.

If instanceFeatureIdLabel is set to an integer N, it is converted to the string "instanceFeatureId\_N" automatically. If both per-primitive and per-instance feature IDs are present, the instance feature IDs take priority.

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#lightColor) lightColor : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Model/Model.js 1413](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1413) 

 The directional light color when shading the model. When `undefined` the scene's light color is used instead.

Disabling additional light sources by setting`model.imageBasedLighting.imageBasedLightingFactor = new Cartesian2(0.0, 0.0)`will make the model much darker. Here, increasing the intensity of the light source will make the model brighter.

Default Value: `undefined` 

#### [](#maximumScale) maximumScale : number 

[engine/Source/Scene/Model/Model.js 1585](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1585) 

 The maximum scale size for a model. This can be used to give an upper limit to the [Model#minimumPixelSize](Model.html#minimumPixelSize), ensuring that the model is never an unreasonable scale.

#### [](#minimumPixelSize) minimumPixelSize : number 

[engine/Source/Scene/Model/Model.js 1564](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1564) 

 The approximate minimum pixel size of the model regardless of zoom. This can be used to ensure that a model is visible even when the viewer zooms out. When `0.0`, no minimum size is enforced.

Default Value: `0.0` 

#### [](#modelMatrix) modelMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/Model/Model.js 217](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L217) 

 The 4x4 transformation matrix that transforms the model from model to world coordinates. When this is the identity matrix, the model is drawn in world coordinates, i.e., Earth's Cartesian WGS84 coordinates. Local reference frames can be used by providing a different transformation matrix, like that returned by [Transforms.eastNorthUpToFixedFrame](Transforms.html#.eastNorthUpToFixedFrame).

Default Value: `[Matrix4.IDENTITY](Matrix4.html#.IDENTITY)` 

##### Example:

```javascript
const origin = Cesium.Cartesian3.fromDegrees(-95.0, 40.0, 200000.0);
m.modelMatrix = Cesium.Transforms.eastNorthUpToFixedFrame(origin);
```

#### [](#outlineColor) outlineColor : [Color](Color.html) 

[engine/Source/Scene/Model/Model.js 489](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L489) 

 The color to use when rendering outlines.

Default Value: `Color.BLACK` 

#### [](#pointCloudShading) pointCloudShading : [PointCloudShading](PointCloudShading.html) 

[engine/Source/Scene/Model/Model.js 798](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L798) 

 Point cloud shading settings for controlling point cloud attenuation and lighting. For 3D Tiles, this is inherited from the[Cesium3DTileset](Cesium3DTileset.html).

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/Model/Model.js 631](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L631) 

 When `true`, this model is ready to render, i.e., the external binary, image, and shader files were downloaded and the WebGL resources were created.

Default Value: `false` 

#### [](#readyEvent) readonly readyEvent : [Event](Event.html) 

[engine/Source/Scene/Model/Model.js 664](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L664) 

 Gets an event that is raised when the model is loaded and ready for rendering, i.e. when the external resources have been downloaded and the WebGL resources are created. Event listeners are passed an instance of the [Model](Model.html).

If `Model.incrementallyLoadTextures` is true, this event will be raised before all textures are loaded and ready for rendering. Subscribe to `Model.texturesReadyEvent` to be notified when the textures are ready.

#### [](#scale) scale : number 

[engine/Source/Scene/Model/Model.js 1524](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1524) 

 A uniform scale applied to this model before the [Model#modelMatrix](Model.html#modelMatrix). Values greater than `1.0` increase the size of the model; values less than `1.0` decrease.

Default Value: `1.0` 

#### [](#shadows) shadows : [ShadowMode](global.html#ShadowMode) 

[engine/Source/Scene/Model/Model.js 1606](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1606) 

 Determines whether the model casts or receives shadows from light sources.

Default Value: `ShadowMode.ENABLED` 

#### [](#show) show : boolean 

[engine/Source/Scene/Model/Model.js 1232](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1232) 

 Whether or not to render the model.

Default Value: `true` 

#### [](#showCreditsOnScreen) showCreditsOnScreen : boolean 

[engine/Source/Scene/Model/Model.js 1643](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1643) 

 Gets or sets whether the credits of the model will be displayed on the screen.

Default Value: `false` 

#### [](#showOutline) showOutline : boolean 

[engine/Source/Scene/Model/Model.js 480](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L480) 

 Whether to display the outline for models using the[CESIUM\_primitive\_outline](https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Vendor/CESIUM%5Fprimitive%5Foutline) extension. When true, outlines are displayed. When false, outlines are not displayed.

Default Value: `true` 

#### [](#silhouetteColor) silhouetteColor : [Color](Color.html) 

[engine/Source/Scene/Model/Model.js 1090](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1090) 

 The silhouette color.

Default Value: `Color.RED` 

#### [](#silhouetteSize) silhouetteSize : number 

[engine/Source/Scene/Model/Model.js 1113](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1113) 

 The size of the silhouette in pixels.

Default Value: `0.0` 

#### [](#splitDirection) splitDirection : [SplitDirection](global.html#SplitDirection) 

[engine/Source/Scene/Model/Model.js 1665](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1665) 

 The [SplitDirection](global.html#SplitDirection) to apply to this model.

Default Value: `[SplitDirection.NONE](global.html#SplitDirection#.NONE)` 

#### [](#style) style : [Cesium3DTileStyle](Cesium3DTileStyle.html) 

[engine/Source/Scene/Model/Model.js 1014](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1014) 

 The style to apply to the features in the model. Cannot be applied if a [CustomShader](CustomShader.html) is also applied.

#### [](#texturesReadyEvent) readonly texturesReadyEvent : [Event](Event.html) 

[engine/Source/Scene/Model/Model.js 694](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L694) 

 Gets an event that, if `Model.incrementallyLoadTextures` is true, is raised when the model textures are loaded and ready for rendering, i.e. when the external resources have been downloaded and the WebGL resources are created. Event listeners are passed an instance of the [Model](Model.html).

### Methods

#### [](#.fromGltfAsync) static Cesium.Model.fromGltfAsync(options) → Promise.<[Model](Model.html)\> 

[engine/Source/Scene/Model/Model.js 3014](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L3014) 

Asynchronously creates a model from a glTF asset. This function returns a promise that resolves when the model is ready to render, i.e., when the external binary, image, and shader files are downloaded and the WebGL resources are created.

The model can be a traditional glTF asset with a .gltf extension or a Binary glTF using the .glb extension.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description url string\|[Resource](Resource.html)  The url to the .gltf or .glb file. basePath string|[Resource](Resource.html) '' optional The base path that paths in the glTF JSON are relative to. show boolean true optional Whether or not to render the model. modelMatrix [Matrix4](Matrix4.html) Matrix4.IDENTITY optional The 4x4 transformation matrix that transforms the model from model to world coordinates. scale number 1.0 optional A uniform scale applied to this model. enableVerticalExaggeration boolean true optional If true, the model is exaggerated along the ellipsoid normal when Scene.verticalExaggeration is set to a value other than 1.0. minimumPixelSize number 0.0 optional The approximate minimum pixel size of the model regardless of zoom. maximumScale number optional The maximum scale size of a model. An upper limit for minimumPixelSize. id object optional A user-defined object to return when the model is picked with [Scene#pick](Scene.html#pick). allowPicking boolean true optional When true, each primitive is pickable with [Scene#pick](Scene.html#pick). incrementallyLoadTextures boolean true optional Determine if textures may continue to stream in after the model is loaded. asynchronous boolean true optional Determines if model WebGL resource creation will be spread out over several frames or block until completion once all glTF files are loaded. clampAnimations boolean true optional Determines if the model's animations should hold a pose over frames where no keyframes are specified. shadows [ShadowMode](global.html#ShadowMode) ShadowMode.ENABLED optional Determines whether the model casts or receives shadows from light sources. releaseGltfJson boolean false optional When true, the glTF JSON is released once the glTF is loaded. This is is especially useful for cases like 3D Tiles, where each .gltf model is unique and caching the glTF JSON is not effective. debugShowBoundingVolume boolean false optional For debugging only. Draws the bounding sphere for each draw command in the model. enableDebugWireframe boolean false optional For debugging only. This must be set to true for debugWireframe to work in WebGL1\. This cannot be set after the model has loaded. debugWireframe boolean false optional For debugging only. Draws the model in wireframe. Will only work for WebGL1 if enableDebugWireframe is set to true. cull boolean true optional Whether or not to cull the model using frustum/horizon culling. If the model is part of a 3D Tiles tileset, this property will always be false, since the 3D Tiles culling system is used. opaquePass boolean Pass.OPAQUE optional The pass to use in the [DrawCommand](DrawCommand.html) for the opaque portions of the model. upAxis [Axis](global.html#Axis) Axis.Y optional The up-axis of the glTF model. forwardAxis [Axis](global.html#Axis) Axis.Z optional The forward-axis of the glTF model. customShader [CustomShader](CustomShader.html) optional A custom shader. This will add user-defined GLSL code to the vertex and fragment shaders. Using custom shaders with a [Cesium3DTileStyle](Cesium3DTileStyle.html) may lead to undefined behavior. content [Cesium3DTileContent](Cesium3DTileContent.html) optional The tile content this model belongs to. This property will be undefined if model is not loaded as part of a tileset. heightReference [HeightReference](global.html#HeightReference) HeightReference.NONE optional Determines how the model is drawn relative to terrain. scene [Scene](Scene.html) optional Must be passed in for models that use the height reference property. distanceDisplayCondition [DistanceDisplayCondition](DistanceDisplayCondition.html) optional The condition specifying at what distance from the camera that this model will be displayed. color [Color](Color.html) optional A color that blends with the model's rendered color. colorBlendMode [ColorBlendMode](global.html#ColorBlendMode) ColorBlendMode.HIGHLIGHT optional Defines how the color blends with the model. colorBlendAmount number 0.5 optional Value used to determine the color strength when the colorBlendMode is MIX. A value of 0.0 results in the model's rendered color while a value of 1.0 results in a solid color, with any value in-between resulting in a mix of the two. silhouetteColor [Color](Color.html) Color.RED optional The silhouette color. If more than 256 models have silhouettes enabled, there is a small chance that overlapping models will have minor artifacts. silhouetteSize number 0.0 optional The size of the silhouette in pixels. enableShowOutline boolean true optional Whether to enable outlines for models using the [CESIUM\_primitive\_outline](https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Vendor/CESIUM%5Fprimitive%5Foutline) extension. This can be set false to avoid post-processing geometry at load time. When false, the showOutlines and outlineColor options are ignored. showOutline boolean true optional Whether to display the outline for models using the [CESIUM\_primitive\_outline](https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Vendor/CESIUM%5Fprimitive%5Foutline) extension. When true, outlines are displayed. When false, outlines are not displayed. outlineColor [Color](Color.html) Color.BLACK optional The color to use when rendering outlines. clippingPlanes [ClippingPlaneCollection](ClippingPlaneCollection.html) optional The [ClippingPlaneCollection](ClippingPlaneCollection.html) used to selectively disable rendering the model. clippingPolygons [ClippingPolygonCollection](ClippingPolygonCollection.html) optional The [ClippingPolygonCollection](ClippingPolygonCollection.html) used to selectively disable rendering the model. lightColor [Cartesian3](Cartesian3.html) optional The light color when shading the model. When undefined the scene's light color is used instead. imageBasedLighting [ImageBasedLighting](ImageBasedLighting.html) optional The properties for managing image-based lighting on this model. environmentMapOptions [DynamicEnvironmentMapManager.ConstructorOptions](DynamicEnvironmentMapManager.html#.ConstructorOptions) optional The properties for managing dynamic environment maps on this model. backFaceCulling boolean true optional Whether to cull back-facing geometry. When true, back face culling is determined by the material's doubleSided property; when false, back face culling is disabled. Back faces are not culled if the model's color is translucent. credit [Credit](Credit.html)|string optional A credit for the data source, which is displayed on the canvas. showCreditsOnScreen boolean false optional Whether to display the credits of this model on screen. splitDirection [SplitDirection](global.html#SplitDirection) SplitDirection.NONE optional The [SplitDirection](global.html#SplitDirection) split to apply to this model. projectTo2D boolean false optional Whether to accurately project the model's positions in 2D. If this is true, the model will be projected accurately to 2D, but it will use more memory to do so. If this is false, the model will use less memory and will still render in 2D / CV mode, but its positions may be inaccurate. This disables minimumPixelSize and prevents future modification to the model matrix. This also cannot be set after the model has loaded. enablePick boolean false optional Whether to allow with CPU picking with pick when not using WebGL 2 or above. If using WebGL 2 or above, this option will be ignored. If using WebGL 1 and this is true, the pick operation will work correctly, but it will use more memory to do so. If running with WebGL 1 and this is false, the model will use less memory, but pick will always return undefined. This cannot be set after the model has loaded. featureIdLabel string|number "featureId\_0" optional Label of the feature ID set to use for picking and styling. For EXT\_mesh\_features, this is the feature ID's label property, or "featureId\_N" (where N is the index in the featureIds array) when not specified. EXT\_feature\_metadata did not have a label field, so such feature ID sets are always labeled "featureId\_N" where N is the index in the list of all feature Ids, where feature ID attributes are listed before feature ID textures. If featureIdLabel is an integer N, it is converted to the string "featureId\_N" automatically. If both per-primitive and per-instance feature IDs are present, the instance feature IDs take priority. instanceFeatureIdLabel string|number "instanceFeatureId\_0" optional Label of the instance feature ID set used for picking and styling. If instanceFeatureIdLabel is set to an integer N, it is converted to the string "instanceFeatureId\_N" automatically. If both per-primitive and per-instance feature IDs are present, the instance feature IDs take priority. pointCloudShading object optional Options for constructing a [PointCloudShading](PointCloudShading.html) object to control point attenuation and lighting. classificationType [ClassificationType](global.html#ClassificationType) optional Determines whether terrain, 3D Tiles or both will be classified by this model. This cannot be set after the model has loaded. gltfCallback [Model.GltfCallback](Model.html#.GltfCallback) optional A function that is called with the loaded gltf object once loaded. |

##### Returns:

 A promise that resolves to the created model when it is ready to render.

##### Throws:

* [RuntimeError](RuntimeError.html): The model failed to load.
* [RuntimeError](RuntimeError.html): Unsupported glTF version.
* [RuntimeError](RuntimeError.html): Unsupported glTF Extension

##### Examples:

```javascript
// Load a model and add it to the scene
try {
 const model = await Cesium.Model.fromGltfAsync({
   url: "../../SampleData/models/CesiumMan/Cesium_Man.glb"
 });
 viewer.scene.primitives.add(model);
} catch (error) {
 console.log(`Failed to load model. ${error}`);
}
```

```javascript
// Position a model with modelMatrix and display it with a minimum size of 128 pixels
const position = Cesium.Cartesian3.fromDegrees(
  -123.0744619,
  44.0503706,
  5000.0
);
const headingPositionRoll = new Cesium.HeadingPitchRoll();
const fixedFrameTransform = Cesium.Transforms.localFrameToFixedFrameGenerator(
  "north",
  "west"
);
try {
 const model = await Cesium.Model.fromGltfAsync({
   url: "../../SampleData/models/CesiumAir/Cesium_Air.glb",
   modelMatrix: Cesium.Transforms.headingPitchRollToFixedFrame(
     position,
     headingPositionRoll,
     Cesium.Ellipsoid.WGS84,
     fixedFrameTransform
   ),
   minimumPixelSize: 128,
 });
 viewer.scene.primitives.add(model);
} catch (error) {
 console.log(`Failed to load model. ${error}`);
}
```

```javascript
// Load a model and play the last animation at half speed
let animations;
try {
 const model = await Cesium.Model.fromGltfAsync({
   url: "../../SampleData/models/CesiumMan/Cesium_Man.glb",
   gltfCallback: gltf => {
     animations = gltf.animations
   }
 });
 viewer.scene.primitives.add(model);
 model.readyEvent.addEventListener(() => {
   model.activeAnimations.add({
     index: animations.length - 1,
     loop: Cesium.ModelAnimationLoop.REPEAT,
     multiplier: 0.5,
   });
 });
} catch (error) {
 console.log(`Failed to load model. ${error}`);
}
```

#### [](#applyArticulations) applyArticulations() 

[engine/Source/Scene/Model/Model.js 1809](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1809) 

 Applies any modified articulation stages to the matrix of each node that participates in any articulation. Note that this will overwrite any node transformations on participating nodes.

##### Throws:

* [DeveloperError](DeveloperError.html): The model is not loaded. Use Model.readyEvent or wait for Model.ready to be true.

#### [](#destroy) destroy() 

[engine/Source/Scene/Model/Model.js 2787](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L2787) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
model = model && model.destroy();
```

##### See:

* [Model#isDestroyed](Model.html#isDestroyed)

#### [](#getExtension) getExtension(extensionName) → object|undefined 

[engine/Source/Scene/Model/Model.js 1835](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1835) 

 Returns the object that was created for the given extension. The given name may be the name of a glTF extension, like \`"EXT\_example\_extension"\`. If the specified extension was present in the root of the underlying glTF asset, and a loader for the specified extension has processed the extension data, then this will return the model representation of the extension.

| Name          | Type   | Description               |
| ------------- | ------ | ------------------------- |
| extensionName | string | The name of the extension |

##### Returns:

 The object, or \`undefined\`

##### Throws:

* [DeveloperError](DeveloperError.html): The model is not loaded. Use Model.readyEvent or wait for Model.ready to be true.

##### Experimental

This feature is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#getNode) getNode(name) → [ModelNode](ModelNode.html) 

[engine/Source/Scene/Model/Model.js 1760](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1760) 

 Returns the node with the given `name` in the glTF. This is used to modify a node's transform for user-defined animation.

| Name | Type   | Description                       |
| ---- | ------ | --------------------------------- |
| name | string | The name of the node in the glTF. |

##### Returns:

 The node, or `undefined` if no node with the `name` exists.

##### Throws:

* [DeveloperError](DeveloperError.html): The model is not loaded. Use Model.readyEvent or wait for Model.ready to be true.

##### Example:

```javascript
// Apply non-uniform scale to node "Hand"
const node = model.getNode("Hand");
node.matrix = Cesium.Matrix4.fromScale(new Cesium.Cartesian3(5.0, 1.0, 1.0), node.matrix);
```

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/Model/Model.js 2767](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L2767) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [Model#destroy](Model.html#destroy)

#### [](#makeStyleDirty) makeStyleDirty() 

[engine/Source/Scene/Model/Model.js 1852](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1852) 

 Marks the model's [Model#style](Model.html#style) as dirty, which forces all features to re-evaluate the style in the next frame the model is visible.

#### [](#setArticulationStage) setArticulationStage(articulationStageKey, value) 

[engine/Source/Scene/Model/Model.js 1789](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1789) 

 Sets the current value of an articulation stage. After setting one or multiple stage values, call Model.applyArticulations() to cause the node matrices to be recalculated.

| Name                 | Type   | Description                                                       |
| -------------------- | ------ | ----------------------------------------------------------------- |
| articulationStageKey | string | The name of the articulation, a space, and the name of the stage. |
| value                | number | The numeric value of this stage of the articulation.              |

##### Throws:

* [DeveloperError](DeveloperError.html): The model is not loaded. Use Model.readyEvent or wait for Model.ready to be true.

##### Example:

```javascript
// Sets the value of the stage named "MoveX" belonging to the articulation named "SampleArticulation"
model.setArticulationStage("SampleArticulation MoveX", 50.0);
```

##### See:

* [Model#applyArticulations](Model.html#applyArticulations)

#### [](#update) update() 

[engine/Source/Scene/Model/Model.js 1879](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L1879) 

 Called when [Viewer](Viewer.html) or [CesiumWidget](CesiumWidget.html) render the scene to get the draw commands needed to render this primitive.

Do not call this function directly. This is documented just to list the exceptions that may be propagated when the scene is rendered:

##### Throws:

* [RuntimeError](RuntimeError.html): Failed to load external reference.

### Type Definitions

#### [](#.GltfCallback) Cesium.Model.GltfCallback(gltf) 

[engine/Source/Scene/Model/Model.js 3314](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Model.js#L3314) 

 Interface for the function that is called with the loaded gltf object once loaded.

| Name | Type   | Description     |
| ---- | ------ | --------------- |
| gltf | object | The gltf object |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

