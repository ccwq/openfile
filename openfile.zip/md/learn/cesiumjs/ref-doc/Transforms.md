# [![](Images/CesiumLogo.png)](index.html) Transforms 

[engine/Source/Core/Transforms.js 22](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L22) 

Contains functions for transforming positions to various reference frames.

### Methods

#### [](#.computeFixedToIcrfMatrix) static Cesium.Transforms.computeFixedToIcrfMatrix(date, result) → [Matrix3](Matrix3.html)|undefined 

[engine/Source/Core/Transforms.js 899](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L899) 

 Computes a rotation matrix to transform a point or vector from the Earth-Fixed frame axes (ITRF) to the International Celestial Reference Frame (GCRF/ICRF) inertial frame axes at a given time. This function may return undefined if the data necessary to do the transformation is not yet loaded.

| Name   | Type                          | Description                                                                                                                     |
| ------ | ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| date   | [JulianDate](JulianDate.html) | The time at which to compute the rotation matrix.                                                                               |
| result | [Matrix3](Matrix3.html)       | optional The object onto which to store the result. If this parameter is not specified, a new instance is created and returned. |

##### Returns:

 The rotation matrix, or undefined if the data necessary to do the transformation is not yet loaded.

##### Example:

```javascript
// Transform a point from the Fixed axes to the ICRF axes.
const now = Cesium.JulianDate.now();
const pointInFixed = Cesium.Cartesian3.fromDegrees(0.0, 0.0);
const fixedToIcrf = Cesium.Transforms.computeFixedToIcrfMatrix(now);
let pointInInertial = new Cesium.Cartesian3();
if (Cesium.defined(fixedToIcrf)) {
    pointInInertial = Cesium.Matrix3.multiplyByVector(fixedToIcrf, pointInFixed, pointInInertial);
}
```

##### See:

* [Transforms.preloadIcrfFixed](Transforms.html#.preloadIcrfFixed)

#### [](#.computeIcrfToCentralBodyFixedMatrix) static Cesium.Transforms.computeIcrfToCentralBodyFixedMatrix(date, result) → [Matrix3](Matrix3.html)|undefined 

[engine/Source/Core/Transforms.js 559](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L559) 

 The default function to compute a rotation matrix to transform a point or vector from the International Celestial Reference Frame (GCRF/ICRF) inertial frame axes to the central body, typically Earth, fixed frame axis at a given time for use in lighting and transformation from inertial reference frames. This function may return undefined if the data necessary to do the transformation is not yet loaded.

| Name   | Type                          | Description                                                                                                                     |
| ------ | ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| date   | [JulianDate](JulianDate.html) | The time at which to compute the rotation matrix.                                                                               |
| result | [Matrix3](Matrix3.html)       | optional The object onto which to store the result. If this parameter is not specified, a new instance is created and returned. |

##### Returns:

 The rotation matrix, or undefined if the data necessary to do the transformation is not yet loaded.

##### Example:

```javascript
// Set the default ICRF to fixed transformation to that of the Moon.
Cesium.Transforms.computeIcrfToCentralBodyFixedMatrix = Cesium.Transforms.computeIcrfToMoonFixedMatrix;
```

##### See:

* [Transforms.computeIcrfToFixedMatrix](Transforms.html#.computeIcrfToFixedMatrix)
* [Transforms.computeTemeToPseudoFixedMatrix](Transforms.html#.computeTemeToPseudoFixedMatrix)
* [Transforms.computeIcrfToMoonFixedMatrix](Transforms.html#.computeIcrfToMoonFixedMatrix)

#### [](#.computeIcrfToFixedMatrix) static Cesium.Transforms.computeIcrfToFixedMatrix(date, result) → [Matrix3](Matrix3.html)|undefined 

[engine/Source/Core/Transforms.js 738](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L738) 

 Computes a rotation matrix to transform a point or vector from the International Celestial Reference Frame (GCRF/ICRF) inertial frame axes to the Earth-Fixed frame axes (ITRF) at a given time. This function may return undefined if the data necessary to do the transformation is not yet loaded.

| Name   | Type                          | Description                                                                                                                     |
| ------ | ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| date   | [JulianDate](JulianDate.html) | The time at which to compute the rotation matrix.                                                                               |
| result | [Matrix3](Matrix3.html)       | optional The object onto which to store the result. If this parameter is not specified, a new instance is created and returned. |

##### Returns:

 The rotation matrix, or undefined if the data necessary to do the transformation is not yet loaded.

##### Example:

```javascript
scene.postUpdate.addEventListener(function(scene, time) {
  // View in ICRF.
  const icrfToFixed = Cesium.Transforms.computeIcrfToFixedMatrix(time);
  if (Cesium.defined(icrfToFixed)) {
    const offset = Cesium.Cartesian3.clone(camera.position);
    const transform = Cesium.Matrix4.fromRotationTranslation(icrfToFixed);
    camera.lookAtTransform(transform, offset);
  }
});
```

##### See:

* [Transforms.preloadIcrfFixed](Transforms.html#.preloadIcrfFixed)

#### [](#.computeIcrfToMoonFixedMatrix) static Cesium.Transforms.computeIcrfToMoonFixedMatrix(date, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Transforms.js 844](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L844) 

 Computes a rotation matrix to transform a point or vector from the International Celestial Reference Frame (GCRF/ICRF) inertial frame axes to the Moon-Fixed frame axes at a given time.

| Name   | Type                          | Description                                                                                                                     |
| ------ | ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| date   | [JulianDate](JulianDate.html) | The time at which to compute the rotation matrix.                                                                               |
| result | [Matrix3](Matrix3.html)       | optional The object onto which to store the result. If this parameter is not specified, a new instance is created and returned. |

##### Returns:

 The rotation matrix.

##### Example:

```javascript
// Set the default ICRF to fixed transformation to that of the Moon.
Cesium.Transforms.computeIcrfToCentralBodyFixedMatrix = Cesium.Transforms.computeIcrfToMoonFixedMatrix;
```

#### [](#.computeMoonFixedToIcrfMatrix) static Cesium.Transforms.computeMoonFixedToIcrfMatrix(date, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Transforms.js 782](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L782) 

 Computes a rotation matrix to transform a point or vector from the Moon-Fixed frame axes to the International Celestial Reference Frame (GCRF/ICRF) inertial frame axes at a given time.

| Name   | Type                          | Description                                                                                                                     |
| ------ | ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| date   | [JulianDate](JulianDate.html) | The time at which to compute the rotation matrix.                                                                               |
| result | [Matrix3](Matrix3.html)       | optional The object onto which to store the result. If this parameter is not specified, a new instance is created and returned. |

##### Returns:

 The rotation matrix.

##### Example:

```javascript
// Transform a point from the Fixed axes to the ICRF axes.
const now = Cesium.JulianDate.now();
const pointInFixed = Cesium.Cartesian3.fromDegrees(0.0, 0.0);
const fixedToIcrf = Cesium.Transforms.computeMoonFixedToIcrfMatrix(now);
let pointInInertial = new Cesium.Cartesian3();
if (Cesium.defined(fixedToIcrf)) {
    pointInInertial = Cesium.Matrix3.multiplyByVector(fixedToIcrf, pointInFixed, pointInInertial);
}
```

#### [](#.computeTemeToPseudoFixedMatrix) static Cesium.Transforms.computeTemeToPseudoFixedMatrix(date, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Transforms.js 587](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L587) 

 Computes a rotation matrix to transform a point or vector from True Equator Mean Equinox (TEME) axes to the pseudo-fixed axes at a given time. This method treats the UT1 time standard as equivalent to UTC.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| date   | [JulianDate](JulianDate.html) | The time at which to compute the rotation matrix.   |
| result | [Matrix3](Matrix3.html)       | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Matrix3 instance if none was provided.

##### Example:

```javascript
//Set the view to the inertial frame.
scene.postUpdate.addEventListener(function(scene, time) {
   const now = Cesium.JulianDate.now();
   const offset = Cesium.Matrix4.multiplyByPoint(camera.transform, camera.position, new Cesium.Cartesian3());
   const transform = Cesium.Matrix4.fromRotationTranslation(Cesium.Transforms.computeTemeToPseudoFixedMatrix(now));
   const inverseTransform = Cesium.Matrix4.inverseTransformation(transform, new Cesium.Matrix4());
   Cesium.Matrix4.multiplyByPoint(inverseTransform, offset, offset);
   camera.lookAtTransform(transform, offset);
});
```

#### [](#.eastNorthUpToFixedFrame) static Cesium.Transforms.eastNorthUpToFixedFrame(origin, ellipsoid, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Transforms.js 277](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L277) 

 Computes a 4x4 transformation matrix from a reference frame with an east-north-up axes centered at the provided origin to the provided ellipsoid's fixed reference frame. The local axes are defined as:
* The `x` axis points in the local east direction.
* The `y` axis points in the local north direction.
* The `z` axis points in the direction of the ellipsoid surface normal which passes through the position.

| Name      | Type                          | Default           | Description                                                             |
| --------- | ----------------------------- | ----------------- | ----------------------------------------------------------------------- |
| origin    | [Cartesian3](Cartesian3.html) |                   | The center point of the local reference frame.                          |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | Ellipsoid.default | optional The ellipsoid whose fixed frame is used in the transformation. |
| result    | [Matrix4](Matrix4.html)       |                   | optional The object onto which to store the result.                     |

##### Returns:

 The modified result parameter or a new Matrix4 instance if none was provided.

##### Example:

```javascript
// Get the transform from local east-north-up at cartographic (0.0, 0.0) to Earth's fixed frame.
const center = Cesium.Cartesian3.fromDegrees(0.0, 0.0);
const transform = Cesium.Transforms.eastNorthUpToFixedFrame(center);
```

#### [](#.fixedFrameToHeadingPitchRoll) static Cesium.Transforms.fixedFrameToHeadingPitchRoll(transform, ellipsoid, fixedFrameTransform, result) → [HeadingPitchRoll](HeadingPitchRoll.html) 

[engine/Source/Core/Transforms.js 480](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L480) 

 Computes heading-pitch-roll angles from a transform in a particular reference frame. Heading is the rotation from the local east direction where a positive angle is increasing eastward. Pitch is the rotation from the local east-north plane. Positive pitch angles are above the plane. Negative pitch angles are below the plane. Roll is the first rotation applied about the local east axis.

| Name                | Type                                                                         | Default                            | Description                                                                                                   |
| ------------------- | ---------------------------------------------------------------------------- | ---------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| transform           | [Matrix4](Matrix4.html)                                                      |                                    | The transform                                                                                                 |
| ellipsoid           | [Ellipsoid](Ellipsoid.html)                                                  | Ellipsoid.default                  | optional The ellipsoid whose fixed frame is used in the transformation.                                       |
| fixedFrameTransform | [Transforms.LocalFrameToFixedFrame](Transforms.html#.LocalFrameToFixedFrame) | Transforms.eastNorthUpToFixedFrame | optional A 4x4 transformation matrix from a reference frame to the provided ellipsoid's fixed reference frame |
| result              | [HeadingPitchRoll](HeadingPitchRoll.html)                                    |                                    | optional The object onto which to store the result.                                                           |

##### Returns:

 The modified result parameter or a new HeadingPitchRoll instance if none was provided.

#### [](#.headingPitchRollQuaternion) static Cesium.Transforms.headingPitchRollQuaternion(origin, headingPitchRoll, ellipsoid, fixedFrameTransform, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Transforms.js 440](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L440) 

 Computes a quaternion from a reference frame with axes computed from the heading-pitch-roll angles centered at the provided origin. Heading is the rotation from the local east direction where a positive angle is increasing eastward. Pitch is the rotation from the local east-north plane. Positive pitch angles are above the plane. Negative pitch angles are below the plane. Roll is the first rotation applied about the local east axis.

| Name                | Type                                                                         | Default                            | Description                                                                                                   |
| ------------------- | ---------------------------------------------------------------------------- | ---------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| origin              | [Cartesian3](Cartesian3.html)                                                |                                    | The center point of the local reference frame.                                                                |
| headingPitchRoll    | [HeadingPitchRoll](HeadingPitchRoll.html)                                    |                                    | The heading, pitch, and roll.                                                                                 |
| ellipsoid           | [Ellipsoid](Ellipsoid.html)                                                  | Ellipsoid.default                  | optional The ellipsoid whose fixed frame is used in the transformation.                                       |
| fixedFrameTransform | [Transforms.LocalFrameToFixedFrame](Transforms.html#.LocalFrameToFixedFrame) | Transforms.eastNorthUpToFixedFrame | optional A 4x4 transformation matrix from a reference frame to the provided ellipsoid's fixed reference frame |
| result              | [Quaternion](Quaternion.html)                                                |                                    | optional The object onto which to store the result.                                                           |

##### Returns:

 The modified result parameter or a new Quaternion instance if none was provided.

##### Example:

```javascript
// Get the quaternion from local heading-pitch-roll at cartographic (0.0, 0.0) to Earth's fixed frame.
const center = Cesium.Cartesian3.fromDegrees(0.0, 0.0);
const heading = -Cesium.Math.PI_OVER_TWO;
const pitch = Cesium.Math.PI_OVER_FOUR;
const roll = 0.0;
const hpr = new HeadingPitchRoll(heading, pitch, roll);
const quaternion = Cesium.Transforms.headingPitchRollQuaternion(center, hpr);
```

#### [](#.headingPitchRollToFixedFrame) static Cesium.Transforms.headingPitchRollToFixedFrame(origin, headingPitchRoll, ellipsoid, fixedFrameTransform, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Transforms.js 385](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L385) 

 Computes a 4x4 transformation matrix from a reference frame with axes computed from the heading-pitch-roll angles centered at the provided origin to the provided ellipsoid's fixed reference frame. Heading is the rotation from the local east direction where a positive angle is increasing eastward. Pitch is the rotation from the local east-north plane. Positive pitch angles are above the plane. Negative pitch angles are below the plane. Roll is the first rotation applied about the local east axis.

| Name                | Type                                                                         | Default                            | Description                                                                                                   |
| ------------------- | ---------------------------------------------------------------------------- | ---------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| origin              | [Cartesian3](Cartesian3.html)                                                |                                    | The center point of the local reference frame.                                                                |
| headingPitchRoll    | [HeadingPitchRoll](HeadingPitchRoll.html)                                    |                                    | The heading, pitch, and roll.                                                                                 |
| ellipsoid           | [Ellipsoid](Ellipsoid.html)                                                  | Ellipsoid.default                  | optional The ellipsoid whose fixed frame is used in the transformation.                                       |
| fixedFrameTransform | [Transforms.LocalFrameToFixedFrame](Transforms.html#.LocalFrameToFixedFrame) | Transforms.eastNorthUpToFixedFrame | optional A 4x4 transformation matrix from a reference frame to the provided ellipsoid's fixed reference frame |
| result              | [Matrix4](Matrix4.html)                                                      |                                    | optional The object onto which to store the result.                                                           |

##### Returns:

 The modified result parameter or a new Matrix4 instance if none was provided.

##### Example:

```javascript
// Get the transform from local heading-pitch-roll at cartographic (0.0, 0.0) to Earth's fixed frame.
const center = Cesium.Cartesian3.fromDegrees(0.0, 0.0);
const heading = -Cesium.Math.PI_OVER_TWO;
const pitch = Cesium.Math.PI_OVER_FOUR;
const roll = 0.0;
const hpr = new Cesium.HeadingPitchRoll(heading, pitch, roll);
const transform = Cesium.Transforms.headingPitchRollToFixedFrame(center, hpr);
```

#### [](#.localFrameToFixedFrameGenerator) static Cesium.Transforms.localFrameToFixedFrameGenerator(firstAxis, secondAxis) → [Transforms.LocalFrameToFixedFrame](Transforms.html#.LocalFrameToFixedFrame) 

[engine/Source/Core/Transforms.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L100) 

 Generates a function that computes a 4x4 transformation matrix from a reference frame centered at the provided origin to the provided ellipsoid's fixed reference frame.

| Name       | Type   | Description                                                                                                     |
| ---------- | ------ | --------------------------------------------------------------------------------------------------------------- |
| firstAxis  | string | name of the first axis of the local reference frame. Must be 'east', 'north', 'up', 'west', 'south' or 'down'.  |
| secondAxis | string | name of the second axis of the local reference frame. Must be 'east', 'north', 'up', 'west', 'south' or 'down'. |

##### Returns:

 The function that will computes a 4x4 transformation matrix from a reference frame, with first axis and second axis compliant with the parameters,

#### [](#.northEastDownToFixedFrame) static Cesium.Transforms.northEastDownToFixedFrame(origin, ellipsoid, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Transforms.js 303](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L303) 

 Computes a 4x4 transformation matrix from a reference frame with an north-east-down axes centered at the provided origin to the provided ellipsoid's fixed reference frame. The local axes are defined as:
* The `x` axis points in the local north direction.
* The `y` axis points in the local east direction.
* The `z` axis points in the opposite direction of the ellipsoid surface normal which passes through the position.

| Name      | Type                          | Default           | Description                                                             |
| --------- | ----------------------------- | ----------------- | ----------------------------------------------------------------------- |
| origin    | [Cartesian3](Cartesian3.html) |                   | The center point of the local reference frame.                          |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | Ellipsoid.default | optional The ellipsoid whose fixed frame is used in the transformation. |
| result    | [Matrix4](Matrix4.html)       |                   | optional The object onto which to store the result.                     |

##### Returns:

 The modified result parameter or a new Matrix4 instance if none was provided.

##### Example:

```javascript
// Get the transform from local north-east-down at cartographic (0.0, 0.0) to Earth's fixed frame.
const center = Cesium.Cartesian3.fromDegrees(0.0, 0.0);
const transform = Cesium.Transforms.northEastDownToFixedFrame(center);
```

#### [](#.northUpEastToFixedFrame) static Cesium.Transforms.northUpEastToFixedFrame(origin, ellipsoid, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Transforms.js 327](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L327) 

 Computes a 4x4 transformation matrix from a reference frame with an north-up-east axes centered at the provided origin to the provided ellipsoid's fixed reference frame. The local axes are defined as:
* The `x` axis points in the local north direction.
* The `y` axis points in the direction of the ellipsoid surface normal which passes through the position.
* The `z` axis points in the local east direction.

| Name      | Type                          | Default           | Description                                                             |
| --------- | ----------------------------- | ----------------- | ----------------------------------------------------------------------- |
| origin    | [Cartesian3](Cartesian3.html) |                   | The center point of the local reference frame.                          |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | Ellipsoid.default | optional The ellipsoid whose fixed frame is used in the transformation. |
| result    | [Matrix4](Matrix4.html)       |                   | optional The object onto which to store the result.                     |

##### Returns:

 The modified result parameter or a new Matrix4 instance if none was provided.

##### Example:

```javascript
// Get the transform from local north-up-east at cartographic (0.0, 0.0) to Earth's fixed frame.
const center = Cesium.Cartesian3.fromDegrees(0.0, 0.0);
const transform = Cesium.Transforms.northUpEastToFixedFrame(center);
```

#### [](#.northWestUpToFixedFrame) static Cesium.Transforms.northWestUpToFixedFrame(origin, ellipsoid, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Transforms.js 353](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L353) 

 Computes a 4x4 transformation matrix from a reference frame with an north-west-up axes centered at the provided origin to the provided ellipsoid's fixed reference frame. The local axes are defined as:
* The `x` axis points in the local north direction.
* The `y` axis points in the local west direction.
* The `z` axis points in the direction of the ellipsoid surface normal which passes through the position.

| Name      | Type                          | Default           | Description                                                             |
| --------- | ----------------------------- | ----------------- | ----------------------------------------------------------------------- |
| origin    | [Cartesian3](Cartesian3.html) |                   | The center point of the local reference frame.                          |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | Ellipsoid.default | optional The ellipsoid whose fixed frame is used in the transformation. |
| result    | [Matrix4](Matrix4.html)       |                   | optional The object onto which to store the result.                     |

##### Returns:

 The modified result parameter or a new Matrix4 instance if none was provided.

##### Example:

```javascript
// Get the transform from local north-West-Up at cartographic (0.0, 0.0) to Earth's fixed frame.
const center = Cesium.Cartesian3.fromDegrees(0.0, 0.0);
const transform = Cesium.Transforms.northWestUpToFixedFrame(center);
```

#### [](#.pointToWindowCoordinates) static Cesium.Transforms.pointToWindowCoordinates(modelViewProjectionMatrix, viewportTransformation, point, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Transforms.js 1022](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L1022) 

 Transform a point from model coordinates to window coordinates.

| Name                      | Type                          | Description                                         |
| ------------------------- | ----------------------------- | --------------------------------------------------- |
| modelViewProjectionMatrix | [Matrix4](Matrix4.html)       | The 4x4 model-view-projection matrix.               |
| viewportTransformation    | [Matrix4](Matrix4.html)       | The 4x4 viewport transformation.                    |
| point                     | [Cartesian3](Cartesian3.html) | The point to transform.                             |
| result                    | [Cartesian2](Cartesian2.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian2 instance if none was provided.

#### [](#.preloadIcrfFixed) static Cesium.Transforms.preloadIcrfFixed(timeInterval) → Promise.<void> 

[engine/Source/Core/Transforms.js 698](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L698) 

 Preloads the data necessary to transform between the ICRF and Fixed axes, in either direction, over a given interval. This function returns a promise that, when resolved, indicates that the preload has completed.

| Name         | Type                              | Description              |
| ------------ | --------------------------------- | ------------------------ |
| timeInterval | [TimeInterval](TimeInterval.html) | The interval to preload. |

##### Returns:

 A promise that, when resolved, indicates that the preload has completed and evaluation of the transformation between the fixed and ICRF axes will no longer return undefined for a time inside the interval.

##### Example:

```javascript
const interval = new Cesium.TimeInterval(...);
await Cesium.Transforms.preloadIcrfFixed(interval));
// the data is now loaded
```

##### See:

* [Transforms.computeIcrfToFixedMatrix](Transforms.html#.computeIcrfToFixedMatrix)
* [Transforms.computeFixedToIcrfMatrix](Transforms.html#.computeFixedToIcrfMatrix)

#### [](#.rotationMatrixFromPositionVelocity) static Cesium.Transforms.rotationMatrixFromPositionVelocity(position, velocity, ellipsoid, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Transforms.js 1090](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L1090) 

 Transform a position and velocity to a rotation matrix.

| Name      | Type                          | Default           | Description                                                             |
| --------- | ----------------------------- | ----------------- | ----------------------------------------------------------------------- |
| position  | [Cartesian3](Cartesian3.html) |                   | The position to transform.                                              |
| velocity  | [Cartesian3](Cartesian3.html) |                   | The velocity vector to transform.                                       |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | Ellipsoid.default | optional The ellipsoid whose fixed frame is used in the transformation. |
| result    | [Matrix3](Matrix3.html)       |                   | optional The object onto which to store the result.                     |

##### Returns:

 The modified result parameter or a new Matrix3 instance if none was provided.

### Type Definitions

#### [](#.LocalFrameToFixedFrame) Cesium.Transforms.LocalFrameToFixedFrame(origin, ellipsoid, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Transforms.js 111](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Transforms.js#L111) 

 Computes a 4x4 transformation matrix from a reference frame centered at the provided origin to the provided ellipsoid's fixed reference frame.

| Name      | Type                          | Default           | Description                                                             |
| --------- | ----------------------------- | ----------------- | ----------------------------------------------------------------------- |
| origin    | [Cartesian3](Cartesian3.html) |                   | The center point of the local reference frame.                          |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | Ellipsoid.default | optional The ellipsoid whose fixed frame is used in the transformation. |
| result    | [Matrix4](Matrix4.html)       |                   | optional The object onto which to store the result.                     |

##### Returns:

 The modified result parameter or a new Matrix4 instance if none was provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

