# [![](Images/CesiumLogo.png)](index.html) Particle 

#### [](#Particle) new Cesium.Particle(options) 

[engine/Source/Scene/Particle.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L27) 

 A particle emitted by a [ParticleSystem](ParticleSystem.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | An object with the following properties: Name Type Default Description mass number 1.0 optional The mass of the particle in kilograms. position [Cartesian3](Cartesian3.html) Cartesian3.ZERO optional The initial position of the particle in world coordinates. velocity [Cartesian3](Cartesian3.html) Cartesian3.ZERO optional The velocity vector of the particle in world coordinates. life number Number.MAX\_VALUE optional The life of the particle in seconds. image object optional The URI, HTMLImageElement, or HTMLCanvasElement to use for the billboard. startColor [Color](Color.html) Color.WHITE optional The color of a particle when it is born. endColor [Color](Color.html) Color.WHITE optional The color of a particle when it dies. startScale number 1.0 optional The scale of the particle when it is born. endScale number 1.0 optional The scale of the particle when it dies. imageSize [Cartesian2](Cartesian2.html) new Cartesian2(1.0, 1.0) optional The dimensions, width by height, to scale the particle image in pixels. |

### Members

#### [](#age) age : number 

[engine/Source/Scene/Particle.js 110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L110) 

 Gets the age of the particle in seconds.

#### [](#endColor) endColor : [Color](Color.html) 

[engine/Source/Scene/Particle.js 75](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L75) 

 The color of the particle when it dies.

Default Value: `Color.WHITE` 

#### [](#endScale) endScale : number 

[engine/Source/Scene/Particle.js 87](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L87) 

 The scale of the particle when it dies.

Default Value: `1.0` 

#### [](#image) image : object 

[engine/Source/Scene/Particle.js 63](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L63) 

 The image to use for the particle.

Default Value: `undefined` 

#### [](#imageSize) imageSize : [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/Particle.js 93](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L93) 

 The dimensions, width by height, to scale the particle image in pixels.

Default Value: `new Cartesian(1.0, 1.0)` 

#### [](#life) life : number 

[engine/Source/Scene/Particle.js 57](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L57) 

 The life of the particle in seconds.

Default Value: `Number.MAX_VALUE` 

#### [](#mass) mass : number 

[engine/Source/Scene/Particle.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L35) 

 The mass of the particle in kilograms.

Default Value: `1.0` 

#### [](#normalizedAge) normalizedAge : number 

[engine/Source/Scene/Particle.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L120) 

 Gets the age normalized to a value in the range \[0.0, 1.0\].

#### [](#position) position : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Particle.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L41) 

 The positon of the particle in world coordinates.

Default Value: `Cartesian3.ZERO` 

#### [](#startColor) startColor : [Color](Color.html) 

[engine/Source/Scene/Particle.js 69](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L69) 

 The color of the particle when it is born.

Default Value: `Color.WHITE` 

#### [](#startScale) startScale : number 

[engine/Source/Scene/Particle.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L81) 

 the scale of the particle when it is born.

Default Value: `1.0` 

#### [](#velocity) velocity : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Particle.js 49](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Particle.js#L49) 

 The velocity of the particle in world coordinates.

Default Value: `Cartesian3.ZERO` 

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

