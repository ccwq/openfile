# [![](Images/CesiumLogo.png)](index.html) Cartesian2 

#### [](#Cartesian2) new Cesium.Cartesian2(x, y) 

[engine/Source/Core/Cartesian2.js 19](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L19) 

 A 2D Cartesian point.

| Name | Type   | Default | Description               |
| ---- | ------ | ------- | ------------------------- |
| x    | number | 0.0     | optional The X component. |
| y    | number | 0.0     | optional The Y component. |

##### See:

* [Cartesian3](Cartesian3.html)
* [Cartesian4](Cartesian4.html)
* [Packable](Packable.html)

### Members

#### [](#x) x : number 

[engine/Source/Core/Cartesian2.js 25](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L25) 

 The X component.

Default Value: `0.0` 

#### [](#y) y : number 

[engine/Source/Core/Cartesian2.js 32](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L32) 

 The Y component.

Default Value: `0.0` 

#### [](#.ONE) static constant Cesium.Cartesian2.ONE : [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 754](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L754) 

 An immutable Cartesian2 instance initialized to (1.0, 1.0).

#### [](#.packedLength) static Cesium.Cartesian2.packedLength : number 

[engine/Source/Core/Cartesian2.js 99](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L99) 

 The number of elements used to pack the object into an array.

#### [](#.UNIT%5FX) static constant Cesium.Cartesian2.UNIT\_X : [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 762](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L762) 

 An immutable Cartesian2 instance initialized to (1.0, 0.0).

#### [](#.UNIT%5FY) static constant Cesium.Cartesian2.UNIT\_Y : [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 770](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L770) 

 An immutable Cartesian2 instance initialized to (0.0, 1.0).

#### [](#.ZERO) static constant Cesium.Cartesian2.ZERO : [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 746](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L746) 

 An immutable Cartesian2 instance initialized to (0.0, 0.0).

### Methods

#### [](#clone) clone(result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 778](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L778) 

 Duplicates this Cartesian2 instance.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| result | [Cartesian2](Cartesian2.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian2 instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/Cartesian2.js 789](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L789) 

 Compares this Cartesian against the provided Cartesian componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                          | Description                             |
| ----- | ----------------------------- | --------------------------------------- |
| right | [Cartesian2](Cartesian2.html) | optional The right hand side Cartesian. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(right, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/Cartesian2.js 803](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L803) 

 Compares this Cartesian against the provided Cartesian componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                          | Default         | Description                                                          |
| --------------- | ----------------------------- | --------------- | -------------------------------------------------------------------- |
| right           | [Cartesian2](Cartesian2.html) |                 | optional The right hand side Cartesian.                              |
| relativeEpsilon | number                        | 0               | optional The relative epsilon tolerance to use for equality testing. |
| absoluteEpsilon | number                        | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if they are within the provided epsilon, `false` otherwise.

#### [](#toString) toString() → string 

[engine/Source/Core/Cartesian2.js 821](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L821) 

 Creates a string representing this Cartesian in the format '(x, y)'.

##### Returns:

 A string representing the provided Cartesian in the format '(x, y)'.

#### [](#.abs) static Cesium.Cartesian2.abs(cartesian, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 597](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L597) 

 Computes the absolute value of the provided Cartesian.

| Name      | Type                          | Description                                           |
| --------- | ----------------------------- | ----------------------------------------------------- |
| cartesian | [Cartesian2](Cartesian2.html) | The Cartesian whose absolute value is to be computed. |
| result    | [Cartesian2](Cartesian2.html) | The object onto which to store the result.            |

##### Returns:

 The modified result parameter.

#### [](#.add) static Cesium.Cartesian2.add(left, right, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 500](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L500) 

 Computes the componentwise sum of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian2](Cartesian2.html) | The first Cartesian.                       |
| right  | [Cartesian2](Cartesian2.html) | The second Cartesian.                      |
| result | [Cartesian2](Cartesian2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.angleBetween) static Cesium.Cartesian2.angleBetween(left, right) → number 

[engine/Source/Core/Cartesian2.js 640](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L640) 

 Returns the angle, in radians, between the provided Cartesians.

| Name  | Type                          | Description           |
| ----- | ----------------------------- | --------------------- |
| left  | [Cartesian2](Cartesian2.html) | The first Cartesian.  |
| right | [Cartesian2](Cartesian2.html) | The second Cartesian. |

##### Returns:

 The angle between the Cartesians.

#### [](#.clamp) static Cesium.Cartesian2.clamp(value, min, max, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 307](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L307) 

 Constrain a value to lie between two values.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| value  | [Cartesian2](Cartesian2.html) | The value to clamp.                        |
| min    | [Cartesian2](Cartesian2.html) | The minimum bound.                         |
| max    | [Cartesian2](Cartesian2.html) | The maximum bound.                         |
| result | [Cartesian2](Cartesian2.html) | The object into which to store the result. |

##### Returns:

 The clamped value such that min <= result <= max.

#### [](#.clone) static Cesium.Cartesian2.clone(cartesian, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L60) 

 Duplicates a Cartesian2 instance.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian2](Cartesian2.html) | The Cartesian to duplicate.                         |
| result    | [Cartesian2](Cartesian2.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian2 instance if one was not provided. (Returns undefined if cartesian is undefined)

#### [](#.cross) static Cesium.Cartesian2.cross(left, right) → number 

[engine/Source/Core/Cartesian2.js 443](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L443) 

 Computes the magnitude of the cross product that would result from implicitly setting the Z coordinate of the input vectors to 0

| Name  | Type                          | Description           |
| ----- | ----------------------------- | --------------------- |
| left  | [Cartesian2](Cartesian2.html) | The first Cartesian.  |
| right | [Cartesian2](Cartesian2.html) | The second Cartesian. |

##### Returns:

 The cross product.

#### [](#.distance) static Cesium.Cartesian2.distance(left, right) → number 

[engine/Source/Core/Cartesian2.js 361](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L361) 

 Computes the distance between two points.

| Name  | Type                          | Description                                   |
| ----- | ----------------------------- | --------------------------------------------- |
| left  | [Cartesian2](Cartesian2.html) | The first point to compute the distance from. |
| right | [Cartesian2](Cartesian2.html) | The second point to compute the distance to.  |

##### Returns:

 The distance between two points.

##### Example:

```javascript
// Returns 1.0
const d = Cesium.Cartesian2.distance(new Cesium.Cartesian2(1.0, 0.0), new Cesium.Cartesian2(2.0, 0.0));
```

#### [](#.distanceSquared) static Cesium.Cartesian2.distanceSquared(left, right) → number 

[engine/Source/Core/Cartesian2.js 383](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L383) 

 Computes the squared distance between two points. Comparing squared distances using this function is more efficient than comparing distances using `Cartesian2#distance`.

| Name  | Type                          | Description                                   |
| ----- | ----------------------------- | --------------------------------------------- |
| left  | [Cartesian2](Cartesian2.html) | The first point to compute the distance from. |
| right | [Cartesian2](Cartesian2.html) | The second point to compute the distance to.  |

##### Returns:

 The distance between two points.

##### Example:

```javascript
// Returns 4.0, not 2.0
const d = Cesium.Cartesian2.distance(new Cesium.Cartesian2(1.0, 0.0), new Cesium.Cartesian2(3.0, 0.0));
```

#### [](#.divideByScalar) static Cesium.Cartesian2.divideByScalar(cartesian, scalar, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 560](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L560) 

 Divides the provided Cartesian componentwise by the provided scalar.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian2](Cartesian2.html) | The Cartesian to be divided.               |
| scalar    | number                        | The scalar to divide by.                   |
| result    | [Cartesian2](Cartesian2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.divideComponents) static Cesium.Cartesian2.divideComponents(left, right, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 480](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L480) 

 Computes the componentwise quotient of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian2](Cartesian2.html) | The first Cartesian.                       |
| right  | [Cartesian2](Cartesian2.html) | The second Cartesian.                      |
| result | [Cartesian2](Cartesian2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.dot) static Cesium.Cartesian2.dot(left, right) → number 

[engine/Source/Core/Cartesian2.js 427](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L427) 

 Computes the dot (scalar) product of two Cartesians.

| Name  | Type                          | Description           |
| ----- | ----------------------------- | --------------------- |
| left  | [Cartesian2](Cartesian2.html) | The first Cartesian.  |
| right | [Cartesian2](Cartesian2.html) | The second Cartesian. |

##### Returns:

 The dot product.

#### [](#.equals) static Cesium.Cartesian2.equals(left, right) → boolean 

[engine/Source/Core/Cartesian2.js 687](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L687) 

 Compares the provided Cartesians componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                          | Description                    |
| ----- | ----------------------------- | ------------------------------ |
| left  | [Cartesian2](Cartesian2.html) | optional The first Cartesian.  |
| right | [Cartesian2](Cartesian2.html) | optional The second Cartesian. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.equalsEpsilon) static Cesium.Cartesian2.equalsEpsilon(left, right, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/Cartesian2.js 715](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L715) 

 Compares the provided Cartesians componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                          | Default         | Description                                                          |
| --------------- | ----------------------------- | --------------- | -------------------------------------------------------------------- |
| left            | [Cartesian2](Cartesian2.html) |                 | optional The first Cartesian.                                        |
| right           | [Cartesian2](Cartesian2.html) |                 | optional The second Cartesian.                                       |
| relativeEpsilon | number                        | 0               | optional The relative epsilon tolerance to use for equality testing. |
| absoluteEpsilon | number                        | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if left and right are within the provided epsilon, `false` otherwise.

#### [](#.fromArray) static Cesium.Cartesian2.fromArray(array, startingIndex, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 227](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L227) 

 Creates a Cartesian2 from two consecutive elements in an array.

| Name          | Type                          | Default | Description                                                                                    |
| ------------- | ----------------------------- | ------- | ---------------------------------------------------------------------------------------------- |
| array         | Array.<number>                |         | The array whose two consecutive elements correspond to the x and y components, respectively.   |
| startingIndex | number                        | 0       | optional The offset into the array of the first element, which corresponds to the x component. |
| result        | [Cartesian2](Cartesian2.html) |         | optional The object onto which to store the result.                                            |

##### Returns:

 The modified result parameter or a new Cartesian2 instance if one was not provided.

##### Example:

```javascript
// Create a Cartesian2 with (1.0, 2.0)
const v = [1.0, 2.0];
const p = Cesium.Cartesian2.fromArray(v);

// Create a Cartesian2 with (1.0, 2.0) using an offset into an array
const v2 = [0.0, 0.0, 1.0, 2.0];
const p2 = Cesium.Cartesian2.fromArray(v2, 2);
```

#### [](#.fromCartesian3) static Cesium.Cartesian2.fromCartesian3(cartesian, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 82](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L82) 

 Creates a Cartesian2 instance from an existing Cartesian3\. This simply takes the x and y properties of the Cartesian3 and drops z.

| Name      | Type                          | Description                                                   |
| --------- | ----------------------------- | ------------------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian3 instance to create a Cartesian2 instance from. |
| result    | [Cartesian2](Cartesian2.html) | optional The object onto which to store the result.           |

##### Returns:

 The modified result parameter or a new Cartesian2 instance if one was not provided.

#### [](#.fromCartesian4) static Cesium.Cartesian2.fromCartesian4(cartesian, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 93](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L93) 

 Creates a Cartesian2 instance from an existing Cartesian4\. This simply takes the x and y properties of the Cartesian4 and drops z and w.

| Name      | Type                          | Description                                                   |
| --------- | ----------------------------- | ------------------------------------------------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian4 instance to create a Cartesian2 instance from. |
| result    | [Cartesian2](Cartesian2.html) | optional The object onto which to store the result.           |

##### Returns:

 The modified result parameter or a new Cartesian2 instance if one was not provided.

#### [](#.fromElements) static Cesium.Cartesian2.fromElements(x, y, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 43](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L43) 

 Creates a Cartesian2 instance from x and y coordinates.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| x      | number                        | The x coordinate.                                   |
| y      | number                        | The y coordinate.                                   |
| result | [Cartesian2](Cartesian2.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian2 instance if one was not provided.

#### [](#.lerp) static Cesium.Cartesian2.lerp(start, end, t, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 618](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L618) 

 Computes the linear interpolation or extrapolation at t using the provided cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| start  | [Cartesian2](Cartesian2.html) | The value corresponding to t at 0.0.       |
| end    | [Cartesian2](Cartesian2.html) | The value corresponding to t at 1.0.       |
| t      | number                        | The point along t at which to interpolate. |
| result | [Cartesian2](Cartesian2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.magnitude) static Cesium.Cartesian2.magnitude(cartesian) → number 

[engine/Source/Core/Cartesian2.js 344](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L344) 

 Computes the Cartesian's magnitude (length).

| Name      | Type                          | Description                                               |
| --------- | ----------------------------- | --------------------------------------------------------- |
| cartesian | [Cartesian2](Cartesian2.html) | The Cartesian instance whose magnitude is to be computed. |

##### Returns:

 The magnitude.

#### [](#.magnitudeSquared) static Cesium.Cartesian2.magnitudeSquared(cartesian) → number 

[engine/Source/Core/Cartesian2.js 330](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L330) 

 Computes the provided Cartesian's squared magnitude.

| Name      | Type                          | Description                                                       |
| --------- | ----------------------------- | ----------------------------------------------------------------- |
| cartesian | [Cartesian2](Cartesian2.html) | The Cartesian instance whose squared magnitude is to be computed. |

##### Returns:

 The squared magnitude.

#### [](#.maximumByComponent) static Cesium.Cartesian2.maximumByComponent(first, second, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 286](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L286) 

 Compares two Cartesians and computes a Cartesian which contains the maximum components of the supplied Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| first  | [Cartesian2](Cartesian2.html) | A cartesian to compare.                    |
| second | [Cartesian2](Cartesian2.html) | A cartesian to compare.                    |
| result | [Cartesian2](Cartesian2.html) | The object into which to store the result. |

##### Returns:

 A cartesian with the maximum components.

#### [](#.maximumComponent) static Cesium.Cartesian2.maximumComponent(cartesian) → number 

[engine/Source/Core/Cartesian2.js 235](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L235) 

 Computes the value of the maximum component for the supplied Cartesian.

| Name      | Type                          | Description           |
| --------- | ----------------------------- | --------------------- |
| cartesian | [Cartesian2](Cartesian2.html) | The cartesian to use. |

##### Returns:

 The value of the maximum component.

#### [](#.minimumByComponent) static Cesium.Cartesian2.minimumByComponent(first, second, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 265](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L265) 

 Compares two Cartesians and computes a Cartesian which contains the minimum components of the supplied Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| first  | [Cartesian2](Cartesian2.html) | A cartesian to compare.                    |
| second | [Cartesian2](Cartesian2.html) | A cartesian to compare.                    |
| result | [Cartesian2](Cartesian2.html) | The object into which to store the result. |

##### Returns:

 A cartesian with the minimum components.

#### [](#.minimumComponent) static Cesium.Cartesian2.minimumComponent(cartesian) → number 

[engine/Source/Core/Cartesian2.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L249) 

 Computes the value of the minimum component for the supplied Cartesian.

| Name      | Type                          | Description           |
| --------- | ----------------------------- | --------------------- |
| cartesian | [Cartesian2](Cartesian2.html) | The cartesian to use. |

##### Returns:

 The value of the minimum component.

#### [](#.mostOrthogonalAxis) static Cesium.Cartesian2.mostOrthogonalAxis(cartesian, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 661](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L661) 

 Returns the axis that is most orthogonal to the provided Cartesian.

| Name      | Type                          | Description                                              |
| --------- | ----------------------------- | -------------------------------------------------------- |
| cartesian | [Cartesian2](Cartesian2.html) | The Cartesian on which to find the most orthogonal axis. |
| result    | [Cartesian2](Cartesian2.html) | The object onto which to store the result.               |

##### Returns:

 The most orthogonal axis.

#### [](#.multiplyByScalar) static Cesium.Cartesian2.multiplyByScalar(cartesian, scalar, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 540](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L540) 

 Multiplies the provided Cartesian componentwise by the provided scalar.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian2](Cartesian2.html) | The Cartesian to be scaled.                |
| scalar    | number                        | The scalar to multiply with.               |
| result    | [Cartesian2](Cartesian2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiplyComponents) static Cesium.Cartesian2.multiplyComponents(left, right, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 460](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L460) 

 Computes the componentwise product of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian2](Cartesian2.html) | The first Cartesian.                       |
| right  | [Cartesian2](Cartesian2.html) | The second Cartesian.                      |
| result | [Cartesian2](Cartesian2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.negate) static Cesium.Cartesian2.negate(cartesian, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 579](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L579) 

 Negates the provided Cartesian.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian2](Cartesian2.html) | The Cartesian to be negated.               |
| result    | [Cartesian2](Cartesian2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.normalize) static Cesium.Cartesian2.normalize(cartesian, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 400](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L400) 

 Computes the normalized form of the supplied Cartesian.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian2](Cartesian2.html) | The Cartesian to be normalized.            |
| result    | [Cartesian2](Cartesian2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.pack) static Cesium.Cartesian2.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/Cartesian2.js 110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L110) 

 Stores the provided instance into the provided array.

| Name          | Type                          | Default | Description                                                               |
| ------------- | ----------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [Cartesian2](Cartesian2.html) |         | The value to pack.                                                        |
| array         | Array.<number>                |         | The array to pack into.                                                   |
| startingIndex | number                        | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.packArray) static Cesium.Cartesian2.packArray(array, result) → Array.<number> 

[engine/Source/Core/Cartesian2.js 154](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L154) 

 Flattens an array of Cartesian2s into an array of components.

| Name   | Type                                   | Description                                                                                                                                                                                                                                                             |
| ------ | -------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| array  | Array.<[Cartesian2](Cartesian2.html)\> | The array of cartesians to pack.                                                                                                                                                                                                                                        |
| result | Array.<number>                         | optional The array onto which to store the result. If this is a typed array, it must have array.length \* 2 components, else a [DeveloperError](DeveloperError.html) will be thrown. If it is a regular array, it will be resized to have (array.length \* 2) elements. |

##### Returns:

 The packed array.

#### [](#.subtract) static Cesium.Cartesian2.subtract(left, right, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 520](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L520) 

 Computes the componentwise difference of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian2](Cartesian2.html) | The first Cartesian.                       |
| right  | [Cartesian2](Cartesian2.html) | The second Cartesian.                      |
| result | [Cartesian2](Cartesian2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.unpack) static Cesium.Cartesian2.unpack(array, startingIndex, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Cartesian2.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L132) 

 Retrieves an instance from a packed array.

| Name          | Type                          | Default | Description                                                |
| ------------- | ----------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                |         | The packed array.                                          |
| startingIndex | number                        | 0       | optional The starting index of the element to be unpacked. |
| result        | [Cartesian2](Cartesian2.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new Cartesian2 instance if one was not provided.

#### [](#.unpackArray) static Cesium.Cartesian2.unpackArray(array, result) → Array.<[Cartesian2](Cartesian2.html)\> 

[engine/Source/Core/Cartesian2.js 186](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian2.js#L186) 

 Unpacks an array of cartesian components into an array of Cartesian2s.

| Name   | Type                                   | Description                                        |
| ------ | -------------------------------------- | -------------------------------------------------- |
| array  | Array.<number>                         | The array of components to unpack.                 |
| result | Array.<[Cartesian2](Cartesian2.html)\> | optional The array onto which to store the result. |

##### Returns:

 The unpacked array.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

