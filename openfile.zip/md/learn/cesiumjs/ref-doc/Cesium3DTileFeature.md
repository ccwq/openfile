# [![](Images/CesiumLogo.png)](index.html) Cesium3DTileFeature 

#### [](#Cesium3DTileFeature) new Cesium.Cesium3DTileFeature() 

[engine/Source/Scene/Cesium3DTileFeature.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L39) 

 A feature of a [Cesium3DTileset](Cesium3DTileset.html).

Provides access to a feature's properties stored in the tile's batch table, as well as the ability to show/hide a feature and change its highlight color via[Cesium3DTileFeature#show](Cesium3DTileFeature.html#show) and [Cesium3DTileFeature#color](Cesium3DTileFeature.html#color), respectively.

Modifications to a `Cesium3DTileFeature` object have the lifetime of the tile's content. If the tile's content is unloaded, e.g., due to it going out of view and needing to free space in the cache for visible tiles, listen to the [Cesium3DTileset#tileUnload](Cesium3DTileset.html#tileUnload) event to save any modifications. Also listen to the [Cesium3DTileset#tileVisible](Cesium3DTileset.html#tileVisible) event to reapply any modifications.

Do not construct this directly. Access it through [Cesium3DTileContent#getFeature](Cesium3DTileContent.html#getFeature)or picking using [Scene#pick](Scene.html#pick).

##### Example:

```javascript
// On mouse over, display all the properties for a feature in the console log.
handler.setInputAction(function(movement) {
    const feature = scene.pick(movement.endPosition);
    if (feature instanceof Cesium.Cesium3DTileFeature) {
        const propertyIds = feature.getPropertyIds();
        const length = propertyIds.length;
        for (let i = 0; i < length; ++i) {
            const propertyId = propertyIds[i];
            console.log(`{propertyId}: ${feature.getProperty(propertyId)}`);
        }
    }
}, Cesium.ScreenSpaceEventType.MOUSE_MOVE);
```

### Members

#### [](#color) color : [Color](Color.html) 

[engine/Source/Scene/Cesium3DTileFeature.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L76) 

 Gets or sets the highlight color multiplied with the feature's color. When this is white, the feature's color is not changed. This is set for all features when a style's color is evaluated.

Default Value: `[Color.WHITE](Color.html#.WHITE)` 

#### [](#featureId) readonly featureId : number 

[engine/Source/Scene/Cesium3DTileFeature.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L168) 

 Get the feature ID associated with this feature. For 3D Tiles 1.0, the batch ID is returned. For EXT\_mesh\_features, this is the feature ID from the selected feature ID set.

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#polylinePositions) polylinePositions : Float64Array 

[engine/Source/Scene/Cesium3DTileFeature.js 99](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L99) 

 Gets a typed array containing the ECEF positions of the polyline. Returns undefined if [Cesium3DTileset#vectorKeepDecodedPositions](Cesium3DTileset.html#vectorKeepDecodedPositions) is false or the feature is not a polyline in a vector tile.

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#primitive) readonly primitive : [Cesium3DTileset](Cesium3DTileset.html) 

[engine/Source/Scene/Cesium3DTileFeature.js 150](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L150) 

 All objects returned by [Scene#pick](Scene.html#pick) have a `primitive` property. This returns the tileset containing the feature.

#### [](#show) show : boolean 

[engine/Source/Scene/Cesium3DTileFeature.js 56](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L56) 

 Gets or sets if the feature will be shown. This is set for all features when a style's show is evaluated.

Default Value: `true` 

#### [](#tileset) readonly tileset : [Cesium3DTileset](Cesium3DTileset.html) 

[engine/Source/Scene/Cesium3DTileFeature.js 134](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L134) 

 Gets the tileset containing the feature.

### Methods

#### [](#.getPropertyInherited) static Cesium.Cesium3DTileFeature.getPropertyInherited(content, batchId, name) → \* 

[engine/Source/Scene/Cesium3DTileFeature.js 268](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L268) 

 Returns a copy of the feature's property with the given name, examining all the metadata from 3D Tiles 1.0 formats, the EXT\_structural\_metadata and legacy EXT\_feature\_metadata glTF extensions, and the metadata present either in the tileset JSON (3D Tiles 1.1) or in the 3DTILES\_metadata 3D Tiles extension. Metadata is checked against name from most specific to most general and the first match is returned. Metadata is checked in this order:
1. Batch table (structural metadata) property by semantic
2. Batch table (structural metadata) property by property ID
3. Content metadata property by semantic
4. Content metadata property by property
5. Tile metadata property by semantic
6. Tile metadata property by property ID
7. Subtree metadata property by semantic
8. Subtree metadata property by property ID
9. Group metadata property by semantic
10. Group metadata property by property ID
11. Tileset metadata property by semantic
12. Tileset metadata property by property ID
13. Otherwise, return undefined

For 3D Tiles Next details, see the [3DTILES\_metadata Extension](https://github.com/CesiumGS/3d-tiles/tree/main/extensions/3DTILES%5Fmetadata)for 3D Tiles, as well as the [EXT\_structural\_metadata Extension](https://github.com/CesiumGS/glTF/tree/3d-tiles-next/extensions/2.0/Vendor/EXT%5Fstructural%5Fmetadata)for glTF. For the legacy glTF extension, see [EXT\_feature\_metadata Extension](https://github.com/CesiumGS/glTF/tree/3d-tiles-next/extensions/2.0/Vendor/EXT%5Ffeature%5Fmetadata) 

| Name    | Type                                            | Description                                                                                                            |
| ------- | ----------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| content | [Cesium3DTileContent](Cesium3DTileContent.html) | The content for accessing the metadata                                                                                 |
| batchId | number                                          | The batch ID (or feature ID) of the feature to get a property for                                                      |
| name    | string                                          | The semantic or property ID of the feature. Semantics are checked before property IDs in each granularity of metadata. |

##### Returns:

 The value of the property or `undefined` if the feature does not have this property.

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#getProperty) getProperty(name) → \* 

[engine/Source/Scene/Cesium3DTileFeature.js 228](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L228) 

 Returns a copy of the value of the feature's property with the given name. This includes properties from this feature's class and inherited classes when using a batch table hierarchy.

| Name | Type   | Description                              |
| ---- | ------ | ---------------------------------------- |
| name | string | The case-sensitive name of the property. |

##### Returns:

 The value of the property or `undefined` if the feature does not have this property.

##### Example:

```javascript
// Display all the properties for a feature in the console log.
const propertyIds = feature.getPropertyIds();
const length = propertyIds.length;
for (let i = 0; i < length; ++i) {
    const propertyId = propertyIds[i];
    console.log(`{propertyId}: ${feature.getProperty(propertyId)}`);
}
```

##### See:

* <https://github.com/CesiumGS/3d-tiles/tree/main/extensions/3DTILES%5Fbatch%5Ftable%5Fhierarchy>

#### [](#getPropertyIds) getPropertyIds(results) → Array.<string> 

[engine/Source/Scene/Cesium3DTileFeature.js 206](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L206) 

 Returns an array of property IDs for the feature. This includes properties from this feature's class and inherited classes when using a batch table hierarchy.

| Name    | Type           | Description                                        |
| ------- | -------------- | -------------------------------------------------- |
| results | Array.<string> | optional An array into which to store the results. |

##### Returns:

 The IDs of the feature's properties.

##### See:

* <https://github.com/CesiumGS/3d-tiles/tree/main/extensions/3DTILES%5Fbatch%5Ftable%5Fhierarchy>

#### [](#hasProperty) hasProperty(name) → boolean 

[engine/Source/Scene/Cesium3DTileFeature.js 193](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L193) 

 Returns whether the feature contains this property. This includes properties from this feature's class and inherited classes when using a batch table hierarchy.

| Name | Type   | Description                              |
| ---- | ------ | ---------------------------------------- |
| name | string | The case-sensitive name of the property. |

##### Returns:

 Whether the feature contains this property.

##### See:

* <https://github.com/CesiumGS/3d-tiles/tree/main/extensions/3DTILES%5Fbatch%5Ftable%5Fhierarchy>

#### [](#setProperty) setProperty(name, value) 

[engine/Source/Scene/Cesium3DTileFeature.js 391](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileFeature.js#L391) 

 Sets the value of the feature's property with the given name.

If a property with the given name doesn't exist, it is created.

| Name  | Type   | Description                                    |
| ----- | ------ | ---------------------------------------------- |
| name  | string | The case-sensitive name of the property.       |
| value | \*     | The value of the property that will be copied. |

##### Throws:

* [DeveloperError](DeveloperError.html): Inherited batch table hierarchy property is read only.

##### Examples:

```javascript
const height = feature.getProperty('Height'); // e.g., the height of a building
```

```javascript
const name = 'clicked';
if (feature.getProperty(name)) {
    console.log('already clicked');
} else {
    feature.setProperty(name, true);
    console.log('first click');
}
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

