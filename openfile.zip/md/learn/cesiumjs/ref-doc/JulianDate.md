# [![](Images/CesiumLogo.png)](index.html) JulianDate 

#### [](#JulianDate) new Cesium.JulianDate(julianDayNumber, secondsOfDay, timeStandard) 

[engine/Source/Core/JulianDate.js 206](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L206) 

 Represents an astronomical Julian date, which is the number of days since noon on January 1, -4712 (4713 BC). For increased precision, this class stores the whole number part of the date and the seconds part of the date in separate components. In order to be safe for arithmetic and represent leap seconds, the date is always stored in the International Atomic Time standard[TimeStandard.TAI](global.html#TimeStandard#.TAI).

| Name            | Type                                     | Default          | Description                                                                                                                                                       |
| --------------- | ---------------------------------------- | ---------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| julianDayNumber | number                                   | 0.0              | optional The Julian Day Number representing the number of whole days. Fractional days will also be handled correctly.                                             |
| secondsOfDay    | number                                   | 0.0              | optional The number of seconds into the current Julian Day Number. Fractional seconds, negative seconds and seconds greater than a day will be handled correctly. |
| timeStandard    | [TimeStandard](global.html#TimeStandard) | TimeStandard.UTC | optional The time standard in which the first two parameters are defined.                                                                                         |

### Members

#### [](#.leapSeconds) static Cesium.JulianDate.leapSeconds : Array.<[LeapSecond](LeapSecond.html)\> 

[engine/Source/Core/JulianDate.js 1200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1200) 

 Gets or sets the list of leap seconds used throughout Cesium.

#### [](#dayNumber) dayNumber : number 

[engine/Source/Core/JulianDate.js 211](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L211) 

 Gets or sets the number of whole days.

#### [](#secondsOfDay) secondsOfDay : number 

[engine/Source/Core/JulianDate.js 217](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L217) 

 Gets or sets the number of seconds into the current day.

### Methods

#### [](#.addDays) static Cesium.JulianDate.addDays(julianDate, days, result) → [JulianDate](JulianDate.html) 

[engine/Source/Core/JulianDate.js 1091](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1091) 

 Adds the provided number of days to the provided date instance.

| Name       | Type                          | Description                                 |
| ---------- | ----------------------------- | ------------------------------------------- |
| julianDate | [JulianDate](JulianDate.html) | The date.                                   |
| days       | number                        | The number of days to add or subtract.      |
| result     | [JulianDate](JulianDate.html) | An existing instance to use for the result. |

##### Returns:

 The modified result parameter.

#### [](#.addHours) static Cesium.JulianDate.addHours(julianDate, hours, result) → [JulianDate](JulianDate.html) 

[engine/Source/Core/JulianDate.js 1065](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1065) 

 Adds the provided number of hours to the provided date instance.

| Name       | Type                          | Description                                 |
| ---------- | ----------------------------- | ------------------------------------------- |
| julianDate | [JulianDate](JulianDate.html) | The date.                                   |
| hours      | number                        | The number of hours to add or subtract.     |
| result     | [JulianDate](JulianDate.html) | An existing instance to use for the result. |

##### Returns:

 The modified result parameter.

#### [](#.addMinutes) static Cesium.JulianDate.addMinutes(julianDate, minutes, result) → [JulianDate](JulianDate.html) 

[engine/Source/Core/JulianDate.js 1039](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1039) 

 Adds the provided number of minutes to the provided date instance.

| Name       | Type                          | Description                                 |
| ---------- | ----------------------------- | ------------------------------------------- |
| julianDate | [JulianDate](JulianDate.html) | The date.                                   |
| minutes    | number                        | The number of minutes to add or subtract.   |
| result     | [JulianDate](JulianDate.html) | An existing instance to use for the result. |

##### Returns:

 The modified result parameter.

#### [](#.addSeconds) static Cesium.JulianDate.addSeconds(julianDate, seconds, result) → [JulianDate](JulianDate.html) 

[engine/Source/Core/JulianDate.js 1011](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1011) 

 Adds the provided number of seconds to the provided date instance.

| Name       | Type                          | Description                                 |
| ---------- | ----------------------------- | ------------------------------------------- |
| julianDate | [JulianDate](JulianDate.html) | The date.                                   |
| seconds    | number                        | The number of seconds to add or subtract.   |
| result     | [JulianDate](JulianDate.html) | An existing instance to use for the result. |

##### Returns:

 The modified result parameter.

#### [](#.clone) static Cesium.JulianDate.clone(julianDate, result) → [JulianDate](JulianDate.html) 

[engine/Source/Core/JulianDate.js 837](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L837) 

 Duplicates a JulianDate instance.

| Name       | Type                          | Description                                          |
| ---------- | ----------------------------- | ---------------------------------------------------- |
| julianDate | [JulianDate](JulianDate.html) | The date to duplicate.                               |
| result     | [JulianDate](JulianDate.html) | optional An existing instance to use for the result. |

##### Returns:

 The modified result parameter or a new instance if none was provided. Returns undefined if julianDate is undefined.

#### [](#.compare) static Cesium.JulianDate.compare(left, right) → number 

[engine/Source/Core/JulianDate.js 860](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L860) 

 Compares two instances.

| Name  | Type                          | Description          |
| ----- | ----------------------------- | -------------------- |
| left  | [JulianDate](JulianDate.html) | The first instance.  |
| right | [JulianDate](JulianDate.html) | The second instance. |

##### Returns:

 A negative value if left is less than right, a positive value if left is greater than right, or zero if left and right are equal.

#### [](#.computeTaiMinusUtc) static Cesium.JulianDate.computeTaiMinusUtc(julianDate) → number 

[engine/Source/Core/JulianDate.js 985](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L985) 

 Computes the number of seconds the provided instance is ahead of UTC.

| Name       | Type                          | Description |
| ---------- | ----------------------------- | ----------- |
| julianDate | [JulianDate](JulianDate.html) | The date.   |

##### Returns:

 The number of seconds the provided instance is ahead of UTC

#### [](#.daysDifference) static Cesium.JulianDate.daysDifference(left, right) → number 

[engine/Source/Core/JulianDate.js 963](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L963) 

 Computes the difference in days between the provided instance.

| Name  | Type                          | Description          |
| ----- | ----------------------------- | -------------------- |
| left  | [JulianDate](JulianDate.html) | The first instance.  |
| right | [JulianDate](JulianDate.html) | The second instance. |

##### Returns:

 The difference, in days, when subtracting `right` from `left`.

#### [](#.equals) static Cesium.JulianDate.equals(left, right) → boolean 

[engine/Source/Core/JulianDate.js 884](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L884) 

 Compares two instances and returns `true` if they are equal, `false` otherwise.

| Name  | Type                          | Description                   |
| ----- | ----------------------------- | ----------------------------- |
| left  | [JulianDate](JulianDate.html) | optional The first instance.  |
| right | [JulianDate](JulianDate.html) | optional The second instance. |

##### Returns:

`true` if the dates are equal; otherwise, `false`.

#### [](#.equalsEpsilon) static Cesium.JulianDate.equalsEpsilon(left, right, epsilon) → boolean 

[engine/Source/Core/JulianDate.js 905](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L905) 

 Compares two instances and returns `true` if they are within `epsilon` seconds of each other. That is, in order for the dates to be considered equal (and for this function to return `true`), the absolute value of the difference between them, in seconds, must be less than `epsilon`.

| Name    | Type                          | Default | Description                                                                    |
| ------- | ----------------------------- | ------- | ------------------------------------------------------------------------------ |
| left    | [JulianDate](JulianDate.html) |         | optional The first instance.                                                   |
| right   | [JulianDate](JulianDate.html) |         | optional The second instance.                                                  |
| epsilon | number                        | 0       | optional The maximum number of seconds that should separate the two instances. |

##### Returns:

`true` if the two dates are within `epsilon` seconds of each other; otherwise `false`.

#### [](#.fromDate) static Cesium.JulianDate.fromDate(date, result) → [JulianDate](JulianDate.html) 

[engine/Source/Core/JulianDate.js 278](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L278) 

 Creates a new instance from a JavaScript Date.

| Name   | Type                          | Description                                          |
| ------ | ----------------------------- | ---------------------------------------------------- |
| date   | Date                          | A JavaScript Date.                                   |
| result | [JulianDate](JulianDate.html) | optional An existing instance to use for the result. |

##### Returns:

 The modified result parameter or a new instance if none was provided.

##### Throws:

* [DeveloperError](DeveloperError.html): date must be a valid JavaScript Date.

#### [](#.fromGregorianDate) static Cesium.JulianDate.fromGregorianDate(date, result) → [JulianDate](JulianDate.html) 

[engine/Source/Core/JulianDate.js 245](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L245) 

 Creates a new instance from a GregorianDate.

| Name   | Type                                | Description                                          |
| ------ | ----------------------------------- | ---------------------------------------------------- |
| date   | [GregorianDate](GregorianDate.html) | A GregorianDate.                                     |
| result | [JulianDate](JulianDate.html)       | optional An existing instance to use for the result. |

##### Returns:

 The modified result parameter or a new instance if none was provided.

##### Throws:

* [DeveloperError](DeveloperError.html): date must be a valid GregorianDate.

#### [](#.fromIso8601) static Cesium.JulianDate.fromIso8601(iso8601String, result) → [JulianDate](JulianDate.html) 

[engine/Source/Core/JulianDate.js 313](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L313) 

 Creates a new instance from a from an [ISO 8601](http://en.wikipedia.org/wiki/ISO%5F8601) date. This method is superior to `Date.parse` because it will handle all valid formats defined by the ISO 8601 specification, including leap seconds and sub-millisecond times, which discarded by most JavaScript implementations.

| Name          | Type                          | Description                                          |
| ------------- | ----------------------------- | ---------------------------------------------------- |
| iso8601String | string                        | An ISO 8601 date.                                    |
| result        | [JulianDate](JulianDate.html) | optional An existing instance to use for the result. |

##### Returns:

 The modified result parameter or a new instance if none was provided.

##### Throws:

* [DeveloperError](DeveloperError.html): Invalid ISO 8601 date.

#### [](#.greaterThan) static Cesium.JulianDate.greaterThan(left, right) → boolean 

[engine/Source/Core/JulianDate.js 1137](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1137) 

 Compares the provided instances and returns `true` if `left` is later than `right`, `false` otherwise.

| Name  | Type                          | Description          |
| ----- | ----------------------------- | -------------------- |
| left  | [JulianDate](JulianDate.html) | The first instance.  |
| right | [JulianDate](JulianDate.html) | The second instance. |

##### Returns:

`true` if `left` is later than `right`, `false` otherwise.

#### [](#.greaterThanOrEquals) static Cesium.JulianDate.greaterThanOrEquals(left, right) → boolean 

[engine/Source/Core/JulianDate.js 1148](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1148) 

 Compares the provided instances and returns `true` if `left` is later than or equal to `right`, `false` otherwise.

| Name  | Type                          | Description          |
| ----- | ----------------------------- | -------------------- |
| left  | [JulianDate](JulianDate.html) | The first instance.  |
| right | [JulianDate](JulianDate.html) | The second instance. |

##### Returns:

`true` if `left` is later than or equal to `right`, `false` otherwise.

#### [](#.lessThan) static Cesium.JulianDate.lessThan(left, right) → boolean 

[engine/Source/Core/JulianDate.js 1115](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1115) 

 Compares the provided instances and returns `true` if `left` is earlier than `right`, `false` otherwise.

| Name  | Type                          | Description          |
| ----- | ----------------------------- | -------------------- |
| left  | [JulianDate](JulianDate.html) | The first instance.  |
| right | [JulianDate](JulianDate.html) | The second instance. |

##### Returns:

`true` if `left` is earlier than `right`, `false` otherwise.

#### [](#.lessThanOrEquals) static Cesium.JulianDate.lessThanOrEquals(left, right) → boolean 

[engine/Source/Core/JulianDate.js 1126](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1126) 

 Compares the provided instances and returns `true` if `left` is earlier than or equal to `right`, `false` otherwise.

| Name  | Type                          | Description          |
| ----- | ----------------------------- | -------------------- |
| left  | [JulianDate](JulianDate.html) | The first instance.  |
| right | [JulianDate](JulianDate.html) | The second instance. |

##### Returns:

`true` if `left` is earlier than or equal to `right`, `false` otherwise.

#### [](#.now) static Cesium.JulianDate.now(result) → [JulianDate](JulianDate.html) 

[engine/Source/Core/JulianDate.js 615](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L615) 

 Creates a new instance that represents the current system time. This is equivalent to calling `JulianDate.fromDate(new Date());`.

| Name   | Type                          | Description                                          |
| ------ | ----------------------------- | ---------------------------------------------------- |
| result | [JulianDate](JulianDate.html) | optional An existing instance to use for the result. |

##### Returns:

 The modified result parameter or a new instance if none was provided.

#### [](#.secondsDifference) static Cesium.JulianDate.secondsDifference(left, right) → number 

[engine/Source/Core/JulianDate.js 941](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L941) 

 Computes the difference in seconds between the provided instance.

| Name  | Type                          | Description          |
| ----- | ----------------------------- | -------------------- |
| left  | [JulianDate](JulianDate.html) | The first instance.  |
| right | [JulianDate](JulianDate.html) | The second instance. |

##### Returns:

 The difference, in seconds, when subtracting `right` from `left`.

#### [](#.toDate) static Cesium.JulianDate.toDate(julianDate) → Date 

[engine/Source/Core/JulianDate.js 719](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L719) 

 Creates a JavaScript Date from the provided instance. Since JavaScript dates are only accurate to the nearest millisecond and cannot represent a leap second, consider using [JulianDate.toGregorianDate](JulianDate.html#.toGregorianDate) instead. If the provided JulianDate is during a leap second, the previous second is used.

| Name       | Type                          | Description               |
| ---------- | ----------------------------- | ------------------------- |
| julianDate | [JulianDate](JulianDate.html) | The date to be converted. |

##### Returns:

 A new instance representing the provided date.

#### [](#.toGregorianDate) static Cesium.JulianDate.toGregorianDate(julianDate, result) → [GregorianDate](GregorianDate.html) 

[engine/Source/Core/JulianDate.js 628](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L628) 

 Creates a [GregorianDate](GregorianDate.html) from the provided instance.

| Name       | Type                                | Description                                          |
| ---------- | ----------------------------------- | ---------------------------------------------------- |
| julianDate | [JulianDate](JulianDate.html)       | The date to be converted.                            |
| result     | [GregorianDate](GregorianDate.html) | optional An existing instance to use for the result. |

##### Returns:

 The modified result parameter or a new instance if none was provided.

#### [](#.toIso8601) static Cesium.JulianDate.toIso8601(julianDate, precision) → string 

[engine/Source/Core/JulianDate.js 751](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L751) 

 Creates an ISO8601 representation of the provided date.

| Name       | Type                          | Description                                                                                                                            |
| ---------- | ----------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| julianDate | [JulianDate](JulianDate.html) | The date to be converted.                                                                                                              |
| precision  | number                        | optional The number of fractional digits used to represent the seconds component. By default, the most precise representation is used. |

##### Returns:

 The ISO8601 representation of the provided date.

#### [](#.totalDays) static Cesium.JulianDate.totalDays(julianDate) → number 

[engine/Source/Core/JulianDate.js 922](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L922) 

 Computes the total number of whole and fractional days represented by the provided instance.

| Name       | Type                          | Description |
| ---------- | ----------------------------- | ----------- |
| julianDate | [JulianDate](JulianDate.html) | The date.   |

##### Returns:

 The Julian date as single floating point number.

#### [](#clone) clone(result) → [JulianDate](JulianDate.html) 

[engine/Source/Core/JulianDate.js 1158](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1158) 

 Duplicates this instance.

| Name   | Type                          | Description                                          |
| ------ | ----------------------------- | ---------------------------------------------------- |
| result | [JulianDate](JulianDate.html) | optional An existing instance to use for the result. |

##### Returns:

 The modified result parameter or a new instance if none was provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/JulianDate.js 1168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1168) 

 Compares this and the provided instance and returns `true` if they are equal, `false` otherwise.

| Name  | Type                          | Description                   |
| ----- | ----------------------------- | ----------------------------- |
| right | [JulianDate](JulianDate.html) | optional The second instance. |

##### Returns:

`true` if the dates are equal; otherwise, `false`.

#### [](#equalsEpsilon) equalsEpsilon(right, epsilon) → boolean 

[engine/Source/Core/JulianDate.js 1182](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1182) 

 Compares this and the provided instance and returns `true` if they are within `epsilon` seconds of each other. That is, in order for the dates to be considered equal (and for this function to return `true`), the absolute value of the difference between them, in seconds, must be less than `epsilon`.

| Name    | Type                          | Default | Description                                                                    |
| ------- | ----------------------------- | ------- | ------------------------------------------------------------------------------ |
| right   | [JulianDate](JulianDate.html) |         | optional The second instance.                                                  |
| epsilon | number                        | 0       | optional The maximum number of seconds that should separate the two instances. |

##### Returns:

`true` if the two dates are within `epsilon` seconds of each other; otherwise `false`.

#### [](#toString) toString() → string 

[engine/Source/Core/JulianDate.js 1191](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/JulianDate.js#L1191) 

 Creates a string representing this date in ISO8601 format.

##### Returns:

 A string representing this date in ISO8601 format.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

