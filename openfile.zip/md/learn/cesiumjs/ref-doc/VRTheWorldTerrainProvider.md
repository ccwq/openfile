# [![](Images/CesiumLogo.png)](index.html) VRTheWorldTerrainProvider 

#### [](#VRTheWorldTerrainProvider) new Cesium.VRTheWorldTerrainProvider(options) 

[engine/Source/Core/VRTheWorldTerrainProvider.js 158](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L158) 

To construct a VRTheWorldTerrainProvider, call [VRTheWorldTerrainProvider.fromUrl](VRTheWorldTerrainProvider.html#.fromUrl). Do not call the constructor directly.

A [TerrainProvider](TerrainProvider.html) that produces terrain geometry by tessellating height maps retrieved from a [VT MÄK VR-TheWorld server](http://vr-theworld.com/).

| Name    | Type                                                                                               | Description                                           |
| ------- | -------------------------------------------------------------------------------------------------- | ----------------------------------------------------- |
| options | [VRTheWorldTerrainProvider.ConstructorOptions](VRTheWorldTerrainProvider.html#.ConstructorOptions) | optional An object describing initialization options. |

##### Example:

```javascript
const terrainProvider = await Cesium.VRTheWorldTerrainProvider.fromUrl(
  "https://www.vr-theworld.com/vr-theworld/tiles1.0.0/73/"
);
viewer.terrainProvider = terrainProvider;
```

##### See:

* [TerrainProvider](TerrainProvider.html)

### Members

#### [](#availability) readonly availability : [TileAvailability](TileAvailability.html) 

[engine/Source/Core/VRTheWorldTerrainProvider.js 257](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L257) 

 Gets an object that can be used to determine availability of terrain from this provider, such as at points and in rectangles. This property may be undefined if availability information is not available.

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Core/VRTheWorldTerrainProvider.js 206](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L206) 

 Gets the credit to display when this terrain provider is active. Typically this is used to credit the source of the terrain.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Core/VRTheWorldTerrainProvider.js 193](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L193) 

 Gets an event that is raised when the terrain provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasVertexNormals) readonly hasVertexNormals : boolean 

[engine/Source/Core/VRTheWorldTerrainProvider.js 244](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L244) 

 Gets a value indicating whether or not the requested tiles include vertex normals.

#### [](#hasWaterMask) readonly hasWaterMask : boolean 

[engine/Source/Core/VRTheWorldTerrainProvider.js 232](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L232) 

 Gets a value indicating whether or not the provider includes a water mask. The water mask indicates which areas of the globe are water rather than land, so they can be rendered as a reflective surface with animated waves.

#### [](#tilingScheme) readonly tilingScheme : [GeographicTilingScheme](GeographicTilingScheme.html) 

[engine/Source/Core/VRTheWorldTerrainProvider.js 218](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L218) 

 Gets the tiling scheme used by this provider.

### Methods

#### [](#.fromUrl) static Cesium.VRTheWorldTerrainProvider.fromUrl(url, options) → Promise.<[VRTheWorldTerrainProvider](VRTheWorldTerrainProvider.html)\> 

[engine/Source/Core/VRTheWorldTerrainProvider.js 280](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L280) 

 Creates a [TerrainProvider](TerrainProvider.html) that produces terrain geometry by tessellating height maps retrieved from a [VT MÄK VR-TheWorld server](http://vr-theworld.com/).

| Name    | Type                                                                                               | Description                                           |
| ------- | -------------------------------------------------------------------------------------------------- | ----------------------------------------------------- |
| url     | [Resource](Resource.html)\|String                                                                  | The URL of the VR-TheWorld TileMap.                   |
| options | [VRTheWorldTerrainProvider.ConstructorOptions](VRTheWorldTerrainProvider.html#.ConstructorOptions) | optional An object describing initialization options. |

##### Returns:

##### Throws:

* [RuntimeError](RuntimeError.html): metadata specifies and unknown SRS

##### Example:

```javascript
const terrainProvider = await Cesium.VRTheWorldTerrainProvider.fromUrl(
  "https://www.vr-theworld.com/vr-theworld/tiles1.0.0/73/"
);
viewer.terrainProvider = terrainProvider;
```

#### [](#getLevelMaximumGeometricError) getLevelMaximumGeometricError(level) → number 

[engine/Source/Core/VRTheWorldTerrainProvider.js 350](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L350) 

 Gets the maximum geometric error allowed in a tile at a given level.

| Name  | Type   | Description                                                  |
| ----- | ------ | ------------------------------------------------------------ |
| level | number | The tile level for which to get the maximum geometric error. |

##### Returns:

 The maximum geometric error.

#### [](#getTileDataAvailable) getTileDataAvailable(x, y, level) → boolean|undefined 

[engine/Source/Core/VRTheWorldTerrainProvider.js 439](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L439) 

 Determines whether data for a tile is available to be loaded.

| Name  | Type   | Description                                                 |
| ----- | ------ | ----------------------------------------------------------- |
| x     | number | The X coordinate of the tile for which to request geometry. |
| y     | number | The Y coordinate of the tile for which to request geometry. |
| level | number | The level of the tile for which to request geometry.        |

##### Returns:

 Undefined if not supported, otherwise true or false.

#### [](#loadTileDataAvailability) loadTileDataAvailability(x, y, level) → undefined|Promise.<void> 

[engine/Source/Core/VRTheWorldTerrainProvider.js 455](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L455) 

 Makes sure we load availability data for a tile

| Name  | Type   | Description                                                 |
| ----- | ------ | ----------------------------------------------------------- |
| x     | number | The X coordinate of the tile for which to request geometry. |
| y     | number | The Y coordinate of the tile for which to request geometry. |
| level | number | The level of the tile for which to request geometry.        |

##### Returns:

 Undefined if nothing need to be loaded or a Promise that resolves when all required tiles are loaded

#### [](#requestTileGeometry) requestTileGeometry(x, y, level, request) → Promise.<[TerrainData](TerrainData.html)\>|undefined 

[engine/Source/Core/VRTheWorldTerrainProvider.js 311](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L311) 

 Requests the geometry for a given tile. The result includes terrain data and indicates that all child tiles are available.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The X coordinate of the tile for which to request geometry.  |
| y       | number                  | The Y coordinate of the tile for which to request geometry.  |
| level   | number                  | The level of the tile for which to request geometry.         |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the requested geometry. If this method returns undefined instead of a promise, it is an indication that too many requests are already pending and the request will be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.VRTheWorldTerrainProvider.ConstructorOptions

[engine/Source/Core/VRTheWorldTerrainProvider.js 22](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VRTheWorldTerrainProvider.js#L22) 

 Initialization options for the VRTheWorldTerrainProvider constructor

##### Properties:

| Name      | Type                          | Attributes | Default           | Description                                                     |
| --------- | ----------------------------- | ---------- | ----------------- | --------------------------------------------------------------- |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | <optional> | Ellipsoid.default | The ellipsoid. If not specified, the default ellipsoid is used. |
| credit    | [Credit](Credit.html)\|string | <optional> |                   | A credit for the data source, which is displayed on the canvas. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

