# [![](Images/CesiumLogo.png)](index.html) PerspectiveOffCenterFrustum 

#### [](#PerspectiveOffCenterFrustum) new Cesium.PerspectiveOffCenterFrustum(options) 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L39) 

 The viewing frustum is defined by 6 planes. Each plane is represented by a [Cartesian4](Cartesian4.html) object, where the x, y, and z components define the unit vector normal to the plane, and the w component is the distance of the plane from the origin/camera position.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional An object with the following properties: Name Type Default Description left number optional The left clipping plane distance. right number optional The right clipping plane distance. top number optional The top clipping plane distance. bottom number optional The bottom clipping plane distance. near number 1.0 optional The near clipping plane distance. far number 500000000.0 optional The far clipping plane distance. |

##### Example:

```javascript
const frustum = new Cesium.PerspectiveOffCenterFrustum({
    left : -1.0,
    right : 1.0,
    top : 1.0,
    bottom : -1.0,
    near : 1.0,
    far : 100.0
});
```

##### See:

* [PerspectiveFrustum](PerspectiveFrustum.html)

### Members

#### [](#bottom) bottom : number|undefined 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 71](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L71) 

 Defines the bottom clipping plane.

Default Value: `undefined` 

#### [](#far) far : number 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 87](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L87) 

 The distance of the far plane.

Default Value: `500000000.0` 

#### [](#infiniteProjectionMatrix) readonly infiniteProjectionMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 183](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L183) 

 Gets the perspective projection matrix computed from the view frustum with an infinite far plane.

##### See:

* [PerspectiveOffCenterFrustum#projectionMatrix](PerspectiveOffCenterFrustum.html#projectionMatrix)

#### [](#left) left : number|undefined 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 47](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L47) 

 Defines the left clipping plane.

Default Value: `undefined` 

#### [](#near) near : number 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 79](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L79) 

 The distance of the near plane.

Default Value: `1.0` 

#### [](#projectionMatrix) readonly projectionMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L168) 

 Gets the perspective projection matrix computed from the view frustum. The projection matrix will be recomputed if any frustum parameters have changed.

##### See:

* [PerspectiveOffCenterFrustum#infiniteProjectionMatrix](PerspectiveOffCenterFrustum.html#infiniteProjectionMatrix)

#### [](#right) right : number|undefined 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L55) 

 Defines the right clipping plane.

Default Value: `undefined` 

#### [](#top) top : number|undefined 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 63](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L63) 

 Defines the top clipping plane.

Default Value: `undefined` 

### Methods

#### [](#clone) clone(result) → [PerspectiveOffCenterFrustum](PerspectiveOffCenterFrustum.html) 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 422](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L422) 

 Returns a duplicate of a PerspectiveOffCenterFrustum instance.

| Name   | Type                                                            | Description                                         |
| ------ | --------------------------------------------------------------- | --------------------------------------------------- |
| result | [PerspectiveOffCenterFrustum](PerspectiveOffCenterFrustum.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new PerspectiveFrustum instance if one was not provided.

#### [](#computeCullingVolume) computeCullingVolume(position, direction, up) → [CullingVolume](CullingVolume.html) 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 208](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L208) 

 Creates a culling volume for this frustum.

| Name      | Type                          | Description         |
| --------- | ----------------------------- | ------------------- |
| position  | [Cartesian3](Cartesian3.html) | The eye position.   |
| direction | [Cartesian3](Cartesian3.html) | The view direction. |
| up        | [Cartesian3](Cartesian3.html) | The up direction.   |

##### Returns:

 A culling volume at the given position and orientation.

##### Example:

```javascript
// Check if a bounding volume intersects the frustum.
const cullingVolume = frustum.computeCullingVolume(cameraPosition, cameraDirection, cameraUp);
const intersect = cullingVolume.computeVisibility(boundingVolume);
```

#### [](#equals) equals(other) → boolean 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 452](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L452) 

 Compares the provided PerspectiveOffCenterFrustum componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                                            | Description                                               |
| ----- | --------------------------------------------------------------- | --------------------------------------------------------- |
| other | [PerspectiveOffCenterFrustum](PerspectiveOffCenterFrustum.html) | optional The right hand side PerspectiveOffCenterFrustum. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(other, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 475](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L475) 

 Compares the provided PerspectiveOffCenterFrustum componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                                                            | Default         | Description                                                          |
| --------------- | --------------------------------------------------------------- | --------------- | -------------------------------------------------------------------- |
| other           | [PerspectiveOffCenterFrustum](PerspectiveOffCenterFrustum.html) |                 | The right hand side PerspectiveOffCenterFrustum.                     |
| relativeEpsilon | number                                                          |                 | The relative epsilon tolerance to use for equality testing.          |
| absoluteEpsilon | number                                                          | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if this and other are within the provided epsilon, `false` otherwise.

#### [](#getPixelDimensions) getPixelDimensions(drawingBufferWidth, drawingBufferHeight, distance, pixelRatio, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/PerspectiveOffCenterFrustum.js 368](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveOffCenterFrustum.js#L368) 

 Returns the pixel's width and height in meters.

| Name                | Type                          | Description                                              |
| ------------------- | ----------------------------- | -------------------------------------------------------- |
| drawingBufferWidth  | number                        | The width of the drawing buffer.                         |
| drawingBufferHeight | number                        | The height of the drawing buffer.                        |
| distance            | number                        | The distance to the near plane in meters.                |
| pixelRatio          | number                        | The scaling factor from pixel space to coordinate space. |
| result              | [Cartesian2](Cartesian2.html) | The object onto which to store the result.               |

##### Returns:

 The modified result parameter or a new instance of [Cartesian2](Cartesian2.html) with the pixel's width and height in the x and y properties, respectively.

##### Throws:

* [DeveloperError](DeveloperError.html): drawingBufferWidth must be greater than zero.
* [DeveloperError](DeveloperError.html): drawingBufferHeight must be greater than zero.
* [DeveloperError](DeveloperError.html): pixelRatio must be greater than zero.

##### Examples:

```javascript
// Example 1
// Get the width and height of a pixel.
const pixelSize = camera.frustum.getPixelDimensions(scene.drawingBufferWidth, scene.drawingBufferHeight, 1.0, scene.pixelRatio, new Cesium.Cartesian2());
```

```javascript
// Example 2
// Get the width and height of a pixel if the near plane was set to 'distance'.
// For example, get the size of a pixel of an image on a billboard.
const position = camera.position;
const direction = camera.direction;
const toCenter = Cesium.Cartesian3.subtract(primitive.boundingVolume.center, position, new Cesium.Cartesian3());      // vector from camera to a primitive
const toCenterProj = Cesium.Cartesian3.multiplyByScalar(direction, Cesium.Cartesian3.dot(direction, toCenter), new Cesium.Cartesian3()); // project vector onto camera direction vector
const distance = Cesium.Cartesian3.magnitude(toCenterProj);
const pixelSize = camera.frustum.getPixelDimensions(scene.drawingBufferWidth, scene.drawingBufferHeight, distance, scene.pixelRatio, new Cesium.Cartesian2());
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

