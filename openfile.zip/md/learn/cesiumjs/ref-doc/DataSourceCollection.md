# [![](Images/CesiumLogo.png)](index.html) DataSourceCollection 

#### [](#DataSourceCollection) new Cesium.DataSourceCollection() 

[engine/Source/DataSources/DataSourceCollection.js 13](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L13) 

 A collection of [DataSource](DataSource.html) instances.

### Members

#### [](#dataSourceAdded) readonly dataSourceAdded : [Event](Event.html) 

[engine/Source/DataSources/DataSourceCollection.js 40](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L40) 

 An event that is raised when a data source is added to the collection. Event handlers are passed the data source that was added.

#### [](#dataSourceMoved) readonly dataSourceMoved : [Event](Event.html) 

[engine/Source/DataSources/DataSourceCollection.js 66](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L66) 

 An event that is raised when a data source changes position in the collection. Event handlers are passed the data source that was moved, its new index after the move, and its old index prior to the move.

#### [](#dataSourceRemoved) readonly dataSourceRemoved : [Event](Event.html) 

[engine/Source/DataSources/DataSourceCollection.js 53](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L53) 

 An event that is raised when a data source is removed from the collection. Event handlers are passed the data source that was removed.

#### [](#length) readonly length : number 

[engine/Source/DataSources/DataSourceCollection.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L27) 

 Gets the number of data sources in this collection.

### Methods

#### [](#add) add(dataSource) → Promise.<[DataSource](DataSource.html)\> 

[engine/Source/DataSources/DataSourceCollection.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L81) 

 Adds a data source to the collection.

| Name       | Type                                                                    | Description                                                                                                                                                                                         |
| ---------- | ----------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| dataSource | [DataSource](DataSource.html)\|Promise.<[DataSource](DataSource.html)\> | A data source or a promise to a data source to add to the collection. When passing a promise, the data source will not actually be added to the collection until the promise resolves successfully. |

##### Returns:

 A Promise that resolves once the data source has been added to the collection.

#### [](#contains) contains(dataSource) → boolean 

[engine/Source/DataSources/DataSourceCollection.js 153](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L153) 

 Checks to see if the collection contains a given data source.

| Name       | Type                          | Description                   |
| ---------- | ----------------------------- | ----------------------------- |
| dataSource | [DataSource](DataSource.html) | The data source to check for. |

##### Returns:

 true if the collection contains the data source, false otherwise.

#### [](#destroy) destroy() 

[engine/Source/DataSources/DataSourceCollection.js 332](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L332) 

 Destroys the resources held by all data sources in this collection. Explicitly destroying this object allows for deterministic release of WebGL resources, instead of relying on the garbage collector. Once this object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
dataSourceCollection = dataSourceCollection && dataSourceCollection.destroy();
```

##### See:

* [DataSourceCollection#isDestroyed](DataSourceCollection.html#isDestroyed)

#### [](#get) get(index) → [DataSource](DataSource.html) 

[engine/Source/DataSources/DataSourceCollection.js 173](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L173) 

 Gets a data source by index from the collection.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| index | number | the index to retrieve. |

##### Returns:

 The data source at the specified index.

#### [](#getByName) getByName(name) → Array.<[DataSource](DataSource.html)\> 

[engine/Source/DataSources/DataSourceCollection.js 189](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L189) 

 Gets a data source by name from the collection.

| Name | Type   | Description           |
| ---- | ------ | --------------------- |
| name | string | The name to retrieve. |

##### Returns:

 A list of all data sources matching the provided name.

#### [](#indexOf) indexOf(dataSource) → number 

[engine/Source/DataSources/DataSourceCollection.js 163](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L163) 

 Determines the index of a given data source in the collection.

| Name       | Type                          | Description                           |
| ---------- | ----------------------------- | ------------------------------------- |
| dataSource | [DataSource](DataSource.html) | The data source to find the index of. |

##### Returns:

 The index of the data source in the collection, or -1 if the data source does not exist in the collection.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/DataSources/DataSourceCollection.js 313](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L313) 

 Returns true if this object was destroyed; otherwise, false. If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

 true if this object was destroyed; otherwise, false.

##### See:

* [DataSourceCollection#destroy](DataSourceCollection.html#destroy)

#### [](#lower) lower(dataSource) 

[engine/Source/DataSources/DataSourceCollection.js 257](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L257) 

 Lowers a data source down one position in the collection.

| Name       | Type                          | Description              |
| ---------- | ----------------------------- | ------------------------ |
| dataSource | [DataSource](DataSource.html) | The data source to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): dataSource is not in this collection.
* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

#### [](#lowerToBottom) lowerToBottom(dataSource) 

[engine/Source/DataSources/DataSourceCollection.js 293](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L293) 

 Lowers a data source to the bottom of the collection.

| Name       | Type                          | Description              |
| ---------- | ----------------------------- | ------------------------ |
| dataSource | [DataSource](DataSource.html) | The data source to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): dataSource is not in this collection.
* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

#### [](#raise) raise(dataSource) 

[engine/Source/DataSources/DataSourceCollection.js 244](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L244) 

 Raises a data source up one position in the collection.

| Name       | Type                          | Description              |
| ---------- | ----------------------------- | ------------------------ |
| dataSource | [DataSource](DataSource.html) | The data source to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): dataSource is not in this collection.
* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

#### [](#raiseToTop) raiseToTop(dataSource) 

[engine/Source/DataSources/DataSourceCollection.js 270](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L270) 

 Raises a data source to the top of the collection.

| Name       | Type                          | Description              |
| ---------- | ----------------------------- | ------------------------ |
| dataSource | [DataSource](DataSource.html) | The data source to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): dataSource is not in this collection.
* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

#### [](#remove) remove(dataSource, destroy) → boolean 

[engine/Source/DataSources/DataSourceCollection.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L109) 

 Removes a data source from this collection, if present.

| Name       | Type                          | Default | Description                                                             |
| ---------- | ----------------------------- | ------- | ----------------------------------------------------------------------- |
| dataSource | [DataSource](DataSource.html) |         | The data source to remove.                                              |
| destroy    | boolean                       | false   | optional Whether to destroy the data source in addition to removing it. |

##### Returns:

 true if the data source was in the collection and was removed, false if the data source was not in the collection.

#### [](#removeAll) removeAll(destroy) 

[engine/Source/DataSources/DataSourceCollection.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceCollection.js#L132) 

 Removes all data sources from this collection.

| Name    | Type    | Default | Description                                                                |
| ------- | ------- | ------- | -------------------------------------------------------------------------- |
| destroy | boolean | false   | optional whether to destroy the data sources in addition to removing them. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

