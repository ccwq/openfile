# [![](Images/CesiumLogo.png)](index.html) EllipsoidTerrainProvider 

#### [](#EllipsoidTerrainProvider) new Cesium.EllipsoidTerrainProvider(options) 

[engine/Source/Core/EllipsoidTerrainProvider.js 26](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTerrainProvider.js#L26) 

 A very simple [TerrainProvider](TerrainProvider.html) that produces geometry by tessellating an ellipsoidal surface.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description tilingScheme [TilingScheme](TilingScheme.html) optional The tiling scheme specifying how the ellipsoidal surface is broken into tiles. If this parameter is not provided, a [GeographicTilingScheme](GeographicTilingScheme.html)is used. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid. If the tilingScheme is specified, this parameter is ignored and the tiling scheme's ellipsoid is used instead. If neither parameter is specified, the default ellipsoid is used. |

##### See:

* [TerrainProvider](TerrainProvider.html)

### Members

#### [](#availability) readonly availability : [TileAvailability](TileAvailability.html) 

[engine/Source/Core/EllipsoidTerrainProvider.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTerrainProvider.js#L121) 

 Gets an object that can be used to determine availability of terrain from this provider, such as at points and in rectangles. This property may be undefined if availability information is not available.

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Core/EllipsoidTerrainProvider.js 70](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTerrainProvider.js#L70) 

 Gets the credit to display when this terrain provider is active. Typically this is used to credit the source of the terrain.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Core/EllipsoidTerrainProvider.js 57](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTerrainProvider.js#L57) 

 Gets an event that is raised when the terrain provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasVertexNormals) readonly hasVertexNormals : boolean 

[engine/Source/Core/EllipsoidTerrainProvider.js 108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTerrainProvider.js#L108) 

 Gets a value indicating whether or not the requested tiles include vertex normals.

#### [](#hasWaterMask) readonly hasWaterMask : boolean 

[engine/Source/Core/EllipsoidTerrainProvider.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTerrainProvider.js#L96) 

 Gets a value indicating whether or not the provider includes a water mask. The water mask indicates which areas of the globe are water rather than land, so they can be rendered as a reflective surface with animated waves.

#### [](#tilingScheme) readonly tilingScheme : [GeographicTilingScheme](GeographicTilingScheme.html) 

[engine/Source/Core/EllipsoidTerrainProvider.js 82](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTerrainProvider.js#L82) 

 Gets the tiling scheme used by this provider.

### Methods

#### [](#getLevelMaximumGeometricError) getLevelMaximumGeometricError(level) → number 

[engine/Source/Core/EllipsoidTerrainProvider.js 164](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTerrainProvider.js#L164) 

 Gets the maximum geometric error allowed in a tile at a given level.

| Name  | Type   | Description                                                  |
| ----- | ------ | ------------------------------------------------------------ |
| level | number | The tile level for which to get the maximum geometric error. |

##### Returns:

 The maximum geometric error.

#### [](#getTileDataAvailable) getTileDataAvailable(x, y, level) → boolean|undefined 

[engine/Source/Core/EllipsoidTerrainProvider.js 178](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTerrainProvider.js#L178) 

 Determines whether data for a tile is available to be loaded.

| Name  | Type   | Description                                                 |
| ----- | ------ | ----------------------------------------------------------- |
| x     | number | The X coordinate of the tile for which to request geometry. |
| y     | number | The Y coordinate of the tile for which to request geometry. |
| level | number | The level of the tile for which to request geometry.        |

##### Returns:

 Undefined if not supported, otherwise true or false.

#### [](#loadTileDataAvailability) loadTileDataAvailability(x, y, level) → undefined 

[engine/Source/Core/EllipsoidTerrainProvider.js 194](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTerrainProvider.js#L194) 

 Makes sure we load availability data for a tile

| Name  | Type   | Description                                                 |
| ----- | ------ | ----------------------------------------------------------- |
| x     | number | The X coordinate of the tile for which to request geometry. |
| y     | number | The Y coordinate of the tile for which to request geometry. |
| level | number | The level of the tile for which to request geometry.        |

##### Returns:

 This provider does not support loading availability.

#### [](#requestTileGeometry) requestTileGeometry(x, y, level, request) → Promise.<[TerrainData](TerrainData.html)\>|undefined 

[engine/Source/Core/EllipsoidTerrainProvider.js 141](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTerrainProvider.js#L141) 

 Requests the geometry for a given tile. The result includes terrain data and indicates that all child tiles are available.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The X coordinate of the tile for which to request geometry.  |
| y       | number                  | The Y coordinate of the tile for which to request geometry.  |
| level   | number                  | The level of the tile for which to request geometry.         |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the requested geometry. If this method returns undefined instead of a promise, it is an indication that too many requests are already pending and the request will be retried later.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

