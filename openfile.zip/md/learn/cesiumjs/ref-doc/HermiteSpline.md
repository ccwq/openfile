# [![](Images/CesiumLogo.png)](index.html) HermiteSpline 

#### [](#HermiteSpline) new Cesium.HermiteSpline(options) 

[engine/Source/Core/HermiteSpline.js 169](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L169) 

 A Hermite spline is a cubic interpolating spline. Points, incoming tangents, outgoing tangents, and times must be defined for each control point. The outgoing tangents are defined for points \[0, n - 2\] and the incoming tangents are defined for points \[1, n - 1\]. For example, when interpolating a segment of the curve between `points[i]` and`points[i + 1]`, the tangents at the points will be `outTangents[i]` and `inTangents[i]`, respectively.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description times Array.<number>  An array of strictly increasing, unit-less, floating-point times at each point. The values are in no way connected to the clock time. They are the parameterization for the curve. points Array.<[Cartesian3](Cartesian3.html)\>  The array of control points. inTangents Array.<[Cartesian3](Cartesian3.html)\>  The array of incoming tangents at each control point. outTangents Array.<[Cartesian3](Cartesian3.html)\>  The array of outgoing tangents at each control point. |

##### Throws:

* [DeveloperError](DeveloperError.html): points.length must be greater than or equal to 2.
* [DeveloperError](DeveloperError.html): times.length must be equal to points.length.
* [DeveloperError](DeveloperError.html): inTangents and outTangents must have a length equal to points.length - 1.
* [DeveloperError](DeveloperError.html): inTangents and outTangents must be of the same type as points.

##### Example:

```javascript
// Create a G<sup>1</sup> continuous Hermite spline
const times = [ 0.0, 1.5, 3.0, 4.5, 6.0 ];
const spline = new Cesium.HermiteSpline({
    times : times,
    points : [
        new Cesium.Cartesian3(1235398.0, -4810983.0, 4146266.0),
        new Cesium.Cartesian3(1372574.0, -5345182.0, 4606657.0),
        new Cesium.Cartesian3(-757983.0, -5542796.0, 4514323.0),
        new Cesium.Cartesian3(-2821260.0, -5248423.0, 4021290.0),
        new Cesium.Cartesian3(-2539788.0, -4724797.0, 3620093.0)
    ],
    outTangents : [
        new Cesium.Cartesian3(1125196, -161816, 270551),
        new Cesium.Cartesian3(-996690.5, -365906.5, 184028.5),
        new Cesium.Cartesian3(-2096917, 48379.5, -292683.5),
        new Cesium.Cartesian3(-890902.5, 408999.5, -447115)
    ],
    inTangents : [
        new Cesium.Cartesian3(-1993381, -731813, 368057),
        new Cesium.Cartesian3(-4193834, 96759, -585367),
        new Cesium.Cartesian3(-1781805, 817999, -894230),
        new Cesium.Cartesian3(1165345, 112641, 47281)
    ]
});

const p0 = spline.evaluate(times[0]);
```

##### See:

* [ConstantSpline](ConstantSpline.html)
* [SteppedSpline](SteppedSpline.html)
* [LinearSpline](LinearSpline.html)
* [CatmullRomSpline](CatmullRomSpline.html)
* [QuaternionSpline](QuaternionSpline.html)
* [MorphWeightSpline](MorphWeightSpline.html)

### Members

#### [](#inTangents) readonly inTangents : Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/HermiteSpline.js 263](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L263) 

 An array of incoming tangents at each control point.

#### [](#outTangents) readonly outTangents : Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/HermiteSpline.js 277](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L277) 

 An array of outgoing tangents at each control point.

#### [](#points) readonly points : Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/HermiteSpline.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L249) 

 An array of control points.

#### [](#times) readonly times : Array.<number> 

[engine/Source/Core/HermiteSpline.js 235](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L235) 

 An array of times for the control points.

### Methods

#### [](#.createC1) static Cesium.HermiteSpline.createC1(options) → [HermiteSpline](HermiteSpline.html) 

[engine/Source/Core/HermiteSpline.js 322](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L322) 

 Creates a spline where the tangents at each control point are the same. The curves are guaranteed to be at least in the class C1.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                   |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description times Array.<number>  The array of control point times. points Array.<[Cartesian3](Cartesian3.html)\>  The array of control points. tangents Array.<[Cartesian3](Cartesian3.html)\>  The array of tangents at the control points. |

##### Returns:

 A hermite spline.

##### Throws:

* [DeveloperError](DeveloperError.html): points, times and tangents are required.
* [DeveloperError](DeveloperError.html): points.length must be greater than or equal to 2.
* [DeveloperError](DeveloperError.html): times, points and tangents must have the same length.

##### Example:

```javascript
const points = [
    new Cesium.Cartesian3(1235398.0, -4810983.0, 4146266.0),
    new Cesium.Cartesian3(1372574.0, -5345182.0, 4606657.0),
    new Cesium.Cartesian3(-757983.0, -5542796.0, 4514323.0),
    new Cesium.Cartesian3(-2821260.0, -5248423.0, 4021290.0),
    new Cesium.Cartesian3(-2539788.0, -4724797.0, 3620093.0)
];

// Add tangents
const tangents = new Array(points.length);
tangents[0] = new Cesium.Cartesian3(1125196, -161816, 270551);
const temp = new Cesium.Cartesian3();
for (let i = 1; i < tangents.length - 1; ++i) {
    tangents[i] = Cesium.Cartesian3.multiplyByScalar(Cesium.Cartesian3.subtract(points[i + 1], points[i - 1], temp), 0.5, new Cesium.Cartesian3());
}
tangents[tangents.length - 1] = new Cesium.Cartesian3(1165345, 112641, 47281);

const spline = Cesium.HermiteSpline.createC1({
    times : times,
    points : points,
    tangents : tangents
});
```

#### [](#.createClampedCubic) static Cesium.HermiteSpline.createClampedCubic(options) → [HermiteSpline](HermiteSpline.html)|[LinearSpline](LinearSpline.html) 

[engine/Source/Core/HermiteSpline.js 452](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L452) 

 Creates a clamped cubic spline. The tangents at the interior control points are generated to create a curve in the class C2.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                             |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description times Array.<number>  The array of control point times. points Array.<number>\|Array.<[Cartesian3](Cartesian3.html)\>  The array of control points. firstTangent [Cartesian3](Cartesian3.html)  The outgoing tangent of the first control point. lastTangent [Cartesian3](Cartesian3.html)  The incoming tangent of the last control point. |

##### Returns:

 A hermite spline, or a linear spline if less than 3 control points were given.

##### Throws:

* [DeveloperError](DeveloperError.html): points, times, firstTangent and lastTangent are required.
* [DeveloperError](DeveloperError.html): points.length must be greater than or equal to 2.
* [DeveloperError](DeveloperError.html): times.length must be equal to points.length.
* [DeveloperError](DeveloperError.html): firstTangent and lastTangent must be of the same type as points.

##### Example:

```javascript
// Create a clamped cubic spline above the earth from Philadelphia to Los Angeles.
const spline = Cesium.HermiteSpline.createClampedCubic({
    times : [ 0.0, 1.5, 3.0, 4.5, 6.0 ],
    points : [
        new Cesium.Cartesian3(1235398.0, -4810983.0, 4146266.0),
        new Cesium.Cartesian3(1372574.0, -5345182.0, 4606657.0),
        new Cesium.Cartesian3(-757983.0, -5542796.0, 4514323.0),
        new Cesium.Cartesian3(-2821260.0, -5248423.0, 4021290.0),
        new Cesium.Cartesian3(-2539788.0, -4724797.0, 3620093.0)
    ],
    firstTangent : new Cesium.Cartesian3(1125196, -161816, 270551),
    lastTangent : new Cesium.Cartesian3(1165345, 112641, 47281)
});
```

#### [](#.createNaturalCubic) static Cesium.HermiteSpline.createNaturalCubic(options) → [HermiteSpline](HermiteSpline.html)|[LinearSpline](LinearSpline.html) 

[engine/Source/Core/HermiteSpline.js 382](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L382) 

 Creates a natural cubic spline. The tangents at the control points are generated to create a curve in the class C2.

| Name    | Type   | Description                                                                                                                                                                                     |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description times Array.<number>  The array of control point times. points Array.<[Cartesian3](Cartesian3.html)\>  The array of control points. |

##### Returns:

 A hermite spline, or a linear spline if less than 3 control points were given.

##### Throws:

* [DeveloperError](DeveloperError.html): points and times are required.
* [DeveloperError](DeveloperError.html): points.length must be greater than or equal to 2.
* [DeveloperError](DeveloperError.html): times.length must be equal to points.length.

##### Example:

```javascript
// Create a natural cubic spline above the earth from Philadelphia to Los Angeles.
const spline = Cesium.HermiteSpline.createNaturalCubic({
    times : [ 0.0, 1.5, 3.0, 4.5, 6.0 ],
    points : [
        new Cesium.Cartesian3(1235398.0, -4810983.0, 4146266.0),
        new Cesium.Cartesian3(1372574.0, -5345182.0, 4606657.0),
        new Cesium.Cartesian3(-757983.0, -5542796.0, 4514323.0),
        new Cesium.Cartesian3(-2821260.0, -5248423.0, 4021290.0),
        new Cesium.Cartesian3(-2539788.0, -4724797.0, 3620093.0)
    ]
});
```

#### [](#clampTime) clampTime(time) → number 

[engine/Source/Core/HermiteSpline.js 554](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L554) 

 Clamps the given time to the period covered by the spline.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The time, clamped to the animation period.

#### [](#evaluate) evaluate(time, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/HermiteSpline.js 567](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L567) 

 Evaluates the curve at a given time.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| time   | number                        | The time at which to evaluate the curve.            |
| result | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance of the point on the curve at the given time.

##### Throws:

* [DeveloperError](DeveloperError.html): time must be in the range `[t0, tn]`, where `t0` is the first element in the array `times` and `tn` is the last element in the array `times`.

#### [](#findTimeInterval) findTimeInterval(time) → number 

[engine/Source/Core/HermiteSpline.js 533](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L533) 

 Finds an index `i` in `times` such that the parameter`time` is in the interval `[times[i], times[i + 1]]`.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The index for the element at the start of the interval.

##### Throws:

* [DeveloperError](DeveloperError.html): time must be in the range `[t0, tn]`, where `t0` is the first element in the array `times` and `tn` is the last element in the array `times`.

#### [](#wrapTime) wrapTime(time) → number 

[engine/Source/Core/HermiteSpline.js 545](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HermiteSpline.js#L545) 

 Wraps the given time to the period covered by the spline.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The time, wrapped around to the updated animation.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

