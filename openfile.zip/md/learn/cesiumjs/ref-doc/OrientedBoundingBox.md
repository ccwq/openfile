# [![](Images/CesiumLogo.png)](index.html) OrientedBoundingBox 

#### [](#OrientedBoundingBox) new Cesium.OrientedBoundingBox(center, halfAxes) 

[engine/Source/Core/OrientedBoundingBox.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L41) 

 Creates an instance of an OrientedBoundingBox. An OrientedBoundingBox of some object is a closed and convex rectangular cuboid. It can provide a tighter bounding volume than [BoundingSphere](BoundingSphere.html) or [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) in many cases.

| Name     | Type                          | Default         | Description                                                                                                                                                    |
| -------- | ----------------------------- | --------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| center   | [Cartesian3](Cartesian3.html) | Cartesian3.ZERO | optional The center of the box.                                                                                                                                |
| halfAxes | [Matrix3](Matrix3.html)       | Matrix3.ZERO    | optional The three orthogonal half-axes of the bounding box. Equivalently, the transformation matrix, to rotate and scale a 2x2x2 cube centered at the origin. |

##### Example:

```javascript
// Create an OrientedBoundingBox using a transformation matrix, a position where the box will be translated, and a scale.
const center = new Cesium.Cartesian3(1.0, 0.0, 0.0);
const halfAxes = Cesium.Matrix3.fromScale(new Cesium.Cartesian3(1.0, 3.0, 2.0), new Cesium.Matrix3());

const obb = new Cesium.OrientedBoundingBox(center, halfAxes);
```

##### See:

* [BoundingSphere](BoundingSphere.html)
* [BoundingRectangle](BoundingRectangle.html)

### Members

#### [](#.packedLength) static Cesium.OrientedBoundingBox.packedLength : number 

[engine/Source/Core/OrientedBoundingBox.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L62) 

 The number of elements used to pack the object into an array.

#### [](#center) center : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/OrientedBoundingBox.js 47](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L47) 

 The center of the box.

Default Value: `[Cartesian3.ZERO](Cartesian3.html#.ZERO)` 

#### [](#halfAxes) halfAxes : [Matrix3](Matrix3.html) 

[engine/Source/Core/OrientedBoundingBox.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L55) 

 The three orthogonal half-axes of the bounding box. Equivalently, the transformation matrix, to rotate and scale a 2x2x2 cube centered at the origin.

Default Value: `[Matrix3.ZERO](Matrix3.html#.ZERO)` 

### Methods

#### [](#.clone) static Cesium.OrientedBoundingBox.clone(box, result) → [OrientedBoundingBox](OrientedBoundingBox.html) 

[engine/Source/Core/OrientedBoundingBox.js 647](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L647) 

 Duplicates a OrientedBoundingBox instance.

| Name   | Type                                            | Description                                         |
| ------ | ----------------------------------------------- | --------------------------------------------------- |
| box    | [OrientedBoundingBox](OrientedBoundingBox.html) | The bounding box to duplicate.                      |
| result | [OrientedBoundingBox](OrientedBoundingBox.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new OrientedBoundingBox instance if none was provided. (Returns undefined if box is undefined)

#### [](#.computeCorners) static Cesium.OrientedBoundingBox.computeCorners(box, result) → Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/OrientedBoundingBox.js 1031](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1031) 

 Computes the eight corners of an oriented bounding box. The corners are ordered by (-X, -Y, -Z), (-X, -Y, +Z), (-X, +Y, -Z), (-X, +Y, +Z), (+X, -Y, -Z), (+X, -Y, +Z), (+X, +Y, -Z), (+X, +Y, +Z).

| Name   | Type                                            | Description                                                                                         |
| ------ | ----------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| box    | [OrientedBoundingBox](OrientedBoundingBox.html) | The oriented bounding box.                                                                          |
| result | Array.<[Cartesian3](Cartesian3.html)\>          | optional An array of eight [Cartesian3](Cartesian3.html) instances onto which to store the corners. |

##### Returns:

 The modified result parameter or a new array if none was provided.

#### [](#.computePlaneDistances) static Cesium.OrientedBoundingBox.computePlaneDistances(box, position, direction, result) → [Interval](Interval.html) 

[engine/Source/Core/OrientedBoundingBox.js 893](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L893) 

 The distances calculated by the vector from the center of the bounding box to position projected onto direction.  
If you imagine the infinite number of planes with normal direction, this computes the smallest distance to the closest and farthest planes from position that intersect the bounding box.

| Name      | Type                                            | Description                                                      |
| --------- | ----------------------------------------------- | ---------------------------------------------------------------- |
| box       | [OrientedBoundingBox](OrientedBoundingBox.html) | The bounding box to calculate the distance to.                   |
| position  | [Cartesian3](Cartesian3.html)                   | The position to calculate the distance from.                     |
| direction | [Cartesian3](Cartesian3.html)                   | The direction from position.                                     |
| result    | [Interval](Interval.html)                       | optional A Interval to store the nearest and farthest distances. |

##### Returns:

 The nearest and farthest distances on the bounding box from position in direction.

#### [](#.computeTransformation) static Cesium.OrientedBoundingBox.computeTransformation(box, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/OrientedBoundingBox.js 1107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1107) 

 Computes a transformation matrix from an oriented bounding box.

| Name   | Type                                            | Description                                |
| ------ | ----------------------------------------------- | ------------------------------------------ |
| box    | [OrientedBoundingBox](OrientedBoundingBox.html) | The oriented bounding box.                 |
| result | [Matrix4](Matrix4.html)                         | The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new [Matrix4](Matrix4.html) instance if none was provided.

#### [](#.distanceSquaredTo) static Cesium.OrientedBoundingBox.distanceSquaredTo(box, cartesian) → number 

[engine/Source/Core/OrientedBoundingBox.js 738](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L738) 

 Computes the estimated distance squared from the closest point on a bounding box to a point.

| Name      | Type                                            | Description |
| --------- | ----------------------------------------------- | ----------- |
| box       | [OrientedBoundingBox](OrientedBoundingBox.html) | The box.    |
| cartesian | [Cartesian3](Cartesian3.html)                   | The point   |

##### Returns:

 The distance squared from the oriented bounding box to the point. Returns 0 if the point is inside the box.

##### Example:

```javascript
// Sort bounding boxes from back to front
boxes.sort(function(a, b) {
    return Cesium.OrientedBoundingBox.distanceSquaredTo(b, camera.positionWC) - Cesium.OrientedBoundingBox.distanceSquaredTo(a, camera.positionWC);
});
```

#### [](#.equals) static Cesium.OrientedBoundingBox.equals(left, right) → boolean 

[engine/Source/Core/OrientedBoundingBox.js 1243](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1243) 

 Compares the provided OrientedBoundingBox componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                            | Description                              |
| ----- | ----------------------------------------------- | ---------------------------------------- |
| left  | [OrientedBoundingBox](OrientedBoundingBox.html) | optional The first OrientedBoundingBox.  |
| right | [OrientedBoundingBox](OrientedBoundingBox.html) | optional The second OrientedBoundingBox. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.fromPoints) static Cesium.OrientedBoundingBox.fromPoints(positions, result) → [OrientedBoundingBox](OrientedBoundingBox.html) 

[engine/Source/Core/OrientedBoundingBox.js 141](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L141) 

 Computes an instance of an OrientedBoundingBox of the given positions. This is an implementation of Stefan Gottschalk's Collision Queries using Oriented Bounding Boxes solution (PHD thesis). Reference: http://gamma.cs.unc.edu/users/gottschalk/main.pdf

| Name      | Type                                            | Description                                                                               |
| --------- | ----------------------------------------------- | ----------------------------------------------------------------------------------------- |
| positions | Array.<[Cartesian3](Cartesian3.html)\>          | optional List of [Cartesian3](Cartesian3.html) points that the bounding box will enclose. |
| result    | [OrientedBoundingBox](OrientedBoundingBox.html) | optional The object onto which to store the result.                                       |

##### Returns:

 The modified result parameter or a new OrientedBoundingBox instance if one was not provided.

##### Example:

```javascript
// Compute an object oriented bounding box enclosing two points.
const box = Cesium.OrientedBoundingBox.fromPoints([new Cesium.Cartesian3(2, 0, 0), new Cesium.Cartesian3(-2, 0, 0)]);
```

#### [](#.fromRectangle) static Cesium.OrientedBoundingBox.fromRectangle(rectangle, minimumHeight, maximumHeight, ellipsoid, result) → [OrientedBoundingBox](OrientedBoundingBox.html) 

[engine/Source/Core/OrientedBoundingBox.js 343](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L343) 

 Computes an OrientedBoundingBox that bounds a [Rectangle](Rectangle.html) on the surface of an [Ellipsoid](Ellipsoid.html). There are no guarantees about the orientation of the bounding box.

| Name          | Type                                            | Default           | Description                                                 |
| ------------- | ----------------------------------------------- | ----------------- | ----------------------------------------------------------- |
| rectangle     | [Rectangle](Rectangle.html)                     |                   | The cartographic rectangle on the surface of the ellipsoid. |
| minimumHeight | number                                          | 0.0               | optional The minimum height (elevation) within the tile.    |
| maximumHeight | number                                          | 0.0               | optional The maximum height (elevation) within the tile.    |
| ellipsoid     | [Ellipsoid](Ellipsoid.html)                     | Ellipsoid.default | optional The ellipsoid on which the rectangle is defined.   |
| result        | [OrientedBoundingBox](OrientedBoundingBox.html) |                   | optional The object onto which to store the result.         |

##### Returns:

 The modified result parameter or a new OrientedBoundingBox instance if none was provided.

##### Throws:

* [DeveloperError](DeveloperError.html): rectangle.width must be between 0 and 2 \* pi.
* [DeveloperError](DeveloperError.html): rectangle.height must be between 0 and pi.
* [DeveloperError](DeveloperError.html): ellipsoid must be an ellipsoid of revolution (`radii.x == radii.y`)

#### [](#.fromTransformation) static Cesium.OrientedBoundingBox.fromTransformation(transformation, result) → [OrientedBoundingBox](OrientedBoundingBox.html) 

[engine/Source/Core/OrientedBoundingBox.js 621](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L621) 

 Computes an OrientedBoundingBox that bounds an affine transformation.

| Name           | Type                                            | Description                                         |
| -------------- | ----------------------------------------------- | --------------------------------------------------- |
| transformation | [Matrix4](Matrix4.html)                         | The affine transformation.                          |
| result         | [OrientedBoundingBox](OrientedBoundingBox.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new OrientedBoundingBox instance if none was provided.

#### [](#.intersectPlane) static Cesium.OrientedBoundingBox.intersectPlane(box, plane) → [Intersect](global.html#Intersect) 

[engine/Source/Core/OrientedBoundingBox.js 672](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L672) 

 Determines which side of a plane the oriented bounding box is located.

| Name  | Type                                            | Description                        |
| ----- | ----------------------------------------------- | ---------------------------------- |
| box   | [OrientedBoundingBox](OrientedBoundingBox.html) | The oriented bounding box to test. |
| plane | [Plane](Plane.html)                             | The plane to test against.         |

##### Returns:

[Intersect.INSIDE](global.html#Intersect#.INSIDE) if the entire box is on the side of the plane the normal is pointing, [Intersect.OUTSIDE](global.html#Intersect#.OUTSIDE) if the entire box is on the opposite side, and [Intersect.INTERSECTING](global.html#Intersect#.INTERSECTING) if the box intersects the plane.

#### [](#.isOccluded) static Cesium.OrientedBoundingBox.isOccluded(box, occluder) → boolean 

[engine/Source/Core/OrientedBoundingBox.js 1134](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1134) 

 Determines whether or not a bounding box is hidden from view by the occluder.

| Name     | Type                                            | Description                                       |
| -------- | ----------------------------------------------- | ------------------------------------------------- |
| box      | [OrientedBoundingBox](OrientedBoundingBox.html) | The bounding box surrounding the occludee object. |
| occluder | [Occluder](Occluder.html)                       | The occluder.                                     |

##### Returns:

`true` if the box is not visible; otherwise `false`.

#### [](#.pack) static Cesium.OrientedBoundingBox.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/OrientedBoundingBox.js 74](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L74) 

 Stores the provided instance into the provided array.

| Name          | Type                                            | Default | Description                                                               |
| ------------- | ----------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [OrientedBoundingBox](OrientedBoundingBox.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                  |         | The array to pack into.                                                   |
| startingIndex | number                                          | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.OrientedBoundingBox.unpack(array, startingIndex, result) → [OrientedBoundingBox](OrientedBoundingBox.html) 

[engine/Source/Core/OrientedBoundingBox.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L96) 

 Retrieves an instance from a packed array.

| Name          | Type                                            | Default | Description                                                |
| ------------- | ----------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                  |         | The packed array.                                          |
| startingIndex | number                                          | 0       | optional The starting index of the element to be unpacked. |
| result        | [OrientedBoundingBox](OrientedBoundingBox.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new OrientedBoundingBox instance if one was not provided.

#### [](#clone) clone(result) → [OrientedBoundingBox](OrientedBoundingBox.html) 

[engine/Source/Core/OrientedBoundingBox.js 1259](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1259) 

 Duplicates this OrientedBoundingBox instance.

| Name   | Type                                            | Description                                         |
| ------ | ----------------------------------------------- | --------------------------------------------------- |
| result | [OrientedBoundingBox](OrientedBoundingBox.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new OrientedBoundingBox instance if one was not provided.

#### [](#computeCorners) computeCorners(result) → Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/OrientedBoundingBox.js 1211](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1211) 

 Computes the eight corners of an oriented bounding box. The corners are ordered by (-X, -Y, -Z), (-X, -Y, +Z), (-X, +Y, -Z), (-X, +Y, +Z), (+X, -Y, -Z), (+X, -Y, +Z), (+X, +Y, -Z), (+X, +Y, +Z).

| Name   | Type                                   | Description                                                                                         |
| ------ | -------------------------------------- | --------------------------------------------------------------------------------------------------- |
| result | Array.<[Cartesian3](Cartesian3.html)\> | optional An array of eight [Cartesian3](Cartesian3.html) instances onto which to store the corners. |

##### Returns:

 The modified result parameter or a new array if none was provided.

#### [](#computePlaneDistances) computePlaneDistances(position, direction, result) → [Interval](Interval.html) 

[engine/Source/Core/OrientedBoundingBox.js 1192](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1192) 

 The distances calculated by the vector from the center of the bounding box to position projected onto direction.  
If you imagine the infinite number of planes with normal direction, this computes the smallest distance to the closest and farthest planes from position that intersect the bounding box.

| Name      | Type                          | Description                                                      |
| --------- | ----------------------------- | ---------------------------------------------------------------- |
| position  | [Cartesian3](Cartesian3.html) | The position to calculate the distance from.                     |
| direction | [Cartesian3](Cartesian3.html) | The direction from position.                                     |
| result    | [Interval](Interval.html)     | optional A Interval to store the nearest and farthest distances. |

##### Returns:

 The nearest and farthest distances on the bounding box from position in direction.

#### [](#computeTransformation) computeTransformation(result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/OrientedBoundingBox.js 1221](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1221) 

 Computes a transformation matrix from an oriented bounding box.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new [Matrix4](Matrix4.html) instance if none was provided.

#### [](#distanceSquaredTo) distanceSquaredTo(cartesian) → number 

[engine/Source/Core/OrientedBoundingBox.js 1177](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1177) 

 Computes the estimated distance squared from the closest point on a bounding box to a point.

| Name      | Type                          | Description |
| --------- | ----------------------------- | ----------- |
| cartesian | [Cartesian3](Cartesian3.html) | The point   |

##### Returns:

 The estimated distance squared from the bounding sphere to the point.

##### Example:

```javascript
// Sort bounding boxes from back to front
boxes.sort(function(a, b) {
    return b.distanceSquaredTo(camera.positionWC) - a.distanceSquaredTo(camera.positionWC);
});
```

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/OrientedBoundingBox.js 1270](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1270) 

 Compares this OrientedBoundingBox against the provided OrientedBoundingBox componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                            | Description                                       |
| ----- | ----------------------------------------------- | ------------------------------------------------- |
| right | [OrientedBoundingBox](OrientedBoundingBox.html) | optional The right hand side OrientedBoundingBox. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#intersectPlane) intersectPlane(plane) → [Intersect](global.html#Intersect) 

[engine/Source/Core/OrientedBoundingBox.js 1161](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1161) 

 Determines which side of a plane the oriented bounding box is located.

| Name  | Type                | Description                |
| ----- | ------------------- | -------------------------- |
| plane | [Plane](Plane.html) | The plane to test against. |

##### Returns:

[Intersect.INSIDE](global.html#Intersect#.INSIDE) if the entire box is on the side of the plane the normal is pointing, [Intersect.OUTSIDE](global.html#Intersect#.OUTSIDE) if the entire box is on the opposite side, and [Intersect.INTERSECTING](global.html#Intersect#.INTERSECTING) if the box intersects the plane.

#### [](#isOccluded) isOccluded(occluder) → boolean 

[engine/Source/Core/OrientedBoundingBox.js 1231](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrientedBoundingBox.js#L1231) 

 Determines whether or not a bounding box is hidden from view by the occluder.

| Name     | Type                      | Description   |
| -------- | ------------------------- | ------------- |
| occluder | [Occluder](Occluder.html) | The occluder. |

##### Returns:

`true` if the sphere is not visible; otherwise `false`.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

