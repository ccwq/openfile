# [![](Images/CesiumLogo.png)](index.html) Appearance 

#### [](#Appearance) new Cesium.Appearance(options) 

[engine/Source/Scene/Appearance.js 33](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Appearance.js#L33) 

 An appearance defines the full GLSL vertex and fragment shaders and the render state used to draw a [Primitive](Primitive.html). All appearances implement this base `Appearance` interface.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description translucent boolean true optional When true, the geometry is expected to appear translucent so [Appearance#renderState](Appearance.html#renderState) has alpha blending enabled. closed boolean false optional When true, the geometry is expected to be closed so [Appearance#renderState](Appearance.html#renderState) has backface culling enabled. material [Material](Material.html) Material.ColorType optional The material used to determine the fragment color. vertexShaderSource string optional Optional GLSL vertex shader source to override the default vertex shader. fragmentShaderSource string optional Optional GLSL fragment shader source to override the default fragment shader. renderState object optional Optional render state to override the default render state. |

##### Demo:

* [Geometry and Appearances Demo](https://sandcastle.cesium.com/index.html?src=Geometry%2520and%2520Appearances.html)

##### See:

* [MaterialAppearance](MaterialAppearance.html)
* [EllipsoidSurfaceAppearance](EllipsoidSurfaceAppearance.html)
* [PerInstanceColorAppearance](PerInstanceColorAppearance.html)
* [DebugAppearance](DebugAppearance.html)
* [PolylineColorAppearance](PolylineColorAppearance.html)
* [PolylineMaterialAppearance](PolylineMaterialAppearance.html)

### Members

#### [](#closed) readonly closed : boolean 

[engine/Source/Scene/Appearance.js 116](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Appearance.js#L116) 

 When `true`, the geometry is expected to be closed.

Default Value: `false` 

#### [](#fragmentShaderSource) readonly fragmentShaderSource : string 

[engine/Source/Scene/Appearance.js 86](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Appearance.js#L86) 

 The GLSL source code for the fragment shader. The full fragment shader source is built procedurally taking into account the [Appearance#material](Appearance.html#material). Use [Appearance#getFragmentShaderSource](Appearance.html#getFragmentShaderSource) to get the full source.

#### [](#material) material : [Material](Material.html) 

[engine/Source/Scene/Appearance.js 44](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Appearance.js#L44) 

 The material used to determine the fragment color. Unlike other [Appearance](Appearance.html)properties, this is not read-only, so an appearance's material can change on the fly.

##### See:

* [Fabric](https://github.com/CesiumGS/cesium/wiki/Fabric)

#### [](#renderState) readonly renderState : object 

[engine/Source/Scene/Appearance.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Appearance.js#L100) 

 The WebGL fixed-function state to use when rendering the geometry.

#### [](#translucent) translucent : boolean 

[engine/Source/Scene/Appearance.js 53](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Appearance.js#L53) 

 When `true`, the geometry is expected to appear translucent.

Default Value: `true` 

#### [](#vertexShaderSource) readonly vertexShaderSource : string 

[engine/Source/Scene/Appearance.js 70](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Appearance.js#L70) 

 The GLSL source code for the vertex shader.

### Methods

#### [](#getFragmentShaderSource) getFragmentShaderSource() → string 

[engine/Source/Scene/Appearance.js 129](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Appearance.js#L129) 

 Procedurally creates the full GLSL fragment shader source for this appearance taking into account [Appearance#fragmentShaderSource](Appearance.html#fragmentShaderSource) and [Appearance#material](Appearance.html#material).

##### Returns:

 The full GLSL fragment shader source.

#### [](#getRenderState) getRenderState() → object 

[engine/Source/Scene/Appearance.js 164](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Appearance.js#L164) 

 Creates a render state. This is not the final render state instance; instead, it can contain a subset of render state properties identical to the render state created in the context.

##### Returns:

 The render state.

#### [](#isTranslucent) isTranslucent() → boolean 

[engine/Source/Scene/Appearance.js 150](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Appearance.js#L150) 

 Determines if the geometry is translucent based on [Appearance#translucent](Appearance.html#translucent) and [Material#isTranslucent](Material.html#isTranslucent).

##### Returns:

`true` if the appearance is translucent.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

