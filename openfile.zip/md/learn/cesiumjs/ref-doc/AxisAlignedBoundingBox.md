# [![](Images/CesiumLogo.png)](index.html) AxisAlignedBoundingBox 

#### [](#AxisAlignedBoundingBox) new Cesium.AxisAlignedBoundingBox(minimum, maximum, center) 

[engine/Source/Core/AxisAlignedBoundingBox.js 19](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L19) 

 Creates an instance of an AxisAlignedBoundingBox from the minimum and maximum points along the x, y, and z axes.

| Name    | Type                          | Default         | Description                                                             |
| ------- | ----------------------------- | --------------- | ----------------------------------------------------------------------- |
| minimum | [Cartesian3](Cartesian3.html) | Cartesian3.ZERO | optional The minimum point along the x, y, and z axes.                  |
| maximum | [Cartesian3](Cartesian3.html) | Cartesian3.ZERO | optional The maximum point along the x, y, and z axes.                  |
| center  | [Cartesian3](Cartesian3.html) |                 | optional The center of the box; automatically computed if not supplied. |

##### See:

* [BoundingSphere](BoundingSphere.html)
* [BoundingRectangle](BoundingRectangle.html)

### Members

#### [](#center) center : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/AxisAlignedBoundingBox.js 45](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L45) 

 The center point of the bounding box.

#### [](#maximum) maximum : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/AxisAlignedBoundingBox.js 32](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L32) 

 The maximum point defining the bounding box.

Default Value: `[Cartesian3.ZERO](Cartesian3.html#.ZERO)` 

#### [](#minimum) minimum : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/AxisAlignedBoundingBox.js 25](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L25) 

 The minimum point defining the bounding box.

Default Value: `[Cartesian3.ZERO](Cartesian3.html#.ZERO)` 

### Methods

#### [](#.clone) static Cesium.AxisAlignedBoundingBox.clone(box, result) → [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) 

[engine/Source/Core/AxisAlignedBoundingBox.js 146](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L146) 

 Duplicates a AxisAlignedBoundingBox instance.

| Name   | Type                                                  | Description                                         |
| ------ | ----------------------------------------------------- | --------------------------------------------------- |
| box    | [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) | The bounding box to duplicate.                      |
| result | [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new AxisAlignedBoundingBox instance if none was provided. (Returns undefined if box is undefined)

#### [](#.equals) static Cesium.AxisAlignedBoundingBox.equals(left, right) → boolean 

[engine/Source/Core/AxisAlignedBoundingBox.js 169](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L169) 

 Compares the provided AxisAlignedBoundingBox componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                                  | Description                                 |
| ----- | ----------------------------------------------------- | ------------------------------------------- |
| left  | [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) | optional The first AxisAlignedBoundingBox.  |
| right | [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) | optional The second AxisAlignedBoundingBox. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.fromCorners) static Cesium.AxisAlignedBoundingBox.fromCorners(minimum, maximum, result) → [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) 

[engine/Source/Core/AxisAlignedBoundingBox.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L60) 

 Creates an instance of an AxisAlignedBoundingBox from its corners.

| Name    | Type                                                  | Description                                         |
| ------- | ----------------------------------------------------- | --------------------------------------------------- |
| minimum | [Cartesian3](Cartesian3.html)                         | The minimum point along the x, y, and z axes.       |
| maximum | [Cartesian3](Cartesian3.html)                         | The maximum point along the x, y, and z axes.       |
| result  | [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new AxisAlignedBoundingBox instance if one was not provided.

##### Example:

```javascript
// Compute an axis aligned bounding box from the two corners.
const box = Cesium.AxisAlignedBoundingBox.fromCorners(new Cesium.Cartesian3(-1, -1, -1), new Cesium.Cartesian3(1, 1, 1));
```

#### [](#.fromPoints) static Cesium.AxisAlignedBoundingBox.fromPoints(positions, result) → [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) 

[engine/Source/Core/AxisAlignedBoundingBox.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L89) 

 Computes an instance of an AxisAlignedBoundingBox. The box is determined by finding the points spaced the farthest apart on the x, y, and z axes.

| Name      | Type                                                  | Description                                                                                       |
| --------- | ----------------------------------------------------- | ------------------------------------------------------------------------------------------------- |
| positions | Array.<[Cartesian3](Cartesian3.html)\>                | List of points that the bounding box will enclose. Each point must have a x, y, and z properties. |
| result    | [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) | optional The object onto which to store the result.                                               |

##### Returns:

 The modified result parameter or a new AxisAlignedBoundingBox instance if one was not provided.

##### Example:

```javascript
// Compute an axis aligned bounding box enclosing two points.
const box = Cesium.AxisAlignedBoundingBox.fromPoints([new Cesium.Cartesian3(2, 0, 0), new Cesium.Cartesian3(-2, 0, 0)]);
```

#### [](#.intersectPlane) static Cesium.AxisAlignedBoundingBox.intersectPlane(box, plane) → [Intersect](global.html#Intersect) 

[engine/Source/Core/AxisAlignedBoundingBox.js 191](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L191) 

 Determines which side of a plane a box is located.

| Name  | Type                                                  | Description                |
| ----- | ----------------------------------------------------- | -------------------------- |
| box   | [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) | The bounding box to test.  |
| plane | [Plane](Plane.html)                                   | The plane to test against. |

##### Returns:

[Intersect.INSIDE](global.html#Intersect#.INSIDE) if the entire box is on the side of the plane the normal is pointing, [Intersect.OUTSIDE](global.html#Intersect#.OUTSIDE) if the entire box is on the opposite side, and [Intersect.INTERSECTING](global.html#Intersect#.INTERSECTING) if the box intersects the plane.

#### [](#clone) clone(result) → [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) 

[engine/Source/Core/AxisAlignedBoundingBox.js 232](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L232) 

 Duplicates this AxisAlignedBoundingBox instance.

| Name   | Type                                                  | Description                                         |
| ------ | ----------------------------------------------------- | --------------------------------------------------- |
| result | [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new AxisAlignedBoundingBox instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/AxisAlignedBoundingBox.js 256](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L256) 

 Compares this AxisAlignedBoundingBox against the provided AxisAlignedBoundingBox componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                                  | Description                                          |
| ----- | ----------------------------------------------------- | ---------------------------------------------------- |
| right | [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) | optional The right hand side AxisAlignedBoundingBox. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#intersectPlane) intersectPlane(plane) → [Intersect](global.html#Intersect) 

[engine/Source/Core/AxisAlignedBoundingBox.js 245](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/AxisAlignedBoundingBox.js#L245) 

 Determines which side of a plane this box is located.

| Name  | Type                | Description                |
| ----- | ------------------- | -------------------------- |
| plane | [Plane](Plane.html) | The plane to test against. |

##### Returns:

[Intersect.INSIDE](global.html#Intersect#.INSIDE) if the entire box is on the side of the plane the normal is pointing, [Intersect.OUTSIDE](global.html#Intersect#.OUTSIDE) if the entire box is on the opposite side, and [Intersect.INTERSECTING](global.html#Intersect#.INTERSECTING) if the box intersects the plane.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

