# [![](Images/CesiumLogo.png)](index.html) PolylineCollection 

#### [](#PolylineCollection) new Cesium.PolylineCollection(options) 

[engine/Source/Scene/PolylineCollection.js 117](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L117) 

 A renderable collection of polylines.  
  
![](Images/Polyline.png)  
Example polylines
  
  
Polylines are added and removed from the collection using [PolylineCollection#add](PolylineCollection.html#add)and [PolylineCollection#remove](PolylineCollection.html#remove).

##### Performance:

For best performance, prefer a few collections, each with many polylines, to many collections with only a few polylines each. Organize collections so that polylines with the same update frequency are in the same collection, i.e., polylines that do not change should be in one collection; polylines that change every frame should be in another collection; and so on.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description modelMatrix [Matrix4](Matrix4.html) Matrix4.IDENTITY optional The 4x4 transformation matrix that transforms each polyline from model to world coordinates. debugShowBoundingVolume boolean false optional For debugging only. Determines if this primitive's commands' bounding spheres are shown. show boolean true optional Determines if the polylines in the collection will be shown. |

##### Example:

```javascript
// Create a polyline collection with two polylines
const polylines = new Cesium.PolylineCollection();
polylines.add({
  positions : Cesium.Cartesian3.fromDegreesArray([
    -75.10, 39.57,
    -77.02, 38.53,
    -80.50, 35.14,
    -80.12, 25.46]),
  width : 2
});

polylines.add({
  positions : Cesium.Cartesian3.fromDegreesArray([
    -73.10, 37.57,
    -75.02, 36.53,
    -78.50, 33.14,
    -78.12, 23.46]),
  width : 4
});
```

##### See:

* [PolylineCollection#add](PolylineCollection.html#add)
* [PolylineCollection#remove](PolylineCollection.html#remove)
* [Polyline](Polyline.html)
* [LabelCollection](LabelCollection.html)

### Members

#### [](#debugShowBoundingVolume) debugShowBoundingVolume : boolean 

[engine/Source/Scene/PolylineCollection.js 152](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L152) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the bounding sphere for each draw command in the primitive.

Default Value: `false` 

#### [](#length) length : number 

[engine/Source/Scene/PolylineCollection.js 205](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L205) 

 Returns the number of polylines in this collection. This is commonly used with[PolylineCollection#get](PolylineCollection.html#get) to iterate over all the polylines in the collection.

#### [](#modelMatrix) modelMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/PolylineCollection.js 137](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L137) 

 The 4x4 transformation matrix that transforms each polyline in this collection from model to world coordinates. When this is the identity matrix, the polylines are drawn in world coordinates, i.e., Earth's WGS84 coordinates. Local reference frames can be used by providing a different transformation matrix, like that returned by [Transforms.eastNorthUpToFixedFrame](Transforms.html#.eastNorthUpToFixedFrame).

Default Value: `[Matrix4.IDENTITY](Matrix4.html#.IDENTITY)` 

#### [](#show) show : boolean 

[engine/Source/Scene/PolylineCollection.js 126](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L126) 

 Determines if polylines in this collection will be shown.

Default Value: `true` 

### Methods

#### [](#add) add(options) → [Polyline](Polyline.html) 

[engine/Source/Scene/PolylineCollection.js 241](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L241) 

 Creates and adds a polyline with the specified initial properties to the collection. The added polyline is returned so it can be modified or removed from the collection later.

##### Performance:

After calling `add`, [PolylineCollection#update](PolylineCollection.html#update) is called and the collection's vertex buffer is rewritten - an `O(n)` operation that also incurs CPU to GPU overhead. For best performance, add as many polylines as possible before calling `update`.

| Name    | Type   | Description                                                                     |
| ------- | ------ | ------------------------------------------------------------------------------- |
| options | object | optional A template describing the polyline's properties as shown in Example 1. |

##### Returns:

 The polyline that was added to the collection.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
// Example 1:  Add a polyline, specifying all the default values.
const p = polylines.add({
  show : true,
  positions : ellipsoid.cartographicArrayToCartesianArray([
           Cesium.Cartographic.fromDegrees(-75.10, 39.57),
           Cesium.Cartographic.fromDegrees(-77.02, 38.53)]),
  width : 1
});
```

##### See:

* [PolylineCollection#remove](PolylineCollection.html#remove)
* [PolylineCollection#removeAll](PolylineCollection.html#removeAll)
* [PolylineCollection#update](PolylineCollection.html#update)

#### [](#contains) contains(polyline) → boolean 

[engine/Source/Scene/PolylineCollection.js 327](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L327) 

 Determines if this collection contains the specified polyline.

| Name     | Type                      | Description                |
| -------- | ------------------------- | -------------------------- |
| polyline | [Polyline](Polyline.html) | The polyline to check for. |

##### Returns:

 true if this collection contains the polyline, false otherwise.

##### See:

* [PolylineCollection#get](PolylineCollection.html#get)

#### [](#destroy) destroy() 

[engine/Source/Scene/PolylineCollection.js 813](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L813) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
polylines = polylines && polylines.destroy();
```

##### See:

* [PolylineCollection#isDestroyed](PolylineCollection.html#isDestroyed)

#### [](#get) get(index) → [Polyline](Polyline.html) 

[engine/Source/Scene/PolylineCollection.js 357](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L357) 

 Returns the polyline in the collection at the specified index. Indices are zero-based and increase as polylines are added. Removing a polyline shifts all polylines after it to the left, changing their indices. This function is commonly used with[PolylineCollection#length](PolylineCollection.html#length) to iterate over all the polylines in the collection.

##### Performance:

If polylines were removed from the collection and[PolylineCollection#update](PolylineCollection.html#update) was not called, an implicit `O(n)`operation is performed.

| Name  | Type   | Description                           |
| ----- | ------ | ------------------------------------- |
| index | number | The zero-based index of the polyline. |

##### Returns:

 The polyline at the specified index.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
// Toggle the show property of every polyline in the collection
const len = polylines.length;
for (let i = 0; i < len; ++i) {
  const p = polylines.get(i);
  p.show = !p.show;
}
```

##### See:

* [PolylineCollection#length](PolylineCollection.html#length)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/PolylineCollection.js 793](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L793) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [PolylineCollection#destroy](PolylineCollection.html#destroy)

#### [](#remove) remove(polyline) → boolean 

[engine/Source/Scene/PolylineCollection.js 274](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L274) 

 Removes a polyline from the collection.

##### Performance:

After calling `remove`, [PolylineCollection#update](PolylineCollection.html#update) is called and the collection's vertex buffer is rewritten - an `O(n)` operation that also incurs CPU to GPU overhead. For best performance, remove as many polylines as possible before calling `update`. If you intend to temporarily hide a polyline, it is usually more efficient to call[Polyline#show](Polyline.html#show) instead of removing and re-adding the polyline.

| Name     | Type                      | Description             |
| -------- | ------------------------- | ----------------------- |
| polyline | [Polyline](Polyline.html) | The polyline to remove. |

##### Returns:

`true` if the polyline was removed; `false` if the polyline was not found in the collection.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
const p = polylines.add(...);
polylines.remove(p);  // Returns true
```

##### See:

* [PolylineCollection#add](PolylineCollection.html#add)
* [PolylineCollection#removeAll](PolylineCollection.html#removeAll)
* [PolylineCollection#update](PolylineCollection.html#update)
* [Polyline#show](Polyline.html#show)

#### [](#removeAll) removeAll() 

[engine/Source/Scene/PolylineCollection.js 309](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L309) 

 Removes all polylines from the collection.

##### Performance:

`O(n)`. It is more efficient to remove all the polylines from a collection and then add new ones than to create a new collection entirely.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
polylines.add(...);
polylines.add(...);
polylines.removeAll();
```

##### See:

* [PolylineCollection#add](PolylineCollection.html#add)
* [PolylineCollection#remove](PolylineCollection.html#remove)
* [PolylineCollection#update](PolylineCollection.html#update)

#### [](#update) update() 

[engine/Source/Scene/PolylineCollection.js 423](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineCollection.js#L423) 

 Called when [Viewer](Viewer.html) or [CesiumWidget](CesiumWidget.html) render the scene to get the draw commands needed to render this primitive.

Do not call this function directly. This is documented just to list the exceptions that may be propagated when the scene is rendered:

##### Throws:

* [RuntimeError](RuntimeError.html): Vertex texture fetch support is required to render primitives with per-instance attributes. The maximum number of vertex texture image units must be greater than zero.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

