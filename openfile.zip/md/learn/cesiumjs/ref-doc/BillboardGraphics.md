# [![](Images/CesiumLogo.png)](index.html) BillboardGraphics 

#### [](#BillboardGraphics) new Cesium.BillboardGraphics(options) 

[engine/Source/DataSources/BillboardGraphics.js 51](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L51) 

 Describes a two dimensional icon located at the position of the containing [Entity](Entity.html).

![](Images/Billboard.png)  
Example billboards

| Name    | Type                                                                               | Description                                       |
| ------- | ---------------------------------------------------------------------------------- | ------------------------------------------------- |
| options | [BillboardGraphics.ConstructorOptions](BillboardGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle Billboard Demo](https://sandcastle.cesium.com/index.html?src=Billboards.html)

### Members

#### [](#alignedAxis) alignedAxis : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 248](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L248) 

 Gets or sets the [Cartesian3](Cartesian3.html) Property specifying the unit vector axis of rotation in the fixed frame. When set to Cartesian3.ZERO the rotation is from the top of the screen.

Default Value: `Cartesian3.ZERO` 

#### [](#color) color : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 230](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L230) 

 Gets or sets the Property specifying the [Color](Color.html) that is multiplied with the `image`. This has two common use cases. First, the same white texture may be used by many different billboards, each with a different color, to create colored billboards. Second, the color's alpha component can be used to make the billboard translucent as shown below. An alpha of `0.0` makes the billboard transparent, and `1.0` makes the billboard opaque.

| default![](Images/Billboard.setColor.Alpha255.png) | alpha : 0.5![](Images/Billboard.setColor.Alpha127.png) |
| -------------------------------------------------- | ------------------------------------------------------ |

Default Value: `Color.WHITE` 

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/BillboardGraphics.js 107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L107) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#disableDepthTestDistance) disableDepthTestDistance : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 333](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L333) 

 Gets or sets the distance from the camera at which to disable the depth test to, for example, prevent clipping against terrain. When set to zero, the depth test is always applied. When set to Number.POSITIVE\_INFINITY, the depth test is never applied.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 323](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L323) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this billboard will be displayed.

#### [](#eyeOffset) eyeOffset : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 186](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L186) 

 Gets or sets the [Cartesian3](Cartesian3.html) Property specifying the billboard's offset in eye coordinates. Eye coordinates is a left-handed coordinate system, where `x` points towards the viewer's right, `y` points up, and `z` points into the screen.

An eye offset is commonly used to arrange multiple billboards or objects at the same position, e.g., to arrange a billboard above its corresponding 3D model.

Below, the billboard is positioned at the center of the Earth but an eye offset makes it always appear on top of the Earth regardless of the viewer's or Earth's orientation.

| ![](Images/Billboard.setEyeOffset.one.png) | ![](Images/Billboard.setEyeOffset.two.png) |
| ------------------------------------------ | ------------------------------------------ |

`b.eyeOffset = new Cartesian3(0.0, 8000000.0, 0.0);` 

Default Value: `Cartesian3.ZERO` 

#### [](#height) height : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 272](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L272) 

 Gets or sets the numeric Property specifying the height of the billboard in pixels. When undefined, the native height is used.

#### [](#heightReference) heightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 210](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L210) 

 Gets or sets the Property specifying the [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#horizontalOrigin) horizontalOrigin : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 194](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L194) 

 Gets or sets the Property specifying the [HorizontalOrigin](global.html#HorizontalOrigin).

Default Value: `HorizontalOrigin.CENTER` 

#### [](#image) image : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 126](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L126) 

 Gets or sets the Property specifying the Image, URI, or Canvas to use for the billboard.

#### [](#imageSubRegion) imageSubRegion : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 316](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L316) 

 Gets or sets the Property specifying a [BoundingRectangle](BoundingRectangle.html) that defines a sub-region of the `image` to use for the billboard, rather than the entire image, measured in pixels from the bottom-left.

#### [](#pixelOffset) pixelOffset : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 161](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L161) 

 Gets or sets the [Cartesian2](Cartesian2.html) Property specifying the billboard's pixel offset in screen space from the origin of this billboard. This is commonly used to align multiple billboards and labels at the same position, e.g., an image and text. The screen space origin is the top, left corner of the canvas; `x` increases from left to right, and `y` increases from top to bottom.

| default![](Images/Billboard.setPixelOffset.default.png) | b.pixeloffset = new Cartesian2(50, 25);![](Images/Billboard.setPixelOffset.x50y-25.png) |
| ------------------------------------------------------- | --------------------------------------------------------------------------------------- |

The billboard's origin is indicated by the yellow point.

Default Value: `Cartesian2.ZERO` 

#### [](#pixelOffsetScaleByDistance) pixelOffsetScaleByDistance : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 305](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L305) 

 Gets or sets [NearFarScalar](NearFarScalar.html) Property specifying the pixel offset of the billboard based on the distance from the camera. A billboard's pixel offset will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the billboard's pixel offset remains clamped to the nearest bound.

#### [](#rotation) rotation : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 239](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L239) 

 Gets or sets the numeric Property specifying the rotation of the image counter clockwise from the `alignedAxis`.

Default Value: `0` 

#### [](#scale) scale : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 141](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L141) 

 Gets or sets the numeric Property specifying the uniform scale to apply to the image. A scale greater than `1.0` enlarges the billboard while a scale less than `1.0` shrinks it.

![](Images/Billboard.setScale.png)  
From left to right in the above image, the scales are `0.5`, `1.0`, and `2.0`.

Default Value: `1.0` 

#### [](#scaleByDistance) scaleByDistance : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 283](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L283) 

 Gets or sets [NearFarScalar](NearFarScalar.html) Property specifying the scale of the billboard based on the distance from the camera. A billboard's scale will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the billboard's scale remains clamped to the nearest bound.

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 119](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L119) 

 Gets or sets the boolean Property specifying the visibility of the billboard.

Default Value: `true` 

#### [](#sizeInMeters) sizeInMeters : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 256](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L256) 

 Gets or sets the boolean Property specifying if this billboard's size will be measured in meters.

Default Value: `false` 

#### [](#splitDirection) splitDirection : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 343](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L343) 

 Gets or sets the Property specifying the [SplitDirection](global.html#SplitDirection) of this billboard.

Default Value: `SplitDirection.NONE` 

#### [](#translucencyByDistance) translucencyByDistance : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 294](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L294) 

 Gets or sets [NearFarScalar](NearFarScalar.html) Property specifying the translucency of the billboard based on the distance from the camera. A billboard's translucency will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the billboard's translucency remains clamped to the nearest bound.

#### [](#verticalOrigin) verticalOrigin : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 202](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L202) 

 Gets or sets the Property specifying the [VerticalOrigin](global.html#VerticalOrigin).

Default Value: `VerticalOrigin.CENTER` 

#### [](#width) width : [Property](Property.html)|undefined 

[engine/Source/DataSources/BillboardGraphics.js 264](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L264) 

 Gets or sets the numeric Property specifying the width of the billboard in pixels. When undefined, the native width is used.

### Methods

#### [](#clone) clone(result) → [BillboardGraphics](BillboardGraphics.html) 

[engine/Source/DataSources/BillboardGraphics.js 352](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L352) 

 Duplicates this instance.

| Name   | Type                                        | Description                                         |
| ------ | ------------------------------------------- | --------------------------------------------------- |
| result | [BillboardGraphics](BillboardGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/BillboardGraphics.js 386](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L386) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                        | Description                               |
| ------ | ------------------------------------------- | ----------------------------------------- |
| source | [BillboardGraphics](BillboardGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.BillboardGraphics.ConstructorOptions

[engine/Source/DataSources/BillboardGraphics.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BillboardGraphics.js#L7) 

 Initialization options for the BillboardGraphics constructor

##### Properties:

| Name                       | Type                                                                                 | Attributes | Default                 | Description                                                                                                                                                                                                 |
| -------------------------- | ------------------------------------------------------------------------------------ | ---------- | ----------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| show                       | [Property](Property.html)\|boolean                                                   | <optional> | true                    | A boolean Property specifying the visibility of the billboard.                                                                                                                                              |
| image                      | [Property](Property.html)\|string|HTMLCanvasElement                                  | <optional> |                         | A Property specifying the Image, URI, or Canvas to use for the billboard.                                                                                                                                   |
| scale                      | [Property](Property.html)\|number                                                    | <optional> | 1.0                     | A numeric Property specifying the scale to apply to the image size.                                                                                                                                         |
| pixelOffset                | [Property](Property.html)\|[Cartesian2](Cartesian2.html)                             | <optional> | Cartesian2.ZERO         | A [Cartesian2](Cartesian2.html) Property specifying the pixel offset.                                                                                                                                       |
| eyeOffset                  | [Property](Property.html)\|[Cartesian3](Cartesian3.html)                             | <optional> | Cartesian3.ZERO         | A [Cartesian3](Cartesian3.html) Property specifying the eye offset.                                                                                                                                         |
| horizontalOrigin           | [Property](Property.html)\|[HorizontalOrigin](global.html#HorizontalOrigin)          | <optional> | HorizontalOrigin.CENTER | A Property specifying the [HorizontalOrigin](global.html#HorizontalOrigin).                                                                                                                                 |
| verticalOrigin             | [Property](Property.html)\|[VerticalOrigin](global.html#VerticalOrigin)              | <optional> | VerticalOrigin.CENTER   | A Property specifying the [VerticalOrigin](global.html#VerticalOrigin).                                                                                                                                     |
| heightReference            | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE    | A Property specifying what the height is relative to.                                                                                                                                                       |
| color                      | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.WHITE             | A Property specifying the tint [Color](Color.html) of the image.                                                                                                                                            |
| rotation                   | [Property](Property.html)\|number                                                    | <optional> | 0                       | A numeric Property specifying the rotation about the alignedAxis.                                                                                                                                           |
| alignedAxis                | [Property](Property.html)\|[Cartesian3](Cartesian3.html)                             | <optional> | Cartesian3.ZERO         | A [Cartesian3](Cartesian3.html) Property specifying the unit vector axis of rotation.                                                                                                                       |
| sizeInMeters               | [Property](Property.html)\|boolean                                                   | <optional> |                         | A boolean Property specifying whether this billboard's size should be measured in meters.                                                                                                                   |
| width                      | [Property](Property.html)\|number                                                    | <optional> |                         | A numeric Property specifying the width of the billboard in pixels, overriding the native size.                                                                                                             |
| height                     | [Property](Property.html)\|number                                                    | <optional> |                         | A numeric Property specifying the height of the billboard in pixels, overriding the native size.                                                                                                            |
| scaleByDistance            | [Property](Property.html)\|[NearFarScalar](NearFarScalar.html)                       | <optional> |                         | A [NearFarScalar](NearFarScalar.html) Property used to scale the point based on distance from the camera.                                                                                                   |
| translucencyByDistance     | [Property](Property.html)\|[NearFarScalar](NearFarScalar.html)                       | <optional> |                         | A [NearFarScalar](NearFarScalar.html) Property used to set translucency based on distance from the camera.                                                                                                  |
| pixelOffsetScaleByDistance | [Property](Property.html)\|[NearFarScalar](NearFarScalar.html)                       | <optional> |                         | A [NearFarScalar](NearFarScalar.html) Property used to set pixelOffset based on distance from the camera.                                                                                                   |
| imageSubRegion             | [Property](Property.html)\|[BoundingRectangle](BoundingRectangle.html)               | <optional> |                         | A Property specifying a [BoundingRectangle](BoundingRectangle.html) that defines a sub-region of the image to use for the billboard, rather than the entire image, measured in pixels from the bottom-left. |
| distanceDisplayCondition   | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                         | A Property specifying at what distance from the camera that this billboard will be displayed.                                                                                                               |
| disableDepthTestDistance   | [Property](Property.html)\|number                                                    | <optional> |                         | A Property specifying the distance from the camera at which to disable the depth test to.                                                                                                                   |
| splitDirection             | [Property](Property.html)\|[SplitDirection](global.html#SplitDirection)              | <optional> |                         | A Property specifying the [SplitDirection](global.html#SplitDirection) of the billboard.                                                                                                                    |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

