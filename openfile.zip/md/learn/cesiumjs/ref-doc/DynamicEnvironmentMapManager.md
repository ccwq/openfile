# [![](Images/CesiumLogo.png)](index.html) DynamicEnvironmentMapManager 

#### [](#DynamicEnvironmentMapManager) new Cesium.DynamicEnvironmentMapManager(options) 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 69](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L69) 

 Generates an environment map at the given position based on scene's current lighting conditions. From this, it produces multiple levels of specular maps and spherical harmonic coefficients than can be used with [ImageBasedLighting](ImageBasedLighting.html) for models or tilesets.

| Name    | Type                                                                                                     | Description                                           |
| ------- | -------------------------------------------------------------------------------------------------------- | ----------------------------------------------------- |
| options | [DynamicEnvironmentMapManager.ConstructorOptions](DynamicEnvironmentMapManager.html#.ConstructorOptions) | optional An object describing initialization options. |

##### Examples:

```javascript
// Enable time-of-day environment mapping in a scene
scene.atmosphere.dynamicLighting = Cesium.DynamicAtmosphereLightingType.SUNLIGHT;

// Decrease the directional lighting contribution
scene.light.intensity = 0.5

// Increase the intensity of of the environment map lighting contribution
const environmentMapManager = tileset.environmentMapManager;
environmentMapManager.atmosphereScatteringIntensity = 3.0;
```

```javascript
// Change the ground color used for a model's environment map to a forest green
const environmentMapManager = model.environmentMapManager;
environmentMapManager.groundColor = Cesium.Color.fromCssColorString("#203b34");
```

### Members

#### [](#.AVERAGE%5FEARTH%5FGROUND%5FCOLOR) static readonly Cesium.DynamicEnvironmentMapManager.AVERAGE\_EARTH\_GROUND\_COLOR : [Color](Color.html) 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 1004](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L1004) 

 Average hue of ground color on earth, a warm green-gray.

#### [](#.DEFAULT%5FSPHERICAL%5FHARMONIC%5FCOEFFICIENTS) static readonly Cesium.DynamicEnvironmentMapManager.DEFAULT\_SPHERICAL\_HARMONIC\_COEFFICIENTS : Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 1018](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L1018) 

 The default third order spherical harmonic coefficients used for the diffuse color of image-based lighting, a white ambient light with low intensity.

There are nine `Cartesian3` coefficients. The order of the coefficients is: L0,0, L1,-1, L1,0, L1,1, L2,-2, L2,-1, L2,0, L2,1, L2,2 

##### See:

* [An Efficient Representation for Irradiance Environment Maps](https://graphics.stanford.edu/papers/envmap/envmap.pdf)

#### [](#atmosphereScatteringIntensity) atmosphereScatteringIntensity : number 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 160](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L160) 

 The intensity of the scattered light emitted from the atmosphere. This should be adjusted relative to the value of `Scene.light` intensity.

Default Value: `2.0` 

##### See:

* DirectionalLight.intensity
* SunLight.intensity

#### [](#brightness) brightness : number 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 178](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L178) 

 The brightness of light emitted from the environment. 1.0 uses the unmodified emitted environment color. Less than 1.0 makes the light darker while greater than 1.0 makes it brighter.

Default Value: `1.0` 

#### [](#enabled) enabled : boolean 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 124](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L124) 

 If true, the environment map and related properties will continue to update.

Default Value: `true` 

#### [](#gamma) gamma : number 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 170](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L170) 

 The gamma correction to apply to the range of light emitted from the environment. 1.0 uses the unmodified incoming light color.

Default Value: `1.0` 

#### [](#groundAlbedo) groundAlbedo : number 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 203](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L203) 

 The percentage of light reflected from the ground. The average earth albedo is 0.31.

Default Value: `0.31` 

#### [](#groundColor) groundColor : [Color](Color.html) 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 193](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L193) 

 Solid color used to represent the ground.

Default Value: `DynamicEnvironmentMapManager.AVERAGE_EARTH_GROUND_COLOR` 

#### [](#maximumPositionEpsilon) maximumPositionEpsilon : number 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 148](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L148) 

 The maximum difference in position before a new environment map is created, in meters. Small differences in position will not visibly affect results.

Default Value: `1000` 

#### [](#maximumSecondsDifference) maximumSecondsDifference : number 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 138](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L138) 

 The maximum amount of elapsed seconds before a new environment map is created.

Default Value: `3600` 

#### [](#position) position : [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 238](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L238) 

 The position around which the environment map is generated.

#### [](#saturation) saturation : number 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 186](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L186) 

 The saturation of the light emitted from the environment. 1.0 uses the unmodified emitted environment color. Less than 1.0 reduces the saturation while greater than 1.0 increases it.

Default Value: `1.0` 

### Methods

#### [](#.isDynamicUpdateSupported) static Cesium.DynamicEnvironmentMapManager.isDynamicUpdateSupported(scene) → boolean 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 994](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L994) 

 Returns `true` if dynamic updates are supported in the current WebGL rendering context. Dynamic updates requires the EXT\_color\_buffer\_float or EXT\_color\_buffer\_half\_float extension.

| Name  | Type                | Description                                 |
| ----- | ------------------- | ------------------------------------------- |
| scene | [Scene](Scene.html) | The object containing the rendering context |

##### Returns:

 true if supported

#### [](#destroy) destroy() 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 938](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L938) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
mapManager = mapManager && mapManager.destroy();
```

##### See:

* [DynamicEnvironmentMapManager#isDestroyed](DynamicEnvironmentMapManager.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/DynamicEnvironmentMapManager.js 922](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L922) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [DynamicEnvironmentMapManager#destroy](DynamicEnvironmentMapManager.html#destroy)

### Type Definitions

#### [](#.ConstructorOptions) Cesium.DynamicEnvironmentMapManager.ConstructorOptions

[engine/Source/Scene/DynamicEnvironmentMapManager.js 32](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicEnvironmentMapManager.js#L32) 

 Options for the DynamicEnvironmentMapManager constructor

##### Properties:

| Name                          | Type                | Attributes | Default                                                    | Description                                                                                                                                                                             |
| ----------------------------- | ------------------- | ---------- | ---------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| enabled                       | boolean             | <optional> | true                                                       | If true, the environment map and related properties will continue to update.                                                                                                            |
| mipmapLevels                  | number              | <optional> | 7                                                          | The number of mipmap levels to generate for specular maps. More mipmap levels will produce a higher resolution specular reflection.                                                     |
| maximumSecondsDifference      | number              | <optional> | 3600                                                       | The maximum amount of elapsed seconds before a new environment map is created.                                                                                                          |
| maximumPositionEpsilon        | number              | <optional> | 1000                                                       | The maximum difference in position before a new environment map is created, in meters. Small differences in position will not visibly affect results.                                   |
| atmosphereScatteringIntensity | number              | <optional> | 2.0                                                        | The intensity of the scattered light emitted from the atmosphere. This should be adjusted relative to the value of Scene.light intensity.                                               |
| gamma                         | number              | <optional> | 1.0                                                        | The gamma correction to apply to the range of light emitted from the environment. 1.0 uses the unmodified emitted light color.                                                          |
| brightness                    | number              | <optional> | 1.0                                                        | The brightness of light emitted from the environment. 1.0 uses the unmodified emitted environment color. Less than 1.0 makes the light darker while greater than 1.0 makes it brighter. |
| saturation                    | number              | <optional> | 1.0                                                        | The saturation of the light emitted from the environment. 1.0 uses the unmodified emitted environment color. Less than 1.0 reduces the saturation while greater than 1.0 increases it.  |
| groundColor                   | [Color](Color.html) | <optional> | DynamicEnvironmentMapManager.AVERAGE\_EARTH\_GROUND\_COLOR | Solid color used to represent the ground.                                                                                                                                               |
| groundAlbedo                  | number              | <optional> | 0.31                                                       | The percentage of light reflected from the ground. The average earth albedo is 0.31.                                                                                                    |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

