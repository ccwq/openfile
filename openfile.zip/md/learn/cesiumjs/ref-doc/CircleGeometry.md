# [![](Images/CesiumLogo.png)](index.html) CircleGeometry 

#### [](#CircleGeometry) new Cesium.CircleGeometry(options) 

[engine/Source/Core/CircleGeometry.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CircleGeometry.js#L39) 

 A description of a circle on the ellipsoid. Circle geometry can be rendered with both [Primitive](Primitive.html) and [GroundPrimitive](GroundPrimitive.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description center [Cartesian3](Cartesian3.html)  The circle's center point in the fixed frame. radius number  The radius in meters. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid the circle will be on. height number 0.0 optional The distance in meters between the circle and the ellipsoid surface. granularity number 0.02 optional The angular distance between points on the circle in radians. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. extrudedHeight number 0.0 optional The distance in meters between the circle's extruded face and the ellipsoid surface. stRotation number 0.0 optional The rotation of the texture coordinates, in radians. A positive rotation is counter-clockwise. |

##### Throws:

* [DeveloperError](DeveloperError.html): radius must be greater than zero.
* [DeveloperError](DeveloperError.html): granularity must be greater than zero.

##### Example:

```javascript
// Create a circle.
const circle = new Cesium.CircleGeometry({
  center : Cesium.Cartesian3.fromDegrees(-75.59777, 40.03883),
  radius : 100000.0
});
const geometry = Cesium.CircleGeometry.createGeometry(circle);
```

##### See:

* [CircleGeometry.createGeometry](CircleGeometry.html#.createGeometry)
* [Packable](Packable.html)

### Members

#### [](#.packedLength) static Cesium.CircleGeometry.packedLength : number 

[engine/Source/Core/CircleGeometry.js 67](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CircleGeometry.js#L67) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.CircleGeometry.createGeometry(circleGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/CircleGeometry.js 157](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CircleGeometry.js#L157) 

 Computes the geometric representation of a circle on an ellipsoid, including its vertices, indices, and a bounding sphere.

| Name           | Type                                  | Description                  |
| -------------- | ------------------------------------- | ---------------------------- |
| circleGeometry | [CircleGeometry](CircleGeometry.html) | A description of the circle. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.CircleGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/CircleGeometry.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CircleGeometry.js#L78) 

 Stores the provided instance into the provided array.

| Name          | Type                                  | Default | Description                                                               |
| ------------- | ------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [CircleGeometry](CircleGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                        |         | The array to pack into.                                                   |
| startingIndex | number                                | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.CircleGeometry.unpack(array, startingIndex, result) → [CircleGeometry](CircleGeometry.html) 

[engine/Source/Core/CircleGeometry.js 112](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CircleGeometry.js#L112) 

 Retrieves an instance from a packed array.

| Name          | Type                                  | Default | Description                                                |
| ------------- | ------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                        |         | The packed array.                                          |
| startingIndex | number                                | 0       | optional The starting index of the element to be unpacked. |
| result        | [CircleGeometry](CircleGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new CircleGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

