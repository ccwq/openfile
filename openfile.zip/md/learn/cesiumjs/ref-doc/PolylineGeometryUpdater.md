# [![](Images/CesiumLogo.png)](index.html) PolylineGeometryUpdater 

#### [](#PolylineGeometryUpdater) new Cesium.PolylineGeometryUpdater(entity, scene) 

[engine/Source/DataSources/PolylineGeometryUpdater.js 71](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L71) 

 A [GeometryUpdater](GeometryUpdater.html) for polylines. Clients do not normally create this class directly, but instead rely on [DataSourceDisplay](DataSourceDisplay.html).

| Name   | Type                  | Description                                          |
| ------ | --------------------- | ---------------------------------------------------- |
| entity | [Entity](Entity.html) | The entity containing the geometry to be visualized. |
| scene  | [Scene](Scene.html)   | The scene where visualization is taking place.       |

### Members

#### [](#arcType) readonly arcType : [ArcType](global.html#ArcType) 

[engine/Source/DataSources/PolylineGeometryUpdater.js 295](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L295) 

 Gets a value indicating if the path of the line.

#### [](#clampToGround) readonly clampToGround : boolean 

[engine/Source/DataSources/PolylineGeometryUpdater.js 309](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L309) 

 Gets a value indicating if the geometry is clamped to the ground. Returns false if polylines on terrain is not supported.

#### [](#classificationTypeProperty) readonly classificationTypeProperty : [Property](Property.html) 

[engine/Source/DataSources/PolylineGeometryUpdater.js 245](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L245) 

 Gets or sets the [ClassificationType](global.html#ClassificationType) Property specifying if this geometry will classify terrain, 3D Tiles, or both when on the ground.

#### [](#depthFailMaterialProperty) readonly depthFailMaterialProperty : [MaterialProperty](MaterialProperty.html) 

[engine/Source/DataSources/PolylineGeometryUpdater.js 178](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L178) 

 Gets the material property used to fill the geometry when it fails the depth test.

#### [](#distanceDisplayConditionProperty) readonly distanceDisplayConditionProperty : [Property](Property.html) 

[engine/Source/DataSources/PolylineGeometryUpdater.js 233](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L233) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this geometry will be displayed.

#### [](#entity) readonly entity : [Entity](Entity.html) 

[engine/Source/DataSources/PolylineGeometryUpdater.js 126](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L126) 

 Gets the entity associated with this geometry.

#### [](#fillEnabled) readonly fillEnabled : boolean 

[engine/Source/DataSources/PolylineGeometryUpdater.js 138](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L138) 

 Gets a value indicating if the geometry has a fill component.

#### [](#fillMaterialProperty) readonly fillMaterialProperty : [MaterialProperty](MaterialProperty.html) 

[engine/Source/DataSources/PolylineGeometryUpdater.js 166](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L166) 

 Gets the material property used to fill the geometry.

#### [](#geometryChanged) readonly geometryChanged : boolean 

[engine/Source/DataSources/PolylineGeometryUpdater.js 282](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L282) 

 Gets an event that is raised whenever the public properties of this updater change.

#### [](#hasConstantFill) readonly hasConstantFill : boolean 

[engine/Source/DataSources/PolylineGeometryUpdater.js 150](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L150) 

 Gets a value indicating if fill visibility varies with simulation time.

#### [](#hasConstantOutline) readonly hasConstantOutline : boolean 

[engine/Source/DataSources/PolylineGeometryUpdater.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L200) 

 Gets a value indicating if outline visibility varies with simulation time.

#### [](#id) readonly id : string 

[engine/Source/DataSources/PolylineGeometryUpdater.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L114) 

 Gets the unique ID associated with this updater

#### [](#isClosed) readonly isClosed : boolean 

[engine/Source/DataSources/PolylineGeometryUpdater.js 271](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L271) 

 Gets a value indicating if the geometry is closed. This property is only valid for static geometry.

#### [](#isDynamic) readonly isDynamic : boolean 

[engine/Source/DataSources/PolylineGeometryUpdater.js 258](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L258) 

 Gets a value indicating if the geometry is time-varying.

#### [](#outlineColorProperty) readonly outlineColorProperty : [Property](Property.html) 

[engine/Source/DataSources/PolylineGeometryUpdater.js 210](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L210) 

 Gets the [Color](Color.html) property for the geometry outline.

#### [](#outlineEnabled) readonly outlineEnabled : boolean 

[engine/Source/DataSources/PolylineGeometryUpdater.js 190](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L190) 

 Gets a value indicating if the geometry has an outline component.

#### [](#shadowsProperty) readonly shadowsProperty : [Property](Property.html) 

[engine/Source/DataSources/PolylineGeometryUpdater.js 221](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L221) 

 Gets the property specifying whether the geometry casts or receives shadows from light sources.

#### [](#zIndex) readonly zIndex : number 

[engine/Source/DataSources/PolylineGeometryUpdater.js 321](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L321) 

 Gets the zindex

### Methods

#### [](#createFillGeometryInstance) createFillGeometryInstance(time) → [GeometryInstance](GeometryInstance.html) 

[engine/Source/DataSources/PolylineGeometryUpdater.js 361](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L361) 

 Creates the geometry instance which represents the fill of the geometry.

| Name | Type                          | Description                                               |
| ---- | ----------------------------- | --------------------------------------------------------- |
| time | [JulianDate](JulianDate.html) | The time to use when retrieving initial attribute values. |

##### Returns:

 The geometry instance representing the filled portion of the geometry.

##### Throws:

* [DeveloperError](DeveloperError.html): This instance does not represent a filled geometry.

#### [](#createOutlineGeometryInstance) createOutlineGeometryInstance(time) → [GeometryInstance](GeometryInstance.html) 

[engine/Source/DataSources/PolylineGeometryUpdater.js 448](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L448) 

 Creates the geometry instance which represents the outline of the geometry.

| Name | Type                          | Description                                               |
| ---- | ----------------------------- | --------------------------------------------------------- |
| time | [JulianDate](JulianDate.html) | The time to use when retrieving initial attribute values. |

##### Returns:

 The geometry instance representing the outline portion of the geometry.

##### Throws:

* [DeveloperError](DeveloperError.html): This instance does not represent an outlined geometry.

#### [](#destroy) destroy() 

[engine/Source/DataSources/PolylineGeometryUpdater.js 472](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L472) 

 Destroys and resources used by the object. Once an object is destroyed, it should not be used.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/DataSources/PolylineGeometryUpdater.js 463](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L463) 

 Returns true if this object was destroyed; otherwise, false.

##### Returns:

 True if this object was destroyed; otherwise, false.

#### [](#isFilled) isFilled(time) → boolean 

[engine/Source/DataSources/PolylineGeometryUpdater.js 344](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L344) 

 Checks if the geometry is filled at the provided time.

| Name | Type                          | Description                                |
| ---- | ----------------------------- | ------------------------------------------ |
| time | [JulianDate](JulianDate.html) | The time for which to retrieve visibility. |

##### Returns:

 true if geometry is filled at the provided time, false otherwise.

#### [](#isOutlineVisible) isOutlineVisible(time) → boolean 

[engine/Source/DataSources/PolylineGeometryUpdater.js 334](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGeometryUpdater.js#L334) 

 Checks if the geometry is outlined at the provided time.

| Name | Type                          | Description                                |
| ---- | ----------------------------- | ------------------------------------------ |
| time | [JulianDate](JulianDate.html) | The time for which to retrieve visibility. |

##### Returns:

 true if geometry is outlined at the provided time, false otherwise.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

