# [![](Images/CesiumLogo.png)](index.html) Cesium3DTilesVoxelProvider 

#### [](#Cesium3DTilesVoxelProvider) new Cesium.Cesium3DTilesVoxelProvider(options) 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 70](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L70) 

 A [VoxelProvider](VoxelProvider.html) that fetches voxel data from a 3D Tiles tileset.

Implements the [VoxelProvider](VoxelProvider.html) interface.

This object is normally not instantiated directly, use [Cesium3DTilesVoxelProvider.fromUrl](Cesium3DTilesVoxelProvider.html#.fromUrl).

| Name    | Type                                                                                                 | Description                                 |
| ------- | ---------------------------------------------------------------------------------------------------- | ------------------------------------------- |
| options | [Cesium3DTilesVoxelProvider.ConstructorOptions](Cesium3DTilesVoxelProvider.html#.ConstructorOptions) | An object describing initialization options |

##### Experimental

This feature is not final and is subject to change without Cesium's standard deprecation policy.

##### See:

* [Cesium3DTilesVoxelProvider.fromUrl](Cesium3DTilesVoxelProvider.html#.fromUrl)
* [VoxelProvider](VoxelProvider.html)
* [VoxelPrimitive](VoxelPrimitive.html)
* [VoxelShapeType](global.html#VoxelShapeType)

### Extends

* [VoxelProvider](VoxelProvider.html)

### Members

#### [](#availableLevels) readonly availableLevels : number|undefined 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 345](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L345) 

 The number of levels of detail containing available tiles in the tileset.

#### [](#className) readonly className : string 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 239](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L239) 

 The metadata class for this tileset.

#### [](#componentTypes) readonly componentTypes : Array.<[MetadataComponentType](global.html#MetadataComponentType)\> 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 278](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L278) 

 Gets the metadata component types.

#### [](#dimensions) readonly dimensions : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 198](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L198) 

 Gets the number of voxels per dimension of a tile. This is the same for all tiles in the dataset.

#### [](#globalTransform) readonly globalTransform : [Matrix4](Matrix4.html) 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 130](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L130) 

 A transform from local space to global space.

Default Value: `Matrix4.IDENTITY` 

#### [](#maxBounds) readonly maxBounds : [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 185](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L185) 

 Gets the maximum bounds. If undefined, the shape's default maximum bounds will be used instead.

#### [](#maximumTileCount) readonly maximumTileCount : number|undefined 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 332](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L332) 

 The maximum number of tiles that exist for this provider. This value is used as a hint to the voxel renderer to allocate an appropriate amount of GPU memory. If this value is not known it can be undefined.

#### [](#maximumValues) readonly maximumValues : Array.<Array.<number>>|undefined 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 317](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L317) 

 Gets the metadata maximum values.

#### [](#metadataOrder) readonly metadataOrder : [VoxelMetadataOrder](global.html#VoxelMetadataOrder) 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 291](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L291) 

 Gets the ordering of the metadata in the buffers.

#### [](#minBounds) readonly minBounds : [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 171](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L171) 

 Gets the minimum bounds. If undefined, the shape's default minimum bounds will be used instead.

#### [](#minimumValues) readonly minimumValues : Array.<Array.<number>>|undefined 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 304](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L304) 

 Gets the metadata minimum values.

#### [](#names) readonly names : Array.<string> 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 252](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L252) 

 Gets the metadata names.

#### [](#paddingAfter) readonly paddingAfter : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 226](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L226) 

 Gets the number of padding voxels after the tile. This improves rendering quality when sampling the edge of a tile, but it increases memory usage.

Default Value: `Cartesian3.ZERO` 

#### [](#paddingBefore) readonly paddingBefore : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 212](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L212) 

 Gets the number of padding voxels before the tile. This improves rendering quality when sampling the edge of a tile, but it increases memory usage.

Default Value: `Cartesian3.ZERO` 

#### [](#shape) readonly shape : [VoxelShapeType](global.html#VoxelShapeType) 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 157](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L157) 

 Gets the [VoxelShapeType](global.html#VoxelShapeType) 

#### [](#shapeTransform) readonly shapeTransform : [Matrix4](Matrix4.html) 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L144) 

 A transform from shape space to local space.

Default Value: `Matrix4.IDENTITY` 

#### [](#types) readonly types : Array.<[MetadataType](global.html#MetadataType)\> 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 265](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L265) 

 Gets the metadata types.

### Methods

#### [](#.fromUrl) static Cesium.Cesium3DTilesVoxelProvider.fromUrl(url) → Promise.<[Cesium3DTilesVoxelProvider](Cesium3DTilesVoxelProvider.html)\> 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 380](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L380) 

 Creates a [Cesium3DTilesVoxelProvider](Cesium3DTilesVoxelProvider.html) that fetches voxel data from a 3D Tiles tileset.

| Name | Type                              | Description                    |
| ---- | --------------------------------- | ------------------------------ |
| url  | [Resource](Resource.html)\|string | The URL to a tileset JSON file |

##### Returns:

 The created provider

##### Throws:

* RuntimeException: Root must have content
* RuntimeException: Root tile content must have 3DTILES\_content\_voxels extension
* RuntimeException: Root tile must have implicit tiling
* RuntimeException: Tileset must have a metadata schema
* RuntimeException: Only box, region and 3DTILES\_bounding\_volume\_cylinder are supported in Cesium3DTilesVoxelProvider

##### Example:

```javascript
try {
  const voxelProvider = await Cesium3DTilesVoxelProvider.fromUrl(
    "http://localhost:8002/tilesets/voxel/tileset.json"
  );
  const voxelPrimitive = new VoxelPrimitive({
    provider: voxelProvider,
    customShader: customShader,
  });
  scene.primitives.add(voxelPrimitive);
} catch (error) {
  console.error(`Error creating voxel primitive: ${error}`);
}
```

##### See:

* [VoxelPrimitive](VoxelPrimitive.html)

#### [](#requestData) requestData(options) → Promise.<[VoxelContent](VoxelContent.html)\>|undefined 

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 670](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L670) 

 Requests the data for a given tile.

| Name    | Type   | Description                                                                                                                                                                                                                                                                   |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description tileLevel number 0 optional The tile's level. tileX number 0 optional The tile's X coordinate. tileY number 0 optional The tile's Y coordinate. tileZ number 0 optional The tile's Z coordinate. |

##### Returns:

 A promise resolving to a VoxelContent containing the data for the tile, or undefined if the request could not be scheduled this frame.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.Cesium3DTilesVoxelProvider.ConstructorOptions

[engine/Source/Scene/Cesium3DTilesVoxelProvider.js 26](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilesVoxelProvider.js#L26) 

 Initialization options for the Cesium3DTilesVoxelProvider constructor

##### Properties:

| Name             | Type                                                                | Attributes | Default          | Description                                                                                                                                                                                                   |
| ---------------- | ------------------------------------------------------------------- | ---------- | ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| className        | string                                                              |            |                  | The class in the tileset schema describing voxel metadata.                                                                                                                                                    |
| names            | Array.<string>                                                      |            |                  | The metadata names.                                                                                                                                                                                           |
| types            | Array.<[MetadataType](global.html#MetadataType)\>                   |            |                  | The metadata types.                                                                                                                                                                                           |
| componentTypes   | Array.<[MetadataComponentType](global.html#MetadataComponentType)\> |            |                  | The metadata component types.                                                                                                                                                                                 |
| shape            | [VoxelShapeType](global.html#VoxelShapeType)                        |            |                  | The [VoxelShapeType](global.html#VoxelShapeType).                                                                                                                                                             |
| dimensions       | [Cartesian3](Cartesian3.html)                                       |            |                  | The number of voxels per dimension of a tile. This is the same for all tiles in the dataset.                                                                                                                  |
| paddingBefore    | [Cartesian3](Cartesian3.html)                                       | <optional> | Cartesian3.ZERO  | The number of padding voxels before the tile. This improves rendering quality when sampling the edge of a tile, but it increases memory usage.                                                                |
| paddingAfter     | [Cartesian3](Cartesian3.html)                                       | <optional> | Cartesian3.ZERO  | The number of padding voxels after the tile. This improves rendering quality when sampling the edge of a tile, but it increases memory usage.                                                                 |
| globalTransform  | [Matrix4](Matrix4.html)                                             | <optional> | Matrix4.IDENTITY | A transform from local space to global space.                                                                                                                                                                 |
| shapeTransform   | [Matrix4](Matrix4.html)                                             | <optional> | Matrix4.IDENTITY | A transform from shape space to local space.                                                                                                                                                                  |
| minBounds        | [Cartesian3](Cartesian3.html)                                       | <optional> |                  | The minimum bounds.                                                                                                                                                                                           |
| maxBounds        | [Cartesian3](Cartesian3.html)                                       | <optional> |                  | The maximum bounds.                                                                                                                                                                                           |
| minimumValues    | Array.<Array.<number>>                                              | <optional> |                  | The metadata minimum values.                                                                                                                                                                                  |
| maximumValues    | Array.<Array.<number>>                                              | <optional> |                  | The metadata maximum values.                                                                                                                                                                                  |
| maximumTileCount | number                                                              | <optional> |                  | The maximum number of tiles that exist for this provider. This value is used as a hint to the voxel renderer to allocate an appropriate amount of GPU memory. If this value is not known it can be undefined. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

