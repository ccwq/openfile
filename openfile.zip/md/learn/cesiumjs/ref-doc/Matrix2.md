# [![](Images/CesiumLogo.png)](index.html) Matrix2 

#### [](#Matrix2) new Cesium.Matrix2(column0Row0, column1Row0, column0Row1, column1Row1) 

[engine/Source/Core/Matrix2.js 28](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L28) 

 A 2x2 matrix, indexable as a column-major order array. Constructor parameters are in row-major order for code readability.

| Name        | Type   | Default | Description                             |
| ----------- | ------ | ------- | --------------------------------------- |
| column0Row0 | number | 0.0     | optional The value for column 0, row 0. |
| column1Row0 | number | 0.0     | optional The value for column 1, row 0. |
| column0Row1 | number | 0.0     | optional The value for column 0, row 1. |
| column1Row1 | number | 0.0     | optional The value for column 1, row 1. |

##### See:

* [Matrix2.fromArray](Matrix2.html#.fromArray)
* [Matrix2.fromColumnMajorArray](Matrix2.html#.fromColumnMajorArray)
* [Matrix2.fromRowMajorArray](Matrix2.html#.fromRowMajorArray)
* [Matrix2.fromScale](Matrix2.html#.fromScale)
* [Matrix2.fromUniformScale](Matrix2.html#.fromUniformScale)
* [Matrix2.fromRotation](Matrix2.html#.fromRotation)
* [Matrix3](Matrix3.html)
* [Matrix4](Matrix4.html)

### Members

#### [](#length) length : number 

[engine/Source/Core/Matrix2.js 1043](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L1043) 

 Gets the number of items in the collection.

#### [](#.COLUMN0ROW0) static constant Cesium.Matrix2.COLUMN0ROW0 : number 

[engine/Source/Core/Matrix2.js 998](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L998) 

 The index into Matrix2 for column 0, row 0.

##### Example:

```javascript
const matrix = new Cesium.Matrix2();
matrix[Cesium.Matrix2.COLUMN0ROW0] = 5.0; // set column 0, row 0 to 5.0
```

#### [](#.COLUMN0ROW1) static constant Cesium.Matrix2.COLUMN0ROW1 : number 

[engine/Source/Core/Matrix2.js 1010](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L1010) 

 The index into Matrix2 for column 0, row 1.

##### Example:

```javascript
const matrix = new Cesium.Matrix2();
matrix[Cesium.Matrix2.COLUMN0ROW1] = 5.0; // set column 0, row 1 to 5.0
```

#### [](#.COLUMN1ROW0) static constant Cesium.Matrix2.COLUMN1ROW0 : number 

[engine/Source/Core/Matrix2.js 1022](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L1022) 

 The index into Matrix2 for column 1, row 0.

##### Example:

```javascript
const matrix = new Cesium.Matrix2();
matrix[Cesium.Matrix2.COLUMN1ROW0] = 5.0; // set column 1, row 0 to 5.0
```

#### [](#.COLUMN1ROW1) static constant Cesium.Matrix2.COLUMN1ROW1 : number 

[engine/Source/Core/Matrix2.js 1034](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L1034) 

 The index into Matrix2 for column 1, row 1.

##### Example:

```javascript
const matrix = new Cesium.Matrix2();
matrix[Cesium.Matrix2.COLUMN1ROW1] = 5.0; // set column 1, row 1 to 5.0
```

#### [](#.IDENTITY) static constant Cesium.Matrix2.IDENTITY : [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 978](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L978) 

 An immutable Matrix2 instance initialized to the identity matrix.

#### [](#.packedLength) static Cesium.Matrix2.packedLength : number 

[engine/Source/Core/Matrix2.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L39) 

 The number of elements used to pack the object into an array.

#### [](#.ZERO) static constant Cesium.Matrix2.ZERO : [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 986](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L986) 

 An immutable Matrix2 instance initialized to the zero matrix.

### Methods

#### [](#clone) clone(result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 1056](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L1056) 

 Duplicates the provided Matrix2 instance.

| Name   | Type                    | Description                                         |
| ------ | ----------------------- | --------------------------------------------------- |
| result | [Matrix2](Matrix2.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Matrix2 instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/Matrix2.js 1067](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L1067) 

 Compares this matrix to the provided matrix componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                    | Description                          |
| ----- | ----------------------- | ------------------------------------ |
| right | [Matrix2](Matrix2.html) | optional The right hand side matrix. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(right, epsilon) → boolean 

[engine/Source/Core/Matrix2.js 1080](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L1080) 

 Compares this matrix to the provided matrix componentwise and returns`true` if they are within the provided epsilon,`false` otherwise.

| Name    | Type                    | Default | Description                                       |
| ------- | ----------------------- | ------- | ------------------------------------------------- |
| right   | [Matrix2](Matrix2.html) |         | optional The right hand side matrix.              |
| epsilon | number                  | 0       | optional The epsilon to use for equality testing. |

##### Returns:

`true` if they are within the provided epsilon, `false` otherwise.

#### [](#toString) toString() → string 

[engine/Source/Core/Matrix2.js 1090](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L1090) 

 Creates a string representing this Matrix with each row being on a separate line and in the format '(column0, column1)'.

##### Returns:

 A string representing the provided Matrix with each row being on a separate line and in the format '(column0, column1)'.

#### [](#.abs) static Cesium.Matrix2.abs(matrix, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 903](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L903) 

 Computes a matrix, which contains the absolute (unsigned) values of the provided matrix's elements.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix2](Matrix2.html) | The matrix with signed elements.           |
| result | [Matrix2](Matrix2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.add) static Cesium.Matrix2.add(left, right, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 701](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L701) 

 Computes the sum of two matrices.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| left   | [Matrix2](Matrix2.html) | The first matrix.                          |
| right  | [Matrix2](Matrix2.html) | The second matrix.                         |
| result | [Matrix2](Matrix2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.clone) static Cesium.Matrix2.clone(matrix, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 162](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L162) 

 Duplicates a Matrix2 instance.

| Name   | Type                    | Description                                         |
| ------ | ----------------------- | --------------------------------------------------- |
| matrix | [Matrix2](Matrix2.html) | The matrix to duplicate.                            |
| result | [Matrix2](Matrix2.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Matrix2 instance if one was not provided. (Returns undefined if matrix is undefined)

#### [](#.equals) static Cesium.Matrix2.equals(left, right) → boolean 

[engine/Source/Core/Matrix2.js 925](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L925) 

 Compares the provided matrices componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                    | Description                 |
| ----- | ----------------------- | --------------------------- |
| left  | [Matrix2](Matrix2.html) | optional The first matrix.  |
| right | [Matrix2](Matrix2.html) | optional The second matrix. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.equalsEpsilon) static Cesium.Matrix2.equalsEpsilon(left, right, epsilon) → boolean 

[engine/Source/Core/Matrix2.js 959](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L959) 

 Compares the provided matrices componentwise and returns`true` if they are within the provided epsilon,`false` otherwise.

| Name    | Type                    | Default | Description                                       |
| ------- | ----------------------- | ------- | ------------------------------------------------- |
| left    | [Matrix2](Matrix2.html) |         | optional The first matrix.                        |
| right   | [Matrix2](Matrix2.html) |         | optional The second matrix.                       |
| epsilon | number                  | 0       | optional The epsilon to use for equality testing. |

##### Returns:

`true` if left and right are within the provided epsilon, `false` otherwise.

#### [](#.fromArray) static Cesium.Matrix2.fromArray(array, startingIndex, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 197](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L197) 

 Creates a Matrix2 from 4 consecutive elements in an array.

| Name          | Type                    | Default | Description                                                                                                                  |
| ------------- | ----------------------- | ------- | ---------------------------------------------------------------------------------------------------------------------------- |
| array         | Array.<number>          |         | The array whose 4 consecutive elements correspond to the positions of the matrix. Assumes column-major order.                |
| startingIndex | number                  | 0       | optional The offset into the array of the first element, which corresponds to first column first row position in the matrix. |
| result        | [Matrix2](Matrix2.html) |         | optional The object onto which to store the result.                                                                          |

##### Returns:

 The modified result parameter or a new Matrix2 instance if one was not provided.

##### Example:

```javascript
// Create the Matrix2:
// [1.0, 2.0]
// [1.0, 2.0]

const v = [1.0, 1.0, 2.0, 2.0];
const m = Cesium.Matrix2.fromArray(v);

// Create same Matrix2 with using an offset into an array
const v2 = [0.0, 0.0, 1.0, 1.0, 2.0, 2.0];
const m2 = Cesium.Matrix2.fromArray(v2, 2);
```

#### [](#.fromColumnMajorArray) static Cesium.Matrix2.fromColumnMajorArray(values, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 205](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L205) 

 Creates a Matrix2 instance from a column-major order array.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| values | Array.<number>          | The column-major order array.                                                                        |
| result | [Matrix2](Matrix2.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix2 instance if one was not provided.

#### [](#.fromRotation) static Cesium.Matrix2.fromRotation(angle, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 307](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L307) 

 Creates a rotation matrix.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| angle  | number                  | The angle, in radians, of the rotation. Positive angles are counterclockwise.                        |
| result | [Matrix2](Matrix2.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix2 instance if one was not provided.

##### Example:

```javascript
// Rotate a point 45 degrees counterclockwise.
const p = new Cesium.Cartesian2(5, 6);
const m = Cesium.Matrix2.fromRotation(Cesium.Math.toRadians(45.0));
const rotated = Cesium.Matrix2.multiplyByVector(m, p, new Cesium.Cartesian2());
```

#### [](#.fromRowMajorArray) static Cesium.Matrix2.fromRowMajorArray(values, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 221](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L221) 

 Creates a Matrix2 instance from a row-major order array. The resulting matrix will be in column-major order.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| values | Array.<number>          | The row-major order array.                                                                           |
| result | [Matrix2](Matrix2.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix2 instance if one was not provided.

#### [](#.fromScale) static Cesium.Matrix2.fromScale(scale, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L249) 

 Computes a Matrix2 instance representing a non-uniform scale.

| Name   | Type                          | Description                                                                                          |
| ------ | ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| scale  | [Cartesian2](Cartesian2.html) | The x and y scale factors.                                                                           |
| result | [Matrix2](Matrix2.html)       | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix2 instance if one was not provided.

##### Example:

```javascript
// Creates
//   [7.0, 0.0]
//   [0.0, 8.0]
const m = Cesium.Matrix2.fromScale(new Cesium.Cartesian2(7.0, 8.0));
```

#### [](#.fromUniformScale) static Cesium.Matrix2.fromUniformScale(scale, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 278](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L278) 

 Computes a Matrix2 instance representing a uniform scale.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| scale  | number                  | The uniform scale factor.                                                                            |
| result | [Matrix2](Matrix2.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix2 instance if one was not provided.

##### Example:

```javascript
// Creates
//   [2.0, 0.0]
//   [0.0, 2.0]
const m = Cesium.Matrix2.fromUniformScale(2.0);
```

#### [](#.getColumn) static Cesium.Matrix2.getColumn(matrix, index, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Matrix2.js 386](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L386) 

 Retrieves a copy of the matrix column at the provided index as a Cartesian2 instance.

| Name   | Type                          | Description                                     |
| ------ | ----------------------------- | ----------------------------------------------- |
| matrix | [Matrix2](Matrix2.html)       | The matrix to use.                              |
| index  | number                        | The zero-based index of the column to retrieve. |
| result | [Cartesian2](Cartesian2.html) | The object onto which to store the result.      |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0 or 1.

#### [](#.getElementIndex) static Cesium.Matrix2.getElementIndex(row, column) → number 

[engine/Source/Core/Matrix2.js 364](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L364) 

 Computes the array index of the element at the provided row and column.

| Name   | Type   | Description                         |
| ------ | ------ | ----------------------------------- |
| row    | number | The zero-based index of the row.    |
| column | number | The zero-based index of the column. |

##### Returns:

 The index of the element at the provided row and column.

##### Throws:

* [DeveloperError](DeveloperError.html): row must be 0 or 1.
* [DeveloperError](DeveloperError.html): column must be 0 or 1.

##### Example:

```javascript
const myMatrix = new Cesium.Matrix2();
const column1Row0Index = Cesium.Matrix2.getElementIndex(1, 0);
const column1Row0 = myMatrix[column1Row0Index]
myMatrix[column1Row0Index] = 10.0;
```

#### [](#.getMaximumScale) static Cesium.Matrix2.getMaximumScale(matrix) → number 

[engine/Source/Core/Matrix2.js 604](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L604) 

 Computes the maximum scale assuming the matrix is an affine transformation. The maximum scale is the maximum length of the column vectors.

| Name   | Type                    | Description |
| ------ | ----------------------- | ----------- |
| matrix | [Matrix2](Matrix2.html) | The matrix. |

##### Returns:

 The maximum scale.

#### [](#.getRotation) static Cesium.Matrix2.getRotation(matrix, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 650](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L650) 

 Extracts the rotation matrix assuming the matrix is an affine transformation.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix2](Matrix2.html) | The matrix.                                |
| result | [Matrix2](Matrix2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix2.setRotation](Matrix2.html#.setRotation)
* [Matrix2.fromRotation](Matrix2.html#.fromRotation)

#### [](#.getRow) static Cesium.Matrix2.getRow(matrix, index, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Matrix2.js 444](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L444) 

 Retrieves a copy of the matrix row at the provided index as a Cartesian2 instance.

| Name   | Type                          | Description                                  |
| ------ | ----------------------------- | -------------------------------------------- |
| matrix | [Matrix2](Matrix2.html)       | The matrix to use.                           |
| index  | number                        | The zero-based index of the row to retrieve. |
| result | [Cartesian2](Cartesian2.html) | The object onto which to store the result.   |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0 or 1.

#### [](#.getScale) static Cesium.Matrix2.getScale(matrix, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Matrix2.js 580](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L580) 

 Extracts the non-uniform scale assuming the matrix is an affine transformation.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| matrix | [Matrix2](Matrix2.html)       | The matrix.                                |
| result | [Cartesian2](Cartesian2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix2.multiplyByScale](Matrix2.html#.multiplyByScale)
* [Matrix2.multiplyByUniformScale](Matrix2.html#.multiplyByUniformScale)
* [Matrix2.fromScale](Matrix2.html#.fromScale)
* [Matrix2.fromUniformScale](Matrix2.html#.fromUniformScale)
* [Matrix2.setScale](Matrix2.html#.setScale)
* [Matrix2.setUniformScale](Matrix2.html#.setUniformScale)

#### [](#.multiply) static Cesium.Matrix2.multiply(left, right, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 674](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L674) 

 Computes the product of two matrices.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| left   | [Matrix2](Matrix2.html) | The first matrix.                          |
| right  | [Matrix2](Matrix2.html) | The second matrix.                         |
| result | [Matrix2](Matrix2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiplyByScalar) static Cesium.Matrix2.multiplyByScalar(matrix, scalar, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 768](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L768) 

 Computes the product of a matrix and a scalar.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix2](Matrix2.html) | The matrix.                                |
| scalar | number                  | The number to multiply by.                 |
| result | [Matrix2](Matrix2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiplyByScale) static Cesium.Matrix2.multiplyByScale(matrix, scale, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 802](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L802) 

 Computes the product of a matrix times a (non-uniform) scale, as if the scale were a scale matrix.

| Name   | Type                          | Description                                   |
| ------ | ----------------------------- | --------------------------------------------- |
| matrix | [Matrix2](Matrix2.html)       | The matrix on the left-hand side.             |
| scale  | [Cartesian2](Cartesian2.html) | The non-uniform scale on the right-hand side. |
| result | [Matrix2](Matrix2.html)       | The object onto which to store the result.    |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
// Instead of Cesium.Matrix2.multiply(m, Cesium.Matrix2.fromScale(scale), m);
Cesium.Matrix2.multiplyByScale(m, scale, m);
```

##### See:

* [Matrix2.multiplyByUniformScale](Matrix2.html#.multiplyByUniformScale)
* [Matrix2.fromScale](Matrix2.html#.fromScale)
* [Matrix2.fromUniformScale](Matrix2.html#.fromUniformScale)
* [Matrix2.setScale](Matrix2.html#.setScale)
* [Matrix2.setUniformScale](Matrix2.html#.setUniformScale)
* [Matrix2.getScale](Matrix2.html#.getScale)

#### [](#.multiplyByUniformScale) static Cesium.Matrix2.multiplyByUniformScale(matrix, scale, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 836](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L836) 

 Computes the product of a matrix times a uniform scale, as if the scale were a scale matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix2](Matrix2.html) | The matrix on the left-hand side.          |
| scale  | number                  | The uniform scale on the right-hand side.  |
| result | [Matrix2](Matrix2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
// Instead of Cesium.Matrix2.multiply(m, Cesium.Matrix2.fromUniformScale(scale), m);
Cesium.Matrix2.multiplyByUniformScale(m, scale, m);
```

##### See:

* [Matrix2.multiplyByScale](Matrix2.html#.multiplyByScale)
* [Matrix2.fromScale](Matrix2.html#.fromScale)
* [Matrix2.fromUniformScale](Matrix2.html#.fromUniformScale)
* [Matrix2.setScale](Matrix2.html#.setScale)
* [Matrix2.setUniformScale](Matrix2.html#.setUniformScale)
* [Matrix2.getScale](Matrix2.html#.getScale)

#### [](#.multiplyByVector) static Cesium.Matrix2.multiplyByVector(matrix, cartesian, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Matrix2.js 745](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L745) 

 Computes the product of a matrix and a column vector.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| matrix    | [Matrix2](Matrix2.html)       | The matrix.                                |
| cartesian | [Cartesian2](Cartesian2.html) | The column.                                |
| result    | [Cartesian2](Cartesian2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.negate) static Cesium.Matrix2.negate(matrix, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 858](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L858) 

 Creates a negated copy of the provided matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix2](Matrix2.html) | The matrix to negate.                      |
| result | [Matrix2](Matrix2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.pack) static Cesium.Matrix2.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/Matrix2.js 50](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L50) 

 Stores the provided instance into the provided array.

| Name          | Type                    | Default | Description                                                               |
| ------------- | ----------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [Matrix2](Matrix2.html) |         | The value to pack.                                                        |
| array         | Array.<number>          |         | The array to pack into.                                                   |
| startingIndex | number                  | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.packArray) static Cesium.Matrix2.packArray(array, result) → Array.<number> 

[engine/Source/Core/Matrix2.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L100) 

 Flattens an array of Matrix2s into an array of components. The components are stored in column-major order.

| Name   | Type                             | Description                                                                                                                                                                                                                                                             |
| ------ | -------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| array  | Array.<[Matrix2](Matrix2.html)\> | The array of matrices to pack.                                                                                                                                                                                                                                          |
| result | Array.<number>                   | optional The array onto which to store the result. If this is a typed array, it must have array.length \* 4 components, else a [DeveloperError](DeveloperError.html) will be thrown. If it is a regular array, it will be resized to have (array.length \* 4) elements. |

##### Returns:

 The packed array.

#### [](#.setColumn) static Cesium.Matrix2.setColumn(matrix, index, cartesian, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 416](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L416) 

 Computes a new matrix that replaces the specified column in the provided matrix with the provided Cartesian2 instance.

| Name      | Type                          | Description                                                          |
| --------- | ----------------------------- | -------------------------------------------------------------------- |
| matrix    | [Matrix2](Matrix2.html)       | The matrix to use.                                                   |
| index     | number                        | The zero-based index of the column to set.                           |
| cartesian | [Cartesian2](Cartesian2.html) | The Cartesian whose values will be assigned to the specified column. |
| result    | [Cartesian2](Cartesian2.html) | The object onto which to store the result.                           |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0 or 1.

#### [](#.setRotation) static Cesium.Matrix2.setRotation(matrix, rotation, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 622](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L622) 

 Sets the rotation assuming the matrix is an affine transformation.

| Name     | Type                    | Description                                |
| -------- | ----------------------- | ------------------------------------------ |
| matrix   | [Matrix2](Matrix2.html) | The matrix.                                |
| rotation | [Matrix2](Matrix2.html) | The rotation matrix.                       |
| result   | [Matrix2](Matrix2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix2.fromRotation](Matrix2.html#.fromRotation)
* [Matrix2.getRotation](Matrix2.html#.getRotation)

#### [](#.setRow) static Cesium.Matrix2.setRow(matrix, index, cartesian, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 473](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L473) 

 Computes a new matrix that replaces the specified row in the provided matrix with the provided Cartesian2 instance.

| Name      | Type                          | Description                                                       |
| --------- | ----------------------------- | ----------------------------------------------------------------- |
| matrix    | [Matrix2](Matrix2.html)       | The matrix to use.                                                |
| index     | number                        | The zero-based index of the row to set.                           |
| cartesian | [Cartesian2](Cartesian2.html) | The Cartesian whose values will be assigned to the specified row. |
| result    | [Matrix2](Matrix2.html)       | The object onto which to store the result.                        |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0 or 1.

#### [](#.setScale) static Cesium.Matrix2.setScale(matrix, scale, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 508](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L508) 

 Computes a new matrix that replaces the scale with the provided scale. This assumes the matrix is an affine transformation.

| Name   | Type                          | Description                                               |
| ------ | ----------------------------- | --------------------------------------------------------- |
| matrix | [Matrix2](Matrix2.html)       | The matrix to use.                                        |
| scale  | [Cartesian2](Cartesian2.html) | The scale that replaces the scale of the provided matrix. |
| result | [Matrix2](Matrix2.html)       | The object onto which to store the result.                |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix2.setUniformScale](Matrix2.html#.setUniformScale)
* [Matrix2.fromScale](Matrix2.html#.fromScale)
* [Matrix2.fromUniformScale](Matrix2.html#.fromUniformScale)
* [Matrix2.multiplyByScale](Matrix2.html#.multiplyByScale)
* [Matrix2.multiplyByUniformScale](Matrix2.html#.multiplyByUniformScale)
* [Matrix2.getScale](Matrix2.html#.getScale)

#### [](#.setUniformScale) static Cesium.Matrix2.setUniformScale(matrix, scale, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 545](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L545) 

 Computes a new matrix that replaces the scale with the provided uniform scale. This assumes the matrix is an affine transformation.

| Name   | Type                    | Description                                                       |
| ------ | ----------------------- | ----------------------------------------------------------------- |
| matrix | [Matrix2](Matrix2.html) | The matrix to use.                                                |
| scale  | number                  | The uniform scale that replaces the scale of the provided matrix. |
| result | [Matrix2](Matrix2.html) | The object onto which to store the result.                        |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix2.setScale](Matrix2.html#.setScale)
* [Matrix2.fromScale](Matrix2.html#.fromScale)
* [Matrix2.fromUniformScale](Matrix2.html#.fromUniformScale)
* [Matrix2.multiplyByScale](Matrix2.html#.multiplyByScale)
* [Matrix2.multiplyByUniformScale](Matrix2.html#.multiplyByUniformScale)
* [Matrix2.getScale](Matrix2.html#.getScale)

#### [](#.subtract) static Cesium.Matrix2.subtract(left, right, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 723](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L723) 

 Computes the difference of two matrices.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| left   | [Matrix2](Matrix2.html) | The first matrix.                          |
| right  | [Matrix2](Matrix2.html) | The second matrix.                         |
| result | [Matrix2](Matrix2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.toArray) static Cesium.Matrix2.toArray(matrix, result) → Array.<number> 

[engine/Source/Core/Matrix2.js 333](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L333) 

 Creates an Array from the provided Matrix2 instance. The array will be in column-major order.

| Name   | Type                    | Description                                        |
| ------ | ----------------------- | -------------------------------------------------- |
| matrix | [Matrix2](Matrix2.html) | The matrix to use..                                |
| result | Array.<number>          | optional The Array onto which to store the result. |

##### Returns:

 The modified Array parameter or a new Array instance if one was not provided.

#### [](#.transpose) static Cesium.Matrix2.transpose(matrix, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 878](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L878) 

 Computes the transpose of the provided matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix2](Matrix2.html) | The matrix to transpose.                   |
| result | [Matrix2](Matrix2.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.unpack) static Cesium.Matrix2.unpack(array, startingIndex, result) → [Matrix2](Matrix2.html) 

[engine/Source/Core/Matrix2.js 74](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L74) 

 Retrieves an instance from a packed array.

| Name          | Type                    | Default | Description                                                |
| ------------- | ----------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>          |         | The packed array.                                          |
| startingIndex | number                  | 0       | optional The starting index of the element to be unpacked. |
| result        | [Matrix2](Matrix2.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new Matrix2 instance if one was not provided.

#### [](#.unpackArray) static Cesium.Matrix2.unpackArray(array, result) → Array.<[Matrix2](Matrix2.html)\> 

[engine/Source/Core/Matrix2.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix2.js#L132) 

 Unpacks an array of column-major matrix components into an array of Matrix2s.

| Name   | Type                             | Description                                        |
| ------ | -------------------------------- | -------------------------------------------------- |
| array  | Array.<number>                   | The array of components to unpack.                 |
| result | Array.<[Matrix2](Matrix2.html)\> | optional The array onto which to store the result. |

##### Returns:

 The unpacked array.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

