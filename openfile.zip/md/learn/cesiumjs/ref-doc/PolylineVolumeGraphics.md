# [![](Images/CesiumLogo.png)](index.html) PolylineVolumeGraphics 

#### [](#PolylineVolumeGraphics) new Cesium.PolylineVolumeGraphics(options) 

[engine/Source/DataSources/PolylineVolumeGraphics.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L39) 

 Describes a polyline volume defined as a line strip and corresponding two dimensional shape which is extruded along it. The resulting volume conforms to the curvature of the globe.

| Name    | Type                                                                                         | Description                                       |
| ------- | -------------------------------------------------------------------------------------------- | ------------------------------------------------- |
| options | [PolylineVolumeGraphics.ConstructorOptions](PolylineVolumeGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle Polyline Volume Demo](https://sandcastle.cesium.com/index.html?src=Polyline%2520Volume.html)

##### See:

* [Entity](Entity.html)

### Members

#### [](#cornerType) cornerType : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineVolumeGraphics.js 111](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L111) 

 Gets or sets the [CornerType](global.html#CornerType) Property specifying the style of the corners.

Default Value: `CornerType.ROUNDED` 

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/PolylineVolumeGraphics.js 77](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L77) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineVolumeGraphics.js 178](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L178) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this volume will be displayed.

#### [](#fill) fill : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineVolumeGraphics.js 127](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L127) 

 Gets or sets the boolean Property specifying whether the volume is filled with the provided material.

Default Value: `true` 

#### [](#granularity) granularity : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineVolumeGraphics.js 119](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L119) 

 Gets or sets the numeric Property specifying the angular distance between points on the volume.

Default Value: `{CesiumMath.RADIANS_PER_DEGREE}` 

#### [](#material) material : [MaterialProperty](MaterialProperty.html) 

[engine/Source/DataSources/PolylineVolumeGraphics.js 135](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L135) 

 Gets or sets the Property specifying the material used to fill the volume.

Default Value: `Color.WHITE` 

#### [](#outline) outline : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineVolumeGraphics.js 143](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L143) 

 Gets or sets the Property specifying whether the volume is outlined.

Default Value: `false` 

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineVolumeGraphics.js 151](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L151) 

 Gets or sets the Property specifying the [Color](Color.html) of the outline.

Default Value: `Color.BLACK` 

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineVolumeGraphics.js 162](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L162) 

 Gets or sets the numeric Property specifying the width of the outline.

Note: This property will be ignored on all major browsers on Windows platforms. For details, see (@link https://github.com/CesiumGS/cesium/issues/40}.

Default Value: `1.0` 

#### [](#positions) positions : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineVolumeGraphics.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L96) 

 Gets or sets the Property specifying the array of [Cartesian3](Cartesian3.html) positions which define the line strip.

#### [](#shadows) shadows : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineVolumeGraphics.js 171](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L171) 

 Get or sets the enum Property specifying whether the volume casts or receives shadows from light sources.

Default Value: `ShadowMode.DISABLED` 

#### [](#shape) shape : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineVolumeGraphics.js 103](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L103) 

 Gets or sets the Property specifying the array of [Cartesian2](Cartesian2.html) positions which define the shape to be extruded.

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineVolumeGraphics.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L89) 

 Gets or sets the boolean Property specifying the visibility of the volume.

Default Value: `true` 

### Methods

#### [](#clone) clone(result) → [PolylineVolumeGraphics](PolylineVolumeGraphics.html) 

[engine/Source/DataSources/PolylineVolumeGraphics.js 189](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L189) 

 Duplicates this instance.

| Name   | Type                                                  | Description                                         |
| ------ | ----------------------------------------------------- | --------------------------------------------------- |
| result | [PolylineVolumeGraphics](PolylineVolumeGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/PolylineVolumeGraphics.js 214](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L214) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                                  | Description                               |
| ------ | ----------------------------------------------------- | ----------------------------------------- |
| source | [PolylineVolumeGraphics](PolylineVolumeGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.PolylineVolumeGraphics.ConstructorOptions

[engine/Source/DataSources/PolylineVolumeGraphics.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineVolumeGraphics.js#L8) 

 Initialization options for the PolylineVolumeGraphics constructor

##### Properties:

| Name                     | Type                                                                                 | Attributes | Default                          | Description                                                                                                       |
| ------------------------ | ------------------------------------------------------------------------------------ | ---------- | -------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| show                     | [Property](Property.html)\|boolean                                                   | <optional> | true                             | A boolean Property specifying the visibility of the volume.                                                       |
| positions                | [Property](Property.html)\|Array.<[Cartesian3](Cartesian3.html)\>                    | <optional> |                                  | A Property specifying the array of [Cartesian3](Cartesian3.html) positions which define the line strip.           |
| shape                    | [Property](Property.html)\|Array.<[Cartesian2](Cartesian2.html)\>                    | <optional> |                                  | A Property specifying the array of [Cartesian2](Cartesian2.html) positions which define the shape to be extruded. |
| cornerType               | [Property](Property.html)\|[CornerType](global.html#CornerType)                      | <optional> | CornerType.ROUNDED               | A [CornerType](global.html#CornerType) Property specifying the style of the corners.                              |
| granularity              | [Property](Property.html)\|number                                                    | <optional> | Cesium.Math.RADIANS\_PER\_DEGREE | A numeric Property specifying the angular distance between each latitude and longitude point.                     |
| fill                     | [Property](Property.html)\|boolean                                                   | <optional> | true                             | A boolean Property specifying whether the volume is filled with the provided material.                            |
| material                 | [MaterialProperty](MaterialProperty.html)\|[Color](Color.html)                       | <optional> | Color.WHITE                      | A Property specifying the material used to fill the volume.                                                       |
| outline                  | [Property](Property.html)\|boolean                                                   | <optional> | false                            | A boolean Property specifying whether the volume is outlined.                                                     |
| outlineColor             | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.BLACK                      | A Property specifying the [Color](Color.html) of the outline.                                                     |
| outlineWidth             | [Property](Property.html)\|number                                                    | <optional> | 1.0                              | A numeric Property specifying the width of the outline.                                                           |
| shadows                  | [Property](Property.html)\|[ShadowMode](global.html#ShadowMode)                      | <optional> | ShadowMode.DISABLED              | An enum Property specifying whether the volume casts or receives shadows from light sources.                      |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                                  | A Property specifying at what distance from the camera that this volume will be displayed.                        |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

