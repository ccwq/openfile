# [![](Images/CesiumLogo.png)](index.html) TileAvailability 

#### [](#TileAvailability) new Cesium.TileAvailability(tilingScheme, maximumLevel) 

[engine/Source/Core/TileAvailability.js 15](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileAvailability.js#L15) 

 Reports the availability of tiles in a [TilingScheme](TilingScheme.html).

| Name         | Type                              | Description                                           |
| ------------ | --------------------------------- | ----------------------------------------------------- |
| tilingScheme | [TilingScheme](TilingScheme.html) | The tiling scheme in which to report availability.    |
| maximumLevel | number                            | The maximum tile level that is potentially available. |

### Methods

#### [](#addAvailableTileRange) addAvailableTileRange(level, startX, startY, endX, endY) 

[engine/Source/Core/TileAvailability.js 46](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileAvailability.js#L46) 

 Marks a rectangular range of tiles in a particular level as being available. For best performance, add your ranges in order of increasing level.

| Name   | Type   | Description                                                 |
| ------ | ------ | ----------------------------------------------------------- |
| level  | number | The level.                                                  |
| startX | number | The X coordinate of the first available tiles at the level. |
| startY | number | The Y coordinate of the first available tiles at the level. |
| endX   | number | The X coordinate of the last available tiles at the level.  |
| endY   | number | The Y coordinate of the last available tiles at the level.  |

#### [](#computeBestAvailableLevelOverRectangle) computeBestAvailableLevelOverRectangle(rectangle) → number 

[engine/Source/Core/TileAvailability.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileAvailability.js#L132) 

 Finds the most detailed level that is available \_everywhere\_ within a given rectangle. More detailed tiles may be available in parts of the rectangle, but not the whole thing. The return value of this function may be safely passed to [sampleTerrain](global.html#sampleTerrain) for any position within the rectangle. This function usually completes in time logarithmic to the number of rectangles added with[TileAvailability#addAvailableTileRange](TileAvailability.html#addAvailableTileRange).

| Name      | Type                        | Description    |
| --------- | --------------------------- | -------------- |
| rectangle | [Rectangle](Rectangle.html) | The rectangle. |

##### Returns:

 The best available level for the entire rectangle.

#### [](#computeChildMaskForTile) computeChildMaskForTile(level, x, y) → number 

[engine/Source/Core/TileAvailability.js 228](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileAvailability.js#L228) 

 Computes a bit mask indicating which of a tile's four children exist. If a child's bit is set, a tile is available for that child. If it is cleared, the tile is not available. The bit values are as follows:

| Bit Position | Bit Value | Child Tile |
| ------------ | --------- | ---------- |
| 0            | 1         | Southwest  |
| 1            | 2         | Southeast  |
| 2            | 4         | Northwest  |
| 3            | 8         | Northeast  |

| Name  | Type   | Description                          |
| ----- | ------ | ------------------------------------ |
| level | number | The level of the parent tile.        |
| x     | number | The X coordinate of the parent tile. |
| y     | number | The Y coordinate of the parent tile. |

##### Returns:

 The bit mask indicating child availability.

#### [](#computeMaximumLevelAtPosition) computeMaximumLevelAtPosition(position) → number 

[engine/Source/Core/TileAvailability.js 99](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileAvailability.js#L99) 

 Determines the level of the most detailed tile covering the position. This function usually completes in time logarithmic to the number of rectangles added with[TileAvailability#addAvailableTileRange](TileAvailability.html#addAvailableTileRange).

| Name     | Type                              | Description                                                                                       |
| -------- | --------------------------------- | ------------------------------------------------------------------------------------------------- |
| position | [Cartographic](Cartographic.html) | The position for which to determine the maximum available level. The height component is ignored. |

##### Returns:

 The level of the most detailed tile covering the position.

##### Throws:

* [DeveloperError](DeveloperError.html): If position is outside any tile according to the tiling scheme.

#### [](#isTileAvailable) isTileAvailable(level, x, y) → boolean 

[engine/Source/Core/TileAvailability.js 195](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileAvailability.js#L195) 

 Determines if a particular tile is available.

| Name  | Type   | Description                            |
| ----- | ------ | -------------------------------------- |
| level | number | The tile level to check.               |
| x     | number | The X coordinate of the tile to check. |
| y     | number | The Y coordinate of the tile to check. |

##### Returns:

 True if the tile is available; otherwise, false.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

