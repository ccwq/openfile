# [![](Images/CesiumLogo.png)](index.html) CompositePositionProperty 

#### [](#CompositePositionProperty) new Cesium.CompositePositionProperty(referenceFrame) 

[engine/Source/DataSources/CompositePositionProperty.js 18](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositePositionProperty.js#L18) 

 A [CompositeProperty](CompositeProperty.html) which is also a [PositionProperty](PositionProperty.html).

| Name           | Type                                         | Default              | Description                                                    |
| -------------- | -------------------------------------------- | -------------------- | -------------------------------------------------------------- |
| referenceFrame | [ReferenceFrame](global.html#ReferenceFrame) | ReferenceFrame.FIXED | optional The reference frame in which the position is defined. |

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/CompositePositionProperty.js 51](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositePositionProperty.js#L51) 

 Gets the event that is raised whenever the definition of this property changes. The definition is changed whenever setValue is called with data different than the current value.

#### [](#intervals) intervals : [TimeIntervalCollection](TimeIntervalCollection.html) 

[engine/Source/DataSources/CompositePositionProperty.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositePositionProperty.js#L62) 

 Gets the interval collection.

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/CompositePositionProperty.js 37](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositePositionProperty.js#L37) 

 Gets a value indicating if this property is constant. A property is considered constant if getValue always returns the same result for the current definition.

#### [](#referenceFrame) referenceFrame : [ReferenceFrame](global.html#ReferenceFrame) 

[engine/Source/DataSources/CompositePositionProperty.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositePositionProperty.js#L76) 

 Gets or sets the reference frame which this position presents itself as. Each PositionProperty making up this object has it's own reference frame, so this property merely exposes a "preferred" reference frame for clients to use.

### Methods

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/CompositePositionProperty.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositePositionProperty.js#L139) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getValue) getValue(time, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/DataSources/CompositePositionProperty.js 95](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositePositionProperty.js#L95) 

 Gets the value of the property at the provided time in the fixed frame.

| Name   | Type                          | Default          | Description                                                                                      |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | [Cartesian3](Cartesian3.html) |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

#### [](#getValueInReferenceFrame) getValueInReferenceFrame(time, referenceFrame, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/DataSources/CompositePositionProperty.js 110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositePositionProperty.js#L110) 

 Gets the value of the property at the provided time and in the provided reference frame.

| Name           | Type                                         | Description                                                                                      |
| -------------- | -------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| time           | [JulianDate](JulianDate.html)                | The time for which to retrieve the value.                                                        |
| referenceFrame | [ReferenceFrame](global.html#ReferenceFrame) | The desired referenceFrame of the result.                                                        |
| result         | [Cartesian3](Cartesian3.html)                | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

