# [![](Images/CesiumLogo.png)](index.html) FeatureDetection 

[engine/Source/Core/FeatureDetection.js 296](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/FeatureDetection.js#L296) 

A set of functions to detect whether the current browser supports various features.

### Methods

#### [](#.supportsBasis) static Cesium.FeatureDetection.supportsBasis(scene) → boolean 

[engine/Source/Core/FeatureDetection.js 331](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/FeatureDetection.js#L331) 

 Detects whether the current browser supports Basis Universal textures and the web assembly modules needed to transcode them.

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| scene | [Scene](Scene.html) |             |

##### Returns:

 true if the browser supports web assembly modules and the scene supports Basis Universal textures, false if not.

#### [](#.supportsBigInt) static Cesium.FeatureDetection.supportsBigInt() → boolean 

[engine/Source/Core/FeatureDetection.js 387](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/FeatureDetection.js#L387) 

 Detects whether the current browser supports BigInt.

##### Returns:

 true if the browser supports BigInt, false if not.

##### See:

* [BigInt Specification](https://tc39.es/ecma262/#sec-bigint-objects)

#### [](#.supportsBigInt64Array) static Cesium.FeatureDetection.supportsBigInt64Array() → boolean 

[engine/Source/Core/FeatureDetection.js 365](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/FeatureDetection.js#L365) 

 Detects whether the current browser supports BigInt64Array typed arrays.

##### Returns:

 true if the browser supports BigInt64Array typed arrays, false if not.

##### See:

* [Typed Array Specification](https://tc39.es/ecma262/#sec-typedarray-objects)

#### [](#.supportsBigUint64Array) static Cesium.FeatureDetection.supportsBigUint64Array() → boolean 

[engine/Source/Core/FeatureDetection.js 376](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/FeatureDetection.js#L376) 

 Detects whether the current browser supports BigUint64Array typed arrays.

##### Returns:

 true if the browser supports BigUint64Array typed arrays, false if not.

##### See:

* [Typed Array Specification](https://tc39.es/ecma262/#sec-typedarray-objects)

#### [](#.supportsEsmWebWorkers) static Cesium.FeatureDetection.supportsEsmWebWorkers() → boolean 

[engine/Source/Core/FeatureDetection.js 434](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/FeatureDetection.js#L434) 

 Detects whether the current browser supports ECMAScript modules in web workers.

##### Returns:

 true if the browser supports ECMAScript modules in web workers.

##### See:

* [Worker](https://developer.mozilla.org/en-US/docs/Web/API/Worker)

#### [](#.supportsFullscreen) static Cesium.FeatureDetection.supportsFullscreen() → boolean 

[engine/Source/Core/FeatureDetection.js 343](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/FeatureDetection.js#L343) 

 Detects whether the current browser supports the full screen standard.

##### Returns:

 true if the browser supports the full screen standard, false if not.

##### See:

* [Fullscreen](Fullscreen.html)
* [W3C Fullscreen Living Specification](http://dvcs.w3.org/hg/fullscreen/raw-file/tip/Overview.html)

#### [](#.supportsTypedArrays) static Cesium.FeatureDetection.supportsTypedArrays() → boolean 

[engine/Source/Core/FeatureDetection.js 354](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/FeatureDetection.js#L354) 

 Detects whether the current browser supports typed arrays.

##### Returns:

 true if the browser supports typed arrays, false if not.

##### See:

* [Typed Array Specification](https://tc39.es/ecma262/#sec-typedarray-objects)

#### [](#.supportsWebAssembly) static Cesium.FeatureDetection.supportsWebAssembly() → boolean 

[engine/Source/Core/FeatureDetection.js 409](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/FeatureDetection.js#L409) 

 Detects whether the current browser supports Web Assembly.

##### Returns:

 true if the browsers supports Web Assembly, false if not.

##### See:

* <https://developer.mozilla.org/en-US/docs/WebAssembly>

#### [](#.supportsWebgl2) static Cesium.FeatureDetection.supportsWebgl2(scene) → boolean 

[engine/Source/Core/FeatureDetection.js 421](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/FeatureDetection.js#L421) 

 Detects whether the current browser supports a WebGL2 rendering context for the specified scene.

| Name  | Type                | Description                                       |
| ----- | ------------------- | ------------------------------------------------- |
| scene | [Scene](Scene.html) | the Cesium scene specifying the rendering context |

##### Returns:

 true if the browser supports a WebGL2 rendering context, false if not.

##### See:

* [WebGL2RenderingContext](https://developer.mozilla.org/en-US/docs/Web/API/WebGL2RenderingContext)

#### [](#.supportsWebWorkers) static Cesium.FeatureDetection.supportsWebWorkers() → boolean 

[engine/Source/Core/FeatureDetection.js 398](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/FeatureDetection.js#L398) 

 Detects whether the current browser supports Web Workers.

##### Returns:

 true if the browsers supports Web Workers, false if not.

##### See:

* <http://www.w3.org/TR/workers/>

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

