# [![](Images/CesiumLogo.png)](index.html) CameraEventAggregator 

#### [](#CameraEventAggregator) new Cesium.CameraEventAggregator(canvas) 

[engine/Source/Scene/CameraEventAggregator.js 357](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L357) 

 Aggregates input events. For example, suppose the following inputs are received between frames: left mouse button down, mouse move, mouse move, left mouse button up. These events will be aggregated into one event with a start and end position of the mouse.

| Name   | Type              | Default  | Description                                |
| ------ | ----------------- | -------- | ------------------------------------------ |
| canvas | HTMLCanvasElement | document | optional The element to handle events for. |

##### See:

* [ScreenSpaceEventHandler](ScreenSpaceEventHandler.html)

### Members

#### [](#anyButtonDown) anyButtonDown : boolean 

[engine/Source/Scene/CameraEventAggregator.js 417](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L417) 

 Gets whether any mouse button is down, a touch has started, or the wheel has been moved.

#### [](#currentMousePosition) currentMousePosition : [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/CameraEventAggregator.js 406](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L406) 

 Gets the current mouse position.

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/CameraEventAggregator.js 615](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L615) 

 Removes mouse listeners held by this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
handler = handler && handler.destroy();
```

##### See:

* [CameraEventAggregator#isDestroyed](CameraEventAggregator.html#isDestroyed)

#### [](#getButtonPressTime) getButtonPressTime(type, modifier) → Date 

[engine/Source/Scene/CameraEventAggregator.js 543](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L543) 

 Gets the time the button was pressed or the touch was started.

| Name     | Type                                                       | Description                     |
| -------- | ---------------------------------------------------------- | ------------------------------- |
| type     | [CameraEventType](global.html#CameraEventType)             | The camera event type.          |
| modifier | [KeyboardEventModifier](global.html#KeyboardEventModifier) | optional The keyboard modifier. |

##### Returns:

 The time the button was pressed or the touch was started.

#### [](#getButtonReleaseTime) getButtonReleaseTime(type, modifier) → Date 

[engine/Source/Scene/CameraEventAggregator.js 561](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L561) 

 Gets the time the button was released or the touch was ended.

| Name     | Type                                                       | Description                     |
| -------- | ---------------------------------------------------------- | ------------------------------- |
| type     | [CameraEventType](global.html#CameraEventType)             | The camera event type.          |
| modifier | [KeyboardEventModifier](global.html#KeyboardEventModifier) | optional The keyboard modifier. |

##### Returns:

 The time the button was released or the touch was ended.

#### [](#getLastMovement) getLastMovement(type, modifier) → object|undefined 

[engine/Source/Scene/CameraEventAggregator.js 477](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L477) 

 Gets the start and end position of the last move event (not the aggregated event).

| Name     | Type                                                       | Description                     |
| -------- | ---------------------------------------------------------- | ------------------------------- |
| type     | [CameraEventType](global.html#CameraEventType)             | The camera event type.          |
| modifier | [KeyboardEventModifier](global.html#KeyboardEventModifier) | optional The keyboard modifier. |

##### Returns:

 An object with two [Cartesian2](Cartesian2.html) properties: `startPosition` and `endPosition` or `undefined`.

#### [](#getMovement) getMovement(type, modifier) → object 

[engine/Source/Scene/CameraEventAggregator.js 458](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L458) 

 Gets the aggregated start and end position of the current event.

| Name     | Type                                                       | Description                     |
| -------- | ---------------------------------------------------------- | ------------------------------- |
| type     | [CameraEventType](global.html#CameraEventType)             | The camera event type.          |
| modifier | [KeyboardEventModifier](global.html#KeyboardEventModifier) | optional The keyboard modifier. |

##### Returns:

 An object with two [Cartesian2](Cartesian2.html) properties: `startPosition` and `endPosition`.

#### [](#getStartMousePosition) getStartMousePosition(type, modifier) → [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/CameraEventAggregator.js 518](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L518) 

 Gets the mouse position that started the aggregation.

| Name     | Type                                                       | Description                     |
| -------- | ---------------------------------------------------------- | ------------------------------- |
| type     | [CameraEventType](global.html#CameraEventType)             | The camera event type.          |
| modifier | [KeyboardEventModifier](global.html#KeyboardEventModifier) | optional The keyboard modifier. |

##### Returns:

 The mouse position.

#### [](#isButtonDown) isButtonDown(type, modifier) → boolean 

[engine/Source/Scene/CameraEventAggregator.js 500](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L500) 

 Gets whether the mouse button is down or a touch has started.

| Name     | Type                                                       | Description                     |
| -------- | ---------------------------------------------------------- | ------------------------------- |
| type     | [CameraEventType](global.html#CameraEventType)             | The camera event type.          |
| modifier | [KeyboardEventModifier](global.html#KeyboardEventModifier) | optional The keyboard modifier. |

##### Returns:

 Whether the mouse button is down or a touch has started.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/CameraEventAggregator.js 596](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L596) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [CameraEventAggregator#destroy](CameraEventAggregator.html#destroy)

#### [](#isMoving) isMoving(type, modifier) → boolean 

[engine/Source/Scene/CameraEventAggregator.js 440](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L440) 

 Gets if a mouse button down or touch has started and has been moved.

| Name     | Type                                                       | Description                     |
| -------- | ---------------------------------------------------------- | ------------------------------- |
| type     | [CameraEventType](global.html#CameraEventType)             | The camera event type.          |
| modifier | [KeyboardEventModifier](global.html#KeyboardEventModifier) | optional The keyboard modifier. |

##### Returns:

 Returns `true` if a mouse button down or touch has started and has been moved; otherwise, `false` 

#### [](#reset) reset() 

[engine/Source/Scene/CameraEventAggregator.js 578](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventAggregator.js#L578) 

 Signals that all of the events have been handled and the aggregator should be reset to handle new events.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

