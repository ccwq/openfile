# [![](Images/CesiumLogo.png)](index.html) IntersectionTests 

[engine/Source/Core/IntersectionTests.js 13](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IntersectionTests.js#L13) 

Functions for computing the intersection between geometries such as rays, planes, triangles, and ellipsoids.

### Methods

#### [](#.grazingAltitudeLocation) static Cesium.IntersectionTests.grazingAltitudeLocation(ray, ellipsoid) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/IntersectionTests.js 665](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IntersectionTests.js#L665) 

 Provides the point along the ray which is nearest to the ellipsoid.

| Name      | Type                        | Description    |
| --------- | --------------------------- | -------------- |
| ray       | [Ray](Ray.html)             | The ray.       |
| ellipsoid | [Ellipsoid](Ellipsoid.html) | The ellipsoid. |

##### Returns:

 The nearest planetodetic point on the ray.

#### [](#.lineSegmentPlane) static Cesium.IntersectionTests.lineSegmentPlane(endPoint0, endPoint1, plane, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/IntersectionTests.js 818](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IntersectionTests.js#L818) 

 Computes the intersection of a line segment and a plane.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| endPoint0 | [Cartesian3](Cartesian3.html) | An end point of the line segment.                   |
| endPoint1 | [Cartesian3](Cartesian3.html) | The other end point of the line segment.            |
| plane     | [Plane](Plane.html)           | The plane.                                          |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The intersection point or undefined if there is no intersection.

##### Example:

```javascript
const origin = Cesium.Cartesian3.fromDegrees(-75.59777, 40.03883);
const normal = ellipsoid.geodeticSurfaceNormal(origin);
const plane = Cesium.Plane.fromPointNormal(origin, normal);

const p0 = new Cesium.Cartesian3(...);
const p1 = new Cesium.Cartesian3(...);

// find the intersection of the line segment from p0 to p1 and the tangent plane at origin.
const intersection = Cesium.IntersectionTests.lineSegmentPlane(p0, p1, plane);
```

#### [](#.lineSegmentSphere) static Cesium.IntersectionTests.lineSegmentSphere(p0, p1, sphere, result) → [Interval](Interval.html) 

[engine/Source/Core/IntersectionTests.js 381](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IntersectionTests.js#L381) 

 Computes the intersection points of a line segment with a sphere.

| Name   | Type                                  | Description                                         |
| ------ | ------------------------------------- | --------------------------------------------------- |
| p0     | [Cartesian3](Cartesian3.html)         | An end point of the line segment.                   |
| p1     | [Cartesian3](Cartesian3.html)         | The other end point of the line segment.            |
| sphere | [BoundingSphere](BoundingSphere.html) | The sphere.                                         |
| result | [Interval](Interval.html)             | optional The result onto which to store the result. |

##### Returns:

 The interval containing scalar points along the ray or undefined if there are no intersections.

#### [](#.lineSegmentTriangle) static Cesium.IntersectionTests.lineSegmentTriangle(v0, v1, p0, p1, p2, cullBackFaces, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/IntersectionTests.js 228](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IntersectionTests.js#L228) 

 Computes the intersection of a line segment and a triangle.

| Name          | Type                          | Default | Description                                                                                                                                        |
| ------------- | ----------------------------- | ------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| v0            | [Cartesian3](Cartesian3.html) |         | The an end point of the line segment.                                                                                                              |
| v1            | [Cartesian3](Cartesian3.html) |         | The other end point of the line segment.                                                                                                           |
| p0            | [Cartesian3](Cartesian3.html) |         | The first vertex of the triangle.                                                                                                                  |
| p1            | [Cartesian3](Cartesian3.html) |         | The second vertex of the triangle.                                                                                                                 |
| p2            | [Cartesian3](Cartesian3.html) |         | The third vertex of the triangle.                                                                                                                  |
| cullBackFaces | boolean                       | false   | optional If true, will only compute an intersection with the front face of the triangle and return undefined for intersections with the back face. |
| result        | [Cartesian3](Cartesian3.html) |         | optional The Cartesian3 onto which to store the result.                                                                                            |

##### Returns:

 The intersection point or undefined if there is no intersections.

#### [](#.rayEllipsoid) static Cesium.IntersectionTests.rayEllipsoid(ray, ellipsoid) → [Interval](Interval.html) 

[engine/Source/Core/IntersectionTests.js 421](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IntersectionTests.js#L421) 

 Computes the intersection points of a ray with an ellipsoid.

| Name      | Type                        | Description    |
| --------- | --------------------------- | -------------- |
| ray       | [Ray](Ray.html)             | The ray.       |
| ellipsoid | [Ellipsoid](Ellipsoid.html) | The ellipsoid. |

##### Returns:

 The interval containing scalar points along the ray or undefined if there are no intersections.

#### [](#.rayPlane) static Cesium.IntersectionTests.rayPlane(ray, plane, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/IntersectionTests.js 28](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IntersectionTests.js#L28) 

 Computes the intersection of a ray and a plane.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| ray    | [Ray](Ray.html)               | The ray.                                            |
| plane  | [Plane](Plane.html)           | The plane.                                          |
| result | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The intersection point or undefined if there is no intersections.

#### [](#.raySphere) static Cesium.IntersectionTests.raySphere(ray, sphere, result) → [Interval](Interval.html) 

[engine/Source/Core/IntersectionTests.js 350](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IntersectionTests.js#L350) 

 Computes the intersection points of a ray with a sphere.

| Name   | Type                                  | Description                                         |
| ------ | ------------------------------------- | --------------------------------------------------- |
| ray    | [Ray](Ray.html)                       | The ray.                                            |
| sphere | [BoundingSphere](BoundingSphere.html) | The sphere.                                         |
| result | [Interval](Interval.html)             | optional The result onto which to store the result. |

##### Returns:

 The interval containing scalar points along the ray or undefined if there are no intersections.

#### [](#.rayTriangle) static Cesium.IntersectionTests.rayTriangle(ray, p0, p1, p2, cullBackFaces, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/IntersectionTests.js 185](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IntersectionTests.js#L185) 

 Computes the intersection of a ray and a triangle as a Cartesian3 coordinate. Implements [ Fast Minimum Storage Ray/Triangle Intersection](https://cadxfem.org/inf/Fast%2520MinimumStorage%2520RayTriangle%2520Intersection.pdf) by Tomas Moller and Ben Trumbore.

| Name          | Type                          | Default | Description                                                                                                                                        |
| ------------- | ----------------------------- | ------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| ray           | [Ray](Ray.html)               |         | The ray.                                                                                                                                           |
| p0            | [Cartesian3](Cartesian3.html) |         | The first vertex of the triangle.                                                                                                                  |
| p1            | [Cartesian3](Cartesian3.html) |         | The second vertex of the triangle.                                                                                                                 |
| p2            | [Cartesian3](Cartesian3.html) |         | The third vertex of the triangle.                                                                                                                  |
| cullBackFaces | boolean                       | false   | optional If true, will only compute an intersection with the front face of the triangle and return undefined for intersections with the back face. |
| result        | [Cartesian3](Cartesian3.html) |         | optional The Cartesian3 onto which to store the result.                                                                                            |

##### Returns:

 The intersection point or undefined if there is no intersections.

#### [](#.rayTriangleParametric) static Cesium.IntersectionTests.rayTriangleParametric(ray, p0, p1, p2, cullBackFaces) → number 

[engine/Source/Core/IntersectionTests.js 84](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IntersectionTests.js#L84) 

 Computes the intersection of a ray and a triangle as a parametric distance along the input ray. The result is negative when the triangle is behind the ray. Implements [ Fast Minimum Storage Ray/Triangle Intersection](https://cadxfem.org/inf/Fast%2520MinimumStorage%2520RayTriangle%2520Intersection.pdf) by Tomas Moller and Ben Trumbore.

| Name          | Type                          | Default | Description                                                                                                                                        |
| ------------- | ----------------------------- | ------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| ray           | [Ray](Ray.html)               |         | The ray.                                                                                                                                           |
| p0            | [Cartesian3](Cartesian3.html) |         | The first vertex of the triangle.                                                                                                                  |
| p1            | [Cartesian3](Cartesian3.html) |         | The second vertex of the triangle.                                                                                                                 |
| p2            | [Cartesian3](Cartesian3.html) |         | The third vertex of the triangle.                                                                                                                  |
| cullBackFaces | boolean                       | false   | optional If true, will only compute an intersection with the front face of the triangle and return undefined for intersections with the back face. |

##### Returns:

 The intersection as a parametric distance along the ray, or undefined if there is no intersection.

#### [](#.trianglePlaneIntersection) static Cesium.IntersectionTests.trianglePlaneIntersection(p0, p1, p2, plane) → object 

[engine/Source/Core/IntersectionTests.js 888](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IntersectionTests.js#L888) 

 Computes the intersection of a triangle and a plane

| Name  | Type                          | Description                  |
| ----- | ----------------------------- | ---------------------------- |
| p0    | [Cartesian3](Cartesian3.html) | First point of the triangle  |
| p1    | [Cartesian3](Cartesian3.html) | Second point of the triangle |
| p2    | [Cartesian3](Cartesian3.html) | Third point of the triangle  |
| plane | [Plane](Plane.html)           | Intersection plane           |

##### Returns:

 An object with properties `positions` and `indices`, which are arrays that represent three triangles that do not cross the plane. (Undefined if no intersection exists)

##### Example:

```javascript
const origin = Cesium.Cartesian3.fromDegrees(-75.59777, 40.03883);
const normal = ellipsoid.geodeticSurfaceNormal(origin);
const plane = Cesium.Plane.fromPointNormal(origin, normal);

const p0 = new Cesium.Cartesian3(...);
const p1 = new Cesium.Cartesian3(...);
const p2 = new Cesium.Cartesian3(...);

// convert the triangle composed of points (p0, p1, p2) to three triangles that don't cross the plane
const triangles = Cesium.IntersectionTests.trianglePlaneIntersection(p0, p1, p2, plane);
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

