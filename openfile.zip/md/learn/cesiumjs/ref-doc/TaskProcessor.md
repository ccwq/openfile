# [![](Images/CesiumLogo.png)](index.html) TaskProcessor 

#### [](#TaskProcessor) new Cesium.TaskProcessor(workerPath, maximumActiveTasks) 

[engine/Source/Core/TaskProcessor.js 185](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TaskProcessor.js#L185) 

 A wrapper around a web worker that allows scheduling tasks for a given worker, returning results asynchronously via a promise. The Worker is not constructed until a task is scheduled.

| Name               | Type   | Default                   | Description                                                                                                                                               |
| ------------------ | ------ | ------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| workerPath         | string |                           | The Url to the worker. This can either be an absolute path or relative to the Cesium Workers folder.                                                      |
| maximumActiveTasks | number | Number.POSITIVE\_INFINITY | optional The maximum number of active tasks. Once exceeded, scheduleTask will not queue any more tasks, allowing work to be rescheduled in future frames. |

### Methods

#### [](#destroy) destroy() 

[engine/Source/Core/TaskProcessor.js 389](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TaskProcessor.js#L389) 

 Destroys this object. This will immediately terminate the Worker.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

#### [](#initWebAssemblyModule) initWebAssemblyModule(webAssemblyOptions) → Promise.<\*> 

[engine/Source/Core/TaskProcessor.js 324](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TaskProcessor.js#L324) 

 Posts a message to a web worker with configuration to initialize loading and compiling a web assembly module asynchronously, as well as an optional fallback JavaScript module to use if Web Assembly is not supported.

| Name               | Type   | Description                                                                                                                                                                                                                                                                                                                                                |
| ------------------ | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| webAssemblyOptions | object | optional An object with the following properties: Name Type Description modulePath string optional The path of the web assembly JavaScript wrapper module. wasmBinaryFile string optional The path of the web assembly binary file. fallbackModulePath string optional The path of the fallback JavaScript module to use if web assembly is not supported. |

##### Returns:

 A promise that resolves to the result when the web worker has loaded and compiled the web assembly module and is ready to process tasks.

##### Throws:

* [RuntimeError](RuntimeError.html): This browser does not support Web Assembly, and no backup module was provided

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Core/TaskProcessor.js 379](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TaskProcessor.js#L379) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

 True if this object was destroyed; otherwise, false.

##### See:

* [TaskProcessor#destroy](TaskProcessor.html#destroy)

#### [](#scheduleTask) scheduleTask(parameters, transferableObjects) → Promise.<object>|undefined 

[engine/Source/Core/TaskProcessor.js 296](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TaskProcessor.js#L296) 

 Schedule a task to be processed by the web worker asynchronously. If there are currently more tasks active than the maximum set by the constructor, will immediately return undefined. Otherwise, returns a promise that will resolve to the result posted back by the worker when finished.

| Name                | Type           | Description                                                                                                      |
| ------------------- | -------------- | ---------------------------------------------------------------------------------------------------------------- |
| parameters          | object         | Any input data that will be posted to the worker.                                                                |
| transferableObjects | Array.<Object> | optional An array of objects contained in parameters that should be transferred to the worker instead of copied. |

##### Returns:

 Either a promise that will resolve to the result when available, or undefined if there are too many active tasks,

##### Example:

```javascript
const taskProcessor = new Cesium.TaskProcessor('myWorkerPath');
const promise = taskProcessor.scheduleTask({
    someParameter : true,
    another : 'hello'
});
if (!Cesium.defined(promise)) {
    // too many active tasks - try again later
} else {
    promise.then(function(result) {
        // use the result of the task
    });
}
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

