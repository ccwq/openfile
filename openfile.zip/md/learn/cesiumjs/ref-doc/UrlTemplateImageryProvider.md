# [![](Images/CesiumLogo.png)](index.html) UrlTemplateImageryProvider 

#### [](#UrlTemplateImageryProvider) new Cesium.UrlTemplateImageryProvider(options) 

[engine/Source/Scene/UrlTemplateImageryProvider.js 189](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L189) 

 Provides imagery by requesting tiles using a specified URL template.

| Name    | Type                                                                                                 | Description                              |
| ------- | ---------------------------------------------------------------------------------------------------- | ---------------------------------------- |
| options | [UrlTemplateImageryProvider.ConstructorOptions](UrlTemplateImageryProvider.html#.ConstructorOptions) | Object describing initialization options |

##### Example:

```javascript
// Access Natural Earth II imagery, which uses a TMS tiling scheme and Geographic (EPSG:4326) project
const tms = new Cesium.UrlTemplateImageryProvider({
    url : Cesium.buildModuleUrl('Assets/Textures/NaturalEarthII') + '/{z}/{x}/{reverseY}.jpg',
    tilingScheme : new Cesium.GeographicTilingScheme(),
    maximumLevel : 5
});
// Access the CartoDB Positron basemap, which uses an OpenStreetMap-like tiling scheme.
const positron = new Cesium.UrlTemplateImageryProvider({
    url : 'http://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png',
    credit : 'Map tiles by CartoDB, under CC BY 3.0. Data by OpenStreetMap, under ODbL.'
});
// Access a Web Map Service (WMS) server.
const wms = new Cesium.UrlTemplateImageryProvider({
   url : 'https://services.ga.gov.au/gis/services/NM_Hydrology_and_Marine_Points/MapServer/WMSServer?' +
         'tiled=true&transparent=true&format=image%2Fpng&exceptions=application%2Fvnd.ogc.se_xml&' +
         'styles=&service=WMS&version=1.3.0&request=GetMap&' +
         'layers=Bores&crs=EPSG%3A3857&' +
         'bbox={westProjected}%2C{southProjected}%2C{eastProjected}%2C{northProjected}&' +
         'width=256&height=256',
   rectangle : Cesium.Rectangle.fromDegrees(95.0, -55.0, 170.0, -1.0)  // From GetCapabilities EX_GeographicBoundingBox
});
// Using custom tags in your template url.
const custom = new Cesium.UrlTemplateImageryProvider({
   url : 'https://yoururl/{Time}/{z}/{y}/{x}.png',
   customTags : {
       Time: function(imageryProvider, x, y, level) {
           return '20171231'
       }
   }
});
```

##### See:

* [ArcGisMapServerImageryProvider](ArcGisMapServerImageryProvider.html)
* [BingMapsImageryProvider](BingMapsImageryProvider.html)
* [GoogleEarthEnterpriseMapsProvider](GoogleEarthEnterpriseMapsProvider.html)
* [OpenStreetMapImageryProvider](OpenStreetMapImageryProvider.html)
* [SingleTileImageryProvider](SingleTileImageryProvider.html)
* [TileMapServiceImageryProvider](TileMapServiceImageryProvider.html)
* [WebMapServiceImageryProvider](WebMapServiceImageryProvider.html)
* [WebMapTileServiceImageryProvider](WebMapTileServiceImageryProvider.html)

### Members

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/UrlTemplateImageryProvider.js 482](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L482) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

Default Value: `undefined` 

#### [](#enablePickFeatures) enablePickFeatures : boolean 

[engine/Source/Scene/UrlTemplateImageryProvider.js 269](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L269) 

 Gets or sets a value indicating whether feature picking is enabled. If true, [UrlTemplateImageryProvider#pickFeatures](UrlTemplateImageryProvider.html#pickFeatures) will request the `options.pickFeaturesUrl` and attempt to interpret the features included in the response. If false,[UrlTemplateImageryProvider#pickFeatures](UrlTemplateImageryProvider.html#pickFeatures) will immediately return undefined (indicating no pickable features) without communicating with the server. Set this property to false if you know your data source does not support picking features or if you don't want this provider's features to be pickable.

Default Value: `true` 

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/UrlTemplateImageryProvider.js 468](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L468) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/UrlTemplateImageryProvider.js 499](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L499) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. When this property is false, memory usage and texture upload time are reduced.

Default Value: `true` 

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/UrlTemplateImageryProvider.js 400](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L400) 

 Gets the maximum level-of-detail that can be requested, or undefined if there is no limit.

Default Value: `undefined` 

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/UrlTemplateImageryProvider.js 413](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L413) 

 Gets the minimum level-of-detail that can be requested.

Default Value: `0` 

#### [](#pickFeaturesUrl) readonly pickFeaturesUrl : string 

[engine/Source/Scene/UrlTemplateImageryProvider.js 348](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L348) 

 Gets the URL template to use to use to pick features. If this property is not specified,[UrlTemplateImageryProvider#pickFeatures](UrlTemplateImageryProvider.html#pickFeatures) will immediately return undefined, indicating no features picked. The URL template supports all of the keywords supported by the[UrlTemplateImageryProvider#url](UrlTemplateImageryProvider.html#url) property, plus the following:
* `{i}`: The pixel column (horizontal coordinate) of the picked position, where the Westernmost pixel is 0.
* `{j}`: The pixel row (vertical coordinate) of the picked position, where the Northernmost pixel is 0.
* `{reverseI}`: The pixel column (horizontal coordinate) of the picked position, where the Easternmost pixel is 0.
* `{reverseJ}`: The pixel row (vertical coordinate) of the picked position, where the Southernmost pixel is 0.
* `{longitudeDegrees}`: The longitude of the picked position in degrees.
* `{latitudeDegrees}`: The latitude of the picked position in degrees.
* `{longitudeProjected}`: The longitude of the picked position in the projected coordinates of the tiling scheme.
* `{latitudeProjected}`: The latitude of the picked position in the projected coordinates of the tiling scheme.
* `{format}`: The format in which to get feature information, as specified in the [GetFeatureInfoFormat](GetFeatureInfoFormat.html).

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/UrlTemplateImageryProvider.js 361](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L361) 

 Gets the proxy used by this provider.

Default Value: `undefined` 

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/UrlTemplateImageryProvider.js 439](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L439) 

 Gets the rectangle, in radians, of the imagery provided by this instance.

Default Value: `tilingScheme.rectangle` 

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/UrlTemplateImageryProvider.js 454](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L454) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

Default Value: `undefined` 

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/UrlTemplateImageryProvider.js 387](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L387) 

 Gets the height of each tile, in pixels.

Default Value: `256` 

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/UrlTemplateImageryProvider.js 374](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L374) 

 Gets the width of each tile, in pixels.

Default Value: `256` 

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/UrlTemplateImageryProvider.js 426](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L426) 

 Gets the tiling scheme used by this provider.

Default Value: `new WebMercatorTilingScheme()` 

#### [](#url) readonly url : string 

[engine/Source/Scene/UrlTemplateImageryProvider.js 298](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L298) 

 Gets the URL template to use to request tiles. It has the following keywords:
* `{z}`: The level of the tile in the tiling scheme. Level zero is the root of the quadtree pyramid.
* `{x}`: The tile X coordinate in the tiling scheme, where 0 is the Westernmost tile.
* `{y}`: The tile Y coordinate in the tiling scheme, where 0 is the Northernmost tile.
* `{s}`: One of the available subdomains, used to overcome browser limits on the number of simultaneous requests per host.
* `{reverseX}`: The tile X coordinate in the tiling scheme, where 0 is the Easternmost tile.
* `{reverseY}`: The tile Y coordinate in the tiling scheme, where 0 is the Southernmost tile.
* `{reverseZ}`: The level of the tile in the tiling scheme, where level zero is the maximum level of the quadtree pyramid. In order to use reverseZ, maximumLevel must be defined.
* `{westDegrees}`: The Western edge of the tile in geodetic degrees.
* `{southDegrees}`: The Southern edge of the tile in geodetic degrees.
* `{eastDegrees}`: The Eastern edge of the tile in geodetic degrees.
* `{northDegrees}`: The Northern edge of the tile in geodetic degrees.
* `{westProjected}`: The Western edge of the tile in projected coordinates of the tiling scheme.
* `{southProjected}`: The Southern edge of the tile in projected coordinates of the tiling scheme.
* `{eastProjected}`: The Eastern edge of the tile in projected coordinates of the tiling scheme.
* `{northProjected}`: The Northern edge of the tile in projected coordinates of the tiling scheme.
* `{width}`: The width of each tile in pixels.
* `{height}`: The height of each tile in pixels.

#### [](#urlSchemeZeroPadding) readonly urlSchemeZeroPadding : object 

[engine/Source/Scene/UrlTemplateImageryProvider.js 322](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L322) 

 Gets the URL scheme zero padding for each tile coordinate. The format is '000' where each coordinate will be padded on the left with zeros to match the width of the passed string of zeros. e.g. Setting: urlSchemeZeroPadding : { '{x}' : '0000'} will cause an 'x' value of 12 to return the string '0012' for {x} in the generated URL. It has the following keywords:
* `{z}`: The zero padding for the level of the tile in the tiling scheme.
* `{x}`: The zero padding for the tile X coordinate in the tiling scheme.
* `{y}`: The zero padding for the the tile Y coordinate in the tiling scheme.
* `{reverseX}`: The zero padding for the tile reverseX coordinate in the tiling scheme.
* `{reverseY}`: The zero padding for the tile reverseY coordinate in the tiling scheme.
* `{reverseZ}`: The zero padding for the reverseZ coordinate of the tile in the tiling scheme.

### Methods

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/UrlTemplateImageryProvider.js 514](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L514) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → Promise.<Array.<[ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html)\>>|undefined 

[engine/Source/Scene/UrlTemplateImageryProvider.js 552](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L552) 

 Asynchronously determines what features, if any, are located at a given longitude and latitude within a tile.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 A promise for the picked features that will resolve when the asynchronous picking completes. The resolved value is an array of [ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html) instances. The array may be empty if no features are found at the given location. It may also be undefined if picking is not supported.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<[ImageryTypes](global.html#ImageryTypes)\>|undefined 

[engine/Source/Scene/UrlTemplateImageryProvider.js 526](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L526) 

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the image that will resolve when the image is available, or undefined if there are too many active requests to the server, and the request should be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.UrlTemplateImageryProvider.ConstructorOptions

[engine/Source/Scene/UrlTemplateImageryProvider.js 51](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/UrlTemplateImageryProvider.js#L51) 

 Initialization options for the UrlTemplateImageryProvider constructor

##### Properties:

| Name                  | Type                                                       | Attributes | Default                 | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| --------------------- | ---------------------------------------------------------- | ---------- | ----------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| url                   | [Resource](Resource.html)\|string                          |            |                         | The URL template to use to request tiles. It has the following keywords: {z}: The level of the tile in the tiling scheme. Level zero is the root of the quadtree pyramid. {x}: The tile X coordinate in the tiling scheme, where 0 is the Westernmost tile. {y}: The tile Y coordinate in the tiling scheme, where 0 is the Northernmost tile. {s}: One of the available subdomains, used to overcome browser limits on the number of simultaneous requests per host. {reverseX}: The tile X coordinate in the tiling scheme, where 0 is the Easternmost tile. {reverseY}: The tile Y coordinate in the tiling scheme, where 0 is the Southernmost tile. {reverseZ}: The level of the tile in the tiling scheme, where level zero is the maximum level of the quadtree pyramid. In order to use reverseZ, maximumLevel must be defined. {westDegrees}: The Western edge of the tile in geodetic degrees. {southDegrees}: The Southern edge of the tile in geodetic degrees. {eastDegrees}: The Eastern edge of the tile in geodetic degrees. {northDegrees}: The Northern edge of the tile in geodetic degrees. {westProjected}: The Western edge of the tile in projected coordinates of the tiling scheme. {southProjected}: The Southern edge of the tile in projected coordinates of the tiling scheme. {eastProjected}: The Eastern edge of the tile in projected coordinates of the tiling scheme. {northProjected}: The Northern edge of the tile in projected coordinates of the tiling scheme. {width}: The width of each tile in pixels. {height}: The height of each tile in pixels. |
| pickFeaturesUrl       | [Resource](Resource.html)\|string                          | <optional> |                         | The URL template to use to pick features. If this property is not specified,[UrlTemplateImageryProvider#pickFeatures](UrlTemplateImageryProvider.html#pickFeatures) will immediately returned undefined, indicating no features picked. The URL template supports all of the keywords supported by the url parameter, plus the following: {i}: The pixel column (horizontal coordinate) of the picked position, where the Westernmost pixel is 0. {j}: The pixel row (vertical coordinate) of the picked position, where the Northernmost pixel is 0. {reverseI}: The pixel column (horizontal coordinate) of the picked position, where the Easternmost pixel is 0. {reverseJ}: The pixel row (vertical coordinate) of the picked position, where the Southernmost pixel is 0. {longitudeDegrees}: The longitude of the picked position in degrees. {latitudeDegrees}: The latitude of the picked position in degrees. {longitudeProjected}: The longitude of the picked position in the projected coordinates of the tiling scheme. {latitudeProjected}: The latitude of the picked position in the projected coordinates of the tiling scheme. {format}: The format in which to get feature information, as specified in the [GetFeatureInfoFormat](GetFeatureInfoFormat.html).                                                                                                                                                                                                                                                                                                              |
| urlSchemeZeroPadding  | object                                                     | <optional> |                         | Gets the URL scheme zero padding for each tile coordinate. The format is '000' where each coordinate will be padded on the left with zeros to match the width of the passed string of zeros. e.g. Setting: urlSchemeZeroPadding : { '{x}' : '0000'} will cause an 'x' value of 12 to return the string '0012' for {x} in the generated URL. It the passed object has the following keywords: {z}: The zero padding for the level of the tile in the tiling scheme. {x}: The zero padding for the tile X coordinate in the tiling scheme. {y}: The zero padding for the the tile Y coordinate in the tiling scheme. {reverseX}: The zero padding for the tile reverseX coordinate in the tiling scheme. {reverseY}: The zero padding for the tile reverseY coordinate in the tiling scheme. {reverseZ}: The zero padding for the reverseZ coordinate of the tile in the tiling scheme.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| subdomains            | string\|Array.<string>                                     | <optional> | 'abc'                   | The subdomains to use for the {s} placeholder in the URL template. If this parameter is a single string, each character in the string is a subdomain. If it is an array, each element in the array is a subdomain.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| credit                | [Credit](Credit.html)\|string                              | <optional> | ''                      | A credit for the data source, which is displayed on the canvas.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| minimumLevel          | number                                                     | <optional> | 0                       | The minimum level-of-detail supported by the imagery provider. Take care when specifying this that the number of tiles at the minimum level is small, such as four or less. A larger number is likely to result in rendering problems.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| maximumLevel          | number                                                     | <optional> |                         | The maximum level-of-detail supported by the imagery provider, or undefined if there is no limit.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| rectangle             | [Rectangle](Rectangle.html)                                | <optional> | Rectangle.MAX\_VALUE    | The rectangle, in radians, covered by the image.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| tilingScheme          | [TilingScheme](TilingScheme.html)                          | <optional> | WebMercatorTilingScheme | The tiling scheme specifying how the ellipsoidal surface is broken into tiles. If this parameter is not provided, a [WebMercatorTilingScheme](WebMercatorTilingScheme.html)is used.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| ellipsoid             | [Ellipsoid](Ellipsoid.html)                                | <optional> |                         | The ellipsoid. If the tilingScheme is specified, this parameter is ignored and the tiling scheme's ellipsoid is used instead. If neither parameter is specified, the WGS84 ellipsoid is used.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| tileWidth             | number                                                     | <optional> | 256                     | Pixel width of image tiles.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| tileHeight            | number                                                     | <optional> | 256                     | Pixel height of image tiles.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| hasAlphaChannel       | boolean                                                    | <optional> | true                    | true if the images provided by this imagery provider include an alpha channel; otherwise, false. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. When this property is false, memory usage and texture upload time are potentially reduced.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| getFeatureInfoFormats | Array.<[GetFeatureInfoFormat](GetFeatureInfoFormat.html)\> | <optional> |                         | The formats in which to get feature information at a specific location when [UrlTemplateImageryProvider#pickFeatures](UrlTemplateImageryProvider.html#pickFeatures) is invoked. If this parameter is not specified, feature picking is disabled.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| enablePickFeatures    | boolean                                                    | <optional> | true                    | If true, [UrlTemplateImageryProvider#pickFeatures](UrlTemplateImageryProvider.html#pickFeatures) will request the pickFeaturesUrl and attempt to interpret the features included in the response. If false,[UrlTemplateImageryProvider#pickFeatures](UrlTemplateImageryProvider.html#pickFeatures) will immediately return undefined (indicating no pickable features) without communicating with the server. Set this property to false if you know your data source does not support picking features or if you don't want this provider's features to be pickable. Note that this can be dynamically overridden by modifying the UriTemplateImageryProvider#enablePickFeatures property.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| tileDiscardPolicy     | [TileDiscardPolicy](TileDiscardPolicy.html)                | <optional> |                         | A policy for discarding tile images according to some criteria                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| customTags            | Object                                                     | <optional> |                         | Allow to replace custom keywords in the URL template. The object must have strings as keys and functions as values.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

