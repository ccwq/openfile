# [![](Images/CesiumLogo.png)](index.html) Quaternion 

#### [](#Quaternion) new Cesium.Quaternion(x, y, z, w) 

[engine/Source/Core/Quaternion.js 21](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L21) 

 A set of 4-dimensional coordinates used to represent rotation in 3-dimensional space.

| Name | Type   | Default | Description               |
| ---- | ------ | ------- | ------------------------- |
| x    | number | 0.0     | optional The X component. |
| y    | number | 0.0     | optional The Y component. |
| z    | number | 0.0     | optional The Z component. |
| w    | number | 0.0     | optional The W component. |

##### See:

* [PackableForInterpolation](PackableForInterpolation.html)

### Members

#### [](#.IDENTITY) static constant Cesium.Quaternion.IDENTITY : [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 1102](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L1102) 

 An immutable Quaternion instance initialized to (0.0, 0.0, 0.0, 1.0).

#### [](#.packedInterpolationLength) static Cesium.Quaternion.packedInterpolationLength : number 

[engine/Source/Core/Quaternion.js 281](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L281) 

 The number of elements used to store the object into an array in its interpolatable form.

#### [](#.packedLength) static Cesium.Quaternion.packedLength : number 

[engine/Source/Core/Quaternion.js 225](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L225) 

 The number of elements used to pack the object into an array.

#### [](#.ZERO) static constant Cesium.Quaternion.ZERO : [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 1094](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L1094) 

 An immutable Quaternion instance initialized to (0.0, 0.0, 0.0, 0.0).

#### [](#w) w : number 

[engine/Source/Core/Quaternion.js 48](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L48) 

 The W component.

Default Value: `0.0` 

#### [](#x) x : number 

[engine/Source/Core/Quaternion.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L27) 

 The X component.

Default Value: `0.0` 

#### [](#y) y : number 

[engine/Source/Core/Quaternion.js 34](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L34) 

 The Y component.

Default Value: `0.0` 

#### [](#z) z : number 

[engine/Source/Core/Quaternion.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L41) 

 The Z component.

Default Value: `0.0` 

### Methods

#### [](#.add) static Cesium.Quaternion.add(left, right, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 511](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L511) 

 Computes the componentwise sum of two quaternions.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Quaternion](Quaternion.html) | The first quaternion.                      |
| right  | [Quaternion](Quaternion.html) | The second quaternion.                     |
| result | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.clone) static Cesium.Quaternion.clone(quaternion, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 391](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L391) 

 Duplicates a Quaternion instance.

| Name       | Type                          | Description                                         |
| ---------- | ----------------------------- | --------------------------------------------------- |
| quaternion | [Quaternion](Quaternion.html) | The quaternion to duplicate.                        |
| result     | [Quaternion](Quaternion.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Quaternion instance if one was not provided. (Returns undefined if quaternion is undefined)

#### [](#.computeAngle) static Cesium.Quaternion.computeAngle(quaternion) → number 

[engine/Source/Core/Quaternion.js 703](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L703) 

 Computes the angle of rotation of the provided quaternion.

| Name       | Type                          | Description            |
| ---------- | ----------------------------- | ---------------------- |
| quaternion | [Quaternion](Quaternion.html) | The quaternion to use. |

##### Returns:

 The angle of rotation.

#### [](#.computeAxis) static Cesium.Quaternion.computeAxis(quaternion, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Quaternion.js 673](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L673) 

 Computes the axis of rotation of the provided quaternion.

| Name       | Type                          | Description                                |
| ---------- | ----------------------------- | ------------------------------------------ |
| quaternion | [Quaternion](Quaternion.html) | The quaternion to use.                     |
| result     | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.computeInnerQuadrangle) static Cesium.Quaternion.computeInnerQuadrangle(q0, q1, q2, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 858](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L858) 

 Computes an inner quadrangle point.

This will compute quaternions that ensure a squad curve is C1.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| q0     | [Quaternion](Quaternion.html) | The first quaternion.                      |
| q1     | [Quaternion](Quaternion.html) | The second quaternion.                     |
| q2     | [Quaternion](Quaternion.html) | The third quaternion.                      |
| result | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### See:

* Quaternion#squad

#### [](#.conjugate) static Cesium.Quaternion.conjugate(quaternion, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 419](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L419) 

 Computes the conjugate of the provided quaternion.

| Name       | Type                          | Description                                |
| ---------- | ----------------------------- | ------------------------------------------ |
| quaternion | [Quaternion](Quaternion.html) | The quaternion to conjugate.               |
| result     | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.convertPackedArrayForInterpolation) static Cesium.Quaternion.convertPackedArrayForInterpolation(packedArray, startingIndex, lastIndex, result) 

[engine/Source/Core/Quaternion.js 291](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L291) 

 Converts a packed array into a form suitable for interpolation.

| Name          | Type           | Default            | Description                                              |
| ------------- | -------------- | ------------------ | -------------------------------------------------------- |
| packedArray   | Array.<number> |                    | The packed array.                                        |
| startingIndex | number         | 0                  | optional The index of the first element to be converted. |
| lastIndex     | number         | packedArray.length | optional The index of the last element to be converted.  |
| result        | Array.<number> |                    | optional The object into which to store the result.      |

#### [](#.divideByScalar) static Cesium.Quaternion.divideByScalar(quaternion, scalar, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 652](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L652) 

 Divides the provided quaternion componentwise by the provided scalar.

| Name       | Type                          | Description                                |
| ---------- | ----------------------------- | ------------------------------------------ |
| quaternion | [Quaternion](Quaternion.html) | The quaternion to be divided.              |
| scalar     | number                        | The scalar to divide by.                   |
| result     | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.dot) static Cesium.Quaternion.dot(left, right) → number 

[engine/Source/Core/Quaternion.js 574](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L574) 

 Computes the dot (scalar) product of two quaternions.

| Name  | Type                          | Description            |
| ----- | ----------------------------- | ---------------------- |
| left  | [Quaternion](Quaternion.html) | The first quaternion.  |
| right | [Quaternion](Quaternion.html) | The second quaternion. |

##### Returns:

 The dot product.

#### [](#.equals) static Cesium.Quaternion.equals(left, right) → boolean 

[engine/Source/Core/Quaternion.js 1052](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L1052) 

 Compares the provided quaternions componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                          | Description                     |
| ----- | ----------------------------- | ------------------------------- |
| left  | [Quaternion](Quaternion.html) | optional The first quaternion.  |
| right | [Quaternion](Quaternion.html) | optional The second quaternion. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.equalsEpsilon) static Cesium.Quaternion.equalsEpsilon(left, right, epsilon) → boolean 

[engine/Source/Core/Quaternion.js 1074](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L1074) 

 Compares the provided quaternions componentwise and returns`true` if they are within the provided epsilon,`false` otherwise.

| Name    | Type                          | Default | Description                                       |
| ------- | ----------------------------- | ------- | ------------------------------------------------- |
| left    | [Quaternion](Quaternion.html) |         | optional The first quaternion.                    |
| right   | [Quaternion](Quaternion.html) |         | optional The second quaternion.                   |
| epsilon | number                        | 0       | optional The epsilon to use for equality testing. |

##### Returns:

`true` if left and right are within the provided epsilon, `false` otherwise.

#### [](#.exp) static Cesium.Quaternion.exp(cartesian, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 820](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L820) 

 The exponential quaternion function.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian3](Cartesian3.html) | The cartesian.                             |
| result    | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.fastSlerp) static Cesium.Quaternion.fastSlerp(start, end, t, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 950](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L950) 

 Computes the spherical linear interpolation or extrapolation at t using the provided quaternions. This implementation is faster than `Quaternion#slerp`, but is only accurate up to 10\-6.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| start  | [Quaternion](Quaternion.html) | The value corresponding to t at 0.0.       |
| end    | [Quaternion](Quaternion.html) | The value corresponding to t at 1.0.       |
| t      | number                        | The point along t at which to interpolate. |
| result | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### See:

* Quaternion#slerp

#### [](#.fastSquad) static Cesium.Quaternion.fastSquad(q0, q1, s0, s1, t, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 1029](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L1029) 

 Computes the spherical quadrangle interpolation between quaternions. An implementation that is faster than `Quaternion#squad`, but less accurate.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| q0     | [Quaternion](Quaternion.html) | The first quaternion.                      |
| q1     | [Quaternion](Quaternion.html) | The second quaternion.                     |
| s0     | [Quaternion](Quaternion.html) | The first inner quadrangle.                |
| s1     | [Quaternion](Quaternion.html) | The second inner quadrangle.               |
| t      | number                        | The time in \[0,1\] used to interpolate.   |
| result | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if none was provided.

##### See:

* Quaternion#squad

#### [](#.fromAxisAngle) static Cesium.Quaternion.fromAxisAngle(axis, angle, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 61](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L61) 

 Computes a quaternion representing a rotation around an axis.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| axis   | [Cartesian3](Cartesian3.html) | The axis of rotation.                               |
| angle  | number                        | The angle in radians to rotate around the axis.     |
| result | [Quaternion](Quaternion.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Quaternion instance if one was not provided.

#### [](#.fromHeadingPitchRoll) static Cesium.Quaternion.fromHeadingPitchRoll(headingPitchRoll, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 187](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L187) 

 Computes a rotation from the given heading, pitch and roll angles. Heading is the rotation about the negative z axis. Pitch is the rotation about the negative y axis. Roll is the rotation about the positive x axis.

| Name             | Type                                      | Description                                          |
| ---------------- | ----------------------------------------- | ---------------------------------------------------- |
| headingPitchRoll | [HeadingPitchRoll](HeadingPitchRoll.html) | The rotation expressed as a heading, pitch and roll. |
| result           | [Quaternion](Quaternion.html)             | optional The object onto which to store the result.  |

##### Returns:

 The modified result parameter or a new Quaternion instance if none was provided.

#### [](#.fromRotationMatrix) static Cesium.Quaternion.fromRotationMatrix(matrix, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L96) 

 Computes a Quaternion from the provided Matrix3 instance.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| matrix | [Matrix3](Matrix3.html)       | The rotation matrix.                                |
| result | [Quaternion](Quaternion.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Quaternion instance if one was not provided.

##### See:

* [Matrix3.fromQuaternion](Matrix3.html#.fromQuaternion)

#### [](#.inverse) static Cesium.Quaternion.inverse(quaternion, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 493](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L493) 

 Computes the inverse of the provided quaternion.

| Name       | Type                          | Description                                |
| ---------- | ----------------------------- | ------------------------------------------ |
| quaternion | [Quaternion](Quaternion.html) | The quaternion to normalize.               |
| result     | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.lerp) static Cesium.Quaternion.lerp(start, end, t, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 724](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L724) 

 Computes the linear interpolation or extrapolation at t using the provided quaternions.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| start  | [Quaternion](Quaternion.html) | The value corresponding to t at 0.0.       |
| end    | [Quaternion](Quaternion.html) | The value corresponding to t at 1.0.       |
| t      | number                        | The point along t at which to interpolate. |
| result | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.log) static Cesium.Quaternion.log(quaternion, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Quaternion.js 797](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L797) 

 The logarithmic quaternion function.

| Name       | Type                          | Description                                |
| ---------- | ----------------------------- | ------------------------------------------ |
| quaternion | [Quaternion](Quaternion.html) | The unit quaternion.                       |
| result     | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.magnitude) static Cesium.Quaternion.magnitude(quaternion) → number 

[engine/Source/Core/Quaternion.js 457](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L457) 

 Computes magnitude for the provided quaternion.

| Name       | Type                          | Description                  |
| ---------- | ----------------------------- | ---------------------------- |
| quaternion | [Quaternion](Quaternion.html) | The quaternion to conjugate. |

##### Returns:

 The magnitude.

#### [](#.magnitudeSquared) static Cesium.Quaternion.magnitudeSquared(quaternion) → number 

[engine/Source/Core/Quaternion.js 438](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L438) 

 Computes magnitude squared for the provided quaternion.

| Name       | Type                          | Description                  |
| ---------- | ----------------------------- | ---------------------------- |
| quaternion | [Quaternion](Quaternion.html) | The quaternion to conjugate. |

##### Returns:

 The magnitude squared.

#### [](#.multiply) static Cesium.Quaternion.multiply(left, right, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 593](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L593) 

 Computes the product of two quaternions.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Quaternion](Quaternion.html) | The first quaternion.                      |
| right  | [Quaternion](Quaternion.html) | The second quaternion.                     |
| result | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiplyByScalar) static Cesium.Quaternion.multiplyByScalar(quaternion, scalar, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 630](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L630) 

 Multiplies the provided quaternion componentwise by the provided scalar.

| Name       | Type                          | Description                                |
| ---------- | ----------------------------- | ------------------------------------------ |
| quaternion | [Quaternion](Quaternion.html) | The quaternion to be scaled.               |
| scalar     | number                        | The scalar to multiply with.               |
| result     | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.negate) static Cesium.Quaternion.negate(quaternion, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 554](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L554) 

 Negates the provided quaternion.

| Name       | Type                          | Description                                |
| ---------- | ----------------------------- | ------------------------------------------ |
| quaternion | [Quaternion](Quaternion.html) | The quaternion to be negated.              |
| result     | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.normalize) static Cesium.Quaternion.normalize(quaternion, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 468](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L468) 

 Computes the normalized form of the provided quaternion.

| Name       | Type                          | Description                                |
| ---------- | ----------------------------- | ------------------------------------------ |
| quaternion | [Quaternion](Quaternion.html) | The quaternion to normalize.               |
| result     | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.pack) static Cesium.Quaternion.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/Quaternion.js 236](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L236) 

 Stores the provided instance into the provided array.

| Name          | Type                          | Default | Description                                                               |
| ------------- | ----------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [Quaternion](Quaternion.html) |         | The value to pack.                                                        |
| array         | Array.<number>                |         | The array to pack into.                                                   |
| startingIndex | number                        | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.slerp) static Cesium.Quaternion.slerp(start, end, t, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 751](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L751) 

 Computes the spherical linear interpolation or extrapolation at t using the provided quaternions.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| start  | [Quaternion](Quaternion.html) | The value corresponding to t at 0.0.       |
| end    | [Quaternion](Quaternion.html) | The value corresponding to t at 1.0.       |
| t      | number                        | The point along t at which to interpolate. |
| result | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### See:

* Quaternion#fastSlerp

#### [](#.squad) static Cesium.Quaternion.squad(q0, q1, s0, s1, t, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 905](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L905) 

 Computes the spherical quadrangle interpolation between quaternions.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| q0     | [Quaternion](Quaternion.html) | The first quaternion.                      |
| q1     | [Quaternion](Quaternion.html) | The second quaternion.                     |
| s0     | [Quaternion](Quaternion.html) | The first inner quadrangle.                |
| s1     | [Quaternion](Quaternion.html) | The second inner quadrangle.               |
| t      | number                        | The time in \[0,1\] used to interpolate.   |
| result | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
// 1. compute the squad interpolation between two quaternions on a curve
const s0 = Cesium.Quaternion.computeInnerQuadrangle(quaternions[i - 1], quaternions[i], quaternions[i + 1], new Cesium.Quaternion());
const s1 = Cesium.Quaternion.computeInnerQuadrangle(quaternions[i], quaternions[i + 1], quaternions[i + 2], new Cesium.Quaternion());
const q = Cesium.Quaternion.squad(quaternions[i], quaternions[i + 1], s0, s1, t, new Cesium.Quaternion());

// 2. compute the squad interpolation as above but where the first quaternion is a end point.
const s1 = Cesium.Quaternion.computeInnerQuadrangle(quaternions[0], quaternions[1], quaternions[2], new Cesium.Quaternion());
const q = Cesium.Quaternion.squad(quaternions[0], quaternions[1], quaternions[0], s1, t, new Cesium.Quaternion());
```

##### See:

* Quaternion#computeInnerQuadrangle

#### [](#.subtract) static Cesium.Quaternion.subtract(left, right, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 533](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L533) 

 Computes the componentwise difference of two quaternions.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Quaternion](Quaternion.html) | The first quaternion.                      |
| right  | [Quaternion](Quaternion.html) | The second quaternion.                     |
| result | [Quaternion](Quaternion.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.unpack) static Cesium.Quaternion.unpack(array, startingIndex, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 260](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L260) 

 Retrieves an instance from a packed array.

| Name          | Type                          | Default | Description                                                |
| ------------- | ----------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                |         | The packed array.                                          |
| startingIndex | number                        | 0       | optional The starting index of the element to be unpacked. |
| result        | [Quaternion](Quaternion.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new Quaternion instance if one was not provided.

#### [](#.unpackInterpolationResult) static Cesium.Quaternion.unpackInterpolationResult(array, sourceArray, firstIndex, lastIndex, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 352](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L352) 

 Retrieves an instance from a packed array converted with `convertPackedArrayForInterpolation`.

| Name        | Type                          | Default            | Description                                         |
| ----------- | ----------------------------- | ------------------ | --------------------------------------------------- |
| array       | Array.<number>                |                    | The array previously packed for interpolation.      |
| sourceArray | Array.<number>                |                    | The original packed array.                          |
| firstIndex  | number                        | 0                  | optional The firstIndex used to convert the array.  |
| lastIndex   | number                        | packedArray.length | optional The lastIndex used to convert the array.   |
| result      | [Quaternion](Quaternion.html) |                    | optional The object into which to store the result. |

##### Returns:

 The modified result parameter or a new Quaternion instance if one was not provided.

#### [](#clone) clone(result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/Quaternion.js 1110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L1110) 

 Duplicates this Quaternion instance.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| result | [Quaternion](Quaternion.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Quaternion instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/Quaternion.js 1121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L1121) 

 Compares this and the provided quaternion componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                          | Description                              |
| ----- | ----------------------------- | ---------------------------------------- |
| right | [Quaternion](Quaternion.html) | optional The right hand side quaternion. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(right, epsilon) → boolean 

[engine/Source/Core/Quaternion.js 1134](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L1134) 

 Compares this and the provided quaternion componentwise and returns`true` if they are within the provided epsilon,`false` otherwise.

| Name    | Type                          | Default | Description                                       |
| ------- | ----------------------------- | ------- | ------------------------------------------------- |
| right   | [Quaternion](Quaternion.html) |         | optional The right hand side quaternion.          |
| epsilon | number                        | 0       | optional The epsilon to use for equality testing. |

##### Returns:

`true` if left and right are within the provided epsilon, `false` otherwise.

#### [](#toString) toString() → string 

[engine/Source/Core/Quaternion.js 1143](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Quaternion.js#L1143) 

 Returns a string representing this quaternion in the format (x, y, z, w).

##### Returns:

 A string representing this Quaternion.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

