# [![](Images/CesiumLogo.png)](index.html) CatmullRomSpline 

#### [](#CatmullRomSpline) new Cesium.CatmullRomSpline(options) 

[engine/Source/Core/CatmullRomSpline.js 150](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CatmullRomSpline.js#L150) 

 A Catmull-Rom spline is a cubic spline where the tangent at control points, except the first and last, are computed using the previous and next control points. Catmull-Rom splines are in the class C1.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description times Array.<number>  An array of strictly increasing, unit-less, floating-point times at each point. The values are in no way connected to the clock time. They are the parameterization for the curve. points Array.<[Cartesian3](Cartesian3.html)\>  The array of [Cartesian3](Cartesian3.html) control points. firstTangent [Cartesian3](Cartesian3.html) optional The tangent of the curve at the first control point. If the tangent is not given, it will be estimated. lastTangent [Cartesian3](Cartesian3.html) optional The tangent of the curve at the last control point. If the tangent is not given, it will be estimated. |

##### Throws:

* [DeveloperError](DeveloperError.html): points.length must be greater than or equal to 2.
* [DeveloperError](DeveloperError.html): times.length must be equal to points.length.

##### Example:

```javascript
// spline above the earth from Philadelphia to Los Angeles
const spline = new Cesium.CatmullRomSpline({
    times : [ 0.0, 1.5, 3.0, 4.5, 6.0 ],
    points : [
        new Cesium.Cartesian3(1235398.0, -4810983.0, 4146266.0),
        new Cesium.Cartesian3(1372574.0, -5345182.0, 4606657.0),
        new Cesium.Cartesian3(-757983.0, -5542796.0, 4514323.0),
        new Cesium.Cartesian3(-2821260.0, -5248423.0, 4021290.0),
        new Cesium.Cartesian3(-2539788.0, -4724797.0, 3620093.0)
    ]
});

const p0 = spline.evaluate(times[i]);         // equal to positions[i]
const p1 = spline.evaluate(times[i] + delta); // interpolated value when delta < times[i + 1] - times[i]
```

##### See:

* [ConstantSpline](ConstantSpline.html)
* [SteppedSpline](SteppedSpline.html)
* [HermiteSpline](HermiteSpline.html)
* [LinearSpline](LinearSpline.html)
* [QuaternionSpline](QuaternionSpline.html)
* [MorphWeightSpline](MorphWeightSpline.html)

### Members

#### [](#firstTangent) readonly firstTangent : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/CatmullRomSpline.js 235](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CatmullRomSpline.js#L235) 

 The tangent at the first control point.

#### [](#lastTangent) readonly lastTangent : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/CatmullRomSpline.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CatmullRomSpline.js#L249) 

 The tangent at the last control point.

#### [](#points) readonly points : Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/CatmullRomSpline.js 221](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CatmullRomSpline.js#L221) 

 An array of [Cartesian3](Cartesian3.html) control points.

#### [](#times) readonly times : Array.<number> 

[engine/Source/Core/CatmullRomSpline.js 207](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CatmullRomSpline.js#L207) 

 An array of times for the control points.

### Methods

#### [](#clampTime) clampTime(time) → number 

[engine/Source/Core/CatmullRomSpline.js 308](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CatmullRomSpline.js#L308) 

 Clamps the given time to the period covered by the spline.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The time, clamped to the animation period.

#### [](#evaluate) evaluate(time, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/CatmullRomSpline.js 321](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CatmullRomSpline.js#L321) 

 Evaluates the curve at a given time.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| time   | number                        | The time at which to evaluate the curve.            |
| result | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance of the point on the curve at the given time.

##### Throws:

* [DeveloperError](DeveloperError.html): time must be in the range `[t0, tn]`, where `t0` is the first element in the array `times` and `tn` is the last element in the array `times`.

#### [](#findTimeInterval) findTimeInterval(time) → number 

[engine/Source/Core/CatmullRomSpline.js 290](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CatmullRomSpline.js#L290) 

 Finds an index `i` in `times` such that the parameter`time` is in the interval `[times[i], times[i + 1]]`.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The index for the element at the start of the interval.

##### Throws:

* [DeveloperError](DeveloperError.html): time must be in the range `[t0, tn]`, where `t0` is the first element in the array `times` and `tn` is the last element in the array `times`.

#### [](#wrapTime) wrapTime(time) → number 

[engine/Source/Core/CatmullRomSpline.js 299](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CatmullRomSpline.js#L299) 

 Wraps the given time to the period covered by the spline.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The time, wrapped around to the updated animation.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

