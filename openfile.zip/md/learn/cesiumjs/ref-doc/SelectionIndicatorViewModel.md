# [![](Images/CesiumLogo.png)](index.html) SelectionIndicatorViewModel 

#### [](#SelectionIndicatorViewModel) new Cesium.SelectionIndicatorViewModel(scene, selectionIndicatorElement, container) 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 23](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L23) 

 The view model for [SelectionIndicator](SelectionIndicator.html).

| Name                      | Type                | Description                                                               |
| ------------------------- | ------------------- | ------------------------------------------------------------------------- |
| scene                     | [Scene](Scene.html) | The scene instance to use for screen-space coordinate conversion.         |
| selectionIndicatorElement | Element             | The element containing all elements that make up the selection indicator. |
| container                 | Element             | The DOM element that contains the widget.                                 |

### Members

#### [](#computeScreenSpacePosition) computeScreenSpacePosition : [SelectionIndicatorViewModel.ComputeScreenSpacePosition](SelectionIndicatorViewModel.html#.ComputeScreenSpacePosition) 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L100) 

 Gets or sets the function for converting the world position of the object to the screen space position.

Default Value: `SceneTransforms.worldToWindowCoordinates` 

##### Example:

```javascript
selectionIndicatorViewModel.computeScreenSpacePosition = function(position, result) {
    return Cesium.SceneTransforms.worldToWindowCoordinates(scene, position, result);
};
```

#### [](#container) container : Element 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 177](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L177) 

 Gets the HTML element containing the selection indicator.

#### [](#isVisible) isVisible : boolean 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 75](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L75) 

 Gets the visibility of the position indicator. This can be false even if an object is selected, when the selected object has no position.

#### [](#position) position : [Cartesian3](Cartesian3.html) 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 54](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L54) 

 Gets or sets the world position of the object for which to display the selection indicator.

#### [](#scene) scene : [Scene](Scene.html) 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 201](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L201) 

 Gets the scene being used.

#### [](#selectionIndicatorElement) selectionIndicatorElement : Element 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 189](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L189) 

 Gets the HTML element that holds the selection indicator.

#### [](#showSelection) showSelection : boolean 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L60) 

 Gets or sets the visibility of the selection indicator.

### Methods

#### [](#animateAppear) animateAppear() 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 145](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L145) 

 Animate the indicator to draw attention to the selection.

#### [](#animateDepart) animateDepart() 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 159](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L159) 

 Animate the indicator to release the selection.

#### [](#update) update() 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L109) 

 Updates the view of the selection indicator to match the position and content properties of the view model. This function should be called as part of the render loop.

### Type Definitions

#### [](#.ComputeScreenSpacePosition) Cesium.SelectionIndicatorViewModel.ComputeScreenSpacePosition(position, result) → [Cartesian2](Cartesian2.html) 

[widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js 208](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SelectionIndicator/SelectionIndicatorViewModel.js#L208) 

 A function that converts the world position of an object to a screen space position.

| Name     | Type                          | Description                                                               |
| -------- | ----------------------------- | ------------------------------------------------------------------------- |
| position | [Cartesian3](Cartesian3.html) | The position in WGS84 (world) coordinates.                                |
| result   | [Cartesian2](Cartesian2.html) | An object to return the input position transformed to window coordinates. |

##### Returns:

 The modified result parameter.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

