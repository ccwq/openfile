# [![](Images/CesiumLogo.png)](index.html) GeographicTilingScheme 

#### [](#GeographicTilingScheme) new Cesium.GeographicTilingScheme(options) 

[engine/Source/Core/GeographicTilingScheme.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeographicTilingScheme.js#L27) 

 A tiling scheme for geometry referenced to a simple [GeographicProjection](GeographicProjection.html) where longitude and latitude are directly mapped to X and Y. This projection is commonly known as geographic, equirectangular, equidistant cylindrical, or plate carrée.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid whose surface is being tiled. Defaults to the default ellipsoid. rectangle [Rectangle](Rectangle.html) Rectangle.MAX\_VALUE optional The rectangle, in radians, covered by the tiling scheme. numberOfLevelZeroTilesX number 2 optional The number of tiles in the X direction at level zero of the tile tree. numberOfLevelZeroTilesY number 1 optional The number of tiles in the Y direction at level zero of the tile tree. |

### Members

#### [](#ellipsoid) ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/GeographicTilingScheme.js 49](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeographicTilingScheme.js#L49) 

 Gets the ellipsoid that is tiled by this tiling scheme.

#### [](#projection) projection : [MapProjection](MapProjection.html) 

[engine/Source/Core/GeographicTilingScheme.js 71](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeographicTilingScheme.js#L71) 

 Gets the map projection used by this tiling scheme.

#### [](#rectangle) rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Core/GeographicTilingScheme.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeographicTilingScheme.js#L60) 

 Gets the rectangle, in radians, covered by this tiling scheme.

### Methods

#### [](#getNumberOfXTilesAtLevel) getNumberOfXTilesAtLevel(level) → number 

[engine/Source/Core/GeographicTilingScheme.js 84](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeographicTilingScheme.js#L84) 

 Gets the total number of tiles in the X direction at a specified level-of-detail.

| Name  | Type   | Description          |
| ----- | ------ | -------------------- |
| level | number | The level-of-detail. |

##### Returns:

 The number of tiles in the X direction at the given level.

#### [](#getNumberOfYTilesAtLevel) getNumberOfYTilesAtLevel(level) → number 

[engine/Source/Core/GeographicTilingScheme.js 94](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeographicTilingScheme.js#L94) 

 Gets the total number of tiles in the Y direction at a specified level-of-detail.

| Name  | Type   | Description          |
| ----- | ------ | -------------------- |
| level | number | The level-of-detail. |

##### Returns:

 The number of tiles in the Y direction at the given level.

#### [](#positionToTileXY) positionToTileXY(position, level, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/GeographicTilingScheme.js 210](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeographicTilingScheme.js#L210) 

 Calculates the tile x, y coordinates of the tile containing a given cartographic position.

| Name     | Type                              | Description                                                                                          |
| -------- | --------------------------------- | ---------------------------------------------------------------------------------------------------- |
| position | [Cartographic](Cartographic.html) | The position.                                                                                        |
| level    | number                            | The tile level-of-detail. Zero is the least detailed.                                                |
| result   | [Cartesian2](Cartesian2.html)     | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the tile x, y coordinates if 'result' is undefined.

#### [](#rectangleToNativeRectangle) rectangleToNativeRectangle(rectangle, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/GeographicTilingScheme.js 108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeographicTilingScheme.js#L108) 

 Transforms a rectangle specified in geodetic radians to the native coordinate system of this tiling scheme.

| Name      | Type                        | Description                                                                                          |
| --------- | --------------------------- | ---------------------------------------------------------------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html) | The rectangle to transform.                                                                          |
| result    | [Rectangle](Rectangle.html) | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the native rectangle if 'result' is undefined.

#### [](#tileXYToNativeRectangle) tileXYToNativeRectangle(x, y, level, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/GeographicTilingScheme.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeographicTilingScheme.js#L144) 

 Converts tile x, y coordinates and level to a rectangle expressed in the native coordinates of the tiling scheme.

| Name   | Type   | Description                                                                                          |
| ------ | ------ | ---------------------------------------------------------------------------------------------------- |
| x      | number | The integer x coordinate of the tile.                                                                |
| y      | number | The integer y coordinate of the tile.                                                                |
| level  | number | The tile level-of-detail. Zero is the least detailed.                                                |
| result | object | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the rectangle if 'result' is undefined.

#### [](#tileXYToRectangle) tileXYToRectangle(x, y, level, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/GeographicTilingScheme.js 169](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeographicTilingScheme.js#L169) 

 Converts tile x, y coordinates and level to a cartographic rectangle in radians.

| Name   | Type   | Description                                                                                          |
| ------ | ------ | ---------------------------------------------------------------------------------------------------- |
| x      | number | The integer x coordinate of the tile.                                                                |
| y      | number | The integer y coordinate of the tile.                                                                |
| level  | number | The tile level-of-detail. Zero is the least detailed.                                                |
| result | object | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the rectangle if 'result' is undefined.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

