# [![](Images/CesiumLogo.png)](index.html) GridMaterialProperty 

#### [](#GridMaterialProperty) new Cesium.GridMaterialProperty(options) 

[engine/Source/DataSources/GridMaterialProperty.js 29](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GridMaterialProperty.js#L29) 

 A [MaterialProperty](MaterialProperty.html) that maps to grid [Material](Material.html) uniforms.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description color [Property](Property.html)\|[Color](Color.html) Color.WHITE optional A Property specifying the grid [Color](Color.html). cellAlpha [Property](Property.html)|number 0.1 optional A numeric Property specifying cell alpha values. lineCount [Property](Property.html)|[Cartesian2](Cartesian2.html) new Cartesian2(8, 8) optional A [Cartesian2](Cartesian2.html) Property specifying the number of grid lines along each axis. lineThickness [Property](Property.html)|[Cartesian2](Cartesian2.html) new Cartesian2(1.0, 1.0) optional A [Cartesian2](Cartesian2.html) Property specifying the thickness of grid lines along each axis. lineOffset [Property](Property.html)|[Cartesian2](Cartesian2.html) new Cartesian2(0.0, 0.0) optional A [Cartesian2](Cartesian2.html) Property specifying starting offset of grid lines along each axis. |

### Members

#### [](#cellAlpha) cellAlpha : [Property](Property.html)|undefined 

[engine/Source/DataSources/GridMaterialProperty.js 101](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GridMaterialProperty.js#L101) 

 Gets or sets the numeric Property specifying cell alpha values.

Default Value: `0.1` 

#### [](#color) color : [Property](Property.html)|undefined 

[engine/Source/DataSources/GridMaterialProperty.js 93](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GridMaterialProperty.js#L93) 

 Gets or sets the Property specifying the grid [Color](Color.html).

Default Value: `Color.WHITE` 

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/GridMaterialProperty.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GridMaterialProperty.js#L81) 

 Gets the event that is raised whenever the definition of this property changes. The definition is considered to have changed if a call to getValue would return a different result for the same time.

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/GridMaterialProperty.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GridMaterialProperty.js#L60) 

 Gets a value indicating if this property is constant. A property is considered constant if getValue always returns the same result for the current definition.

#### [](#lineCount) lineCount : [Property](Property.html)|undefined 

[engine/Source/DataSources/GridMaterialProperty.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GridMaterialProperty.js#L109) 

 Gets or sets the [Cartesian2](Cartesian2.html) Property specifying the number of grid lines along each axis.

Default Value: `new Cartesian2(8.0, 8.0)` 

#### [](#lineOffset) lineOffset : [Property](Property.html)|undefined 

[engine/Source/DataSources/GridMaterialProperty.js 125](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GridMaterialProperty.js#L125) 

 Gets or sets the [Cartesian2](Cartesian2.html) Property specifying the starting offset of grid lines along each axis.

Default Value: `new Cartesian2(0.0, 0.0)` 

#### [](#lineThickness) lineThickness : [Property](Property.html)|undefined 

[engine/Source/DataSources/GridMaterialProperty.js 117](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GridMaterialProperty.js#L117) 

 Gets or sets the [Cartesian2](Cartesian2.html) Property specifying the thickness of grid lines along each axis.

Default Value: `new Cartesian2(1.0, 1.0)` 

### Methods

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/GridMaterialProperty.js 193](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GridMaterialProperty.js#L193) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getType) getType(time) → string 

[engine/Source/DataSources/GridMaterialProperty.js 134](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GridMaterialProperty.js#L134) 

 Gets the [Material](Material.html) type at the provided time.

| Name | Type                          | Description                              |
| ---- | ----------------------------- | ---------------------------------------- |
| time | [JulianDate](JulianDate.html) | The time for which to retrieve the type. |

##### Returns:

 The type of material.

#### [](#getValue) getValue(time, result) → object 

[engine/Source/DataSources/GridMaterialProperty.js 147](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GridMaterialProperty.js#L147) 

 Gets the value of the property at the provided time.

| Name   | Type                          | Default          | Description                                                                                      |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | object                        |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

