# [![](Images/CesiumLogo.png)](index.html) MapboxStyleImageryProvider 

#### [](#MapboxStyleImageryProvider) new Cesium.MapboxStyleImageryProvider(options) 

[engine/Source/Scene/MapboxStyleImageryProvider.js 51](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L51) 

 Provides tiled imagery hosted by Mapbox.

| Name    | Type                                                                                                 | Description                              |
| ------- | ---------------------------------------------------------------------------------------------------- | ---------------------------------------- |
| options | [MapboxStyleImageryProvider.ConstructorOptions](MapboxStyleImageryProvider.html#.ConstructorOptions) | Object describing initialization options |

##### Example:

```javascript
// Mapbox style provider
const mapbox = new Cesium.MapboxStyleImageryProvider({
    styleId: 'streets-v11',
    accessToken: 'thisIsMyAccessToken'
});
```

##### See:

* <https://docs.mapbox.com/api/maps/#styles>
* <https://docs.mapbox.com/api/#access-tokens-and-token-scopes>

### Members

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/MapboxStyleImageryProvider.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L249) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/MapboxStyleImageryProvider.js 236](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L236) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error.. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/MapboxStyleImageryProvider.js 277](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L277) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. When this property is false, memory usage and texture upload time are reduced.

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/MapboxStyleImageryProvider.js 180](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L180) 

 Gets the maximum level-of-detail that can be requested.

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/MapboxStyleImageryProvider.js 196](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L196) 

 Gets the minimum level-of-detail that can be requested. Generally, a minimum level should only be used when the rectangle of the imagery is small enough that the number of tiles at the minimum level is small. An imagery provider with more than a few tiles at the minimum level will lead to rendering problems.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/MapboxStyleImageryProvider.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L261) 

 Gets the proxy used by this provider.

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/MapboxStyleImageryProvider.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L144) 

 Gets the rectangle, in radians, of the imagery provided by the instance.

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/MapboxStyleImageryProvider.js 222](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L222) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/MapboxStyleImageryProvider.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L168) 

 Gets the height of each tile, in pixels.

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/MapboxStyleImageryProvider.js 156](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L156) 

 Gets the width of each tile, in pixels.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/MapboxStyleImageryProvider.js 208](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L208) 

 Gets the tiling scheme used by the provider.

#### [](#url) readonly url : string 

[engine/Source/Scene/MapboxStyleImageryProvider.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L132) 

 Gets the URL of the Mapbox server.

### Methods

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/MapboxStyleImageryProvider.js 292](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L292) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → Promise.<Array.<[ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html)\>>|undefined 

[engine/Source/Scene/MapboxStyleImageryProvider.js 330](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L330) 

 Asynchronously determines what features, if any, are located at a given longitude and latitude within a tile. This function is optional, so it may not exist on all ImageryProviders.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 A promise for the picked features that will resolve when the asynchronous picking completes. The resolved value is an array of [ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html) instances. The array may be empty if no features are found at the given location. It may also be undefined if picking is not supported.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<[ImageryTypes](global.html#ImageryTypes)\>|undefined 

[engine/Source/Scene/MapboxStyleImageryProvider.js 306](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L306) 

 Requests the image for a given tile.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the image that will resolve when the image is available, or undefined if there are too many active requests to the server, and the request should be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.MapboxStyleImageryProvider.ConstructorOptions

[engine/Source/Scene/MapboxStyleImageryProvider.js 13](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxStyleImageryProvider.js#L13) 

 Initialization options for the MapboxStyleImageryProvider constructor

##### Properties:

| Name         | Type                              | Attributes | Default                             | Description                                                                                                                                                                                                                            |
| ------------ | --------------------------------- | ---------- | ----------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| url          | [Resource](Resource.html)\|string | <optional> | 'https://api.mapbox.com/styles/v1/' | The Mapbox server url.                                                                                                                                                                                                                 |
| username     | string                            | <optional> | 'mapbox'                            | The username of the map account.                                                                                                                                                                                                       |
| styleId      | string                            |            |                                     | The Mapbox Style ID.                                                                                                                                                                                                                   |
| accessToken  | string                            |            |                                     | The public access token for the imagery.                                                                                                                                                                                               |
| tilesize     | number                            | <optional> | 512                                 | The size of the image tiles.                                                                                                                                                                                                           |
| scaleFactor  | boolean                           | <optional> |                                     | Determines if tiles are rendered at a @2x scale factor.                                                                                                                                                                                |
| ellipsoid    | [Ellipsoid](Ellipsoid.html)       | <optional> | Ellipsoid.default                   | The ellipsoid. If not specified, the default ellipsoid is used.                                                                                                                                                                        |
| minimumLevel | number                            | <optional> | 0                                   | The minimum level-of-detail supported by the imagery provider. Take care when specifying this that the number of tiles at the minimum level is small, such as four or less. A larger number is likely to result in rendering problems. |
| maximumLevel | number                            | <optional> |                                     | The maximum level-of-detail supported by the imagery provider, or undefined if there is no limit.                                                                                                                                      |
| rectangle    | [Rectangle](Rectangle.html)       | <optional> | Rectangle.MAX\_VALUE                | The rectangle, in radians, covered by the image.                                                                                                                                                                                       |
| credit       | [Credit](Credit.html)\|string     | <optional> |                                     | A credit for the data source, which is displayed on the canvas.                                                                                                                                                                        |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

