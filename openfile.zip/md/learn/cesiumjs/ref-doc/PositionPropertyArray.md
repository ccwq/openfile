# [![](Images/CesiumLogo.png)](index.html) PositionPropertyArray 

#### [](#PositionPropertyArray) new Cesium.PositionPropertyArray(value, referenceFrame) 

[engine/Source/DataSources/PositionPropertyArray.js 20](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PositionPropertyArray.js#L20) 

 A [Property](Property.html) whose value is an array whose items are the computed value of other PositionProperty instances.

| Name           | Type                                         | Default              | Description                                                    |
| -------------- | -------------------------------------------- | -------------------- | -------------------------------------------------------------- |
| value          | Array.<[Property](Property.html)\>           |                      | optional An array of Property instances.                       |
| referenceFrame | [ReferenceFrame](global.html#ReferenceFrame) | ReferenceFrame.FIXED | optional The reference frame in which the position is defined. |

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/PositionPropertyArray.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PositionPropertyArray.js#L62) 

 Gets the event that is raised whenever the definition of this property changes. The definition is changed whenever setValue is called with data different than the current value or one of the properties in the array also changes.

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/PositionPropertyArray.js 37](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PositionPropertyArray.js#L37) 

 Gets a value indicating if this property is constant. This property is considered constant if all property items in the array are constant.

#### [](#referenceFrame) referenceFrame : [ReferenceFrame](global.html#ReferenceFrame) 

[engine/Source/DataSources/PositionPropertyArray.js 73](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PositionPropertyArray.js#L73) 

 Gets the reference frame in which the position is defined.

Default Value: `ReferenceFrame.FIXED;` 

### Methods

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/PositionPropertyArray.js 181](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PositionPropertyArray.js#L181) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getValue) getValue(time, result) → Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/DataSources/PositionPropertyArray.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PositionPropertyArray.js#L89) 

 Gets the value of the property.

| Name   | Type                                   | Default          | Description                                                                                      |
| ------ | -------------------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html)          | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | Array.<[Cartesian3](Cartesian3.html)\> |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

#### [](#getValueInReferenceFrame) getValueInReferenceFrame(time, referenceFrame, result) → Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/DataSources/PositionPropertyArray.js 104](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PositionPropertyArray.js#L104) 

 Gets the value of the property at the provided time and in the provided reference frame.

| Name           | Type                                         | Description                                                                                      |
| -------------- | -------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| time           | [JulianDate](JulianDate.html)                | The time for which to retrieve the value.                                                        |
| referenceFrame | [ReferenceFrame](global.html#ReferenceFrame) | The desired referenceFrame of the result.                                                        |
| result         | Array.<[Cartesian3](Cartesian3.html)\>       | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

#### [](#setValue) setValue(value) 

[engine/Source/DataSources/PositionPropertyArray.js 151](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PositionPropertyArray.js#L151) 

 Sets the value of the property.

| Name  | Type                               | Description                     |
| ----- | ---------------------------------- | ------------------------------- |
| value | Array.<[Property](Property.html)\> | An array of Property instances. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

