# [![](Images/CesiumLogo.png)](index.html) ModelAnimation 

#### [](#ModelAnimation) internal constructor new Cesium.ModelAnimation() 

[engine/Source/Scene/Model/ModelAnimation.js 26](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L26) 

Create animations by calling [ModelAnimationCollection#add](ModelAnimationCollection.html#add). Do not call the constructor directly.

An active animation derived from a glTF asset. An active animation is an animation that is either currently playing or scheduled to be played due to being added to a model's [ModelAnimationCollection](ModelAnimationCollection.html). An active animation is an instance of an animation; for example, there can be multiple active animations for the same glTF animation, each with a different start time.

##### See:

* [ModelAnimationCollection#add](ModelAnimationCollection.html#add)

### Members

#### [](#animationTime) animationTime : [ModelAnimation.AnimationTimeCallback](ModelAnimation.html#.AnimationTimeCallback) 

[engine/Source/Scene/Model/ModelAnimation.js 339](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L339) 

 If this is defined, it will be used to compute the local animation time instead of the scene's time.

Default Value: `undefined` 

#### [](#delay) readonly delay : number 

[engine/Source/Scene/Model/ModelAnimation.js 254](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L254) 

 The delay, in seconds, from [ModelAnimation#startTime](ModelAnimation.html#startTime) to start playing.

Default Value: `undefined` 

#### [](#loop) readonly loop : [ModelAnimationLoop](global.html#ModelAnimationLoop) 

[engine/Source/Scene/Model/ModelAnimation.js 324](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L324) 

 Determines if and how the animation is looped.

Default Value: `[ModelAnimationLoop.NONE](global.html#ModelAnimationLoop#.NONE)` 

#### [](#multiplier) readonly multiplier : number 

[engine/Source/Scene/Model/ModelAnimation.js 292](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L292) 

 Values greater than `1.0` increase the speed that the animation is played relative to the scene clock speed; values less than `1.0` decrease the speed. A value of`1.0` plays the animation at the speed in the glTF animation mapped to the scene clock speed. For example, if the scene is played at 2x real-time, a two-second glTF animation will play in one second even if `multiplier` is `1.0`.

Default Value: `1.0` 

#### [](#name) readonly name : string 

[engine/Source/Scene/Model/ModelAnimation.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L155) 

 The name that identifies this animation in the model, if it exists.

#### [](#removeOnStop) removeOnStop : boolean 

[engine/Source/Scene/Model/ModelAnimation.js 43](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L43) 

 When `true`, the animation is removed after it stops playing. This is slightly more efficient that not removing it, but if, for example, time is reversed, the animation is not played again.

Default Value: `false` 

#### [](#reverse) readonly reverse : boolean 

[engine/Source/Scene/Model/ModelAnimation.js 308](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L308) 

 When `true`, the animation is played in reverse.

Default Value: `false` 

#### [](#start) start : [Event](Event.html) 

[engine/Source/Scene/Model/ModelAnimation.js 65](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L65) 

 The event fired when this animation is started. This can be used, for example, to play a sound or start a particle system, when the animation starts.

This event is fired at the end of the frame after the scene is rendered.

Default Value: `new Event()` 

##### Example:

```javascript
animation.start.addEventListener(function(model, animation) {
  console.log(`Animation started: ${animation.name}`);
});
```

#### [](#startTime) readonly startTime : [JulianDate](JulianDate.html) 

[engine/Source/Scene/Model/ModelAnimation.js 238](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L238) 

 The scene time to start playing this animation. When this is `undefined`, the animation starts at the next frame.

Default Value: `undefined` 

#### [](#stop) stop : [Event](Event.html) 

[engine/Source/Scene/Model/ModelAnimation.js 101](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L101) 

 The event fired when this animation is stopped. This can be used, for example, to play a sound or start a particle system, when the animation stops.

This event is fired at the end of the frame after the scene is rendered.

Default Value: `new Event()` 

##### Example:

```javascript
animation.stop.addEventListener(function(model, animation) {
  console.log(`Animation stopped: ${animation.name}`);
});
```

#### [](#stopTime) readonly stopTime : [JulianDate](JulianDate.html) 

[engine/Source/Scene/Model/ModelAnimation.js 272](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L272) 

 The scene time to stop playing this animation. When this is `undefined`, the animation is played for its full duration and perhaps repeated depending on[ModelAnimation#loop](ModelAnimation.html#loop).

Default Value: `undefined` 

#### [](#update) update : [Event](Event.html) 

[engine/Source/Scene/Model/ModelAnimation.js 84](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L84) 

 The event fired when on each frame when this animation is updated. The current time of the animation, relative to the glTF animation time span, is passed to the event, which allows, for example, starting new animations at a specific time relative to a playing animation.

This event is fired at the end of the frame after the scene is rendered.

Default Value: `new Event()` 

##### Example:

```javascript
animation.update.addEventListener(function(model, animation, time) {
  console.log(`Animation updated: ${animation.name}. glTF animation time: ${time}`);
});
```

### Type Definitions

#### [](#.AnimationTimeCallback) Cesium.ModelAnimation.AnimationTimeCallback(duration, seconds) → number 

[engine/Source/Scene/Model/ModelAnimation.js 402](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimation.js#L402) 

 A function used to compute the local animation time for a ModelAnimation.

| Name     | Type   | Description                                             |
| -------- | ------ | ------------------------------------------------------- |
| duration | number | The animation's original duration in seconds.           |
| seconds  | number | The seconds since the animation started, in scene time. |

##### Returns:

 Returns the local animation time.

##### Examples:

```javascript
// Use real time for model animation (assuming animateWhilePaused was set to true)
function animationTime(duration) {
    return Date.now() / 1000 / duration;
}
```

```javascript
// Offset the phase of the animation, so it starts halfway through its cycle.
function animationTime(duration, seconds) {
    return seconds / duration + 0.5;
}
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

