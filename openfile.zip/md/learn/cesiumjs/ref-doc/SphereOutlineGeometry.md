# [![](Images/CesiumLogo.png)](index.html) SphereOutlineGeometry 

#### [](#SphereOutlineGeometry) new Cesium.SphereOutlineGeometry(options) 

[engine/Source/Core/SphereOutlineGeometry.js 31](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SphereOutlineGeometry.js#L31) 

 A description of the outline of a sphere.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description radius number 1.0 optional The radius of the sphere. stackPartitions number 10 optional The count of stacks for the sphere (1 greater than the number of parallel lines). slicePartitions number 8 optional The count of slices for the sphere (Equal to the number of radial lines). subdivisions number 200 optional The number of points per line, determining the granularity of the curvature . |

##### Throws:

* [DeveloperError](DeveloperError.html): options.stackPartitions must be greater than or equal to one.
* [DeveloperError](DeveloperError.html): options.slicePartitions must be greater than or equal to zero.
* [DeveloperError](DeveloperError.html): options.subdivisions must be greater than or equal to zero.

##### Example:

```javascript
const sphere = new Cesium.SphereOutlineGeometry({
  radius : 100.0,
  stackPartitions : 6,
  slicePartitions: 5
});
const geometry = Cesium.SphereOutlineGeometry.createGeometry(sphere);
```

### Members

#### [](#.packedLength) static Cesium.SphereOutlineGeometry.packedLength : number 

[engine/Source/Core/SphereOutlineGeometry.js 49](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SphereOutlineGeometry.js#L49) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.SphereOutlineGeometry.createGeometry(sphereGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/SphereOutlineGeometry.js 115](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SphereOutlineGeometry.js#L115) 

 Computes the geometric representation of an outline of a sphere, including its vertices, indices, and a bounding sphere.

| Name           | Type                                                | Description                          |
| -------------- | --------------------------------------------------- | ------------------------------------ |
| sphereGeometry | [SphereOutlineGeometry](SphereOutlineGeometry.html) | A description of the sphere outline. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.SphereOutlineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/SphereOutlineGeometry.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SphereOutlineGeometry.js#L60) 

 Stores the provided instance into the provided array.

| Name          | Type                                                | Default | Description                                                               |
| ------------- | --------------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [SphereOutlineGeometry](SphereOutlineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                      |         | The array to pack into.                                                   |
| startingIndex | number                                              | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.SphereOutlineGeometry.unpack(array, startingIndex, result) → [SphereOutlineGeometry](SphereOutlineGeometry.html) 

[engine/Source/Core/SphereOutlineGeometry.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SphereOutlineGeometry.js#L89) 

 Retrieves an instance from a packed array.

| Name          | Type                                                | Default | Description                                                |
| ------------- | --------------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                      |         | The packed array.                                          |
| startingIndex | number                                              | 0       | optional The starting index of the element to be unpacked. |
| result        | [SphereOutlineGeometry](SphereOutlineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new SphereOutlineGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

