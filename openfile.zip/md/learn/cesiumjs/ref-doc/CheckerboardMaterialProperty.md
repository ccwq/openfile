# [![](Images/CesiumLogo.png)](index.html) CheckerboardMaterialProperty 

#### [](#CheckerboardMaterialProperty) new Cesium.CheckerboardMaterialProperty(options) 

[engine/Source/DataSources/CheckerboardMaterialProperty.js 24](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CheckerboardMaterialProperty.js#L24) 

 A [MaterialProperty](MaterialProperty.html) that maps to checkerboard [Material](Material.html) uniforms.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description evenColor [Property](Property.html)\|[Color](Color.html) Color.WHITE optional A Property specifying the first [Color](Color.html). oddColor [Property](Property.html)|[Color](Color.html) Color.BLACK optional A Property specifying the second [Color](Color.html). repeat [Property](Property.html)|[Cartesian2](Cartesian2.html) new Cartesian2(2.0, 2.0) optional A [Cartesian2](Cartesian2.html) Property specifying how many times the tiles repeat in each direction. |

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/CheckerboardMaterialProperty.js 68](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CheckerboardMaterialProperty.js#L68) 

 Gets the event that is raised whenever the definition of this property changes. The definition is considered to have changed if a call to getValue would return a different result for the same time.

#### [](#evenColor) evenColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/CheckerboardMaterialProperty.js 80](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CheckerboardMaterialProperty.js#L80) 

 Gets or sets the Property specifying the first [Color](Color.html).

Default Value: `Color.WHITE` 

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/CheckerboardMaterialProperty.js 49](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CheckerboardMaterialProperty.js#L49) 

 Gets a value indicating if this property is constant. A property is considered constant if getValue always returns the same result for the current definition.

#### [](#oddColor) oddColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/CheckerboardMaterialProperty.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CheckerboardMaterialProperty.js#L88) 

 Gets or sets the Property specifying the second [Color](Color.html).

Default Value: `Color.BLACK` 

#### [](#repeat) repeat : [Property](Property.html)|undefined 

[engine/Source/DataSources/CheckerboardMaterialProperty.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CheckerboardMaterialProperty.js#L96) 

 Gets or sets the [Cartesian2](Cartesian2.html) Property specifying how many times the tiles repeat in each direction.

Default Value: `new Cartesian2(2.0, 2.0)` 

### Methods

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/CheckerboardMaterialProperty.js 148](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CheckerboardMaterialProperty.js#L148) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getType) getType(time) → string 

[engine/Source/DataSources/CheckerboardMaterialProperty.js 105](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CheckerboardMaterialProperty.js#L105) 

 Gets the [Material](Material.html) type at the provided time.

| Name | Type                          | Description                              |
| ---- | ----------------------------- | ---------------------------------------- |
| time | [JulianDate](JulianDate.html) | The time for which to retrieve the type. |

##### Returns:

 The type of material.

#### [](#getValue) getValue(time, result) → object 

[engine/Source/DataSources/CheckerboardMaterialProperty.js 118](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CheckerboardMaterialProperty.js#L118) 

 Gets the value of the property at the provided time.

| Name   | Type                          | Default          | Description                                                                                      |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | object                        |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

