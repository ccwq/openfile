# [![](Images/CesiumLogo.png)](index.html) GlobeTranslucency 

#### [](#GlobeTranslucency) new Cesium.GlobeTranslucency() 

[engine/Source/Scene/GlobeTranslucency.js 13](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GlobeTranslucency.js#L13) 

 Properties for controlling globe translucency.

### Members

#### [](#backFaceAlpha) backFaceAlpha : number 

[engine/Source/Scene/GlobeTranslucency.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GlobeTranslucency.js#L155) 

 A constant translucency to apply to back faces of the globe.  
  
[GlobeTranslucency#enabled](GlobeTranslucency.html#enabled) must be set to true for this option to take effect.

Default Value: `1.0` 

##### Example:

```javascript
// Set back face translucency to 0.5.
globe.translucency.backFaceAlpha = 0.5;
globe.translucency.enabled = true;
```

##### See:

* [GlobeTranslucency#enabled](GlobeTranslucency.html#enabled)
* [GlobeTranslucency#backFaceAlphaByDistance](GlobeTranslucency.html#backFaceAlphaByDistance)

#### [](#backFaceAlphaByDistance) backFaceAlphaByDistance : [NearFarScalar](NearFarScalar.html) 

[engine/Source/Scene/GlobeTranslucency.js 198](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GlobeTranslucency.js#L198) 

 Gets or sets near and far translucency properties of back faces of the globe based on the distance to the camera. The translucency will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the translucency remains clamped to the nearest bound. If undefined, backFaceAlphaByDistance will be disabled.  
  
[GlobeTranslucency#enabled](GlobeTranslucency.html#enabled) must be set to true for this option to take effect.

Default Value: `undefined` 

##### Examples:

```javascript
// Example 1.
// Set back face translucency to 0.5 when the
// camera is 1500 meters from the surface and 1.0
// as the camera distance approaches 8.0e6 meters.
globe.translucency.backFaceAlphaByDistance = new Cesium.NearFarScalar(1.5e2, 0.5, 8.0e6, 1.0);
globe.translucency.enabled = true;
```

```javascript
// Example 2.
// Disable back face translucency by distance
globe.translucency.backFaceAlphaByDistance = undefined;
```

##### See:

* [GlobeTranslucency#enabled](GlobeTranslucency.html#enabled)
* [GlobeTranslucency#backFaceAlpha](GlobeTranslucency.html#backFaceAlpha)

#### [](#enabled) enabled : boolean 

[engine/Source/Scene/GlobeTranslucency.js 45](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GlobeTranslucency.js#L45) 

 When true, the globe is rendered as a translucent surface.  
  
The alpha is computed by blending [Globe#material](Globe.html#material), [Globe#imageryLayers](Globe.html#imageryLayers), and [Globe#baseColor](Globe.html#baseColor), all of which may contain translucency, and then multiplying by[GlobeTranslucency#frontFaceAlpha](GlobeTranslucency.html#frontFaceAlpha) and [GlobeTranslucency#frontFaceAlphaByDistance](GlobeTranslucency.html#frontFaceAlphaByDistance) for front faces and[GlobeTranslucency#backFaceAlpha](GlobeTranslucency.html#backFaceAlpha) and [GlobeTranslucency#backFaceAlphaByDistance](GlobeTranslucency.html#backFaceAlphaByDistance) for back faces. When the camera is underground back faces and front faces are swapped, i.e. back-facing geometry is considered front facing.  
  
Translucency is disabled by default.

Default Value: `false` 

##### See:

* [GlobeTranslucency#frontFaceAlpha](GlobeTranslucency.html#frontFaceAlpha)
* [GlobeTranslucency#frontFaceAlphaByDistance](GlobeTranslucency.html#frontFaceAlphaByDistance)
* [GlobeTranslucency#backFaceAlpha](GlobeTranslucency.html#backFaceAlpha)
* [GlobeTranslucency#backFaceAlphaByDistance](GlobeTranslucency.html#backFaceAlphaByDistance)

#### [](#frontFaceAlpha) frontFaceAlpha : number 

[engine/Source/Scene/GlobeTranslucency.js 75](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GlobeTranslucency.js#L75) 

 A constant translucency to apply to front faces of the globe.  
  
[GlobeTranslucency#enabled](GlobeTranslucency.html#enabled) must be set to true for this option to take effect.

Default Value: `1.0` 

##### Example:

```javascript
// Set front face translucency to 0.5.
globe.translucency.frontFaceAlpha = 0.5;
globe.translucency.enabled = true;
```

##### See:

* [GlobeTranslucency#enabled](GlobeTranslucency.html#enabled)
* [GlobeTranslucency#frontFaceAlphaByDistance](GlobeTranslucency.html#frontFaceAlphaByDistance)

#### [](#frontFaceAlphaByDistance) frontFaceAlphaByDistance : [NearFarScalar](NearFarScalar.html) 

[engine/Source/Scene/GlobeTranslucency.js 118](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GlobeTranslucency.js#L118) 

 Gets or sets near and far translucency properties of front faces of the globe based on the distance to the camera. The translucency will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the translucency remains clamped to the nearest bound. If undefined, frontFaceAlphaByDistance will be disabled.  
  
[GlobeTranslucency#enabled](GlobeTranslucency.html#enabled) must be set to true for this option to take effect.

Default Value: `undefined` 

##### Examples:

```javascript
// Example 1.
// Set front face translucency to 0.5 when the
// camera is 1500 meters from the surface and 1.0
// as the camera distance approaches 8.0e6 meters.
globe.translucency.frontFaceAlphaByDistance = new Cesium.NearFarScalar(1.5e2, 0.5, 8.0e6, 1.0);
globe.translucency.enabled = true;
```

```javascript
// Example 2.
// Disable front face translucency by distance
globe.translucency.frontFaceAlphaByDistance = undefined;
```

##### See:

* [GlobeTranslucency#enabled](GlobeTranslucency.html#enabled)
* [GlobeTranslucency#frontFaceAlpha](GlobeTranslucency.html#frontFaceAlpha)

#### [](#rectangle) rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/GlobeTranslucency.js 226](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GlobeTranslucency.js#L226) 

 A property specifying a [Rectangle](Rectangle.html) used to limit translucency to a cartographic area. Defaults to the maximum extent of cartographic coordinates.

Default Value: `[Rectangle.MAX_VALUE](Rectangle.html#.MAX%5FVALUE)` 

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

