# [![](Images/CesiumLogo.png)](index.html) SkyAtmosphere 

#### [](#SkyAtmosphere) new Cesium.SkyAtmosphere(ellipsoid) 

[engine/Source/Scene/SkyAtmosphere.js 43](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L43) 

 An atmosphere drawn around the limb of the provided ellipsoid. Based on[Display of The Earth Taking Into Account Atmospheric Scattering](http://nishitalab.org/user/nis/cdrom/sig93%5Fnis.pdf).

This is only supported in 3D. Atmosphere is faded out when morphing to 2D or Columbus view.

| Name      | Type                        | Default         | Description                                                 |
| --------- | --------------------------- | --------------- | ----------------------------------------------------------- |
| ellipsoid | [Ellipsoid](Ellipsoid.html) | Ellipsoid.WGS84 | optional The ellipsoid that the atmosphere is drawn around. |

##### Example:

```javascript
scene.skyAtmosphere = new Cesium.SkyAtmosphere();
```

##### See:

* Scene.skyAtmosphere

### Members

#### [](#atmosphereLightIntensity) atmosphereLightIntensity : number 

[engine/Source/Scene/SkyAtmosphere.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L89) 

 The intensity of the light that is used for computing the sky atmosphere color.

Default Value: `50.0` 

#### [](#atmosphereMieAnisotropy) atmosphereMieAnisotropy : number 

[engine/Source/Scene/SkyAtmosphere.js 131](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L131) 

 The anisotropy of the medium to consider for Mie scattering.

Valid values are between -1.0 and 1.0.

Default Value: `0.9` 

#### [](#atmosphereMieCoefficient) atmosphereMieCoefficient : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/SkyAtmosphere.js 105](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L105) 

 The Mie scattering coefficient used in the atmospheric scattering equations for the sky atmosphere.

Default Value: `Cartesian3(21e-6, 21e-6, 21e-6)` 

#### [](#atmosphereMieScaleHeight) atmosphereMieScaleHeight : number 

[engine/Source/Scene/SkyAtmosphere.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L121) 

 The Mie scale height used in the atmospheric scattering equations for the sky atmosphere, in meters.

Default Value: `3200.0` 

#### [](#atmosphereRayleighCoefficient) atmosphereRayleighCoefficient : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/SkyAtmosphere.js 97](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L97) 

 The Rayleigh scattering coefficient used in the atmospheric scattering equations for the sky atmosphere.

Default Value: `Cartesian3(5.5e-6, 13.0e-6, 28.4e-6)` 

#### [](#atmosphereRayleighScaleHeight) atmosphereRayleighScaleHeight : number 

[engine/Source/Scene/SkyAtmosphere.js 113](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L113) 

 The Rayleigh scale height used in the atmospheric scattering equations for the sky atmosphere, in meters.

Default Value: `10000.0` 

#### [](#brightnessShift) brightnessShift : number 

[engine/Source/Scene/SkyAtmosphere.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L155) 

 The brightness shift to apply to the atmosphere. Defaults to 0.0 (no shift). A brightness shift of -1.0 is complete darkness, which will let space show through.

Default Value: `0.0` 

#### [](#ellipsoid) readonly ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Scene/SkyAtmosphere.js 212](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L212) 

 Gets the ellipsoid the atmosphere is drawn around.

#### [](#hueShift) hueShift : number 

[engine/Source/Scene/SkyAtmosphere.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L139) 

 The hue shift to apply to the atmosphere. Defaults to 0.0 (no shift). A hue shift of 1.0 indicates a complete rotation of the hues available.

Default Value: `0.0` 

#### [](#perFragmentAtmosphere) perFragmentAtmosphere : boolean 

[engine/Source/Scene/SkyAtmosphere.js 61](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L61) 

 Compute atmosphere per-fragment instead of per-vertex. This produces better looking atmosphere with a slight performance penalty.

Default Value: `false` 

#### [](#saturationShift) saturationShift : number 

[engine/Source/Scene/SkyAtmosphere.js 147](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L147) 

 The saturation shift to apply to the atmosphere. Defaults to 0.0 (no shift). A saturation shift of -1.0 is monochrome.

Default Value: `0.0` 

#### [](#show) show : boolean 

[engine/Source/Scene/SkyAtmosphere.js 52](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L52) 

 Determines if the atmosphere is shown.

Default Value: `true` 

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/SkyAtmosphere.js 394](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L394) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
skyAtmosphere = skyAtmosphere && skyAtmosphere.destroy();
```

##### See:

* [SkyAtmosphere#isDestroyed](SkyAtmosphere.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/SkyAtmosphere.js 374](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SkyAtmosphere.js#L374) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [SkyAtmosphere#destroy](SkyAtmosphere.html#destroy)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

