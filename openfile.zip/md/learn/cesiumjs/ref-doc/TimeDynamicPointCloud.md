# [![](Images/CesiumLogo.png)](index.html) TimeDynamicPointCloud 

#### [](#TimeDynamicPointCloud) new Cesium.TimeDynamicPointCloud(options) 

[engine/Source/Scene/TimeDynamicPointCloud.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L41) 

 Provides playback of time-dynamic point cloud data.

Point cloud frames are prefetched in intervals determined by the average frame load time and the current clock speed. If intermediate frames cannot be loaded in time to meet playback speed, they will be skipped. If frames are sufficiently small or the clock is sufficiently slow then no frames will be skipped.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description clock [Clock](Clock.html)  A [Clock](Clock.html) instance that is used when determining the value for the time dimension. intervals [TimeIntervalCollection](TimeIntervalCollection.html)  A [TimeIntervalCollection](TimeIntervalCollection.html) with its data property being an object containing a uri to a 3D Tiles Point Cloud tile and an optional transform. show boolean true optional Determines if the point cloud will be shown. modelMatrix [Matrix4](Matrix4.html) Matrix4.IDENTITY optional A 4x4 transformation matrix that transforms the point cloud. shadows [ShadowMode](global.html#ShadowMode) ShadowMode.ENABLED optional Determines whether the point cloud casts or receives shadows from light sources. maximumMemoryUsage number 256 optional The maximum amount of memory in MB that can be used by the point cloud. shading object optional Options for constructing a [PointCloudShading](PointCloudShading.html) object to control point attenuation and eye dome lighting. style [Cesium3DTileStyle](Cesium3DTileStyle.html) optional The style, defined using the [3D Tiles Styling language](https://github.com/CesiumGS/3d-tiles/tree/main/specification/Styling), applied to each point in the point cloud. clippingPlanes [ClippingPlaneCollection](ClippingPlaneCollection.html) optional The [ClippingPlaneCollection](ClippingPlaneCollection.html) used to selectively disable rendering the point cloud. |

### Members

#### [](#boundingSphere) readonly boundingSphere : [BoundingSphere](BoundingSphere.html) 

[engine/Source/Scene/TimeDynamicPointCloud.js 234](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L234) 

 The bounding sphere of the frame being rendered. Returns `undefined` if no frame is being rendered.

#### [](#clippingPlanes) clippingPlanes : [ClippingPlaneCollection](ClippingPlaneCollection.html) 

[engine/Source/Scene/TimeDynamicPointCloud.js 201](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L201) 

 The [ClippingPlaneCollection](ClippingPlaneCollection.html) used to selectively disable rendering the point cloud.

#### [](#frameChanged) frameChanged : [Event](Event.html) 

[engine/Source/Scene/TimeDynamicPointCloud.js 167](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L167) 

 The event fired to indicate that a new frame was rendered.

The time dynamic point cloud [TimeDynamicPointCloud](TimeDynamicPointCloud.html) is passed to the event listener.

Default Value: `new Event()` 

##### Example:

```javascript
pointCloud.frameChanged.addEventListener(function(timeDynamicPointCloud) {
    viewer.camera.viewBoundingSphere(timeDynamicPointCloud.boundingSphere);
});
```

#### [](#frameFailed) frameFailed : [Event](Event.html) 

[engine/Source/Scene/TimeDynamicPointCloud.js 152](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L152) 

 The event fired to indicate that a frame failed to load. A frame may fail to load if the request for its uri fails or processing fails due to invalid content.

If there are no event listeners, error messages will be logged to the console.

The error object passed to the listener contains two properties:
* `uri`: the uri of the failed frame.
* `message`: the error message.

Default Value: `new Event()` 

##### Example:

```javascript
pointCloud.frameFailed.addEventListener(function(error) {
    console.log(`An error occurred loading frame: ${error.uri}`);
    console.log(`Error: ${error.message}`);
});
```

#### [](#maximumMemoryUsage) maximumMemoryUsage : number 

[engine/Source/Scene/TimeDynamicPointCloud.js 95](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L95) 

 The maximum amount of GPU memory (in MB) that may be used to cache point cloud frames.

Frames that are not being loaded or rendered are unloaded to enforce this.

If decreasing this value results in unloading tiles, the tiles are unloaded the next frame.

Default Value: `256` 

##### See:

* [TimeDynamicPointCloud#totalMemoryUsageInBytes](TimeDynamicPointCloud.html#totalMemoryUsageInBytes)

#### [](#modelMatrix) modelMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/TimeDynamicPointCloud.js 63](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L63) 

 A 4x4 transformation matrix that transforms the point cloud.

Default Value: `Matrix4.IDENTITY` 

#### [](#shading) shading : [PointCloudShading](PointCloudShading.html) 

[engine/Source/Scene/TimeDynamicPointCloud.js 101](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L101) 

 Options for controlling point size based on geometric error and eye dome lighting.

#### [](#shadows) shadows : [ShadowMode](global.html#ShadowMode) 

[engine/Source/Scene/TimeDynamicPointCloud.js 79](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L79) 

 Determines whether the point cloud casts or receives shadows from light sources.

Enabling shadows has a performance impact. A point cloud that casts shadows must be rendered twice, once from the camera and again from the light's point of view.

Shadows are rendered only when [Viewer#shadows](Viewer.html#shadows) is `true`.

Default Value: `ShadowMode.ENABLED` 

#### [](#show) show : boolean 

[engine/Source/Scene/TimeDynamicPointCloud.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L55) 

 Determines if the point cloud will be shown.

Default Value: `true` 

#### [](#style) style : [Cesium3DTileStyle](Cesium3DTileStyle.html) 

[engine/Source/Scene/TimeDynamicPointCloud.js 128](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L128) 

 The style, defined using the[3D Tiles Styling language](https://github.com/CesiumGS/3d-tiles/tree/main/specification/Styling), applied to each point in the point cloud.

Assign `undefined` to remove the style, which will restore the visual appearance of the point cloud to its default when no style was applied.

##### Example:

```javascript
pointCloud.style = new Cesium.Cesium3DTileStyle({
   color : {
       conditions : [
           ['${Classification} === 0', 'color("purple", 0.5)'],
           ['${Classification} === 1', 'color("red")'],
           ['true', '${COLOR}']
       ]
   },
   show : '${Classification} !== 2'
});
```

##### See:

* [3D Tiles Styling language](https://github.com/CesiumGS/3d-tiles/tree/main/specification/Styling)

#### [](#totalMemoryUsageInBytes) readonly totalMemoryUsageInBytes : number 

[engine/Source/Scene/TimeDynamicPointCloud.js 220](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L220) 

 The total amount of GPU memory in bytes used by the point cloud.

##### See:

* [TimeDynamicPointCloud#maximumMemoryUsage](TimeDynamicPointCloud.html#maximumMemoryUsage)

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/TimeDynamicPointCloud.js 798](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L798) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
pointCloud = pointCloud && pointCloud.destroy();
```

##### See:

* [TimeDynamicPointCloud#isDestroyed](TimeDynamicPointCloud.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/TimeDynamicPointCloud.js 779](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L779) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [TimeDynamicPointCloud#destroy](TimeDynamicPointCloud.html#destroy)

#### [](#makeStyleDirty) makeStyleDirty() 

[engine/Source/Scene/TimeDynamicPointCloud.js 266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicPointCloud.js#L266) 

 Marks the point cloud's [TimeDynamicPointCloud#style](TimeDynamicPointCloud.html#style) as dirty, which forces all points to re-evaluate the style in the next frame.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

