# [![](Images/CesiumLogo.png)](index.html) LabelGraphics 

#### [](#LabelGraphics) new Cesium.LabelGraphics(options) 

[engine/Source/DataSources/LabelGraphics.js 51](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L51) 

 Describes a two dimensional label located at the position of the containing [Entity](Entity.html).

![](Images/Label.png)  
Example labels

| Name    | Type                                                                       | Description                                       |
| ------- | -------------------------------------------------------------------------- | ------------------------------------------------- |
| options | [LabelGraphics.ConstructorOptions](LabelGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle Labels Demo](https://sandcastle.cesium.com/index.html?src=Labels.html)

### Members

#### [](#backgroundColor) backgroundColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 173](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L173) 

 Gets or sets the Property specifying the background [Color](Color.html).

Default Value: `new Color(0.165, 0.165, 0.165, 0.8)` 

#### [](#backgroundPadding) backgroundPadding : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 182](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L182) 

 Gets or sets the [Cartesian2](Cartesian2.html) Property specifying the label's horizontal and vertical background padding in pixels.

Default Value: `new Cartesian2(7, 5)` 

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/LabelGraphics.js 107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L107) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#disableDepthTestDistance) disableDepthTestDistance : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 323](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L323) 

 Gets or sets the distance from the camera at which to disable the depth test to, for example, prevent clipping against terrain. When set to zero, the depth test is always applied. When set to Number.POSITIVE\_INFINITY, the depth test is never applied.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 313](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L313) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this label will be displayed.

#### [](#eyeOffset) eyeOffset : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 227](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L227) 

 Gets or sets the [Cartesian3](Cartesian3.html) Property specifying the label's offset in eye coordinates. Eye coordinates is a left-handed coordinate system, where `x` points towards the viewer's right, `y` points up, and `z` points into the screen.

An eye offset is commonly used to arrange multiple labels or objects at the same position, e.g., to arrange a label above its corresponding 3D model.

Below, the label is positioned at the center of the Earth but an eye offset makes it always appear on top of the Earth regardless of the viewer's or Earth's orientation.

| ![](Images/Billboard.setEyeOffset.one.png) | ![](Images/Billboard.setEyeOffset.two.png) |
| ------------------------------------------ | ------------------------------------------ |

`l.eyeOffset = new Cartesian3(0.0, 8000000.0, 0.0);`  
  
Default Value: `Cartesian3.ZERO` 

#### [](#fillColor) fillColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 256](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L256) 

 Gets or sets the Property specifying the fill [Color](Color.html).

#### [](#font) font : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 134](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L134) 

 Gets or sets the string Property specifying the font in CSS syntax.

##### See:

* [CSS font on MDN](https://developer.mozilla.org/en-US/docs/Web/CSS/font)

#### [](#heightReference) heightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L249) 

 Gets or sets the Property specifying the [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#horizontalOrigin) horizontalOrigin : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 234](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L234) 

 Gets or sets the Property specifying the [HorizontalOrigin](global.html#HorizontalOrigin).

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 263](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L263) 

 Gets or sets the Property specifying the outline [Color](Color.html).

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 270](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L270) 

 Gets or sets the numeric Property specifying the outline width.

#### [](#pixelOffset) pixelOffset : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 202](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L202) 

 Gets or sets the [Cartesian2](Cartesian2.html) Property specifying the label's pixel offset in screen space from the origin of this label. This is commonly used to align multiple labels and labels at the same position, e.g., an image and text. The screen space origin is the top, left corner of the canvas; `x` increases from left to right, and `y` increases from top to bottom.

| default![](Images/Label.setPixelOffset.default.png) | l.pixeloffset = new Cartesian2(25, 75);![](Images/Label.setPixelOffset.x50y-25.png) |
| --------------------------------------------------- | ----------------------------------------------------------------------------------- |

The label's origin is indicated by the yellow point.

Default Value: `Cartesian2.ZERO` 

#### [](#pixelOffsetScaleByDistance) pixelOffsetScaleByDistance : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 292](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L292) 

 Gets or sets [NearFarScalar](NearFarScalar.html) Property specifying the pixel offset of the label based on the distance from the camera. A label's pixel offset will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the label's pixel offset remains clamped to the nearest bound.

#### [](#scale) scale : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 157](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L157) 

 Gets or sets the numeric Property specifying the uniform scale to apply to the image. A scale greater than `1.0` enlarges the label while a scale less than `1.0` shrinks it.

![](Images/Label.setScale.png)  
From left to right in the above image, the scales are `0.5`, `1.0`, and `2.0`.

Default Value: `1.0` 

#### [](#scaleByDistance) scaleByDistance : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 306](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L306) 

 Gets or sets near and far scaling properties of a Label based on the label's distance from the camera. A label's scale will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the label's scale remains clamped to the nearest bound. If undefined, scaleByDistance will be disabled.

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 118](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L118) 

 Gets or sets the boolean Property specifying the visibility of the label.

#### [](#showBackground) showBackground : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 165](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L165) 

 Gets or sets the boolean Property specifying the visibility of the background behind the label.

Default Value: `false` 

#### [](#style) style : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 141](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L141) 

 Gets or sets the Property specifying the [LabelStyle](global.html#LabelStyle).

#### [](#text) text : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 126](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L126) 

 Gets or sets the string Property specifying the text of the label. Explicit newlines '\\n' are supported.

#### [](#translucencyByDistance) translucencyByDistance : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 281](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L281) 

 Gets or sets [NearFarScalar](NearFarScalar.html) Property specifying the translucency of the label based on the distance from the camera. A label's translucency will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the label's translucency remains clamped to the nearest bound.

#### [](#verticalOrigin) verticalOrigin : [Property](Property.html)|undefined 

[engine/Source/DataSources/LabelGraphics.js 241](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L241) 

 Gets or sets the Property specifying the [VerticalOrigin](global.html#VerticalOrigin).

### Methods

#### [](#clone) clone(result) → [LabelGraphics](LabelGraphics.html) 

[engine/Source/DataSources/LabelGraphics.js 334](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L334) 

 Duplicates this instance.

| Name   | Type                                | Description                                         |
| ------ | ----------------------------------- | --------------------------------------------------- |
| result | [LabelGraphics](LabelGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/LabelGraphics.js 368](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L368) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                | Description                               |
| ------ | ----------------------------------- | ----------------------------------------- |
| source | [LabelGraphics](LabelGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.LabelGraphics.ConstructorOptions

[engine/Source/DataSources/LabelGraphics.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/LabelGraphics.js#L7) 

 Initialization options for the LabelGraphics constructor

##### Properties:

| Name                       | Type                                                                                 | Attributes | Default                             | Description                                                                                                   |
| -------------------------- | ------------------------------------------------------------------------------------ | ---------- | ----------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| show                       | [Property](Property.html)\|boolean                                                   | <optional> | true                                | A boolean Property specifying the visibility of the label.                                                    |
| text                       | [Property](Property.html)\|string                                                    | <optional> |                                     | A Property specifying the text. Explicit newlines '\\n' are supported.                                        |
| font                       | [Property](Property.html)\|string                                                    | <optional> | '30px sans-serif'                   | A Property specifying the CSS font.                                                                           |
| style                      | [Property](Property.html)\|[LabelStyle](global.html#LabelStyle)                      | <optional> | LabelStyle.FILL                     | A Property specifying the [LabelStyle](global.html#LabelStyle).                                               |
| scale                      | [Property](Property.html)\|number                                                    | <optional> | 1.0                                 | A numeric Property specifying the scale to apply to the text.                                                 |
| showBackground             | [Property](Property.html)\|boolean                                                   | <optional> | false                               | A boolean Property specifying the visibility of the background behind the label.                              |
| backgroundColor            | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | new Color(0.165, 0.165, 0.165, 0.8) | A Property specifying the background [Color](Color.html).                                                     |
| backgroundPadding          | [Property](Property.html)\|[Cartesian2](Cartesian2.html)                             | <optional> | new Cartesian2(7, 5)                | A [Cartesian2](Cartesian2.html) Property specifying the horizontal and vertical background padding in pixels. |
| pixelOffset                | [Property](Property.html)\|[Cartesian2](Cartesian2.html)                             | <optional> | Cartesian2.ZERO                     | A [Cartesian2](Cartesian2.html) Property specifying the pixel offset.                                         |
| eyeOffset                  | [Property](Property.html)\|[Cartesian3](Cartesian3.html)                             | <optional> | Cartesian3.ZERO                     | A [Cartesian3](Cartesian3.html) Property specifying the eye offset.                                           |
| horizontalOrigin           | [Property](Property.html)\|[HorizontalOrigin](global.html#HorizontalOrigin)          | <optional> | HorizontalOrigin.CENTER             | A Property specifying the [HorizontalOrigin](global.html#HorizontalOrigin).                                   |
| verticalOrigin             | [Property](Property.html)\|[VerticalOrigin](global.html#VerticalOrigin)              | <optional> | VerticalOrigin.CENTER               | A Property specifying the [VerticalOrigin](global.html#VerticalOrigin).                                       |
| heightReference            | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE                | A Property specifying what the height is relative to.                                                         |
| fillColor                  | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.WHITE                         | A Property specifying the fill [Color](Color.html).                                                           |
| outlineColor               | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.BLACK                         | A Property specifying the outline [Color](Color.html).                                                        |
| outlineWidth               | [Property](Property.html)\|number                                                    | <optional> | 1.0                                 | A numeric Property specifying the outline width.                                                              |
| translucencyByDistance     | [Property](Property.html)\|[NearFarScalar](NearFarScalar.html)                       | <optional> |                                     | A [NearFarScalar](NearFarScalar.html) Property used to set translucency based on distance from the camera.    |
| pixelOffsetScaleByDistance | [Property](Property.html)\|[NearFarScalar](NearFarScalar.html)                       | <optional> |                                     | A [NearFarScalar](NearFarScalar.html) Property used to set pixelOffset based on distance from the camera.     |
| scaleByDistance            | [Property](Property.html)\|[NearFarScalar](NearFarScalar.html)                       | <optional> |                                     | A [NearFarScalar](NearFarScalar.html) Property used to set scale based on distance from the camera.           |
| distanceDisplayCondition   | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                                     | A Property specifying at what distance from the camera that this label will be displayed.                     |
| disableDepthTestDistance   | [Property](Property.html)\|number                                                    | <optional> |                                     | A Property specifying the distance from the camera at which to disable the depth test to.                     |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

