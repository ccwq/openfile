# [![](Images/CesiumLogo.png)](index.html) ClippingPolygonCollection 

#### [](#ClippingPolygonCollection) new Cesium.ClippingPolygonCollection(options) 

[engine/Source/Scene/ClippingPolygonCollection.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L60) 

 Specifies a set of clipping polygons. Clipping polygons selectively disable rendering in a region inside or outside the specified list of [ClippingPolygon](ClippingPolygon.html) objects for a single glTF model, 3D Tileset, or the globe. Clipping Polygons are only supported in WebGL 2 contexts.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | optional Object with the following properties: Name Type Default Description polygons Array.<[ClippingPolygon](ClippingPolygon.html)\> \[\] optional An array of [ClippingPolygon](ClippingPolygon.html) objects used to selectively disable rendering on the inside of each polygon. enabled boolean true optional Determines whether the clipping polygons are active. inverse boolean false optional If true, a region will be clipped if it is outside of every polygon in the collection. Otherwise, a region will only be clipped if it is on the inside of any polygon. |

##### Example:

```javascript
const positions = Cesium.Cartesian3.fromRadiansArray([
    -1.3194369277314022,
    0.6988062530900625,
    -1.31941,
    0.69879,
    -1.3193955980204217,
    0.6988091578771254,
    -1.3193931220959367,
    0.698743632490865,
    -1.3194358224045408,
    0.6987471965556998,
]);

const polygon = new Cesium.ClippingPolygon({
    positions: positions
});

const polygons = new Cesium.ClippingPolygonCollection({
   polygons: [ polygon ]
});
```

### Members

#### [](#length) readonly length : number 

[engine/Source/Scene/ClippingPolygonCollection.js 136](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L136) 

 Returns the number of polygons in this collection. This is commonly used with[ClippingPolygonCollection#get](ClippingPolygonCollection.html#get) to iterate over all the polygons in the collection.

#### [](#polygonAdded) polygonAdded : [Event](Event.html) 

[engine/Source/Scene/ClippingPolygonCollection.js 92](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L92) 

 An event triggered when a new clipping polygon is added to the collection. Event handlers are passed the new polygon and the index at which it was added.

Default Value: `Event()` 

#### [](#polygonRemoved) polygonRemoved : [Event](Event.html) 

[engine/Source/Scene/ClippingPolygonCollection.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L100) 

 An event triggered when a new clipping polygon is removed from the collection. Event handlers are passed the new polygon and the index from which it was removed.

Default Value: `Event()` 

### Methods

#### [](#.isSupported) static Cesium.ClippingPolygonCollection.isSupported(scene) → boolean 

[engine/Source/Scene/ClippingPolygonCollection.js 833](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L833) 

 Function for checking if the context will allow clipping polygons, which require floating point textures.

| Name  | Type                        | Description                                                        |
| ----- | --------------------------- | ------------------------------------------------------------------ |
| scene | [Scene](Scene.html)\|object | The scene that will contain clipped objects and clipping textures. |

##### Returns:

`true` if the context supports clipping polygons.

#### [](#add) add(polygon) → [ClippingPolygon](ClippingPolygon.html) 

[engine/Source/Scene/ClippingPolygonCollection.js 292](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L292) 

 Adds the specified [ClippingPolygon](ClippingPolygon.html) to the collection to be used to selectively disable rendering on the inside of each polygon. Use `ClippingPolygonCollection#unionClippingRegions` to modify how modify the clipping behavior of multiple polygons.

| Name    | Type                                    | Description                                   |
| ------- | --------------------------------------- | --------------------------------------------- |
| polygon | [ClippingPolygon](ClippingPolygon.html) | The ClippingPolygon to add to the collection. |

##### Returns:

 The added ClippingPolygon.

##### Example:

```javascript
const polygons = new Cesium.ClippingPolygonCollection();

const positions = Cesium.Cartesian3.fromRadiansArray([
    -1.3194369277314022,
    0.6988062530900625,
    -1.31941,
    0.69879,
    -1.3193955980204217,
    0.6988091578771254,
    -1.3193931220959367,
    0.698743632490865,
    -1.3194358224045408,
    0.6987471965556998,
]);

polygons.add(new Cesium.ClippingPolygon({
    positions: positions
}));
```

##### See:

* [ClippingPolygonCollection#remove](ClippingPolygonCollection.html#remove)
* [ClippingPolygonCollection#removeAll](ClippingPolygonCollection.html#removeAll)

#### [](#contains) contains(polygon) → boolean 

[engine/Source/Scene/ClippingPolygonCollection.js 331](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L331) 

 Checks whether this collection contains a ClippingPolygon equal to the given ClippingPolygon.

| Name    | Type                                    | Description                       |
| ------- | --------------------------------------- | --------------------------------- |
| polygon | [ClippingPolygon](ClippingPolygon.html) | The ClippingPolygon to check for. |

##### Returns:

 true if this collection contains the ClippingPolygon, false otherwise.

##### See:

* [ClippingPolygonCollection#get](ClippingPolygonCollection.html#get)

#### [](#destroy) destroy() 

[engine/Source/Scene/ClippingPolygonCollection.js 954](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L954) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
clippingPolygons = clippingPolygons && clippingPolygons.destroy();
```

##### See:

* [ClippingPolygonCollection#isDestroyed](ClippingPolygonCollection.html#isDestroyed)

#### [](#get) get(index) → [ClippingPolygon](ClippingPolygon.html) 

[engine/Source/Scene/ClippingPolygonCollection.js 315](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L315) 

 Returns the clipping polygon in the collection at the specified index. Indices are zero-based and increase as polygons are added. Removing a polygon polygon all polygons after it to the left, changing their indices. This function is commonly used with[ClippingPolygonCollection#length](ClippingPolygonCollection.html#length) to iterate over all the polygons in the collection.

| Name  | Type   | Description                          |
| ----- | ------ | ------------------------------------ |
| index | number | The zero-based index of the polygon. |

##### Returns:

 The ClippingPolygon at the specified index.

##### See:

* [ClippingPolygonCollection#length](ClippingPolygonCollection.html#length)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/ClippingPolygonCollection.js 934](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L934) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [ClippingPolygonCollection#destroy](ClippingPolygonCollection.html#destroy)

#### [](#remove) remove(polygon) → boolean 

[engine/Source/Scene/ClippingPolygonCollection.js 349](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L349) 

 Removes the first occurrence of the given ClippingPolygon from the collection.

| Name    | Type                                    | Description |
| ------- | --------------------------------------- | ----------- |
| polygon | [ClippingPolygon](ClippingPolygon.html) |             |

##### Returns:

`true` if the polygon was removed; `false` if the polygon was not found in the collection.

##### See:

* [ClippingPolygonCollection#add](ClippingPolygonCollection.html#add)
* [ClippingPolygonCollection#contains](ClippingPolygonCollection.html#contains)
* [ClippingPolygonCollection#removeAll](ClippingPolygonCollection.html#removeAll)

#### [](#removeAll) removeAll() 

[engine/Source/Scene/ClippingPolygonCollection.js 460](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClippingPolygonCollection.js#L460) 

 Removes all polygons from the collection.

##### See:

* [ClippingPolygonCollection#add](ClippingPolygonCollection.html#add)
* [ClippingPolygonCollection#remove](ClippingPolygonCollection.html#remove)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

