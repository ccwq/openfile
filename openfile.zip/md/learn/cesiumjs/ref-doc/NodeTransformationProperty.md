# [![](Images/CesiumLogo.png)](index.html) NodeTransformationProperty 

#### [](#NodeTransformationProperty) new Cesium.NodeTransformationProperty(options) 

[engine/Source/DataSources/NodeTransformationProperty.js 21](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/NodeTransformationProperty.js#L21) 

 A [Property](Property.html) that produces [TranslationRotationScale](TranslationRotationScale.html) data.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description translation [Property](Property.html)\|[Cartesian3](Cartesian3.html) Cartesian3.ZERO optional A [Cartesian3](Cartesian3.html) Property specifying the (x, y, z) translation to apply to the node. rotation [Property](Property.html)|[Quaternion](Quaternion.html) Quaternion.IDENTITY optional A [Quaternion](Quaternion.html) Property specifying the (x, y, z, w) rotation to apply to the node. scale [Property](Property.html)|[Cartesian3](Cartesian3.html) new Cartesian3(1.0, 1.0, 1.0) optional A [Cartesian3](Cartesian3.html) Property specifying the (x, y, z) scaling to apply to the node. |

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/NodeTransformationProperty.js 65](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/NodeTransformationProperty.js#L65) 

 Gets the event that is raised whenever the definition of this property changes. The definition is considered to have changed if a call to getValue would return a different result for the same time.

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/NodeTransformationProperty.js 46](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/NodeTransformationProperty.js#L46) 

 Gets a value indicating if this property is constant. A property is considered constant if getValue always returns the same result for the current definition.

#### [](#rotation) rotation : [Property](Property.html)|undefined 

[engine/Source/DataSources/NodeTransformationProperty.js 85](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/NodeTransformationProperty.js#L85) 

 Gets or sets the [Quaternion](Quaternion.html) Property specifying the (x, y, z, w) rotation to apply to the node.

Default Value: `Quaternion.IDENTITY` 

#### [](#scale) scale : [Property](Property.html)|undefined 

[engine/Source/DataSources/NodeTransformationProperty.js 93](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/NodeTransformationProperty.js#L93) 

 Gets or sets the [Cartesian3](Cartesian3.html) Property specifying the (x, y, z) scaling to apply to the node.

Default Value: `new Cartesian3(1.0, 1.0, 1.0)` 

#### [](#translation) translation : [Property](Property.html)|undefined 

[engine/Source/DataSources/NodeTransformationProperty.js 77](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/NodeTransformationProperty.js#L77) 

 Gets or sets the [Cartesian3](Cartesian3.html) Property specifying the (x, y, z) translation to apply to the node.

Default Value: `Cartesian3.ZERO` 

### Methods

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/NodeTransformationProperty.js 141](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/NodeTransformationProperty.js#L141) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getValue) getValue(time, result) → [TranslationRotationScale](TranslationRotationScale.html) 

[engine/Source/DataSources/NodeTransformationProperty.js 105](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/NodeTransformationProperty.js#L105) 

 Gets the value of the property at the provided time.

| Name   | Type                                                      | Default          | Description                                                                                      |
| ------ | --------------------------------------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html)                             | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | [TranslationRotationScale](TranslationRotationScale.html) |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

