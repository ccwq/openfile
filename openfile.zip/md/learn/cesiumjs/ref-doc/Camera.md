# [![](Images/CesiumLogo.png)](index.html) Camera 

#### [](#Camera) new Cesium.Camera(scene) 

[engine/Source/Scene/Camera.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L81) 

 The camera is defined by a position, orientation, and view frustum.  
  
The orientation forms an orthonormal basis with a view, up and right = view x up unit vectors.  
  
The viewing frustum is defined by 6 planes. Each plane is represented by a [Cartesian4](Cartesian4.html) object, where the x, y, and z components define the unit vector normal to the plane, and the w component is the distance of the plane from the origin/camera position.

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| scene | [Scene](Scene.html) | The scene.  |

##### Example:

```javascript
// Create a camera looking down the negative z-axis, positioned at the origin,
// with a field of view of 60 degrees, and 1:1 aspect ratio.
const camera = new Cesium.Camera(scene);
camera.position = new Cesium.Cartesian3();
camera.direction = Cesium.Cartesian3.negate(Cesium.Cartesian3.UNIT_Z, new Cesium.Cartesian3());
camera.up = Cesium.Cartesian3.clone(Cesium.Cartesian3.UNIT_Y);
camera.frustum.fov = Cesium.Math.PI_OVER_THREE;
camera.frustum.near = 1.0;
camera.frustum.far = 2.0;
```

##### Demo:

* [Cesium Sandcastle Camera Demo](https://sandcastle.cesium.com/index.html?src=Camera.html)
* [Cesium Sandcastle Camera Tutorial Example](https://sandcastle.cesium.com/index.html?src=Camera%2520Tutorial.html)
* [Camera Tutorial](https://cesium.com/learn/cesiumjs-learn/cesiumjs-camera)

### Members

#### [](#.DEFAULT%5FOFFSET) static Cesium.Camera.DEFAULT\_OFFSET : [HeadingPitchRange](HeadingPitchRange.html) 

[engine/Source/Scene/Camera.js 309](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L309) 

 The default heading/pitch/range that is used when the camera flies to a location that contains a bounding sphere.

#### [](#.DEFAULT%5FVIEW%5FFACTOR) static Cesium.Camera.DEFAULT\_VIEW\_FACTOR : number 

[engine/Source/Scene/Camera.js 303](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L303) 

 A scalar to multiply to the camera position and add it back after setting the camera to view the rectangle. A value of zero means the camera will view the entire `Camera#DEFAULT_VIEW_RECTANGLE`, a value greater than zero will move it further away from the extent, and a value less than zero will move it close to the extent.

#### [](#.DEFAULT%5FVIEW%5FRECTANGLE) static Cesium.Camera.DEFAULT\_VIEW\_RECTANGLE : [Rectangle](Rectangle.html) 

[engine/Source/Scene/Camera.js 290](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L290) 

 The default rectangle the camera will view on creation.

#### [](#changed) readonly changed : [Event](Event.html) 

[engine/Source/Scene/Camera.js 1109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1109) 

 Gets the event that will be raised when the camera has changed by `percentageChanged`.

#### [](#constrainedAxis) constrainedAxis : [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/Scene/Camera.js 203](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L203) 

 If set, the camera will not be able to rotate past this axis in either direction.

Default Value: `undefined` 

#### [](#defaultLookAmount) defaultLookAmount : number 

[engine/Source/Scene/Camera.js 183](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L183) 

 The default amount to rotate the camera when an argument is not provided to the look methods.

Default Value: `Math.PI / 60.0` 

#### [](#defaultMoveAmount) defaultMoveAmount : number 

[engine/Source/Scene/Camera.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L176) 

 The default amount to move the camera when an argument is not provided to the move methods.

Default Value: `100000.0;` 

#### [](#defaultRotateAmount) defaultRotateAmount : number 

[engine/Source/Scene/Camera.js 190](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L190) 

 The default amount to rotate the camera when an argument is not provided to the rotate methods.

Default Value: `Math.PI / 3600.0` 

#### [](#defaultZoomAmount) defaultZoomAmount : number 

[engine/Source/Scene/Camera.js 197](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L197) 

 The default amount to move the camera when an argument is not provided to the zoom methods.

Default Value: `100000.0;` 

#### [](#direction) direction : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 133](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L133) 

 The view direction of the camera.

#### [](#directionWC) readonly directionWC : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 951](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L951) 

 Gets the view direction of the camera in world coordinates.

#### [](#frustum) frustum : [PerspectiveFrustum](PerspectiveFrustum.html)|[PerspectiveOffCenterFrustum](PerspectiveOffCenterFrustum.html)|[OrthographicFrustum](OrthographicFrustum.html) 

[engine/Source/Scene/Camera.js 165](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L165) 

 The region of space in view.

Default Value: `PerspectiveFrustum()` 

##### See:

* [PerspectiveFrustum](PerspectiveFrustum.html)
* [PerspectiveOffCenterFrustum](PerspectiveOffCenterFrustum.html)
* [OrthographicFrustum](OrthographicFrustum.html)

#### [](#heading) readonly heading : number 

[engine/Source/Scene/Camera.js 993](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L993) 

 Gets the camera heading in radians.

#### [](#inverseTransform) readonly inverseTransform : [Matrix4](Matrix4.html) 

[engine/Source/Scene/Camera.js 874](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L874) 

 Gets the inverse camera transform.

Default Value: `[Matrix4.IDENTITY](Matrix4.html#.IDENTITY)` 

#### [](#inverseViewMatrix) readonly inverseViewMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/Camera.js 906](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L906) 

 Gets the inverse view matrix.

##### See:

* [Camera#viewMatrix](Camera.html#viewMatrix)

#### [](#maximumZoomFactor) maximumZoomFactor : number 

[engine/Source/Scene/Camera.js 210](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L210) 

 The factor multiplied by the the map size used to determine where to clamp the camera position when zooming out from the surface. The default is 1.5\. Only valid for 2D and the map is rotatable.

Default Value: `1.5` 

#### [](#moveEnd) readonly moveEnd : [Event](Event.html) 

[engine/Source/Scene/Camera.js 1097](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1097) 

 Gets the event that will be raised when the camera has stopped moving.

#### [](#moveStart) readonly moveStart : [Event](Event.html) 

[engine/Source/Scene/Camera.js 1085](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1085) 

 Gets the event that will be raised at when the camera starts to move.

#### [](#percentageChanged) percentageChanged : number 

[engine/Source/Scene/Camera.js 227](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L227) 

 The amount the camera has to change before the `changed` event is raised. The value is a percentage in the \[0, 1\] range.

Default Value: `0.5` 

#### [](#pitch) readonly pitch : number 

[engine/Source/Scene/Camera.js 1024](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1024) 

 Gets the camera pitch in radians.

#### [](#position) position : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L100) 

 The position of the camera.

#### [](#positionCartographic) readonly positionCartographic : [Cartographic](Cartographic.html) 

[engine/Source/Scene/Camera.js 923](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L923) 

 Gets the [Cartographic](Cartographic.html) position of the camera, with longitude and latitude expressed in radians and height in meters. In 2D and Columbus View, it is possible for the returned longitude and latitude to be outside the range of valid longitudes and latitudes when the camera is outside the map.

#### [](#positionWC) readonly positionWC : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 937](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L937) 

 Gets the position of the camera in world coordinates.

#### [](#right) right : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 151](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L151) 

 The right direction of the camera.

#### [](#rightWC) readonly rightWC : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 979](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L979) 

 Gets the right direction of the camera in world coordinates.

#### [](#roll) readonly roll : number 

[engine/Source/Scene/Camera.js 1055](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1055) 

 Gets the camera roll in radians.

#### [](#transform) readonly transform : [Matrix4](Matrix4.html) 

[engine/Source/Scene/Camera.js 859](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L859) 

 Gets the camera's reference frame. The inverse of this transformation is appended to the view matrix.

Default Value: `[Matrix4.IDENTITY](Matrix4.html#.IDENTITY)` 

#### [](#up) up : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 142](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L142) 

 The up direction of the camera.

#### [](#upWC) readonly upWC : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 965](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L965) 

 Gets the up direction of the camera in world coordinates.

#### [](#viewMatrix) readonly viewMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/Camera.js 890](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L890) 

 Gets the view matrix.

##### See:

* [Camera#inverseViewMatrix](Camera.html#inverseViewMatrix)

### Methods

#### [](#cameraToWorldCoordinates) cameraToWorldCoordinates(cartesian, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Scene/Camera.js 1676](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1676) 

 Transform a vector or point from the camera's reference frame to world coordinates.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The vector or point to transform.                   |
| result    | [Cartesian4](Cartesian4.html) | optional The object onto which to store the result. |

##### Returns:

 The transformed vector or point.

#### [](#cameraToWorldCoordinatesPoint) cameraToWorldCoordinatesPoint(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 1697](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1697) 

 Transform a point from the camera's reference frame to world coordinates.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The point to transform.                             |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The transformed point.

#### [](#cameraToWorldCoordinatesVector) cameraToWorldCoordinatesVector(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 1718](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1718) 

 Transform a vector from the camera's reference frame to world coordinates.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The vector to transform.                            |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The transformed vector.

#### [](#cancelFlight) cancelFlight() 

[engine/Source/Scene/Camera.js 3275](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3275) 

 Cancels the current camera flight and leaves the camera at its current location. If no flight is in progress, this function does nothing.

#### [](#completeFlight) completeFlight() 

[engine/Source/Scene/Camera.js 3286](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3286) 

 Completes the current camera flight and moves the camera immediately to its final destination. If no flight is in progress, this function does nothing.

#### [](#computeViewRectangle) computeViewRectangle(ellipsoid, result) → [Rectangle](Rectangle.html)|undefined 

[engine/Source/Scene/Camera.js 3825](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3825) 

 Computes the approximate visible rectangle on the ellipsoid.

| Name      | Type                        | Default           | Description                                                      |
| --------- | --------------------------- | ----------------- | ---------------------------------------------------------------- |
| ellipsoid | [Ellipsoid](Ellipsoid.html) | Ellipsoid.default | optional The ellipsoid that you want to know the visible region. |
| result    | [Rectangle](Rectangle.html) |                   | optional The rectangle in which to store the result              |

##### Returns:

 The visible rectangle or undefined if the ellipsoid isn't visible at all.

#### [](#distanceToBoundingSphere) distanceToBoundingSphere(boundingSphere) → number 

[engine/Source/Scene/Camera.js 3072](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3072) 

 Return the distance from the camera to the front of the bounding sphere.

| Name           | Type                                  | Description                               |
| -------------- | ------------------------------------- | ----------------------------------------- |
| boundingSphere | [BoundingSphere](BoundingSphere.html) | The bounding sphere in world coordinates. |

##### Returns:

 The distance to the bounding sphere.

#### [](#flyHome) flyHome(duration) 

[engine/Source/Scene/Camera.js 1552](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1552) 

 Fly the camera to the home view. Use `Camera#.DEFAULT_VIEW_RECTANGLE` to set the default view for the 3D scene. The home view for 2D and columbus view shows the entire map.

| Name     | Type   | Description                                                                                                                                                                                          |
| -------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| duration | number | optional The duration of the flight in seconds. If omitted, Cesium attempts to calculate an ideal duration based on the distance to be traveled by the flight. See [Camera#flyTo](Camera.html#flyTo) |

#### [](#flyTo) flyTo(options) 

[engine/Source/Scene/Camera.js 3365](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3365) 

 Flies the camera from its current position to a new position.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description destination [Cartesian3](Cartesian3.html)\|[Rectangle](Rectangle.html)  The final position of the camera in world coordinates or a rectangle that would be visible from a top-down view. orientation object optional An object that contains either direction and up properties or heading, pitch and roll properties. By default, the direction will point towards the center of the frame in 3D and in the negative z direction in Columbus view. The up direction will point towards local north in 3D and in the positive y direction in Columbus view. Orientation is not used in 2D when in infinite scrolling mode. duration number optional The duration of the flight in seconds. If omitted, Cesium attempts to calculate an ideal duration based on the distance to be traveled by the flight. complete [Camera.FlightCompleteCallback](Camera.html#.FlightCompleteCallback) optional The function to execute when the flight is complete. cancel [Camera.FlightCancelledCallback](Camera.html#.FlightCancelledCallback) optional The function to execute if the flight is cancelled. endTransform [Matrix4](Matrix4.html) optional Transform matrix representing the reference frame the camera will be in when the flight is completed. maximumHeight number optional The maximum height at the peak of the flight. pitchAdjustHeight number optional If camera flyes higher than that value, adjust pitch duiring the flight to look down, and keep Earth in viewport. flyOverLongitude number optional There are always two ways between 2 points on globe. This option force camera to choose fight direction to fly over that longitude. flyOverLongitudeWeight number optional Fly over the lon specifyed via flyOverLongitude only if that way is not longer than short way times flyOverLongitudeWeight. convert boolean optional Whether to convert the destination from world coordinates to scene coordinates (only relevant when not using 3D). Defaults to true. easingFunction [EasingFunction.Callback](EasingFunction.html#.Callback) optional Controls how the time is interpolated over the duration of the flight. |

##### Throws:

* [DeveloperError](DeveloperError.html): If either direction or up is given, then both are required.

##### Example:

```javascript
// 1. Fly to a position with a top-down view
viewer.camera.flyTo({
    destination : Cesium.Cartesian3.fromDegrees(-117.16, 32.71, 15000.0)
});

// 2. Fly to a Rectangle with a top-down view
viewer.camera.flyTo({
    destination : Cesium.Rectangle.fromDegrees(west, south, east, north)
});

// 3. Fly to a position with an orientation using unit vectors.
viewer.camera.flyTo({
    destination : Cesium.Cartesian3.fromDegrees(-122.19, 46.25, 5000.0),
    orientation : {
        direction : new Cesium.Cartesian3(-0.04231243104240401, -0.20123236049443421, -0.97862924300734),
        up : new Cesium.Cartesian3(-0.47934589305293746, -0.8553216253114552, 0.1966022179118339)
    }
});

// 4. Fly to a position with an orientation using heading, pitch and roll.
viewer.camera.flyTo({
    destination : Cesium.Cartesian3.fromDegrees(-122.19, 46.25, 5000.0),
    orientation : {
        heading : Cesium.Math.toRadians(175.0),
        pitch : Cesium.Math.toRadians(-35.0),
        roll : 0.0
    }
});
```

#### [](#flyToBoundingSphere) flyToBoundingSphere(boundingSphere, options) 

[engine/Source/Scene/Camera.js 3603](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3603) 

 Flies the camera to a location where the current view contains the provided bounding sphere.

 The offset is heading/pitch/range in the local east-north-up reference frame centered at the center of the bounding sphere. The heading and the pitch angles are defined in the local east-north-up reference frame. The heading is the angle from y axis and increasing towards the x axis. Pitch is the rotation from the xy-plane. Positive pitch angles are below the plane. Negative pitch angles are above the plane. The range is the distance from the center. If the range is zero, a range will be computed such that the whole bounding sphere is visible.

In 2D and Columbus View, there must be a top down view. The camera will be placed above the target looking down. The height above the target will be the range. The heading will be aligned to local north.

| Name           | Type                                  | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| -------------- | ------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| boundingSphere | [BoundingSphere](BoundingSphere.html) | The bounding sphere to view, in world coordinates.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| options        | object                                | optional Object with the following properties: Name Type Description duration number optional The duration of the flight in seconds. If omitted, Cesium attempts to calculate an ideal duration based on the distance to be traveled by the flight. offset [HeadingPitchRange](HeadingPitchRange.html) optional The offset from the target in the local east-north-up reference frame centered at the target. complete [Camera.FlightCompleteCallback](Camera.html#.FlightCompleteCallback) optional The function to execute when the flight is complete. cancel [Camera.FlightCancelledCallback](Camera.html#.FlightCancelledCallback) optional The function to execute if the flight is cancelled. endTransform [Matrix4](Matrix4.html) optional Transform matrix representing the reference frame the camera will be in when the flight is completed. maximumHeight number optional The maximum height at the peak of the flight. pitchAdjustHeight number optional If camera flyes higher than that value, adjust pitch duiring the flight to look down, and keep Earth in viewport. flyOverLongitude number optional There are always two ways between 2 points on globe. This option force camera to choose fight direction to fly over that longitude. flyOverLongitudeWeight number optional Fly over the lon specifyed via flyOverLongitude only if that way is not longer than short way times flyOverLongitudeWeight. easingFunction [EasingFunction.Callback](EasingFunction.html#.Callback) optional Controls how the time is interpolated over the duration of the flight. |

#### [](#getMagnitude) getMagnitude() → number 

[engine/Source/Scene/Camera.js 2290](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2290) 

 Gets the magnitude of the camera position. In 3D, this is the vector magnitude. In 2D and Columbus view, this is the distance to the map.

##### Returns:

 The magnitude of the position.

#### [](#getPickRay) getPickRay(windowPosition, result) → [Ray](Ray.html)|undefined 

[engine/Source/Scene/Camera.js 3035](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3035) 

 Create a ray from the camera position through the pixel at `windowPosition`in world coordinates.

| Name           | Type                          | Description                                         |
| -------------- | ----------------------------- | --------------------------------------------------- |
| windowPosition | [Cartesian2](Cartesian2.html) | The x and y coordinates of a pixel.                 |
| result         | [Ray](Ray.html)               | optional The object onto which to store the result. |

##### Returns:

 Returns the [Cartesian3](Cartesian3.html) position and direction of the ray, or undefined if the pick ray cannot be determined.

#### [](#getPixelSize) getPixelSize(boundingSphere, drawingBufferWidth, drawingBufferHeight) → number 

[engine/Source/Scene/Camera.js 3102](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3102) 

 Return the pixel size in meters.

| Name                | Type                                  | Description                               |
| ------------------- | ------------------------------------- | ----------------------------------------- |
| boundingSphere      | [BoundingSphere](BoundingSphere.html) | The bounding sphere in world coordinates. |
| drawingBufferWidth  | number                                | The drawing buffer width.                 |
| drawingBufferHeight | number                                | The drawing buffer height.                |

##### Returns:

 The pixel size in meters.

#### [](#getRectangleCameraCoordinates) getRectangleCameraCoordinates(rectangle, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 2818](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2818) 

 Get the camera position needed to view a rectangle on an ellipsoid or map

| Name      | Type                          | Description                                               |
| --------- | ----------------------------- | --------------------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html)   | The rectangle to view.                                    |
| result    | [Cartesian3](Cartesian3.html) | optional The camera position needed to view the rectangle |

##### Returns:

 The camera position needed to view the rectangle

#### [](#look) look(axis, angle) 

[engine/Source/Scene/Camera.js 1969](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1969) 

 Rotate each of the camera's orientation vectors around `axis` by `angle` 

| Name  | Type                          | Description                                                                  |
| ----- | ----------------------------- | ---------------------------------------------------------------------------- |
| axis  | [Cartesian3](Cartesian3.html) | The axis to rotate around.                                                   |
| angle | number                        | optional The angle, in radians, to rotate by. Defaults to defaultLookAmount. |

##### See:

* [Camera#lookUp](Camera.html#lookUp)
* [Camera#lookDown](Camera.html#lookDown)
* [Camera#lookLeft](Camera.html#lookLeft)
* [Camera#lookRight](Camera.html#lookRight)

#### [](#lookAt) lookAt(target, offset) 

[engine/Source/Scene/Camera.js 2334](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2334) 

 Sets the camera position and orientation using a target and offset. The target must be given in world coordinates. The offset can be either a cartesian or heading/pitch/range in the local east-north-up reference frame centered at the target. If the offset is a cartesian, then it is an offset from the center of the reference frame defined by the transformation matrix. If the offset is heading/pitch/range, then the heading and the pitch angles are defined in the reference frame defined by the transformation matrix. The heading is the angle from y axis and increasing towards the x axis. Pitch is the rotation from the xy-plane. Positive pitch angles are below the plane. Negative pitch angles are above the plane. The range is the distance from the center. In 2D, there must be a top down view. The camera will be placed above the target looking down. The height above the target will be the magnitude of the offset. The heading will be determined from the offset. If the heading cannot be determined from the offset, the heading will be north.

| Name   | Type                                                                       | Description                                                                                   |
| ------ | -------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| target | [Cartesian3](Cartesian3.html)                                              | The target position in world coordinates.                                                     |
| offset | [Cartesian3](Cartesian3.html)\|[HeadingPitchRange](HeadingPitchRange.html) | The offset from the target in the local east-north-up reference frame centered at the target. |

##### Throws:

* [DeveloperError](DeveloperError.html): lookAt is not supported while morphing.

##### Example:

```javascript
// 1. Using a cartesian offset
const center = Cesium.Cartesian3.fromDegrees(-98.0, 40.0);
viewer.camera.lookAt(center, new Cesium.Cartesian3(0.0, -4790000.0, 3930000.0));

// 2. Using a HeadingPitchRange offset
const center = Cesium.Cartesian3.fromDegrees(-72.0, 40.0);
const heading = Cesium.Math.toRadians(50.0);
const pitch = Cesium.Math.toRadians(-20.0);
const range = 5000.0;
viewer.camera.lookAt(center, new Cesium.HeadingPitchRange(heading, pitch, range));
```

#### [](#lookAtTransform) lookAtTransform(transform, offset) 

[engine/Source/Scene/Camera.js 2425](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2425) 

 Sets the camera position and orientation using a target and transformation matrix. The offset can be either a cartesian or heading/pitch/range. If the offset is a cartesian, then it is an offset from the center of the reference frame defined by the transformation matrix. If the offset is heading/pitch/range, then the heading and the pitch angles are defined in the reference frame defined by the transformation matrix. The heading is the angle from y axis and increasing towards the x axis. Pitch is the rotation from the xy-plane. Positive pitch angles are below the plane. Negative pitch angles are above the plane. The range is the distance from the center. In 2D, there must be a top down view. The camera will be placed above the center of the reference frame. The height above the target will be the magnitude of the offset. The heading will be determined from the offset. If the heading cannot be determined from the offset, the heading will be north.

| Name      | Type                                                                       | Description                                                                      |
| --------- | -------------------------------------------------------------------------- | -------------------------------------------------------------------------------- |
| transform | [Matrix4](Matrix4.html)                                                    | The transformation matrix defining the reference frame.                          |
| offset    | [Cartesian3](Cartesian3.html)\|[HeadingPitchRange](HeadingPitchRange.html) | optional The offset from the target in a reference frame centered at the target. |

##### Throws:

* [DeveloperError](DeveloperError.html): lookAtTransform is not supported while morphing.

##### Example:

```javascript
// 1. Using a cartesian offset
const transform = Cesium.Transforms.eastNorthUpToFixedFrame(Cesium.Cartesian3.fromDegrees(-98.0, 40.0));
viewer.camera.lookAtTransform(transform, new Cesium.Cartesian3(0.0, -4790000.0, 3930000.0));

// 2. Using a HeadingPitchRange offset
const transform = Cesium.Transforms.eastNorthUpToFixedFrame(Cesium.Cartesian3.fromDegrees(-72.0, 40.0));
const heading = Cesium.Math.toRadians(50.0);
const pitch = Cesium.Math.toRadians(-20.0);
const range = 5000.0;
viewer.camera.lookAtTransform(transform, new Cesium.HeadingPitchRange(heading, pitch, range));
```

#### [](#lookDown) lookDown(amount) 

[engine/Source/Scene/Camera.js 1947](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1947) 

 Rotates the camera around its right vector by amount, in radians, in the opposite direction of its up vector if not in 2D mode.

| Name   | Type   | Description                                                                   |
| ------ | ------ | ----------------------------------------------------------------------------- |
| amount | number | optional The amount, in radians, to rotate by. Defaults to defaultLookAmount. |

##### See:

* [Camera#lookUp](Camera.html#lookUp)

#### [](#lookLeft) lookLeft(amount) 

[engine/Source/Scene/Camera.js 1896](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1896) 

 Rotates the camera around its up vector by amount, in radians, in the opposite direction of its right vector if not in 2D mode.

| Name   | Type   | Description                                                                   |
| ------ | ------ | ----------------------------------------------------------------------------- |
| amount | number | optional The amount, in radians, to rotate by. Defaults to defaultLookAmount. |

##### See:

* [Camera#lookRight](Camera.html#lookRight)

#### [](#lookRight) lookRight(amount) 

[engine/Source/Scene/Camera.js 1913](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1913) 

 Rotates the camera around its up vector by amount, in radians, in the direction of its right vector if not in 2D mode.

| Name   | Type   | Description                                                                   |
| ------ | ------ | ----------------------------------------------------------------------------- |
| amount | number | optional The amount, in radians, to rotate by. Defaults to defaultLookAmount. |

##### See:

* [Camera#lookLeft](Camera.html#lookLeft)

#### [](#lookUp) lookUp(amount) 

[engine/Source/Scene/Camera.js 1930](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1930) 

 Rotates the camera around its right vector by amount, in radians, in the direction of its up vector if not in 2D mode.

| Name   | Type   | Description                                                                   |
| ------ | ------ | ----------------------------------------------------------------------------- |
| amount | number | optional The amount, in radians, to rotate by. Defaults to defaultLookAmount. |

##### See:

* [Camera#lookDown](Camera.html#lookDown)

#### [](#move) move(direction, amount) 

[engine/Source/Scene/Camera.js 1780](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1780) 

 Translates the camera's position by `amount` along `direction`.

| Name      | Type                          | Description                                                             |
| --------- | ----------------------------- | ----------------------------------------------------------------------- |
| direction | [Cartesian3](Cartesian3.html) | The direction to move.                                                  |
| amount    | number                        | optional The amount, in meters, to move. Defaults to defaultMoveAmount. |

##### See:

* [Camera#moveBackward](Camera.html#moveBackward)
* [Camera#moveForward](Camera.html#moveForward)
* [Camera#moveLeft](Camera.html#moveLeft)
* [Camera#moveRight](Camera.html#moveRight)
* [Camera#moveUp](Camera.html#moveUp)
* [Camera#moveDown](Camera.html#moveDown)

#### [](#moveBackward) moveBackward(amount) 

[engine/Source/Scene/Camera.js 1826](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1826) 

 Translates the camera's position by `amount` along the opposite direction of the camera's view vector. When in 2D mode, this will zoom out the camera instead of translating the camera's position.

| Name   | Type   | Description                                                             |
| ------ | ------ | ----------------------------------------------------------------------- |
| amount | number | optional The amount, in meters, to move. Defaults to defaultMoveAmount. |

##### See:

* [Camera#moveForward](Camera.html#moveForward)

#### [](#moveDown) moveDown(amount) 

[engine/Source/Scene/Camera.js 1858](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1858) 

 Translates the camera's position by `amount` along the opposite direction of the camera's up vector.

| Name   | Type   | Description                                                             |
| ------ | ------ | ----------------------------------------------------------------------- |
| amount | number | optional The amount, in meters, to move. Defaults to defaultMoveAmount. |

##### See:

* [Camera#moveUp](Camera.html#moveUp)

#### [](#moveForward) moveForward(amount) 

[engine/Source/Scene/Camera.js 1805](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1805) 

 Translates the camera's position by `amount` along the camera's view vector. When in 2D mode, this will zoom in the camera instead of translating the camera's position.

| Name   | Type   | Description                                                             |
| ------ | ------ | ----------------------------------------------------------------------- |
| amount | number | optional The amount, in meters, to move. Defaults to defaultMoveAmount. |

##### See:

* [Camera#moveBackward](Camera.html#moveBackward)

#### [](#moveLeft) moveLeft(amount) 

[engine/Source/Scene/Camera.js 1883](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1883) 

 Translates the camera's position by `amount` along the opposite direction of the camera's right vector.

| Name   | Type   | Description                                                             |
| ------ | ------ | ----------------------------------------------------------------------- |
| amount | number | optional The amount, in meters, to move. Defaults to defaultMoveAmount. |

##### See:

* [Camera#moveRight](Camera.html#moveRight)

#### [](#moveRight) moveRight(amount) 

[engine/Source/Scene/Camera.js 1870](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1870) 

 Translates the camera's position by `amount` along the camera's right vector.

| Name   | Type   | Description                                                             |
| ------ | ------ | ----------------------------------------------------------------------- |
| amount | number | optional The amount, in meters, to move. Defaults to defaultMoveAmount. |

##### See:

* [Camera#moveLeft](Camera.html#moveLeft)

#### [](#moveUp) moveUp(amount) 

[engine/Source/Scene/Camera.js 1845](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1845) 

 Translates the camera's position by `amount` along the camera's up vector.

| Name   | Type   | Description                                                             |
| ------ | ------ | ----------------------------------------------------------------------- |
| amount | number | optional The amount, in meters, to move. Defaults to defaultMoveAmount. |

##### See:

* [Camera#moveDown](Camera.html#moveDown)

#### [](#pickEllipsoid) pickEllipsoid(windowPosition, ellipsoid, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/Scene/Camera.js 2907](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2907) 

 Pick an ellipsoid or map.

| Name           | Type                          | Default           | Description                                         |
| -------------- | ----------------------------- | ----------------- | --------------------------------------------------- |
| windowPosition | [Cartesian2](Cartesian2.html) |                   | The x and y coordinates of a pixel.                 |
| ellipsoid      | [Ellipsoid](Ellipsoid.html)   | Ellipsoid.default | optional The ellipsoid to pick.                     |
| result         | [Cartesian3](Cartesian3.html) |                   | optional The object onto which to store the result. |

##### Returns:

 If the ellipsoid or map was picked, returns the point on the surface of the ellipsoid or map in world coordinates. If the ellipsoid or map was not picked, returns undefined.

##### Example:

```javascript
const canvas = viewer.scene.canvas;
const center = new Cesium.Cartesian2(canvas.clientWidth / 2.0, canvas.clientHeight / 2.0);
const ellipsoid = viewer.scene.ellipsoid;
const result = viewer.camera.pickEllipsoid(center, ellipsoid);
```

#### [](#rotate) rotate(axis, angle) 

[engine/Source/Scene/Camera.js 2031](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2031) 

 Rotates the camera around `axis` by `angle`. The distance of the camera's position to the center of the camera's reference frame remains the same.

| Name  | Type                          | Description                                                                    |
| ----- | ----------------------------- | ------------------------------------------------------------------------------ |
| axis  | [Cartesian3](Cartesian3.html) | The axis to rotate around given in world coordinates.                          |
| angle | number                        | optional The angle, in radians, to rotate by. Defaults to defaultRotateAmount. |

##### See:

* [Camera#rotateUp](Camera.html#rotateUp)
* [Camera#rotateDown](Camera.html#rotateDown)
* [Camera#rotateLeft](Camera.html#rotateLeft)
* [Camera#rotateRight](Camera.html#rotateRight)

#### [](#rotateDown) rotateDown(angle) 

[engine/Source/Scene/Camera.js 2062](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2062) 

 Rotates the camera around the center of the camera's reference frame by angle downwards.

| Name  | Type   | Description                                                                    |
| ----- | ------ | ------------------------------------------------------------------------------ |
| angle | number | optional The angle, in radians, to rotate by. Defaults to defaultRotateAmount. |

##### See:

* [Camera#rotateUp](Camera.html#rotateUp)
* [Camera#rotate](Camera.html#rotate)

#### [](#rotateLeft) rotateLeft(angle) 

[engine/Source/Scene/Camera.js 2161](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2161) 

 Rotates the camera around the center of the camera's reference frame by angle to the left.

| Name  | Type   | Description                                                                    |
| ----- | ------ | ------------------------------------------------------------------------------ |
| angle | number | optional The angle, in radians, to rotate by. Defaults to defaultRotateAmount. |

##### See:

* [Camera#rotateRight](Camera.html#rotateRight)
* [Camera#rotate](Camera.html#rotate)

#### [](#rotateRight) rotateRight(angle) 

[engine/Source/Scene/Camera.js 2148](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2148) 

 Rotates the camera around the center of the camera's reference frame by angle to the right.

| Name  | Type   | Description                                                                    |
| ----- | ------ | ------------------------------------------------------------------------------ |
| angle | number | optional The angle, in radians, to rotate by. Defaults to defaultRotateAmount. |

##### See:

* [Camera#rotateLeft](Camera.html#rotateLeft)
* [Camera#rotate](Camera.html#rotate)

#### [](#rotateUp) rotateUp(angle) 

[engine/Source/Scene/Camera.js 2075](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2075) 

 Rotates the camera around the center of the camera's reference frame by angle upwards.

| Name  | Type   | Description                                                                    |
| ----- | ------ | ------------------------------------------------------------------------------ |
| angle | number | optional The angle, in radians, to rotate by. Defaults to defaultRotateAmount. |

##### See:

* [Camera#rotateDown](Camera.html#rotateDown)
* [Camera#rotate](Camera.html#rotate)

#### [](#setView) setView(options) 

[engine/Source/Scene/Camera.js 1487](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1487) 

 Sets the camera position, orientation and transform.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description destination [Cartesian3](Cartesian3.html)\|[Rectangle](Rectangle.html) optional The final position of the camera in world coordinates or a rectangle that would be visible from a top-down view. orientation [HeadingPitchRollValues](global.html#HeadingPitchRollValues)|[DirectionUp](global.html#DirectionUp) optional An object that contains either direction and up properties or heading, pitch and roll properties. By default, the direction will point towards the center of the frame in 3D and in the negative z direction in Columbus view. The up direction will point towards local north in 3D and in the positive y direction in Columbus view. Orientation is not used in 2D when in infinite scrolling mode. endTransform [Matrix4](Matrix4.html) optional Transform matrix representing the reference frame of the camera. convert boolean optional Whether to convert the destination from world coordinates to scene coordinates (only relevant when not using 3D). Defaults to true. |

##### Example:

```javascript
// 1. Set position with a top-down view
viewer.camera.setView({
    destination : Cesium.Cartesian3.fromDegrees(-117.16, 32.71, 15000.0)
});

// 2 Set view with heading, pitch and roll
viewer.camera.setView({
    destination : cartesianPosition,
    orientation: {
        heading : Cesium.Math.toRadians(90.0), // east, default value is 0.0 (north)
        pitch : Cesium.Math.toRadians(-90),    // default value (looking down)
        roll : 0.0                             // default value
    }
});

// 3. Change heading, pitch and roll with the camera position remaining the same.
viewer.camera.setView({
    orientation: {
        heading : Cesium.Math.toRadians(90.0), // east, default value is 0.0 (north)
        pitch : Cesium.Math.toRadians(-90),    // default value (looking down)
        roll : 0.0                             // default value
    }
});


// 4. View rectangle with a top-down view
viewer.camera.setView({
    destination : Cesium.Rectangle.fromDegrees(west, south, east, north)
});

// 5. Set position with an orientation using unit vectors.
viewer.camera.setView({
    destination : Cesium.Cartesian3.fromDegrees(-122.19, 46.25, 5000.0),
    orientation : {
        direction : new Cesium.Cartesian3(-0.04231243104240401, -0.20123236049443421, -0.97862924300734),
        up : new Cesium.Cartesian3(-0.47934589305293746, -0.8553216253114552, 0.1966022179118339)
    }
});
```

#### [](#switchToOrthographicFrustum) switchToOrthographicFrustum() 

[engine/Source/Scene/Camera.js 3950](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3950) 

 Switches the frustum/projection to orthographic. This function is a no-op in 2D which will always be orthographic.

#### [](#switchToPerspectiveFrustum) switchToPerspectiveFrustum() 

[engine/Source/Scene/Camera.js 3930](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3930) 

 Switches the frustum/projection to perspective. This function is a no-op in 2D which must always be orthographic.

#### [](#twistLeft) twistLeft(amount) 

[engine/Source/Scene/Camera.js 2000](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2000) 

 Rotate the camera counter-clockwise around its direction vector by amount, in radians.

| Name   | Type   | Description                                                                   |
| ------ | ------ | ----------------------------------------------------------------------------- |
| amount | number | optional The amount, in radians, to rotate by. Defaults to defaultLookAmount. |

##### See:

* [Camera#twistRight](Camera.html#twistRight)

#### [](#twistRight) twistRight(amount) 

[engine/Source/Scene/Camera.js 2012](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2012) 

 Rotate the camera clockwise around its direction vector by amount, in radians.

| Name   | Type   | Description                                                                   |
| ------ | ------ | ----------------------------------------------------------------------------- |
| amount | number | optional The amount, in radians, to rotate by. Defaults to defaultLookAmount. |

##### See:

* [Camera#twistLeft](Camera.html#twistLeft)

#### [](#viewBoundingSphere) viewBoundingSphere(boundingSphere, offset) 

[engine/Source/Scene/Camera.js 3552](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3552) 

 Sets the camera so that the current view contains the provided bounding sphere.

The offset is heading/pitch/range in the local east-north-up reference frame centered at the center of the bounding sphere. The heading and the pitch angles are defined in the local east-north-up reference frame. The heading is the angle from y axis and increasing towards the x axis. Pitch is the rotation from the xy-plane. Positive pitch angles are below the plane. Negative pitch angles are above the plane. The range is the distance from the center. If the range is zero, a range will be computed such that the whole bounding sphere is visible.

In 2D, there must be a top down view. The camera will be placed above the target looking down. The height above the target will be the range. The heading will be determined from the offset. If the heading cannot be determined from the offset, the heading will be north.

| Name           | Type                                        | Description                                                                                            |
| -------------- | ------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| boundingSphere | [BoundingSphere](BoundingSphere.html)       | The bounding sphere to view, in world coordinates.                                                     |
| offset         | [HeadingPitchRange](HeadingPitchRange.html) | optional The offset from the target in the local east-north-up reference frame centered at the target. |

##### Throws:

* [DeveloperError](DeveloperError.html): viewBoundingSphere is not supported while morphing.

#### [](#worldToCameraCoordinates) worldToCameraCoordinates(cartesian, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Scene/Camera.js 1609](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1609) 

 Transform a vector or point from world coordinates to the camera's reference frame.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The vector or point to transform.                   |
| result    | [Cartesian4](Cartesian4.html) | optional The object onto which to store the result. |

##### Returns:

 The transformed vector or point.

#### [](#worldToCameraCoordinatesPoint) worldToCameraCoordinatesPoint(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 1630](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1630) 

 Transform a point from world coordinates to the camera's reference frame.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The point to transform.                             |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The transformed point.

#### [](#worldToCameraCoordinatesVector) worldToCameraCoordinatesVector(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Camera.js 1651](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L1651) 

 Transform a vector from world coordinates to the camera's reference frame.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The vector to transform.                            |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The transformed vector.

#### [](#zoomIn) zoomIn(amount) 

[engine/Source/Scene/Camera.js 2258](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2258) 

 Zooms `amount` along the camera's view vector.

| Name   | Type   | Description                                                 |
| ------ | ------ | ----------------------------------------------------------- |
| amount | number | optional The amount to move. Defaults to defaultZoomAmount. |

##### See:

* [Camera#zoomOut](Camera.html#zoomOut)

#### [](#zoomOut) zoomOut(amount) 

[engine/Source/Scene/Camera.js 2275](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L2275) 

 Zooms `amount` along the opposite direction of the camera's view vector.

| Name   | Type   | Description                                                 |
| ------ | ------ | ----------------------------------------------------------- |
| amount | number | optional The amount to move. Defaults to defaultZoomAmount. |

##### See:

* [Camera#zoomIn](Camera.html#zoomIn)

### Type Definitions

#### [](#.FlightCancelledCallback) Cesium.Camera.FlightCancelledCallback() 

[engine/Source/Scene/Camera.js 3993](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3993) 

 A function that will execute when a flight is cancelled.

#### [](#.FlightCompleteCallback) Cesium.Camera.FlightCompleteCallback() 

[engine/Source/Scene/Camera.js 3988](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L3988) 

 A function that will execute when a flight completes.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

