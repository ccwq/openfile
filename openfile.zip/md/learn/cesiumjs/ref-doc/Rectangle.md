# [![](Images/CesiumLogo.png)](index.html) Rectangle 

#### [](#Rectangle) new Cesium.Rectangle(west, south, east, north) 

[engine/Source/Core/Rectangle.js 24](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Rectangle.js#L24) 

 A two dimensional region specified as longitude and latitude coordinates.

| Name  | Type   | Default | Description                                                                   |
| ----- | ------ | ------- | ----------------------------------------------------------------------------- |
| west  | number | 0.0     | optional The westernmost longitude, in radians, in the range \[-Pi, Pi\].     |
| south | number | 0.0     | optional The southernmost latitude, in radians, in the range \[-Pi/2, Pi/2\]. |
| east  | number | 0.0     | optional The easternmost longitude, in radians, in the range \[-Pi, Pi\].     |
| north | number | 0.0     | optional The northernmost latitude, in radians, in the range \[-Pi/2, Pi/2\]. |

##### See:

* [Packable](Packable.html)

### Members

#### [](#.MAX%5FVALUE) static constant Cesium.Rectangle.MAX\_VALUE : [Rectangle](Rectangle.html) 

[engine/Source/Core/Rectangle.js 1064](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Rectangle.js#L1064) 

 The largest possible rectangle.

#### [](#.packedLength) static Cesium.Rectangle.packedLength : number 

[engine/Source/Core/Rectangle.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Rectangle.js#L88) 

 The number of elements used to pack the object into an array.

#### [](#east) east : number 

[engine/Source/Core/Rectangle.js 47](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Rectangle.js#L47) 

 The easternmost longitude in radians in the range \[-Pi, Pi\].

Default Value: `0.0` 

#### [](#height) readonly height : number 

[engine/Source/Core/Rectangle.js 77](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Rectangle.js#L77) 

 Gets the height of the rectangle in radians.

#### [](#north) north : number 

[engine/Source/Core/Rectangle.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Rectangle.js#L55) 

 The northernmost latitude in radians in the range \[-Pi/2, Pi/2\].

Default Value: `0.0` 

#### [](#south) south : number 

[engine/Source/Core/Rectangle.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Rectangle.js#L39) 

 The southernmost latitude in radians in the range \[-Pi/2, Pi/2\].

Default Value: `0.0` 

#### [](#west) west : number 

[engine/Source/Core/Rectangle.js 31](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Rectangle.js#L31) 

 The westernmost longitude in radians in the range \[-Pi, Pi\].

Default Value: `0.0` 

#### [](#width) readonly width : number 

[engine/Source/Core/Rectangle.js 65](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Rectangle.js#L65) 

 Gets the width of the rectangle in radians.

### Methods

#### [](#.center) static Cesium.Rectangle.center(rectangle, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/Rectangle.js 667](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Rectangle.js#L667) 

 Computes the center of a rectangle.

| Name      | Type                              | Description                                         |
| --------- | --------------------------------- | --------------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html)       | The rectangle for which to find the center          |
| result    | [Cartographic](Cartographic.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartographic instance if none was provided.

#### [](#.clone) static Cesium.Rectangle.clone(rectangle, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/Rectangle.js 436](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Rectangle.js#L436) 

 Duplicates a Rectangle.

| Name      | Type                        | Description                                                                                           |
| --------- | --------------------------- | ----------------------------------------------------------------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html) | The rectangle to clone.                                                                               |
| result    | [Rectangle](Rectangle.html) | optional The object onto which to store the result, or undefined if a new instance should be created. |

##### Returns:

 The modified result parameter or a new Rectangle instance if none was provided. (Returns undefined if rectangle is undefined)