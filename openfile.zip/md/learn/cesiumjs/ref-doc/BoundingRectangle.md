# [![](Images/CesiumLogo.png)](index.html) BoundingRectangle 

#### [](#BoundingRectangle) new Cesium.BoundingRectangle(x, y, width, height) 

[engine/Source/Core/BoundingRectangle.js 24](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L24) 

 A bounding rectangle given by a corner, width and height.

| Name   | Type   | Default | Description                                 |
| ------ | ------ | ------- | ------------------------------------------- |
| x      | number | 0.0     | optional The x coordinate of the rectangle. |
| y      | number | 0.0     | optional The y coordinate of the rectangle. |
| width  | number | 0.0     | optional The width of the rectangle.        |
| height | number | 0.0     | optional The height of the rectangle.       |

##### See:

* [BoundingSphere](BoundingSphere.html)
* [Packable](Packable.html)

### Members

#### [](#.packedLength) static Cesium.BoundingRectangle.packedLength : number 

[engine/Source/Core/BoundingRectangle.js 58](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L58) 

 The number of elements used to pack the object into an array.

#### [](#height) height : number 

[engine/Source/Core/BoundingRectangle.js 51](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L51) 

 The height of the rectangle.

Default Value: `0.0` 

#### [](#width) width : number 

[engine/Source/Core/BoundingRectangle.js 44](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L44) 

 The width of the rectangle.

Default Value: `0.0` 

#### [](#x) x : number 

[engine/Source/Core/BoundingRectangle.js 30](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L30) 

 The x coordinate of the rectangle.

Default Value: `0.0` 

#### [](#y) y : number 

[engine/Source/Core/BoundingRectangle.js 37](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L37) 

 The y coordinate of the rectangle.

Default Value: `0.0` 

### Methods

#### [](#.clone) static Cesium.BoundingRectangle.clone(rectangle, result) → [BoundingRectangle](BoundingRectangle.html) 

[engine/Source/Core/BoundingRectangle.js 207](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L207) 

 Duplicates a BoundingRectangle instance.

| Name      | Type                                        | Description                                         |
| --------- | ------------------------------------------- | --------------------------------------------------- |
| rectangle | [BoundingRectangle](BoundingRectangle.html) | The bounding rectangle to duplicate.                |
| result    | [BoundingRectangle](BoundingRectangle.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingRectangle instance if one was not provided. (Returns undefined if rectangle is undefined)

#### [](#.equals) static Cesium.BoundingRectangle.equals(left, right) → boolean 

[engine/Source/Core/BoundingRectangle.js 333](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L333) 

 Compares the provided BoundingRectangles componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                        | Description                            |
| ----- | ------------------------------------------- | -------------------------------------- |
| left  | [BoundingRectangle](BoundingRectangle.html) | optional The first BoundingRectangle.  |
| right | [BoundingRectangle](BoundingRectangle.html) | optional The second BoundingRectangle. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.expand) static Cesium.BoundingRectangle.expand(rectangle, point, result) → [BoundingRectangle](BoundingRectangle.html) 

[engine/Source/Core/BoundingRectangle.js 266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L266) 

 Computes a bounding rectangle by enlarging the provided rectangle until it contains the provided point.

| Name      | Type                                        | Description                                         |
| --------- | ------------------------------------------- | --------------------------------------------------- |
| rectangle | [BoundingRectangle](BoundingRectangle.html) | A rectangle to expand.                              |
| point     | [Cartesian2](Cartesian2.html)               | A point to enclose in a bounding rectangle.         |
| result    | [BoundingRectangle](BoundingRectangle.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingRectangle instance if one was not provided.

#### [](#.fromPoints) static Cesium.BoundingRectangle.fromPoints(positions, result) → [BoundingRectangle](BoundingRectangle.html) 

[engine/Source/Core/BoundingRectangle.js 118](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L118) 

 Computes a bounding rectangle enclosing the list of 2D points. The rectangle is oriented with the corner at the bottom left.

| Name      | Type                                        | Description                                                                                       |
| --------- | ------------------------------------------- | ------------------------------------------------------------------------------------------------- |
| positions | Array.<[Cartesian2](Cartesian2.html)\>      | List of points that the bounding rectangle will enclose. Each point must have x and y properties. |
| result    | [BoundingRectangle](BoundingRectangle.html) | optional The object onto which to store the result.                                               |

##### Returns:

 The modified result parameter or a new BoundingRectangle instance if one was not provided.

#### [](#.fromRectangle) static Cesium.BoundingRectangle.fromRectangle(rectangle, projection, result) → [BoundingRectangle](BoundingRectangle.html) 

[engine/Source/Core/BoundingRectangle.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L168) 

 Computes a bounding rectangle from a rectangle.

| Name       | Type                                        | Default              | Description                                                    |
| ---------- | ------------------------------------------- | -------------------- | -------------------------------------------------------------- |
| rectangle  | [Rectangle](Rectangle.html)                 |                      | The valid rectangle used to create a bounding rectangle.       |
| projection | object                                      | GeographicProjection | optional The projection used to project the rectangle into 2D. |
| result     | [BoundingRectangle](BoundingRectangle.html) |                      | optional The object onto which to store the result.            |

##### Returns:

 The modified result parameter or a new BoundingRectangle instance if one was not provided.

#### [](#.intersect) static Cesium.BoundingRectangle.intersect(left, right) → [Intersect](global.html#Intersect) 

[engine/Source/Core/BoundingRectangle.js 301](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L301) 

 Determines if two rectangles intersect.

| Name  | Type                                        | Description                                    |
| ----- | ------------------------------------------- | ---------------------------------------------- |
| left  | [BoundingRectangle](BoundingRectangle.html) | A rectangle to check for intersection.         |
| right | [BoundingRectangle](BoundingRectangle.html) | The other rectangle to check for intersection. |

##### Returns:

`Intersect.INTERSECTING` if the rectangles intersect, `Intersect.OUTSIDE` otherwise.

#### [](#.pack) static Cesium.BoundingRectangle.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/BoundingRectangle.js 69](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L69) 

 Stores the provided instance into the provided array.

| Name          | Type                                        | Default | Description                                                               |
| ------------- | ------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [BoundingRectangle](BoundingRectangle.html) |         | The value to pack.                                                        |
| array         | Array.<number>                              |         | The array to pack into.                                                   |
| startingIndex | number                                      | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.union) static Cesium.BoundingRectangle.union(left, right, result) → [BoundingRectangle](BoundingRectangle.html) 

[engine/Source/Core/BoundingRectangle.js 236](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L236) 

 Computes a bounding rectangle that is the union of the left and right bounding rectangles.

| Name   | Type                                        | Description                                         |
| ------ | ------------------------------------------- | --------------------------------------------------- |
| left   | [BoundingRectangle](BoundingRectangle.html) | A rectangle to enclose in bounding rectangle.       |
| right  | [BoundingRectangle](BoundingRectangle.html) | A rectangle to enclose in a bounding rectangle.     |
| result | [BoundingRectangle](BoundingRectangle.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingRectangle instance if one was not provided.

#### [](#.unpack) static Cesium.BoundingRectangle.unpack(array, startingIndex, result) → [BoundingRectangle](BoundingRectangle.html) 

[engine/Source/Core/BoundingRectangle.js 93](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L93) 

 Retrieves an instance from a packed array.

| Name          | Type                                        | Default | Description                                                |
| ------------- | ------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                              |         | The packed array.                                          |
| startingIndex | number                                      | 0       | optional The starting index of the element to be unpacked. |
| result        | [BoundingRectangle](BoundingRectangle.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new BoundingRectangle instance if one was not provided.

#### [](#clone) clone(result) → [BoundingRectangle](BoundingRectangle.html) 

[engine/Source/Core/BoundingRectangle.js 351](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L351) 

 Duplicates this BoundingRectangle instance.

| Name   | Type                                        | Description                                         |
| ------ | ------------------------------------------- | --------------------------------------------------- |
| result | [BoundingRectangle](BoundingRectangle.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingRectangle instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/BoundingRectangle.js 372](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L372) 

 Compares this BoundingRectangle against the provided BoundingRectangle componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                        | Description                                     |
| ----- | ------------------------------------------- | ----------------------------------------------- |
| right | [BoundingRectangle](BoundingRectangle.html) | optional The right hand side BoundingRectangle. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#intersect) intersect(right) → [Intersect](global.html#Intersect) 

[engine/Source/Core/BoundingRectangle.js 361](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingRectangle.js#L361) 

 Determines if this rectangle intersects with another.

| Name  | Type                                        | Description                            |
| ----- | ------------------------------------------- | -------------------------------------- |
| right | [BoundingRectangle](BoundingRectangle.html) | A rectangle to check for intersection. |

##### Returns:

`Intersect.INTERSECTING` if the rectangles intersect, `Intersect.OUTSIDE` otherwise.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

