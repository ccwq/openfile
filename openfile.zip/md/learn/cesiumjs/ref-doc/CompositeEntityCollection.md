# [![](Images/CesiumLogo.png)](index.html) CompositeEntityCollection 

#### [](#CompositeEntityCollection) new Cesium.CompositeEntityCollection(collections, owner) 

[engine/Source/DataSources/CompositeEntityCollection.js 130](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L130) 

 Non-destructively composites multiple [EntityCollection](EntityCollection.html) instances into a single collection. If a Entity with the same ID exists in multiple collections, it is non-destructively merged into a single new entity instance. If an entity has the same property in multiple collections, the property of the Entity in the last collection of the list it belongs to is used. CompositeEntityCollection can be used almost anywhere that a EntityCollection is used.

| Name        | Type                                                                                       | Description                                                                              |
| ----------- | ------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------- |
| collections | Array.<[EntityCollection](EntityCollection.html)\>                                         | optional The initial list of EntityCollection instances to merge.                        |
| owner       | [DataSource](DataSource.html)\|[CompositeEntityCollection](CompositeEntityCollection.html) | optional The data source (or composite entity collection) which created this collection. |

### Members

#### [](#collectionChanged) readonly collectionChanged : [Event](Event.html) 

[engine/Source/DataSources/CompositeEntityCollection.js 150](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L150) 

 Gets the event that is fired when entities are added or removed from the collection. The generated event is a `EntityCollection.collectionChangedEventCallback`.

#### [](#id) readonly id : string 

[engine/Source/DataSources/CompositeEntityCollection.js 161](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L161) 

 Gets a globally unique identifier for this collection.

#### [](#owner) readonly owner : [DataSource](DataSource.html)|[CompositeEntityCollection](CompositeEntityCollection.html) 

[engine/Source/DataSources/CompositeEntityCollection.js 184](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L184) 

 Gets the owner of this composite entity collection, ie. the data source or composite entity collection which created it.

#### [](#values) readonly values : Array.<[Entity](Entity.html)\> 

[engine/Source/DataSources/CompositeEntityCollection.js 173](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L173) 

 Gets the array of Entity instances in the collection. This array should not be modified directly.

### Methods

#### [](#addCollection) addCollection(collection, index) 

[engine/Source/DataSources/CompositeEntityCollection.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L200) 

 Adds a collection to the composite.

| Name       | Type                                      | Description                                                                                                            |
| ---------- | ----------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| collection | [EntityCollection](EntityCollection.html) | the collection to add.                                                                                                 |
| index      | number                                    | optional the index to add the collection at. If omitted, the collection will added on top of all existing collections. |

##### Throws:

* [DeveloperError](DeveloperError.html): index, if supplied, must be greater than or equal to zero and less than or equal to the number of collections.

#### [](#computeAvailability) computeAvailability() → [TimeInterval](TimeInterval.html) 

[engine/Source/DataSources/CompositeEntityCollection.js 457](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L457) 

 Computes the maximum availability of the entities in the collection. If the collection contains a mix of infinitely available data and non-infinite data, It will return the interval pertaining to the non-infinite data only. If all data is infinite, an infinite interval will be returned.

##### Returns:

 The availability of entities in the collection.

#### [](#contains) contains(entity) → boolean 

[engine/Source/DataSources/CompositeEntityCollection.js 271](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L271) 

 Returns true if the provided entity is in this collection, false otherwise.

| Name   | Type                  | Description |
| ------ | --------------------- | ----------- |
| entity | [Entity](Entity.html) | The entity. |

##### Returns:

 true if the provided entity is in this collection, false otherwise.

#### [](#containsCollection) containsCollection(collection) → boolean 

[engine/Source/DataSources/CompositeEntityCollection.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L261) 

 Checks to see if the composite contains a given collection.

| Name       | Type                                      | Description                  |
| ---------- | ----------------------------------------- | ---------------------------- |
| collection | [EntityCollection](EntityCollection.html) | the collection to check for. |

##### Returns:

 true if the composite contains the collection, false otherwise.

#### [](#getById) getById(id) → [Entity](Entity.html)|undefined 

[engine/Source/DataSources/CompositeEntityCollection.js 467](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L467) 

 Gets an entity with the specified id.

| Name | Type   | Description                       |
| ---- | ------ | --------------------------------- |
| id   | string | The id of the entity to retrieve. |

##### Returns:

 The entity with the provided id or undefined if the id did not exist in the collection.

#### [](#getCollection) getCollection(index) 

[engine/Source/DataSources/CompositeEntityCollection.js 290](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L290) 

 Gets a collection by index from the composite.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| index | number | the index to retrieve. |

#### [](#getCollectionsLength) getCollectionsLength() 

[engine/Source/DataSources/CompositeEntityCollection.js 303](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L303) 

 Gets the number of collections in this composite.

#### [](#indexOfCollection) indexOfCollection(collection) → number 

[engine/Source/DataSources/CompositeEntityCollection.js 281](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L281) 

 Determines the index of a given collection in the composite.

| Name       | Type                                      | Description                          |
| ---------- | ----------------------------------------- | ------------------------------------ |
| collection | [EntityCollection](EntityCollection.html) | The collection to find the index of. |

##### Returns:

 The index of the collection in the composite, or -1 if the collection does not exist in the composite.

#### [](#lowerCollection) lowerCollection(collection) 

[engine/Source/DataSources/CompositeEntityCollection.js 360](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L360) 

 Lowers a collection down one position in the composite.

| Name       | Type                                      | Description             |
| ---------- | ----------------------------------------- | ----------------------- |
| collection | [EntityCollection](EntityCollection.html) | the collection to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): collection is not in this composite.

#### [](#lowerCollectionToBottom) lowerCollectionToBottom(collection) 

[engine/Source/DataSources/CompositeEntityCollection.js 392](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L392) 

 Lowers a collection to the bottom of the composite.

| Name       | Type                                      | Description             |
| ---------- | ----------------------------------------- | ----------------------- |
| collection | [EntityCollection](EntityCollection.html) | the collection to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): collection is not in this composite.

#### [](#raiseCollection) raiseCollection(collection) 

[engine/Source/DataSources/CompositeEntityCollection.js 348](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L348) 

 Raises a collection up one position in the composite.

| Name       | Type                                      | Description             |
| ---------- | ----------------------------------------- | ----------------------- |
| collection | [EntityCollection](EntityCollection.html) | the collection to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): collection is not in this composite.

#### [](#raiseCollectionToTop) raiseCollectionToTop(collection) 

[engine/Source/DataSources/CompositeEntityCollection.js 372](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L372) 

 Raises a collection to the top of the composite.

| Name       | Type                                      | Description             |
| ---------- | ----------------------------------------- | ----------------------- |
| collection | [EntityCollection](EntityCollection.html) | the collection to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): collection is not in this composite.

#### [](#removeAllCollections) removeAllCollections() 

[engine/Source/DataSources/CompositeEntityCollection.js 250](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L250) 

 Removes all collections from this composite.

#### [](#removeCollection) removeCollection(collection) → boolean 

[engine/Source/DataSources/CompositeEntityCollection.js 237](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L237) 

 Removes a collection from this composite, if present.

| Name       | Type                                      | Description               |
| ---------- | ----------------------------------------- | ------------------------- |
| collection | [EntityCollection](EntityCollection.html) | The collection to remove. |

##### Returns:

 true if the collection was in the composite and was removed, false if the collection was not in the composite.

#### [](#resumeEvents) resumeEvents() 

[engine/Source/DataSources/CompositeEntityCollection.js 430](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L430) 

 Resumes raising [EntityCollection#collectionChanged](EntityCollection.html#collectionChanged) events immediately when an item is added or removed. Any modifications made while while events were suspended will be triggered as a single event when this function is called. This function also ensures the collection is recomposited if events are also resumed. This function is reference counted and can safely be called multiple times as long as there are corresponding calls to [EntityCollection#resumeEvents](EntityCollection.html#resumeEvents).

##### Throws:

* [DeveloperError](DeveloperError.html): resumeEvents can not be called before suspendEvents.

#### [](#suspendEvents) suspendEvents() 

[engine/Source/DataSources/CompositeEntityCollection.js 415](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CompositeEntityCollection.js#L415) 

 Prevents [EntityCollection#collectionChanged](EntityCollection.html#collectionChanged) events from being raised until a corresponding call is made to [EntityCollection#resumeEvents](EntityCollection.html#resumeEvents), at which point a single event will be raised that covers all suspended operations. This allows for many items to be added and removed efficiently. While events are suspended, recompositing of the collections will also be suspended, as this can be a costly operation. This function can be safely called multiple times as long as there are corresponding calls to [EntityCollection#resumeEvents](EntityCollection.html#resumeEvents).

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

