# [![](Images/CesiumLogo.png)](index.html) TimeDynamicImagery 

#### [](#TimeDynamicImagery) new Cesium.TimeDynamicImagery(options) 

[engine/Source/Scene/TimeDynamicImagery.js 21](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicImagery.js#L21) 

 Provides functionality for ImageryProviders that have time dynamic imagery

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description clock [Clock](Clock.html)  A Clock instance that is used when determining the value for the time dimension. Required when options.times is specified. times [TimeIntervalCollection](TimeIntervalCollection.html)  TimeIntervalCollection with its data property being an object containing time dynamic dimension and their values. requestImageFunction function  A function that will request imagery tiles. reloadFunction function  A function that will be called when all imagery tiles need to be reloaded. |

### Members

#### [](#clock) clock : [Clock](Clock.html) 

[engine/Source/Scene/TimeDynamicImagery.js 53](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicImagery.js#L53) 

 Gets or sets a clock that is used to get keep the time used for time dynamic parameters.

#### [](#currentInterval) currentInterval : [TimeInterval](TimeInterval.html) 

[engine/Source/Scene/TimeDynamicImagery.js 99](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicImagery.js#L99) 

 Gets the current interval.

#### [](#times) times : [TimeIntervalCollection](TimeIntervalCollection.html) 

[engine/Source/Scene/TimeDynamicImagery.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicImagery.js#L76) 

 Gets or sets a time interval collection.

### Methods

#### [](#checkApproachingInterval) checkApproachingInterval(x, y, level, request) 

[engine/Source/Scene/TimeDynamicImagery.js 143](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicImagery.js#L143) 

 Checks if the next interval is approaching and will start preload the tile if necessary. Otherwise it will just add the tile to a list to preload when we approach the next interval.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

#### [](#getFromCache) getFromCache(x, y, level, request) → Promise.<HTMLImageElement>|undefined 

[engine/Source/Scene/TimeDynamicImagery.js 117](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/TimeDynamicImagery.js#L117) 

 Gets the tile from the cache if its available.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the image that will resolve when the image is available, or undefined if the tile is not in the cache.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

