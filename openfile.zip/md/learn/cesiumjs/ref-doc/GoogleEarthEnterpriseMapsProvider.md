# [![](Images/CesiumLogo.png)](index.html) GoogleEarthEnterpriseMapsProvider 

#### [](#GoogleEarthEnterpriseMapsProvider) new Cesium.GoogleEarthEnterpriseMapsProvider(options) 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 203](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L203) 

To construct a GoogleEarthEnterpriseMapsProvider, call `GoogleEarthEnterpriseImageryProvider.fromUrl`. Do not call the constructor directly.

Provides tiled imagery using the Google Earth Imagery API. Notes: This imagery provider does not work with the public Google Earth servers. It works with the Google Earth Enterprise Server. By default the Google Earth Enterprise server does not set the[Cross-Origin Resource Sharing](http://www.w3.org/TR/cors/) headers. You can either use a proxy server which adds these headers, or in the /opt/google/gehttpd/conf/gehttpd.conf and add the 'Header set Access-Control-Allow-Origin "\*"' option to the '<Directory />' and '<Directory "/opt/google/gehttpd/htdocs">' directives. This provider is for use with 2D Maps API as part of Google Earth Enterprise. For 3D Earth API uses, it is necessary to use [GoogleEarthEnterpriseImageryProvider](GoogleEarthEnterpriseImageryProvider.html) 

| Name    | Type                                                                                                               | Description                              |
| ------- | ------------------------------------------------------------------------------------------------------------------ | ---------------------------------------- |
| options | [GoogleEarthEnterpriseMapsProvider.ConstructorOptions](GoogleEarthEnterpriseMapsProvider.html#.ConstructorOptions) | Object describing initialization options |

##### Throws:

* [RuntimeError](RuntimeError.html): Could not find layer with channel (id) of `options.channel`.
* [RuntimeError](RuntimeError.html): Could not find a version in channel (id) `options.channel`.
* [RuntimeError](RuntimeError.html): Unsupported projection `data.projection`.

##### Example:

```javascript
const google = await Cesium.GoogleEarthEnterpriseMapsProvider.fromUrl("https://earth.localdomain", 1008);
```

##### See:

* [ArcGisMapServerImageryProvider](ArcGisMapServerImageryProvider.html)
* [BingMapsImageryProvider](BingMapsImageryProvider.html)
* [OpenStreetMapImageryProvider](OpenStreetMapImageryProvider.html)
* [SingleTileImageryProvider](SingleTileImageryProvider.html)
* [TileMapServiceImageryProvider](TileMapServiceImageryProvider.html)
* [WebMapServiceImageryProvider](WebMapServiceImageryProvider.html)
* [WebMapTileServiceImageryProvider](WebMapTileServiceImageryProvider.html)
* [UrlTemplateImageryProvider](UrlTemplateImageryProvider.html)
* [Cross-Origin Resource Sharing](http://www.w3.org/TR/cors/)

### Members

#### [](#.logoUrl) static Cesium.GoogleEarthEnterpriseMapsProvider.logoUrl : string 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 572](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L572) 

 Gets or sets the URL to the Google Earth logo for display in the credit.

#### [](#channel) readonly channel : number 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 278](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L278) 

 Gets the imagery channel (id) currently being used.

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 414](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L414) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 401](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L401) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 430](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L430) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. When this property is false, memory usage and texture upload time are reduced.

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 314](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L314) 

 Gets the maximum level-of-detail that can be requested.

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 326](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L326) 

 Gets the minimum level-of-detail that can be requested.

#### [](#path) readonly path : string 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 254](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L254) 

 Gets the url path of the data on the Google Earth server.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L266) 

 Gets the proxy used by this provider.

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 373](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L373) 

 Gets the rectangle, in radians, of the imagery provided by this instance.

#### [](#requestType) readonly requestType : string 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 362](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L362) 

 Gets the type of data that is being requested from the provider.

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 387](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L387) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 302](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L302) 

 Gets the height of each tile, in pixels.

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 290](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L290) 

 Gets the width of each tile, in pixels.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 338](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L338) 

 Gets the tiling scheme used by this provider.

#### [](#url) readonly url : string 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 242](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L242) 

 Gets the URL of the Google Earth MapServer.

#### [](#version) readonly version : number 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 350](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L350) 

 Gets the version of the data used by this provider.

### Methods

#### [](#.fromUrl) static Cesium.GoogleEarthEnterpriseMapsProvider.fromUrl(url, options) → Promise.<[GoogleEarthEnterpriseMapsProvider](GoogleEarthEnterpriseMapsProvider.html)\> 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 451](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L451) 

 Creates a tiled imagery provider using the Google Earth Imagery API.

| Name    | Type                                                                                                               | Description                                             |
| ------- | ------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------- |
| url     | [Resource](Resource.html)\|String                                                                                  | The url of the Google Earth server hosting the imagery. |
| options | [GoogleEarthEnterpriseMapsProvider.ConstructorOptions](GoogleEarthEnterpriseMapsProvider.html#.ConstructorOptions) | optional Object describing initialization options       |

##### Returns:

 The created GoogleEarthEnterpriseMapsProvider.

##### Throws:

* [RuntimeError](RuntimeError.html): Could not find layer with channel (id) of `options.channel`.
* [RuntimeError](RuntimeError.html): Could not find a version in channel (id) `options.channel`.
* [RuntimeError](RuntimeError.html): Unsupported projection `data.projection`.

##### Example:

```javascript
const google = await Cesium.GoogleEarthEnterpriseMapsProvider.fromUrl("https://earth.localdomain", 1008);
```

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 503](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L503) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → undefined 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 554](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L554) 

 Picking features is not currently supported by this imagery provider, so this function simply returns undefined.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 Undefined since picking is not supported.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<[ImageryTypes](global.html#ImageryTypes)\>|undefined 

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 521](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L521) 

 Requests the image for a given tile.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the image that will resolve when the image is available, or undefined if there are too many active requests to the server, and the request should be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.GoogleEarthEnterpriseMapsProvider.ConstructorOptions

[engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js 15](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseMapsProvider.js#L15) 

 Initialization options for the GoogleEarthEnterpriseMapsProvider constructor

##### Properties:

| Name              | Type                                        | Attributes | Default           | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ----------------- | ------------------------------------------- | ---------- | ----------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| channel           | number                                      |            |                   | The channel (id) to be used when requesting data from the server. The channel number can be found by looking at the json file located at: earth.localdomain/default\_map/query?request=Json&vars=geeServerDefs The /default\_map path may differ depending on your Google Earth Enterprise server configuration. Look for the "id" that is associated with a "ImageryMaps" requestType. There may be more than one id available. Example: { layers: \[ { id: 1002, requestType: "ImageryMaps" }, { id: 1007, requestType: "VectorMapsRaster" } \] } |
| path              | string                                      | <optional> | "/default\_map"   | The path of the Google Earth server hosting the imagery.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| maximumLevel      | number                                      | <optional> |                   | The maximum level-of-detail supported by the Google Earth Enterprise server, or undefined if there is no limit.                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| tileDiscardPolicy | [TileDiscardPolicy](TileDiscardPolicy.html) | <optional> |                   | The policy that determines if a tile is invalid and should be discarded. To ensure that no tiles are discarded, construct and pass a [NeverTileDiscardPolicy](NeverTileDiscardPolicy.html) for this parameter.                                                                                                                                                                                                                                                                                                                                      |
| ellipsoid         | [Ellipsoid](Ellipsoid.html)                 | <optional> | Ellipsoid.default | The ellipsoid. If not specified, the default ellipsoid is used.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

