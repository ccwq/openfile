# [![](Images/CesiumLogo.png)](index.html) VoxelProvider 

#### [](#VoxelProvider) new Cesium.VoxelProvider() 

[engine/Source/Scene/VoxelProvider.js 16](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L16) 

 Provides voxel data. Intended to be used with [VoxelPrimitive](VoxelPrimitive.html). This type describes an interface and is not intended to be instantiated directly.

##### Experimental

This feature is not final and is subject to change without Cesium's standard deprecation policy.

##### See:

* [Cesium3DTilesVoxelProvider](Cesium3DTilesVoxelProvider.html)
* [VoxelPrimitive](VoxelPrimitive.html)
* [VoxelShapeType](global.html#VoxelShapeType)

### Members

#### [](#componentTypes) readonly componentTypes : Array.<[MetadataComponentType](global.html#MetadataComponentType)\> 

[engine/Source/Scene/VoxelProvider.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L144) 

 Gets the metadata component types.

#### [](#dimensions) readonly dimensions : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/VoxelProvider.js 87](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L87) 

 Gets the number of voxels per dimension of a tile. This is the same for all tiles in the dataset.

#### [](#globalTransform) readonly globalTransform : [Matrix4](Matrix4.html) 

[engine/Source/Scene/VoxelProvider.js 29](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L29) 

 A transform from local space to global space.

Default Value: `Matrix4.IDENTITY` 

#### [](#maxBounds) readonly maxBounds : [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/Scene/VoxelProvider.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L76) 

 Gets the maximum bounds. If undefined, the shape's default maximum bounds will be used instead.

#### [](#maximumTileCount) readonly maximumTileCount : number|undefined 

[engine/Source/Scene/VoxelProvider.js 191](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L191) 

 The maximum number of tiles that exist for this provider. This value is used as a hint to the voxel renderer to allocate an appropriate amount of GPU memory. If this value is not known it can be undefined.

#### [](#maximumValues) readonly maximumValues : Array.<Array.<number>>|undefined 

[engine/Source/Scene/VoxelProvider.js 178](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L178) 

 Gets the metadata maximum values.

#### [](#metadataOrder) readonly metadataOrder : [VoxelMetadataOrder](global.html#VoxelMetadataOrder) 

[engine/Source/Scene/VoxelProvider.js 156](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L156) 

 Gets the ordering of the metadata in the buffers.

Default Value: `VoxelMetadataOrder.XYZ` 

#### [](#minBounds) readonly minBounds : [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/Scene/VoxelProvider.js 64](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L64) 

 Gets the minimum bounds. If undefined, the shape's default minimum bounds will be used instead.

#### [](#minimumValues) readonly minimumValues : Array.<Array.<number>>|undefined 

[engine/Source/Scene/VoxelProvider.js 167](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L167) 

 Gets the metadata minimum values.

#### [](#names) readonly names : Array.<string> 

[engine/Source/Scene/VoxelProvider.js 122](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L122) 

 Gets the metadata names.

#### [](#paddingAfter) readonly paddingAfter : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/VoxelProvider.js 111](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L111) 

 Gets the number of padding voxels after the tile. This improves rendering quality when sampling the edge of a tile, but it increases memory usage.

Default Value: `Cartesian3.ZERO` 

#### [](#paddingBefore) readonly paddingBefore : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/VoxelProvider.js 99](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L99) 

 Gets the number of padding voxels before the tile. This improves rendering quality when sampling the edge of a tile, but it increases memory usage.

Default Value: `Cartesian3.ZERO` 

#### [](#shape) readonly shape : [VoxelShapeType](global.html#VoxelShapeType) 

[engine/Source/Scene/VoxelProvider.js 52](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L52) 

 Gets the [VoxelShapeType](global.html#VoxelShapeType) 

#### [](#shapeTransform) readonly shapeTransform : [Matrix4](Matrix4.html) 

[engine/Source/Scene/VoxelProvider.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L41) 

 A transform from shape space to local space.

Default Value: `Matrix4.IDENTITY` 

#### [](#types) readonly types : Array.<[MetadataType](global.html#MetadataType)\> 

[engine/Source/Scene/VoxelProvider.js 133](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L133) 

 Gets the metadata types.

### Methods

#### [](#requestData) requestData(options) → Promise.<[VoxelContent](VoxelContent.html)\>|undefined 

[engine/Source/Scene/VoxelProvider.js 242](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L242) 

 Requests the data for a given tile.

| Name    | Type   | Description                                                                                                                                                                                                                                                                   |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description tileLevel number 0 optional The tile's level. tileX number 0 optional The tile's X coordinate. tileY number 0 optional The tile's Y coordinate. tileZ number 0 optional The tile's Z coordinate. |

##### Returns:

 A promise resolving to a VoxelContent containing the data for the tile, or undefined if the request could not be scheduled this frame.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

