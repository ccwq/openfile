# [![](Images/CesiumLogo.png)](index.html) PostProcessStage 

#### [](#PostProcessStage) new Cesium.PostProcessStage(options) 

[engine/Source/Scene/PostProcessStage.js 94](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L94) 

 Runs a post-process stage on either the texture rendered by the scene or the output of a previous post-process stage.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | An object with the following properties: Name Type Default Description fragmentShader string  The fragment shader to use. The default sampler2D uniforms are colorTexture and depthTexture. The color texture is the output of rendering the scene or the previous stage. The depth texture is the output from rendering the scene. The shader should contain one or both uniforms. There is also a vec2 varying named v\_textureCoordinates that can be used to sample the textures. uniforms object optional An object whose properties will be used to set the shaders uniforms. The properties can be constant values or a function. A constant value can also be a URI, data URI, or HTML element to use as a texture. textureScale number 1.0 optional A number in the range (0.0, 1.0\] used to scale the texture dimensions. A scale of 1.0 will render this post-process stage to a texture the size of the viewport. forcePowerOfTwo boolean false optional Whether or not to force the texture dimensions to be both equal powers of two. The power of two will be the next power of two of the minimum of the dimensions. sampleMode [PostProcessStageSampleMode](global.html#PostProcessStageSampleMode) PostProcessStageSampleMode.NEAREST optional How to sample the input color texture. pixelFormat [PixelFormat](global.html#PixelFormat) PixelFormat.RGBA optional The color pixel format of the output texture. pixelDatatype [PixelDatatype](global.html#PixelDatatype) PixelDatatype.UNSIGNED\_BYTE optional The pixel data type of the output texture. clearColor [Color](Color.html) Color.BLACK optional The color to clear the output texture to. scissorRectangle [BoundingRectangle](BoundingRectangle.html) optional The rectangle to use for the scissor test. name string createGuid() optional The unique name of this post-process stage for reference by other stages in a composite. If a name is not supplied, a GUID will be generated. |

##### Throws:

* [DeveloperError](DeveloperError.html): options.textureScale must be greater than 0.0 and less than or equal to 1.0.
* [DeveloperError](DeveloperError.html): options.pixelFormat must be a color format.
* [DeveloperError](DeveloperError.html): When options.pixelDatatype is FLOAT, this WebGL implementation must support floating point textures. Check context.floatingPointTexture.

##### Examples:

```javascript
// Simple stage to change the color
const fs =`
    uniform sampler2D colorTexture;
    in vec2 v_textureCoordinates;
    uniform float scale;
    uniform vec3 offset;
    void main() {
        vec4 color = texture(colorTexture, v_textureCoordinates);
        out_FragColor = vec4(color.rgb * scale + offset, 1.0);
    }`;
scene.postProcessStages.add(new Cesium.PostProcessStage({
    fragmentShader : fs,
    uniforms : {
        scale : 1.1,
        offset : function() {
            return new Cesium.Cartesian3(0.1, 0.2, 0.3);
        }
    }
}));
```

```javascript
// Simple stage to change the color of what is selected.
// If czm_selected returns true, the current fragment belongs to geometry in the selected array.
const fs =`
    uniform sampler2D colorTexture;
    in vec2 v_textureCoordinates;
    uniform vec4 highlight;
    void main() {
        vec4 color = texture(colorTexture, v_textureCoordinates);
        if (czm_selected()) {
            vec3 highlighted = highlight.a * highlight.rgb + (1.0 - highlight.a) * color.rgb;
            out_FragColor = vec4(highlighted, 1.0);
        } else {
            out_FragColor = color;
        }
    }`;
const stage = scene.postProcessStages.add(new Cesium.PostProcessStage({
    fragmentShader : fs,
    uniforms : {
        highlight : function() {
            return new Cesium.Color(1.0, 0.0, 0.0, 0.5);
        }
    }
}));
stage.selected = [cesium3DTileFeature];
```

##### See:

* [PostProcessStageComposite](PostProcessStageComposite.html)

### Members

#### [](#clearColor) readonly clearColor : [Color](Color.html) 

[engine/Source/Scene/PostProcessStage.js 321](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L321) 

 The color to clear the output texture to.

#### [](#enabled) enabled : boolean 

[engine/Source/Scene/PostProcessStage.js 180](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L180) 

 Whether or not to execute this post-process stage when ready.

#### [](#forcePowerOfTwo) readonly forcePowerOfTwo : number 

[engine/Source/Scene/PostProcessStage.js 273](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L273) 

 Whether or not to force the output texture dimensions to be both equal powers of two. The power of two will be the next power of two of the minimum of the dimensions.

#### [](#fragmentShader) readonly fragmentShader : string 

[engine/Source/Scene/PostProcessStage.js 226](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L226) 

 The fragment shader to use when execute this post-process stage.

The shader must contain a sampler uniform declaration for `colorTexture`, `depthTexture`, or both.

The shader must contain a `vec2` varying declaration for `v_textureCoordinates` for sampling the texture uniforms.

#### [](#name) readonly name : string 

[engine/Source/Scene/PostProcessStage.js 206](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L206) 

 The unique name of this post-process stage for reference by other stages in a [PostProcessStageComposite](PostProcessStageComposite.html).

#### [](#pixelDatatype) readonly pixelDatatype : [PixelDatatype](global.html#PixelDatatype) 

[engine/Source/Scene/PostProcessStage.js 309](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L309) 

 The pixel data type of the output texture.

#### [](#pixelFormat) readonly pixelFormat : [PixelFormat](global.html#PixelFormat) 

[engine/Source/Scene/PostProcessStage.js 297](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L297) 

 The color pixel format of the output texture.

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/PostProcessStage.js 194](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L194) 

 Determines if this post-process stage is ready to be executed. A stage is only executed when both `ready`and [PostProcessStage#enabled](PostProcessStage.html#enabled) are `true`. A stage will not be ready while it is waiting on textures to load.

#### [](#sampleMode) readonly sampleMode : [PostProcessStageSampleMode](global.html#PostProcessStageSampleMode) 

[engine/Source/Scene/PostProcessStage.js 285](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L285) 

 How to sample the input color texture.

#### [](#scissorRectangle) readonly scissorRectangle : [BoundingRectangle](BoundingRectangle.html) 

[engine/Source/Scene/PostProcessStage.js 333](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L333) 

 The [BoundingRectangle](BoundingRectangle.html) to use for the scissor test. A default bounding rectangle will disable the scissor test.

#### [](#selected) selected : Array 

[engine/Source/Scene/PostProcessStage.js 374](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L374) 

 The features selected for applying the post-process.

In the fragment shader, use `czm_selected` to determine whether or not to apply the post-process stage to that fragment. For example:`if (czm_selected(v_textureCoordinates)) { // apply post-process stage } else { out_FragColor = texture(colorTexture, v_textureCoordinates); }` 

#### [](#textureScale) readonly textureScale : number 

[engine/Source/Scene/PostProcessStage.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L261) 

 A number in the range (0.0, 1.0\] used to scale the output texture dimensions. A scale of 1.0 will render this post-process stage to a texture the size of the viewport.

#### [](#uniforms) readonly uniforms : object 

[engine/Source/Scene/PostProcessStage.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L249) 

 An object whose properties are used to set the uniforms of the fragment shader.

The object property values can be either a constant or a function. The function will be called each frame before the post-process stage is executed.

A constant value can also be a URI to an image, a data URI, or an HTML element that can be used as a texture, such as HTMLImageElement or HTMLCanvasElement.

If this post-process stage is part of a [PostProcessStageComposite](PostProcessStageComposite.html) that does not execute in series, the constant value can also be the name of another stage in a composite. This will set the uniform to the output texture the stage with that name.

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/PostProcessStage.js 996](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L996) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.

Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### See:

* [PostProcessStage#isDestroyed](PostProcessStage.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/PostProcessStage.js 979](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStage.js#L979) 

 Returns true if this object was destroyed; otherwise, false.

If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [PostProcessStage#destroy](PostProcessStage.html#destroy)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

