# [![](Images/CesiumLogo.png)](index.html) CircleOutlineGeometry 

#### [](#CircleOutlineGeometry) new Cesium.CircleOutlineGeometry(options) 

[engine/Source/Core/CircleOutlineGeometry.js 37](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CircleOutlineGeometry.js#L37) 

 A description of the outline of a circle on the ellipsoid.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description center [Cartesian3](Cartesian3.html)  The circle's center point in the fixed frame. radius number  The radius in meters. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid the circle will be on. height number 0.0 optional The distance in meters between the circle and the ellipsoid surface. granularity number 0.02 optional The angular distance between points on the circle in radians. extrudedHeight number 0.0 optional The distance in meters between the circle's extruded face and the ellipsoid surface. numberOfVerticalLines number 16 optional Number of lines to draw between the top and bottom of an extruded circle. |

##### Throws:

* [DeveloperError](DeveloperError.html): radius must be greater than zero.
* [DeveloperError](DeveloperError.html): granularity must be greater than zero.

##### Example:

```javascript
// Create a circle.
const circle = new Cesium.CircleOutlineGeometry({
  center : Cesium.Cartesian3.fromDegrees(-75.59777, 40.03883),
  radius : 100000.0
});
const geometry = Cesium.CircleOutlineGeometry.createGeometry(circle);
```

##### See:

* [CircleOutlineGeometry.createGeometry](CircleOutlineGeometry.html#.createGeometry)
* [Packable](Packable.html)

### Members

#### [](#.packedLength) static Cesium.CircleOutlineGeometry.packedLength : number 

[engine/Source/Core/CircleOutlineGeometry.js 63](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CircleOutlineGeometry.js#L63) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.CircleOutlineGeometry.createGeometry(circleGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/CircleOutlineGeometry.js 146](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CircleOutlineGeometry.js#L146) 

 Computes the geometric representation of an outline of a circle on an ellipsoid, including its vertices, indices, and a bounding sphere.

| Name           | Type                                                | Description                  |
| -------------- | --------------------------------------------------- | ---------------------------- |
| circleGeometry | [CircleOutlineGeometry](CircleOutlineGeometry.html) | A description of the circle. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.CircleOutlineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/CircleOutlineGeometry.js 74](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CircleOutlineGeometry.js#L74) 

 Stores the provided instance into the provided array.

| Name          | Type                                                | Default | Description                                                               |
| ------------- | --------------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [CircleOutlineGeometry](CircleOutlineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                      |         | The array to pack into.                                                   |
| startingIndex | number                                              | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.CircleOutlineGeometry.unpack(array, startingIndex, result) → [CircleOutlineGeometry](CircleOutlineGeometry.html) 

[engine/Source/Core/CircleOutlineGeometry.js 110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CircleOutlineGeometry.js#L110) 

 Retrieves an instance from a packed array.

| Name          | Type                                                | Default | Description                                                |
| ------------- | --------------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                      |         | The packed array.                                          |
| startingIndex | number                                              | 0       | optional The starting index of the element to be unpacked. |
| result        | [CircleOutlineGeometry](CircleOutlineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new CircleOutlineGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

