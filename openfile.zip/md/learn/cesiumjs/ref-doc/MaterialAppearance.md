# [![](Images/CesiumLogo.png)](index.html) MaterialAppearance 

#### [](#MaterialAppearance) new Cesium.MaterialAppearance(options) 

[engine/Source/Scene/MaterialAppearance.js 49](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L49) 

 An appearance for arbitrary geometry (as opposed to [EllipsoidSurfaceAppearance](EllipsoidSurfaceAppearance.html), for example) that supports shading with materials.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description flat boolean false optional When true, flat shading is used in the fragment shader, which means lighting is not taking into account. faceForward boolean !options.closed optional When true, the fragment shader flips the surface normal as needed to ensure that the normal faces the viewer to avoid dark spots. This is useful when both sides of a geometry should be shaded like [WallGeometry](WallGeometry.html). translucent boolean true optional When true, the geometry is expected to appear translucent so [MaterialAppearance#renderState](MaterialAppearance.html#renderState) has alpha blending enabled. closed boolean false optional When true, the geometry is expected to be closed so [MaterialAppearance#renderState](MaterialAppearance.html#renderState) has backface culling enabled. materialSupport [MaterialAppearance.MaterialSupportType](MaterialAppearance.html#.MaterialSupportType) MaterialAppearance.MaterialSupport.TEXTURED optional The type of materials that will be supported. material [Material](Material.html) Material.ColorType optional The material used to determine the fragment color. vertexShaderSource string optional Optional GLSL vertex shader source to override the default vertex shader. fragmentShaderSource string optional Optional GLSL fragment shader source to override the default fragment shader. renderState object optional Optional render state to override the default render state. |

##### Example:

```javascript
const primitive = new Cesium.Primitive({
  geometryInstances : new Cesium.GeometryInstance({
    geometry : new Cesium.WallGeometry({
            materialSupport :  Cesium.MaterialAppearance.MaterialSupport.BASIC.vertexFormat,
      // ...
    })
  }),
  appearance : new Cesium.MaterialAppearance({
    material : Cesium.Material.fromType('Color'),
    faceForward : true
  })

});
```

##### Demo:

* [Cesium Sandcastle Material Appearance Demo](https://sandcastle.cesium.com/index.html?src=Materials.html)

##### See:

* [Fabric](https://github.com/CesiumGS/cesium/wiki/Fabric)

### Namespaces

[](namespaces.html#MaterialAppearance.MaterialSupport)[MaterialSupport](MaterialAppearance.MaterialSupport.html)

### Members

#### [](#closed) readonly closed : boolean 

[engine/Source/Scene/MaterialAppearance.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L168) 

 When `true`, the geometry is expected to be closed so[MaterialAppearance#renderState](MaterialAppearance.html#renderState) has backface culling enabled. If the viewer enters the geometry, it will not be visible.

Default Value: `false` 

#### [](#faceForward) readonly faceForward : boolean 

[engine/Source/Scene/MaterialAppearance.js 239](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L239) 

 When `true`, the fragment shader flips the surface normal as needed to ensure that the normal faces the viewer to avoid dark spots. This is useful when both sides of a geometry should be shaded like [WallGeometry](WallGeometry.html).

Default Value: `true` 

#### [](#flat) readonly flat : boolean 

[engine/Source/Scene/MaterialAppearance.js 220](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L220) 

 When `true`, flat shading is used in the fragment shader, which means lighting is not taking into account.

Default Value: `false` 

#### [](#fragmentShaderSource) readonly fragmentShaderSource : string 

[engine/Source/Scene/MaterialAppearance.js 131](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L131) 

 The GLSL source code for the fragment shader. The full fragment shader source is built procedurally taking into account [MaterialAppearance#material](MaterialAppearance.html#material),[MaterialAppearance#flat](MaterialAppearance.html#flat), and [MaterialAppearance#faceForward](MaterialAppearance.html#faceForward). Use [MaterialAppearance#getFragmentShaderSource](MaterialAppearance.html#getFragmentShaderSource) to get the full source.

#### [](#material) material : [Material](Material.html) 

[engine/Source/Scene/MaterialAppearance.js 69](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L69) 

 The material used to determine the fragment color. Unlike other [MaterialAppearance](MaterialAppearance.html)properties, this is not read-only, so an appearance's material can change on the fly.

Default Value: `[Material.ColorType](Material.html#.ColorType)` 

##### See:

* [Fabric](https://github.com/CesiumGS/cesium/wiki/Fabric)

#### [](#materialSupport) readonly materialSupport : [MaterialAppearance.MaterialSupportType](MaterialAppearance.html#.MaterialSupportType) 

[engine/Source/Scene/MaterialAppearance.js 185](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L185) 

 The type of materials supported by this instance. This impacts the required[VertexFormat](VertexFormat.html) and the complexity of the vertex and fragment shaders.

Default Value: `[MaterialAppearance.MaterialSupport.TEXTURED](MaterialAppearance.MaterialSupport.html#.TEXTURED)` 

#### [](#renderState) readonly renderState : object 

[engine/Source/Scene/MaterialAppearance.js 150](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L150) 

 The WebGL fixed-function state to use when rendering the geometry.

The render state can be explicitly defined when constructing a [MaterialAppearance](MaterialAppearance.html)instance, or it is set implicitly via [MaterialAppearance#translucent](MaterialAppearance.html#translucent)and [MaterialAppearance#closed](MaterialAppearance.html#closed).

#### [](#translucent) translucent : boolean 

[engine/Source/Scene/MaterialAppearance.js 80](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L80) 

 When `true`, the geometry is expected to appear translucent.

Default Value: `true` 

#### [](#vertexFormat) readonly vertexFormat : [VertexFormat](VertexFormat.html) 

[engine/Source/Scene/MaterialAppearance.js 203](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L203) 

 The [VertexFormat](VertexFormat.html) that this appearance instance is compatible with. A geometry can have more vertex attributes and still be compatible - at a potential performance cost - but it can't have less.

Default Value: `` `MaterialAppearance.MaterialSupport.TEXTURED.vertexFormat` `` 

#### [](#vertexShaderSource) readonly vertexShaderSource : string 

[engine/Source/Scene/MaterialAppearance.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L114) 

 The GLSL source code for the vertex shader.

### Methods

#### [](#getFragmentShaderSource) getFragmentShaderSource() → string 

[engine/Source/Scene/MaterialAppearance.js 255](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L255) 

 Procedurally creates the full GLSL fragment shader source. For [MaterialAppearance](MaterialAppearance.html), this is derived from [MaterialAppearance#fragmentShaderSource](MaterialAppearance.html#fragmentShaderSource), [MaterialAppearance#material](MaterialAppearance.html#material),[MaterialAppearance#flat](MaterialAppearance.html#flat), and [MaterialAppearance#faceForward](MaterialAppearance.html#faceForward).

##### Returns:

 The full GLSL fragment shader source.

#### [](#getRenderState) getRenderState() → object 

[engine/Source/Scene/MaterialAppearance.js 276](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L276) 

 Creates a render state. This is not the final render state instance; instead, it can contain a subset of render state properties identical to the render state created in the context.

##### Returns:

 The render state.

#### [](#isTranslucent) isTranslucent() → boolean 

[engine/Source/Scene/MaterialAppearance.js 265](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L265) 

 Determines if the geometry is translucent based on [MaterialAppearance#translucent](MaterialAppearance.html#translucent) and [Material#isTranslucent](Material.html#isTranslucent).

##### Returns:

`true` if the appearance is translucent.

### Type Definitions

#### [](#.MaterialSupportType) Cesium.MaterialAppearance.MaterialSupportType

[engine/Source/Scene/MaterialAppearance.js 279](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MaterialAppearance.js#L279) 

##### Properties:

| Name                 | Type                              | Description |
| -------------------- | --------------------------------- | ----------- |
| vertexFormat         | [VertexFormat](VertexFormat.html) |             |
| vertexShaderSource   | string                            |             |
| fragmentShaderSource | string                            |             |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

