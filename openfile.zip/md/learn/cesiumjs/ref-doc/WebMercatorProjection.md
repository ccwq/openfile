# [![](Images/CesiumLogo.png)](index.html) WebMercatorProjection 

#### [](#WebMercatorProjection) new Cesium.WebMercatorProjection(ellipsoid) 

[engine/Source/Core/WebMercatorProjection.js 21](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorProjection.js#L21) 

 The map projection used by Google Maps, Bing Maps, and most of ArcGIS Online, EPSG:3857\. This projection use longitude and latitude expressed with the WGS84 and transforms them to Mercator using the spherical (rather than ellipsoidal) equations.

| Name      | Type                        | Default         | Description             |
| --------- | --------------------------- | --------------- | ----------------------- |
| ellipsoid | [Ellipsoid](Ellipsoid.html) | Ellipsoid.WGS84 | optional The ellipsoid. |

##### See:

* [GeographicProjection](GeographicProjection.html)

### Members

#### [](#.MaximumLatitude) static Cesium.WebMercatorProjection.MaximumLatitude : number 

[engine/Source/Core/WebMercatorProjection.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorProjection.js#L88) 

 The maximum latitude (both North and South) supported by a Web Mercator (EPSG:3857) projection. Technically, the Mercator projection is defined for any latitude up to (but not including) 90 degrees, but it makes sense to cut it off sooner because it grows exponentially with increasing latitude. The logic behind this particular cutoff value, which is the one used by Google Maps, Bing Maps, and Esri, is that it makes the projection square. That is, the rectangle is equal in the X and Y directions. The constant value is computed by calling: WebMercatorProjection.mercatorAngleToGeodeticLatitude(Math.PI)

#### [](#ellipsoid) readonly ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/WebMercatorProjection.js 36](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorProjection.js#L36) 

 Gets the [Ellipsoid](Ellipsoid.html).

### Methods

#### [](#.geodeticLatitudeToMercatorAngle) static Cesium.WebMercatorProjection.geodeticLatitudeToMercatorAngle(latitude) → number 

[engine/Source/Core/WebMercatorProjection.js 63](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorProjection.js#L63) 

 Converts a geodetic latitude in radians, in the range -PI/2 to PI/2, to a Mercator angle in the range -PI to PI.

| Name     | Type   | Description                       |
| -------- | ------ | --------------------------------- |
| latitude | number | The geodetic latitude in radians. |

##### Returns:

 The Mercator angle.

#### [](#.mercatorAngleToGeodeticLatitude) static Cesium.WebMercatorProjection.mercatorAngleToGeodeticLatitude(mercatorAngle) → number 

[engine/Source/Core/WebMercatorProjection.js 50](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorProjection.js#L50) 

 Converts a Mercator angle, in the range -PI to PI, to a geodetic latitude in the range -PI/2 to PI/2.

| Name          | Type   | Description           |
| ------------- | ------ | --------------------- |
| mercatorAngle | number | The angle to convert. |

##### Returns:

 The geodetic latitude in radians.

#### [](#project) project(cartographic, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/WebMercatorProjection.js 101](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorProjection.js#L101) 

 Converts geodetic ellipsoid coordinates, in radians, to the equivalent Web Mercator X, Y, Z coordinates expressed in meters and returned in a [Cartesian3](Cartesian3.html). The height is copied unmodified to the Z coordinate.

| Name         | Type                              | Description                                                                                          |
| ------------ | --------------------------------- | ---------------------------------------------------------------------------------------------------- |
| cartographic | [Cartographic](Cartographic.html) | The cartographic coordinates in radians.                                                             |
| result       | [Cartesian3](Cartesian3.html)     | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The equivalent web mercator X, Y, Z coordinates, in meters.

#### [](#unproject) unproject(cartesian, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/WebMercatorProjection.js 130](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorProjection.js#L130) 

 Converts Web Mercator X, Y coordinates, expressed in meters, to a [Cartographic](Cartographic.html)containing geodetic ellipsoid coordinates. The Z coordinate is copied unmodified to the height.

| Name      | Type                              | Description                                                                                          |
| --------- | --------------------------------- | ---------------------------------------------------------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html)     | The web mercator Cartesian position to unrproject with height (z) in meters.                         |
| result    | [Cartographic](Cartographic.html) | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The equivalent cartographic coordinates.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

