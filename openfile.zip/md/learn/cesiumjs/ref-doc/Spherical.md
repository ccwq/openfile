# [![](Images/CesiumLogo.png)](index.html) Spherical 

#### [](#Spherical) new Cesium.Spherical(clock, cone, magnitude) 

[engine/Source/Core/Spherical.js 15](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L15) 

 A set of curvilinear 3-dimensional coordinates.

| Name      | Type   | Default | Description                                                                                                             |
| --------- | ------ | ------- | ----------------------------------------------------------------------------------------------------------------------- |
| clock     | number | 0.0     | optional The angular coordinate lying in the xy-plane measured from the positive x-axis and toward the positive y-axis. |
| cone      | number | 0.0     | optional The angular coordinate measured from the positive z-axis and toward the negative z-axis.                       |
| magnitude | number | 1.0     | optional The linear coordinate measured from the origin.                                                                |

### Members

#### [](#clock) clock : number 

[engine/Source/Core/Spherical.js 21](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L21) 

 The clock component.

Default Value: `0.0` 

#### [](#cone) cone : number 

[engine/Source/Core/Spherical.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L27) 

 The cone component.

Default Value: `0.0` 

#### [](#magnitude) magnitude : number 

[engine/Source/Core/Spherical.js 33](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L33) 

 The magnitude component.

Default Value: `1.0` 

### Methods

#### [](#.clone) static Cesium.Spherical.clone(spherical, result) → [Spherical](Spherical.html) 

[engine/Source/Core/Spherical.js 70](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L70) 

 Creates a duplicate of a Spherical.

| Name      | Type                        | Description                                                                                |
| --------- | --------------------------- | ------------------------------------------------------------------------------------------ |
| spherical | [Spherical](Spherical.html) | The spherical to clone.                                                                    |
| result    | [Spherical](Spherical.html) | optional The object to store the result into, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter or a new instance if result was undefined. (Returns undefined if spherical is undefined)

#### [](#.equals) static Cesium.Spherical.equals(left, right) → boolean 

[engine/Source/Core/Spherical.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L114) 

 Returns true if the first spherical is equal to the second spherical, false otherwise.

| Name  | Type                        | Description                                   |
| ----- | --------------------------- | --------------------------------------------- |
| left  | [Spherical](Spherical.html) | optional The first Spherical to be compared.  |
| right | [Spherical](Spherical.html) | optional The second Spherical to be compared. |

##### Returns:

 true if the first spherical is equal to the second spherical, false otherwise.

#### [](#.equalsEpsilon) static Cesium.Spherical.equalsEpsilon(left, right, epsilon) → boolean 

[engine/Source/Core/Spherical.js 133](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L133) 

 Returns true if the first spherical is within the provided epsilon of the second spherical, false otherwise.

| Name    | Type                        | Default | Description                              |
| ------- | --------------------------- | ------- | ---------------------------------------- |
| left    | [Spherical](Spherical.html) |         | The first Spherical to be compared.      |
| right   | [Spherical](Spherical.html) |         | The second Spherical to be compared.     |
| epsilon | number                      | 0.0     | optional The epsilon to compare against. |

##### Returns:

 true if the first spherical is within the provided epsilon of the second spherical, false otherwise.

#### [](#.fromCartesian3) static Cesium.Spherical.fromCartesian3(cartesian3, result) → [Spherical](Spherical.html) 

[engine/Source/Core/Spherical.js 43](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L43) 

 Converts the provided Cartesian3 into Spherical coordinates.

| Name       | Type                          | Description                                                                                          |
| ---------- | ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| cartesian3 | [Cartesian3](Cartesian3.html) | The Cartesian3 to be converted to Spherical.                                                         |
| result     | [Spherical](Spherical.html)   | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new instance if one was not provided.

#### [](#.normalize) static Cesium.Spherical.normalize(spherical, result) → [Spherical](Spherical.html) 

[engine/Source/Core/Spherical.js 92](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L92) 

 Computes the normalized version of the provided spherical.

| Name      | Type                        | Description                                                                                |
| --------- | --------------------------- | ------------------------------------------------------------------------------------------ |
| spherical | [Spherical](Spherical.html) | The spherical to be normalized.                                                            |
| result    | [Spherical](Spherical.html) | optional The object to store the result into, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter or a new instance if result was undefined.

#### [](#clone) clone(result) → [Spherical](Spherical.html) 

[engine/Source/Core/Spherical.js 161](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L161) 

 Creates a duplicate of this Spherical.

| Name   | Type                        | Description                                                                                |
| ------ | --------------------------- | ------------------------------------------------------------------------------------------ |
| result | [Spherical](Spherical.html) | optional The object to store the result into, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter or a new instance if result was undefined.

#### [](#equals) equals(other) → boolean 

[engine/Source/Core/Spherical.js 151](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L151) 

 Returns true if this spherical is equal to the provided spherical, false otherwise.

| Name  | Type                        | Description                            |
| ----- | --------------------------- | -------------------------------------- |
| other | [Spherical](Spherical.html) | optional The Spherical to be compared. |

##### Returns:

 true if this spherical is equal to the provided spherical, false otherwise.

#### [](#equalsEpsilon) equalsEpsilon(other, epsilon) → boolean 

[engine/Source/Core/Spherical.js 172](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L172) 

 Returns true if this spherical is within the provided epsilon of the provided spherical, false otherwise.

| Name    | Type                        | Description                     |
| ------- | --------------------------- | ------------------------------- |
| other   | [Spherical](Spherical.html) | The Spherical to be compared.   |
| epsilon | number                      | The epsilon to compare against. |

##### Returns:

 true if this spherical is within the provided epsilon of the provided spherical, false otherwise.

#### [](#toString) toString() → string 

[engine/Source/Core/Spherical.js 181](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Spherical.js#L181) 

 Returns a string representing this instance in the format (clock, cone, magnitude).

##### Returns:

 A string representing this instance.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

