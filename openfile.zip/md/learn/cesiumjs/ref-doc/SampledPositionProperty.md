# [![](Images/CesiumLogo.png)](index.html) SampledPositionProperty 

#### [](#SampledPositionProperty) new Cesium.SampledPositionProperty(referenceFrame, numberOfDerivatives) 

[engine/Source/DataSources/SampledPositionProperty.js 22](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L22) 

 A [SampledProperty](SampledProperty.html) which is also a [PositionProperty](PositionProperty.html).

| Name                | Type                                         | Default              | Description                                                                                          |
| ------------------- | -------------------------------------------- | -------------------- | ---------------------------------------------------------------------------------------------------- |
| referenceFrame      | [ReferenceFrame](global.html#ReferenceFrame) | ReferenceFrame.FIXED | optional The reference frame in which the position is defined.                                       |
| numberOfDerivatives | number                                       | 0                    | optional The number of derivatives that accompany each position; i.e. velocity, acceleration, etc... |

### Members

#### [](#backwardExtrapolationDuration) backwardExtrapolationDuration : number 

[engine/Source/DataSources/SampledPositionProperty.js 172](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L172) 

 Gets or sets the amount of time to extrapolate backward before the property becomes undefined. A value of 0 will extrapolate forever.

Default Value: `0` 

#### [](#backwardExtrapolationType) backwardExtrapolationType : [ExtrapolationType](global.html#ExtrapolationType) 

[engine/Source/DataSources/SampledPositionProperty.js 157](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L157) 

 Gets or sets the type of extrapolation to perform when a value is requested at a time before any available samples.

Default Value: `ExtrapolationType.NONE` 

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/SampledPositionProperty.js 66](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L66) 

 Gets the event that is raised whenever the definition of this property changes. The definition is considered to have changed if a call to getValue would return a different result for the same time.

#### [](#forwardExtrapolationDuration) forwardExtrapolationDuration : number 

[engine/Source/DataSources/SampledPositionProperty.js 142](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L142) 

 Gets or sets the amount of time to extrapolate forward before the property becomes undefined. A value of 0 will extrapolate forever.

Default Value: `0` 

#### [](#forwardExtrapolationType) forwardExtrapolationType : [ExtrapolationType](global.html#ExtrapolationType) 

[engine/Source/DataSources/SampledPositionProperty.js 127](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L127) 

 Gets or sets the type of extrapolation to perform when a value is requested at a time after any available samples.

Default Value: `ExtrapolationType.NONE` 

#### [](#interpolationAlgorithm) readonly interpolationAlgorithm : [InterpolationAlgorithm](InterpolationAlgorithm.html) 

[engine/Source/DataSources/SampledPositionProperty.js 103](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L103) 

 Gets the interpolation algorithm to use when retrieving a value. Call `setInterpolationOptions` to set this.

Default Value: `LinearApproximation` 

#### [](#interpolationDegree) readonly interpolationDegree : number 

[engine/Source/DataSources/SampledPositionProperty.js 90](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L90) 

 Gets the degree of interpolation to perform when retrieving a value. Call `setInterpolationOptions` to set this.

Default Value: `1` 

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/SampledPositionProperty.js 52](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L52) 

 Gets a value indicating if this property is constant. A property is considered constant if getValue always returns the same result for the current definition.

#### [](#numberOfDerivatives) numberOfDerivatives : number 

[engine/Source/DataSources/SampledPositionProperty.js 115](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L115) 

 The number of derivatives contained by this property; i.e. 0 for just position, 1 for velocity, etc.

Default Value: `0` 

#### [](#referenceFrame) referenceFrame : [ReferenceFrame](global.html#ReferenceFrame) 

[engine/Source/DataSources/SampledPositionProperty.js 77](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L77) 

 Gets the reference frame in which the position is defined.

Default Value: `ReferenceFrame.FIXED;` 

### Methods

#### [](#addSample) addSample(time, position, derivatives) 

[engine/Source/DataSources/SampledPositionProperty.js 247](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L247) 

 Adds a new sample.

| Name        | Type                                   | Description                                                   |
| ----------- | -------------------------------------- | ------------------------------------------------------------- |
| time        | [JulianDate](JulianDate.html)          | The sample time.                                              |
| position    | [Cartesian3](Cartesian3.html)          | The position at the provided time.                            |
| derivatives | Array.<[Cartesian3](Cartesian3.html)\> | optional The array of derivative values at the provided time. |

#### [](#addSamples) addSamples(times, positions, derivatives) 

[engine/Source/DataSources/SampledPositionProperty.js 275](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L275) 

 Adds multiple samples via parallel arrays.

| Name        | Type                                   | Description                                                                                                  |
| ----------- | -------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| times       | Array.<[JulianDate](JulianDate.html)\> | An array of JulianDate instances where each index is a sample time.                                          |
| positions   | Array.<[Cartesian3](Cartesian3.html)\> | An array of Cartesian3 position instances, where each value corresponds to the provided time index.          |
| derivatives | Array.<Array>                          | optional An array where each value is another array containing derivatives for the corresponding time index. |

##### Throws:

* [DeveloperError](DeveloperError.html): All arrays must be the same length.

#### [](#addSamplesPackedArray) addSamplesPackedArray(packedSamples, epoch) 

[engine/Source/DataSources/SampledPositionProperty.js 290](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L290) 

 Adds samples as a single packed array where each new sample is represented as a date, followed by the packed representation of the corresponding value and derivatives.

| Name          | Type                          | Description                                                                                                           |
| ------------- | ----------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| packedSamples | Array.<number>                | The array of packed samples.                                                                                          |
| epoch         | [JulianDate](JulianDate.html) | optional If any of the dates in packedSamples are numbers, they are considered an offset from this epoch, in seconds. |

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/SampledPositionProperty.js 323](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L323) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getValue) getValue(time, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/DataSources/SampledPositionProperty.js 191](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L191) 

 Gets the position at the provided time.

| Name   | Type                          | Default          | Description                                                                                      |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | [Cartesian3](Cartesian3.html) |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

#### [](#getValueInReferenceFrame) getValueInReferenceFrame(time, referenceFrame, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/DataSources/SampledPositionProperty.js 206](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L206) 

 Gets the position at the provided time and in the provided reference frame.

| Name           | Type                                         | Description                                                                                      |
| -------------- | -------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| time           | [JulianDate](JulianDate.html)                | The time for which to retrieve the value.                                                        |
| referenceFrame | [ReferenceFrame](global.html#ReferenceFrame) | The desired referenceFrame of the result.                                                        |
| result         | [Cartesian3](Cartesian3.html)                | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

#### [](#removeSample) removeSample(time) → boolean 

[engine/Source/DataSources/SampledPositionProperty.js 303](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L303) 

 Removes a sample at the given time, if present.

| Name | Type                          | Description      |
| ---- | ----------------------------- | ---------------- |
| time | [JulianDate](JulianDate.html) | The sample time. |

##### Returns:

`true` if a sample at time was removed, `false` otherwise.

#### [](#removeSamples) removeSamples(time) 

[engine/Source/DataSources/SampledPositionProperty.js 312](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L312) 

 Removes all samples for the given time interval.

| Name | Type                              | Description                                        |
| ---- | --------------------------------- | -------------------------------------------------- |
| time | [TimeInterval](TimeInterval.html) | The time interval for which to remove all samples. |

#### [](#setInterpolationOptions) setInterpolationOptions(options) 

[engine/Source/DataSources/SampledPositionProperty.js 236](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledPositionProperty.js#L236) 

 Sets the algorithm and degree to use when interpolating a position.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                 |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Description interpolationAlgorithm [InterpolationAlgorithm](InterpolationAlgorithm.html) optional The new interpolation algorithm. If undefined, the existing property will be unchanged. interpolationDegree number optional The new interpolation degree. If undefined, the existing property will be unchanged. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

