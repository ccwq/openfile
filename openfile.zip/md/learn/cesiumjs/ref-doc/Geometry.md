# [![](Images/CesiumLogo.png)](index.html) Geometry 

#### [](#Geometry) new Cesium.Geometry(options) 

[engine/Source/Core/Geometry.js 67](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Geometry.js#L67) 

 A geometry representation with attributes forming vertices and optional index data defining primitives. Geometries and an [Appearance](Appearance.html), which describes the shading, can be assigned to a [Primitive](Primitive.html) for visualization. A `Primitive` can be created from many heterogeneous - in many cases - geometries for performance.

Geometries can be transformed and optimized using functions in [GeometryPipeline](GeometryPipeline.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | Object with the following properties: Name Type Default Description attributes [GeometryAttributes](GeometryAttributes.html)  Attributes, which make up the geometry's vertices. primitiveType [PrimitiveType](global.html#PrimitiveType) PrimitiveType.TRIANGLES optional The type of primitives in the geometry. indices Uint16Array\|Uint32Array optional Optional index data that determines the primitives in the geometry. boundingSphere [BoundingSphere](BoundingSphere.html) optional An optional bounding sphere that fully enclosed the geometry. |

##### Example:

```javascript
// Create geometry with a position attribute and indexed lines.
const positions = new Float64Array([
  0.0, 0.0, 0.0,
  7500000.0, 0.0, 0.0,
  0.0, 7500000.0, 0.0
]);

const geometry = new Cesium.Geometry({
  attributes : {
    position : new Cesium.GeometryAttribute({
      componentDatatype : Cesium.ComponentDatatype.DOUBLE,
      componentsPerAttribute : 3,
      values : positions
    })
  },
  indices : new Uint16Array([0, 1, 1, 2, 2, 0]),
  primitiveType : Cesium.PrimitiveType.LINES,
  boundingSphere : Cesium.BoundingSphere.fromVertices(positions)
});
```

##### Demo:

* [Geometry and Appearances Demo](https://sandcastle.cesium.com/index.html?src=Geometry%2520and%2520Appearances.html)

##### See:

* [PolygonGeometry](PolygonGeometry.html)
* [RectangleGeometry](RectangleGeometry.html)
* [EllipseGeometry](EllipseGeometry.html)
* [CircleGeometry](CircleGeometry.html)
* [WallGeometry](WallGeometry.html)
* [SimplePolylineGeometry](SimplePolylineGeometry.html)
* [BoxGeometry](BoxGeometry.html)
* [EllipsoidGeometry](EllipsoidGeometry.html)

### Members

#### [](#attributes) attributes : [GeometryAttributes](GeometryAttributes.html) 

[engine/Source/Core/Geometry.js 118](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Geometry.js#L118) 

 Attributes, which make up the geometry's vertices. Each property in this object corresponds to a[GeometryAttribute](GeometryAttribute.html) containing the attribute's data.

Attributes are always stored non-interleaved in a Geometry.

There are reserved attribute names with well-known semantics. The following attributes are created by a Geometry (depending on the provided [VertexFormat](VertexFormat.html).
* `position` \- 3D vertex position. 64-bit floating-point (for precision). 3 components per attribute. See [VertexFormat#position](VertexFormat.html#position).
* `normal` \- Normal (normalized), commonly used for lighting. 32-bit floating-point. 3 components per attribute. See [VertexFormat#normal](VertexFormat.html#normal).
* `st` \- 2D texture coordinate. 32-bit floating-point. 2 components per attribute. See [VertexFormat#st](VertexFormat.html#st).
* `bitangent` \- Bitangent (normalized), used for tangent-space effects like bump mapping. 32-bit floating-point. 3 components per attribute. See [VertexFormat#bitangent](VertexFormat.html#bitangent).
* `tangent` \- Tangent (normalized), used for tangent-space effects like bump mapping. 32-bit floating-point. 3 components per attribute. See [VertexFormat#tangent](VertexFormat.html#tangent).

The following attribute names are generally not created by a Geometry, but are added to a Geometry by a [Primitive](Primitive.html) or [GeometryPipeline](GeometryPipeline.html) functions to prepare the geometry for rendering.
* `position3DHigh` \- High 32 bits for encoded 64-bit position computed with [GeometryPipeline.encodeAttribute](GeometryPipeline.html#.encodeAttribute). 32-bit floating-point. 4 components per attribute.
* `position3DLow` \- Low 32 bits for encoded 64-bit position computed with [GeometryPipeline.encodeAttribute](GeometryPipeline.html#.encodeAttribute). 32-bit floating-point. 4 components per attribute.
* `position2DHigh` \- High 32 bits for encoded 64-bit 2D (Columbus view) position computed with [GeometryPipeline.encodeAttribute](GeometryPipeline.html#.encodeAttribute). 32-bit floating-point. 4 components per attribute.
* `position2DLow` \- Low 32 bits for encoded 64-bit 2D (Columbus view) position computed with [GeometryPipeline.encodeAttribute](GeometryPipeline.html#.encodeAttribute). 32-bit floating-point. 4 components per attribute.
* `color` \- RGBA color (normalized) usually from `GeometryInstance#color`. 32-bit floating-point. 4 components per attribute.
* `pickColor` \- RGBA color used for picking. 32-bit floating-point. 4 components per attribute.

##### Example:

```javascript
geometry.attributes.position = new Cesium.GeometryAttribute({
  componentDatatype : Cesium.ComponentDatatype.FLOAT,
  componentsPerAttribute : 3,
  values : new Float32Array(0)
});
```

##### See:

* [GeometryAttribute](GeometryAttribute.html)
* [VertexFormat](VertexFormat.html)

#### [](#boundingSphere) boundingSphere : [BoundingSphere](BoundingSphere.html)|undefined 

[engine/Source/Core/Geometry.js 151](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Geometry.js#L151) 

 An optional bounding sphere that fully encloses the geometry. This is commonly used for culling.

Default Value: `undefined` 

#### [](#indices) indices : Array|undefined 

[engine/Source/Core/Geometry.js 128](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Geometry.js#L128) 

 Optional index data that - along with [Geometry#primitiveType](Geometry.html#primitiveType) \- determines the primitives in the geometry.

Default Value: `undefined` 

#### [](#primitiveType) primitiveType : [PrimitiveType](global.html#PrimitiveType)|undefined 

[engine/Source/Core/Geometry.js 138](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Geometry.js#L138) 

 The type of primitives in the geometry. This is most often [PrimitiveType.TRIANGLES](global.html#PrimitiveType#.TRIANGLES), but can varying based on the specific geometry.

Default Value: `PrimitiveType.TRIANGLES` 

### Methods

#### [](#.computeNumberOfVertices) static Cesium.Geometry.computeNumberOfVertices(geometry) → number 

[engine/Source/Core/Geometry.js 180](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Geometry.js#L180) 

 Computes the number of vertices in a geometry. The runtime is linear with respect to the number of attributes in a vertex, not the number of vertices.

| Name     | Type                      | Description   |
| -------- | ------------------------- | ------------- |
| geometry | [Geometry](Geometry.html) | The geometry. |

##### Returns:

 The number of vertices in the geometry.

##### Example:

```javascript
const numVertices = Cesium.Geometry.computeNumberOfVertices(geometry);
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

