# [![](Images/CesiumLogo.png)](index.html) ReferenceProperty 

#### [](#ReferenceProperty) new Cesium.ReferenceProperty(targetCollection, targetId, targetPropertyNames) 

[engine/Source/DataSources/ReferenceProperty.js 90](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L90) 

 A [Property](Property.html) which transparently links to another property on a provided object.

| Name                | Type                                      | Description                                                        |
| ------------------- | ----------------------------------------- | ------------------------------------------------------------------ |
| targetCollection    | [EntityCollection](EntityCollection.html) | The entity collection which will be used to resolve the reference. |
| targetId            | string                                    | The id of the entity which is being referenced.                    |
| targetPropertyNames | Array.<string>                            | The names of the property on the target entity which we will use.  |

##### Example:

```javascript
const collection = new Cesium.EntityCollection();

//Create a new entity and assign a billboard scale.
const object1 = new Cesium.Entity({id:'object1'});
object1.billboard = new Cesium.BillboardGraphics();
object1.billboard.scale = new Cesium.ConstantProperty(2.0);
collection.add(object1);

//Create a second entity and reference the scale from the first one.
const object2 = new Cesium.Entity({id:'object2'});
object2.model = new Cesium.ModelGraphics();
object2.model.scale = new Cesium.ReferenceProperty(collection, 'object1', ['billboard', 'scale']);
collection.add(object2);

//Create a third object, but use the fromString helper function.
const object3 = new Cesium.Entity({id:'object3'});
object3.billboard = new Cesium.BillboardGraphics();
object3.billboard.scale = Cesium.ReferenceProperty.fromString(collection, 'object1#billboard.scale');
collection.add(object3);

//You can refer to an entity with a # or . in id and property names by escaping them.
const object4 = new Cesium.Entity({id:'#object.4'});
object4.billboard = new Cesium.BillboardGraphics();
object4.billboard.scale = new Cesium.ConstantProperty(2.0);
collection.add(object4);

const object5 = new Cesium.Entity({id:'object5'});
object5.billboard = new Cesium.BillboardGraphics();
object5.billboard.scale = Cesium.ReferenceProperty.fromString(collection, '\\#object\\.4#billboard.scale');
collection.add(object5);
```

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/ReferenceProperty.js 141](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L141) 

 Gets the event that is raised whenever the definition of this property changes. The definition is changed whenever the referenced property's definition is changed.

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/ReferenceProperty.js 129](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L129) 

 Gets a value indicating if this property is constant.

#### [](#referenceFrame) readonly referenceFrame : [ReferenceFrame](global.html#ReferenceFrame) 

[engine/Source/DataSources/ReferenceProperty.js 153](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L153) 

 Gets the reference frame that the position is defined in. This property is only valid if the referenced property is a [PositionProperty](PositionProperty.html).

#### [](#resolvedProperty) readonly resolvedProperty : [Property](Property.html)|undefined 

[engine/Source/DataSources/ReferenceProperty.js 198](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L198) 

 Gets the resolved instance of the underlying referenced property.

#### [](#targetCollection) readonly targetCollection : [EntityCollection](EntityCollection.html) 

[engine/Source/DataSources/ReferenceProperty.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L176) 

 Gets the collection containing the entity being referenced.

#### [](#targetId) readonly targetId : string 

[engine/Source/DataSources/ReferenceProperty.js 165](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L165) 

 Gets the id of the entity being referenced.

#### [](#targetPropertyNames) readonly targetPropertyNames : Object 

[engine/Source/DataSources/ReferenceProperty.js 187](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L187) 

 Gets the array of property names used to retrieve the referenced property.

### Methods

#### [](#.fromString) static Cesium.ReferenceProperty.fromString(targetCollection, referenceString) → [ReferenceProperty](ReferenceProperty.html) 

[engine/Source/DataSources/ReferenceProperty.js 218](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L218) 

 Creates a new instance given the entity collection that will be used to resolve it and a string indicating the target entity id and property. The format of the string is "objectId#foo.bar", where # separates the id from property path and . separates sub-properties. If the reference identifier or or any sub-properties contains a # . or \\ they must be escaped.

| Name             | Type                                      | Description |
| ---------------- | ----------------------------------------- | ----------- |
| targetCollection | [EntityCollection](EntityCollection.html) |             |
| referenceString  | string                                    |             |

##### Returns:

 A new instance of ReferenceProperty.

##### Throws:

* [DeveloperError](DeveloperError.html): invalid referenceString.

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/ReferenceProperty.js 314](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L314) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getType) getType(time) → string 

[engine/Source/DataSources/ReferenceProperty.js 302](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L302) 

 Gets the [Material](Material.html) type at the provided time. This method is only valid if the property being referenced is a [MaterialProperty](MaterialProperty.html).

| Name | Type                          | Description                              |
| ---- | ----------------------------- | ---------------------------------------- |
| time | [JulianDate](JulianDate.html) | The time for which to retrieve the type. |

##### Returns:

 The type of material.

#### [](#getValue) getValue(time, result) → object 

[engine/Source/DataSources/ReferenceProperty.js 267](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L267) 

 Gets the value of the property at the provided time.

| Name   | Type                          | Default          | Description                                                                                      |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | object                        |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

#### [](#getValueInReferenceFrame) getValueInReferenceFrame(time, referenceFrame, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/DataSources/ReferenceProperty.js 284](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ReferenceProperty.js#L284) 

 Gets the value of the property at the provided time and in the provided reference frame. This method is only valid if the property being referenced is a [PositionProperty](PositionProperty.html).

| Name           | Type                                         | Description                                                                                      |
| -------------- | -------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| time           | [JulianDate](JulianDate.html)                | The time for which to retrieve the value.                                                        |
| referenceFrame | [ReferenceFrame](global.html#ReferenceFrame) | The desired referenceFrame of the result.                                                        |
| result         | [Cartesian3](Cartesian3.html)                | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

