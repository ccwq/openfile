# [![](Images/CesiumLogo.png)](index.html) Cesium3DTileStyle 

#### [](#Cesium3DTileStyle) new Cesium.Cesium3DTileStyle(style) 

[engine/Source/Scene/Cesium3DTileStyle.js 44](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L44) 

 A style that is applied to a [Cesium3DTileset](Cesium3DTileset.html).

Evaluates an expression defined using the[3D Tiles Styling language](https://github.com/CesiumGS/3d-tiles/tree/main/specification/Styling).

| Name  | Type   | Description                          |
| ----- | ------ | ------------------------------------ |
| style | object | optional An object defining a style. |

##### Examples:

```javascript
tileset.style = new Cesium.Cesium3DTileStyle({
    color : {
        conditions : [
            ['${Height} >= 100', 'color("purple", 0.5)'],
            ['${Height} >= 50', 'color("red")'],
            ['true', 'color("blue")']
        ]
    },
    show : '${Height} > 0',
    meta : {
        description : '"Building id ${id} has height ${Height}."'
    }
});
```

```javascript
tileset.style = new Cesium.Cesium3DTileStyle({
    color : 'vec4(${Temperature})',
    pointSize : '${Temperature} * 2.0'
});
```

##### See:

* [3D Tiles Styling language](https://github.com/CesiumGS/3d-tiles/tree/main/specification/Styling)

### Members

#### [](#anchorLineColor) anchorLineColor : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 1032](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L1032) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `anchorLineColor` property. Alternatively a string or object defining a color style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Color`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override anchorLineColor expression with a string
style.anchorLineColor = 'color("blue")';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override anchorLineColor expression with a condition
style.anchorLineColor = {
    conditions : [
        ['${height} > 2', 'color("cyan")'],
        ['true', 'color("blue")']
    ]
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#anchorLineEnabled) anchorLineEnabled : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 989](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L989) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `anchorLineEnabled` property. Alternatively a string or object defining a boolean style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Boolean`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override anchorLineEnabled expression with a string
style.anchorLineEnabled = 'true';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override anchorLineEnabled expression with a condition
style.anchorLineEnabled = {
    conditions : [
        ['${height} > 2', 'true'],
        ['true', 'false']
    ]
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#backgroundColor) backgroundColor : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 726](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L726) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `backgroundColor` property. Alternatively a string or object defining a color style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Color`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override backgroundColor expression with a string
style.backgroundColor = 'color("blue")';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override backgroundColor expression with a condition
style.backgroundColor = {
    conditions : [
        ['${height} > 2', 'color("cyan")'],
        ['true', 'color("blue")']
    ]
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#backgroundEnabled) backgroundEnabled : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 803](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L803) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `backgroundEnabled` property. Alternatively a string or object defining a boolean style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Boolean`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override backgroundEnabled expression with a string
style.backgroundEnabled = 'true';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override backgroundEnabled expression with a condition
style.backgroundEnabled = {
    conditions : [
        ['${height} > 2', 'true'],
        ['true', 'false']
    ]
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#backgroundPadding) backgroundPadding : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 760](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L760) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `backgroundPadding` property. Alternatively a string or object defining a vec2 style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Cartesian2`.

This expression is only applicable to point features in a Vector tile.

##### Example:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override backgroundPadding expression with a string
style.backgroundPadding = 'vec2(5.0, 7.0)';
style.backgroundPadding.evaluate(feature); // returns a Cartesian2
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#color) color : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 288](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L288) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `color` property. Alternatively a string or object defining a color style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Color`.

This expression is applicable to all tile formats.

##### Examples:

```javascript
const style = new Cesium3DTileStyle({
    color : '(${Temperature} > 90) ? color("red") : color("white")'
});
style.color.evaluateColor(feature, result); // returns a Cesium.Color object
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override color expression with a custom function
style.color = {
    evaluateColor : function(feature, result) {
        return Cesium.Color.clone(Cesium.Color.WHITE, result);
    }
};
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override color expression with a string
style.color = 'color("blue")';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override color expression with a condition
style.color = {
    conditions : [
        ['${height} > 2', 'color("cyan")'],
        ['true', 'color("blue")']
    ]
};
```

#### [](#disableDepthTestDistance) disableDepthTestDistance : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 1107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L1107) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `disableDepthTestDistance` property. Alternatively a string or object defining a number style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Number`.

This expression is only applicable to point features in a Vector tile.

##### Example:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override disableDepthTestDistance expression with a string
style.disableDepthTestDistance = '1000.0';
style.disableDepthTestDistance.evaluate(feature); // returns a Number
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 905](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L905) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `distanceDisplayCondition` property. Alternatively a string or object defining a vec2 style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Cartesian2`.

This expression is only applicable to point features in a Vector tile.

##### Example:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override distanceDisplayCondition expression with a string
style.distanceDisplayCondition = 'vec2(0.0, 5.5e6)';
style.distanceDisplayCondition.evaluate(feature); // returns a Cartesian2
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#font) font : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 603](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L603) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `font` property. Alternatively a string or object defining a string style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `String`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium3DTileStyle({
    font : '(${Temperature} > 90) ? "30px Helvetica" : "24px Helvetica"'
});
style.font.evaluate(feature); // returns a String
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override font expression with a custom function
style.font = {
    evaluate : function(feature) {
        return '24px Helvetica';
    }
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#heightOffset) heightOffset : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 948](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L948) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `heightOffset` property. Alternatively a string or object defining a number style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Number`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override heightOffset expression with a string
style.heightOffset = '2.0';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override heightOffset expression with a condition
style.heightOffset = {
    conditions : [
        ['${height} > 2', '4.0'],
        ['true', '2.0']
    ]
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#horizontalOrigin) horizontalOrigin : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 1150](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L1150) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `horizontalOrigin` property. Alternatively a string or object defining a number style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `HorizontalOrigin`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium3DTileStyle({
    horizontalOrigin : HorizontalOrigin.LEFT
});
style.horizontalOrigin.evaluate(feature); // returns a HorizontalOrigin
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override horizontalOrigin expression with a custom function
style.horizontalOrigin = {
    evaluate : function(feature) {
        return HorizontalOrigin.CENTER;
    }
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#image) image : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 1075](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L1075) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `image` property. Alternatively a string or object defining a string style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `String`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium3DTileStyle({
    image : '(${Temperature} > 90) ? "/url/to/image1" : "/url/to/image2"'
});
style.image.evaluate(feature); // returns a String
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override image expression with a custom function
style.image = {
    evaluate : function(feature) {
        return '/url/to/image';
    }
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#labelColor) labelColor : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 476](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L476) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `labelColor` property. Alternatively a string or object defining a color style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Color`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override labelColor expression with a string
style.labelColor = 'color("blue")';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override labelColor expression with a condition
style.labelColor = {
    conditions : [
        ['${height} > 2', 'color("cyan")'],
        ['true', 'color("blue")']
    ]
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#labelHorizontalOrigin) labelHorizontalOrigin : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 1234](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L1234) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `labelHorizontalOrigin` property. Alternatively a string or object defining a number style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `HorizontalOrigin`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium3DTileStyle({
    labelHorizontalOrigin : HorizontalOrigin.LEFT
});
style.labelHorizontalOrigin.evaluate(feature); // returns a HorizontalOrigin
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override labelHorizontalOrigin expression with a custom function
style.labelHorizontalOrigin = {
    evaluate : function(feature) {
        return HorizontalOrigin.CENTER;
    }
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#labelOutlineColor) labelOutlineColor : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 517](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L517) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `labelOutlineColor` property. Alternatively a string or object defining a color style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Color`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override labelOutlineColor expression with a string
style.labelOutlineColor = 'color("blue")';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override labelOutlineColor expression with a condition
style.labelOutlineColor = {
    conditions : [
        ['${height} > 2', 'color("cyan")'],
        ['true', 'color("blue")']
    ]
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#labelOutlineWidth) labelOutlineWidth : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 560](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L560) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `labelOutlineWidth` property. Alternatively a string or object defining a number style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Number`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override labelOutlineWidth expression with a string
style.labelOutlineWidth = '5';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override labelOutlineWidth expression with a condition
style.labelOutlineWidth = {
    conditions : [
        ['${height} > 2', '5'],
        ['true', '0']
    ]
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#labelStyle) labelStyle : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 644](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L644) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `label style` property. Alternatively a string or object defining a number style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `LabelStyle`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium3DTileStyle({
    labelStyle : `(\${Temperature} > 90) ? ${LabelStyle.FILL_AND_OUTLINE} : ${LabelStyle.FILL}`
});
style.labelStyle.evaluate(feature); // returns a LabelStyle
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override labelStyle expression with a custom function
style.labelStyle = {
    evaluate : function(feature) {
        return LabelStyle.FILL;
    }
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#labelText) labelText : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 685](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L685) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `labelText` property. Alternatively a string or object defining a string style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `String`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium3DTileStyle({
    labelText : '(${Temperature} > 90) ? ">90" : "<=90"'
});
style.labelText.evaluate(feature); // returns a String
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override labelText expression with a custom function
style.labelText = {
    evaluate : function(feature) {
        return 'Example label text';
    }
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#labelVerticalOrigin) labelVerticalOrigin : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 1277](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L1277) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `labelVerticalOrigin` property. Alternatively a string or object defining a number style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `VerticalOrigin`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium3DTileStyle({
    labelVerticalOrigin : VerticalOrigin.TOP
});
style.labelVerticalOrigin.evaluate(feature); // returns a VerticalOrigin
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override labelVerticalOrigin expression with a custom function
style.labelVerticalOrigin = {
    evaluate : function(feature) {
        return VerticalOrigin.CENTER;
    }
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#meta) meta : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 1305](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L1305) 

 Gets or sets the object containing application-specific expression that can be explicitly evaluated, e.g., for display in a UI.

##### Example:

```javascript
const style = new Cesium3DTileStyle({
    meta : {
        description : '"Building id ${id} has height ${Height}."'
    }
});
style.meta.description.evaluate(feature); // returns a String with the substituted variables
```

#### [](#pointOutlineColor) pointOutlineColor : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 390](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L390) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `pointOutlineColor` property. Alternatively a string or object defining a color style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Color`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override pointOutlineColor expression with a string
style.pointOutlineColor = 'color("blue")';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override pointOutlineColor expression with a condition
style.pointOutlineColor = {
    conditions : [
        ['${height} > 2', 'color("cyan")'],
        ['true', 'color("blue")']
    ]
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#pointOutlineWidth) pointOutlineWidth : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 433](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L433) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `pointOutlineWidth` property. Alternatively a string or object defining a number style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Number`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override pointOutlineWidth expression with a string
style.pointOutlineWidth = '5';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override pointOutlineWidth expression with a condition
style.pointOutlineWidth = {
    conditions : [
        ['${height} > 2', '5'],
        ['true', '0']
    ]
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#pointSize) pointSize : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 348](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L348) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `pointSize` property. Alternatively a string or object defining a point size style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Number`.

This expression is only applicable to point features in a Vector tile or a Point Cloud tile.

##### Examples:

```javascript
const style = new Cesium3DTileStyle({
    pointSize : '(${Temperature} > 90) ? 2.0 : 1.0'
});
style.pointSize.evaluate(feature); // returns a Number
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override pointSize expression with a custom function
style.pointSize = {
    evaluate : function(feature) {
        return 1.0;
    }
};
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override pointSize expression with a number
style.pointSize = 1.0;
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override pointSize expression with a string
style.pointSize = '${height} / 10';
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override pointSize expression with a condition
style.pointSize =  {
    conditions : [
        ['${height} > 2', '1.0'],
        ['true', '2.0']
    ]
};
```

#### [](#scaleByDistance) scaleByDistance : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 837](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L837) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `scaleByDistance` property. Alternatively a string or object defining a vec4 style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Cartesian4`.

This expression is only applicable to point features in a Vector tile.

##### Example:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override scaleByDistance expression with a string
style.scaleByDistance = 'vec4(1.5e2, 2.0, 1.5e7, 0.5)';
style.scaleByDistance.evaluate(feature); // returns a Cartesian4
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#show) show : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 233](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L233) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `show` property. Alternatively a boolean, string, or object defining a show style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return or convert to a `Boolean`.

This expression is applicable to all tile formats.

##### Examples:

```javascript
const style = new Cesium3DTileStyle({
    show : '(regExp("^Chest").test(${County})) && (${YearBuilt} >= 1970)'
});
style.show.evaluate(feature); // returns true or false depending on the feature's properties
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override show expression with a custom function
style.show = {
    evaluate : function(feature) {
        return true;
    }
};
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override show expression with a boolean
style.show = true;
};
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override show expression with a string
style.show = '${Height} > 0';
};
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override show expression with a condition
style.show = {
    conditions: [
        ['${height} > 2', 'false'],
        ['true', 'true']
    ];
};
```

#### [](#style) readonly style : object 

[engine/Source/Scene/Cesium3DTileStyle.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L176) 

 Gets the object defining the style using the[3D Tiles Styling language](https://github.com/CesiumGS/3d-tiles/tree/main/specification/Styling).

Default Value: `{}` 

#### [](#translucencyByDistance) translucencyByDistance : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 871](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L871) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `translucencyByDistance` property. Alternatively a string or object defining a vec4 style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `Cartesian4`.

This expression is only applicable to point features in a Vector tile.

##### Example:

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override translucencyByDistance expression with a string
style.translucencyByDistance = 'vec4(1.5e2, 1.0, 1.5e7, 0.2)';
style.translucencyByDistance.evaluate(feature); // returns a Cartesian4
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#verticalOrigin) verticalOrigin : [StyleExpression](StyleExpression.html) 

[engine/Source/Scene/Cesium3DTileStyle.js 1193](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileStyle.js#L1193) 

 Gets or sets the [StyleExpression](StyleExpression.html) object used to evaluate the style's `verticalOrigin` property. Alternatively a string or object defining a number style can be used. The getter will return the internal [Expression](Expression.html) or [ConditionsExpression](ConditionsExpression.html), which may differ from the value provided to the setter.

The expression must return a `VerticalOrigin`.

This expression is only applicable to point features in a Vector tile.

##### Examples:

```javascript
const style = new Cesium3DTileStyle({
    verticalOrigin : VerticalOrigin.TOP
});
style.verticalOrigin.evaluate(feature); // returns a VerticalOrigin
```

```javascript
const style = new Cesium.Cesium3DTileStyle();
// Override verticalOrigin expression with a custom function
style.verticalOrigin = {
    evaluate : function(feature) {
        return VerticalOrigin.CENTER;
    }
};
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

