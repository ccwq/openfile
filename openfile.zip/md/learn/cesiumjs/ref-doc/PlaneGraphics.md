# [![](Images/CesiumLogo.png)](index.html) PlaneGraphics 

#### [](#PlaneGraphics) new Cesium.PlaneGraphics(options) 

[engine/Source/DataSources/PlaneGraphics.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L35) 

 Describes a plane. The center position and orientation are determined by the containing [Entity](Entity.html).

| Name    | Type                                                                       | Description                                       |
| ------- | -------------------------------------------------------------------------- | ------------------------------------------------- |
| options | [PlaneGraphics.ConstructorOptions](PlaneGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle Plane Demo](https://sandcastle.cesium.com/index.html?src=Plane.html)

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/PlaneGraphics.js 68](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L68) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#dimensions) dimensions : [Property](Property.html)|undefined 

[engine/Source/DataSources/PlaneGraphics.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L96) 

 Gets or sets the [Cartesian2](Cartesian2.html) Property specifying the width and height of the plane.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/PlaneGraphics.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L155) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this plane will be displayed.

#### [](#fill) fill : [Property](Property.html)|undefined 

[engine/Source/DataSources/PlaneGraphics.js 104](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L104) 

 Gets or sets the boolean Property specifying whether the plane is filled with the provided material.

Default Value: `true` 

#### [](#material) material : [MaterialProperty](MaterialProperty.html) 

[engine/Source/DataSources/PlaneGraphics.js 112](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L112) 

 Gets or sets the material used to fill the plane.

Default Value: `Color.WHITE` 

#### [](#outline) outline : [Property](Property.html)|undefined 

[engine/Source/DataSources/PlaneGraphics.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L120) 

 Gets or sets the Property specifying whether the plane is outlined.

Default Value: `false` 

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/PlaneGraphics.js 128](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L128) 

 Gets or sets the Property specifying the [Color](Color.html) of the outline.

Default Value: `Color.BLACK` 

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/PlaneGraphics.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L139) 

 Gets or sets the numeric Property specifying the width of the outline.

Note: This property will be ignored on all major browsers on Windows platforms. For details, see (@link https://github.com/CesiumGS/cesium/issues/40}.

Default Value: `1.0` 

#### [](#plane) plane : [Property](Property.html)|undefined 

[engine/Source/DataSources/PlaneGraphics.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L88) 

 Gets or sets the [Plane](Plane.html) Property specifying the normal and distance of the plane.

#### [](#shadows) shadows : [Property](Property.html)|undefined 

[engine/Source/DataSources/PlaneGraphics.js 148](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L148) 

 Get or sets the enum Property specifying whether the plane casts or receives shadows from light sources.

Default Value: `ShadowMode.DISABLED` 

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/PlaneGraphics.js 80](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L80) 

 Gets or sets the boolean Property specifying the visibility of the plane.

Default Value: `true` 

### Methods

#### [](#clone) clone(result) → [PlaneGraphics](PlaneGraphics.html) 

[engine/Source/DataSources/PlaneGraphics.js 166](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L166) 

 Duplicates this instance.

| Name   | Type                                | Description                                         |
| ------ | ----------------------------------- | --------------------------------------------------- |
| result | [PlaneGraphics](PlaneGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/PlaneGraphics.js 189](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L189) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                | Description                               |
| ------ | ----------------------------------- | ----------------------------------------- |
| source | [PlaneGraphics](PlaneGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.PlaneGraphics.ConstructorOptions

[engine/Source/DataSources/PlaneGraphics.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PlaneGraphics.js#L8) 

 Initialization options for the PlaneGraphics constructor

##### Properties:

| Name                     | Type                                                                                 | Attributes | Default             | Description                                                                                 |
| ------------------------ | ------------------------------------------------------------------------------------ | ---------- | ------------------- | ------------------------------------------------------------------------------------------- |
| show                     | [Property](Property.html)\|boolean                                                   | <optional> | true                | A boolean Property specifying the visibility of the plane.                                  |
| plane                    | [Property](Property.html)\|[Plane](Plane.html)                                       | <optional> |                     | A [Plane](Plane.html) Property specifying the normal and distance for the plane.            |
| dimensions               | [Property](Property.html)\|[Cartesian2](Cartesian2.html)                             | <optional> |                     | A [Cartesian2](Cartesian2.html) Property specifying the width and height of the plane.      |
| fill                     | [Property](Property.html)\|boolean                                                   | <optional> | true                | A boolean Property specifying whether the plane is filled with the provided material.       |
| material                 | [MaterialProperty](MaterialProperty.html)\|[Color](Color.html)                       | <optional> | Color.WHITE         | A Property specifying the material used to fill the plane.                                  |
| outline                  | [Property](Property.html)\|boolean                                                   | <optional> | false               | A boolean Property specifying whether the plane is outlined.                                |
| outlineColor             | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.BLACK         | A Property specifying the [Color](Color.html) of the outline.                               |
| outlineWidth             | [Property](Property.html)\|number                                                    | <optional> | 1.0                 | A numeric Property specifying the width of the outline.                                     |
| shadows                  | [Property](Property.html)\|[ShadowMode](global.html#ShadowMode)                      | <optional> | ShadowMode.DISABLED | An enum Property specifying whether the plane casts or receives shadows from light sources. |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                     | A Property specifying at what distance from the camera that this plane will be displayed.   |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

