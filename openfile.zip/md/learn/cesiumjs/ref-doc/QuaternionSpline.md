# [![](Images/CesiumLogo.png)](index.html) QuaternionSpline 

#### [](#QuaternionSpline) new Cesium.QuaternionSpline(options) 

[engine/Source/Core/QuaternionSpline.js 52](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuaternionSpline.js#L52) 

 A spline that uses spherical linear (slerp) interpolation to create a quaternion curve. The generated curve is in the class C1.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                    |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | Object with the following properties: Name Type Description times Array.<number>  An array of strictly increasing, unit-less, floating-point times at each point. The values are in no way connected to the clock time. They are the parameterization for the curve. points Array.<[Quaternion](Quaternion.html)\>  The array of [Quaternion](Quaternion.html) control points. |

##### Throws:

* [DeveloperError](DeveloperError.html): points and times are required
* [DeveloperError](DeveloperError.html): points.length must be greater than or equal to 2.
* [DeveloperError](DeveloperError.html): times.length must be equal to points.length.

##### See:

* [ConstantSpline](ConstantSpline.html)
* [SteppedSpline](SteppedSpline.html)
* [HermiteSpline](HermiteSpline.html)
* [CatmullRomSpline](CatmullRomSpline.html)
* [LinearSpline](LinearSpline.html)
* [MorphWeightSpline](MorphWeightSpline.html)

### Members

#### [](#points) readonly points : Array.<[Quaternion](Quaternion.html)\> 

[engine/Source/Core/QuaternionSpline.js 102](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuaternionSpline.js#L102) 

 An array of [Quaternion](Quaternion.html) control points.

#### [](#times) readonly times : Array.<number> 

[engine/Source/Core/QuaternionSpline.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuaternionSpline.js#L88) 

 An array of times for the control points.

### Methods

#### [](#clampTime) clampTime(time) → number 

[engine/Source/Core/QuaternionSpline.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuaternionSpline.js#L139) 

 Clamps the given time to the period covered by the spline.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The time, clamped to the animation period.

#### [](#evaluate) evaluate(time, result) → [Quaternion](Quaternion.html) 

[engine/Source/Core/QuaternionSpline.js 152](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuaternionSpline.js#L152) 

 Evaluates the curve at a given time.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| time   | number                        | The time at which to evaluate the curve.            |
| result | [Quaternion](Quaternion.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance of the point on the curve at the given time.

##### Throws:

* [DeveloperError](DeveloperError.html): time must be in the range `[t0, tn]`, where `t0` is the first element in the array `times` and `tn` is the last element in the array `times`.

#### [](#findTimeInterval) findTimeInterval(time) → number 

[engine/Source/Core/QuaternionSpline.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuaternionSpline.js#L121) 

 Finds an index `i` in `times` such that the parameter`time` is in the interval `[times[i], times[i + 1]]`.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The index for the element at the start of the interval.

##### Throws:

* [DeveloperError](DeveloperError.html): time must be in the range `[t0, tn]`, where `t0` is the first element in the array `times` and `tn` is the last element in the array `times`.

#### [](#wrapTime) wrapTime(time) → number 

[engine/Source/Core/QuaternionSpline.js 130](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuaternionSpline.js#L130) 

 Wraps the given time to the period covered by the spline.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The time, wrapped around to the updated animation.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

