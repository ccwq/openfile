# [![](Images/CesiumLogo.png)](index.html) ModelAnimationCollection 

#### [](#ModelAnimationCollection) internal constructor new Cesium.ModelAnimationCollection() 

[engine/Source/Scene/Model/ModelAnimationCollection.js 24](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L24) 

Access a model's animations [Model#activeAnimations](Model.html#activeAnimations). Do not call the constructor directly

A collection of active model animations.

##### See:

* [Model#activeAnimations](Model.html#activeAnimations)

### Members

#### [](#animateWhilePaused) animateWhilePaused : boolean 

[engine/Source/Scene/Model/ModelAnimationCollection.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L62) 

 When true, the animation will play even when the scene time is paused. However, whether animation takes place will depend on the animationTime functions assigned to the model's animations. By default, this is based on scene time, so models using the default will not animate regardless of this setting.

Default Value: `false` 

#### [](#animationAdded) animationAdded : [Event](Event.html) 

[engine/Source/Scene/Model/ModelAnimationCollection.js 37](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L37) 

 The event fired when an animation is added to the collection. This can be used, for example, to keep a UI in sync.

Default Value: `new Event()` 

##### Example:

```javascript
model.activeAnimations.animationAdded.addEventListener(function(model, animation) {
  console.log(`Animation added: ${animation.name}`);
});
```

#### [](#animationRemoved) animationRemoved : [Event](Event.html) 

[engine/Source/Scene/Model/ModelAnimationCollection.js 51](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L51) 

 The event fired when an animation is removed from the collection. This can be used, for example, to keep a UI in sync.

Default Value: `new Event()` 

##### Example:

```javascript
model.activeAnimations.animationRemoved.addEventListener(function(model, animation) {
  console.log(`Animation removed: ${animation.name}`);
});
```

#### [](#length) readonly length : number 

[engine/Source/Scene/Model/ModelAnimationCollection.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L78) 

 The number of animations in the collection.

#### [](#model) readonly model : [Model](Model.html) 

[engine/Source/Scene/Model/ModelAnimationCollection.js 92](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L92) 

 The model that owns this animation collection.

### Methods

#### [](#add) add(options) → [ModelAnimation](ModelAnimation.html) 

[engine/Source/Scene/Model/ModelAnimationCollection.js 169](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L169) 

 Creates and adds an animation with the specified initial properties to the collection.

This raises the [ModelAnimationCollection#animationAdded](ModelAnimationCollection.html#animationAdded) event so, for example, a UI can stay in sync.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description name string optional The glTF animation name that identifies the animation. Must be defined if options.index is undefined. index number optional The glTF animation index that identifies the animation. Must be defined if options.name is undefined. startTime [JulianDate](JulianDate.html) optional The scene time to start playing the animation. When this is undefined, the animation starts at the next frame. delay number 0.0 optional The delay, in seconds, from startTime to start playing. This will only affect the animation if options.loop is ModelAnimationLoop.NONE. stopTime [JulianDate](JulianDate.html) optional The scene time to stop playing the animation. When this is undefined, the animation is played for its full duration. removeOnStop boolean false optional When true, the animation is removed after it stops playing. This will only affect the animation if options.loop is ModelAnimationLoop.NONE. multiplier number 1.0 optional Values greater than 1.0 increase the speed that the animation is played relative to the scene clock speed; values less than 1.0 decrease the speed. reverse boolean false optional When true, the animation is played in reverse. loop [ModelAnimationLoop](global.html#ModelAnimationLoop) ModelAnimationLoop.NONE optional Determines if and how the animation is looped. animationTime [ModelAnimation.AnimationTimeCallback](ModelAnimation.html#.AnimationTimeCallback) optional If defined, computes the local animation time for this animation. |

##### Returns:

 The animation that was added to the collection.

##### Throws:

* [DeveloperError](DeveloperError.html): Animations are not loaded. Wait for the [Model#ready](Model.html#ready) to return trues.
* [DeveloperError](DeveloperError.html): options.name must be a valid animation name.
* [DeveloperError](DeveloperError.html): options.index must be a valid animation index.
* [DeveloperError](DeveloperError.html): Either options.name or options.index must be defined.
* [DeveloperError](DeveloperError.html): options.multiplier must be greater than zero.

##### Examples:

```javascript
// Example 1. Add an animation by name
model.activeAnimations.add({
  name : 'animation name'
});
```

```javascript
// Example 2. Add an animation by index
model.activeAnimations.add({
  index : 0
});
```

```javascript
// Example 3. Add an animation and provide all properties and events
const startTime = Cesium.JulianDate.now();

const animation = model.activeAnimations.add({
  name : 'another animation name',
  startTime : startTime,
  delay : 0.0,                                 // Play at startTime (default)
  stopTime : Cesium.JulianDate.addSeconds(startTime, 4.0, new Cesium.JulianDate()),
  removeOnStop : false,                        // Do not remove when animation stops (default)
  multiplier : 2.0,                            // Play at double speed
  reverse : true,                              // Play in reverse
  loop : Cesium.ModelAnimationLoop.REPEAT      // Loop the animation
});

animation.start.addEventListener(function(model, animation) {
  console.log(`Animation started: ${animation.name}`);
});
animation.update.addEventListener(function(model, animation, time) {
  console.log(`Animation updated: ${animation.name}. glTF animation time: ${time}`);
});
animation.stop.addEventListener(function(model, animation) {
  console.log(`Animation stopped: ${animation.name}`);
});
```

#### [](#addAll) addAll(options) → Array.<[ModelAnimation](ModelAnimation.html)\> 

[engine/Source/Scene/Model/ModelAnimationCollection.js 253](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L253) 

 Creates and adds animations with the specified initial properties to the collection for all animations in the model.

This raises the [ModelAnimationCollection#animationAdded](ModelAnimationCollection.html#animationAdded) event for each model so, for example, a UI can stay in sync.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description startTime [JulianDate](JulianDate.html) optional The scene time to start playing the animations. When this is undefined, the animations starts at the next frame. delay number 0.0 optional The delay, in seconds, from startTime to start playing. This will only affect the animation if options.loop is ModelAnimationLoop.NONE. stopTime [JulianDate](JulianDate.html) optional The scene time to stop playing the animations. When this is undefined, the animations are played for its full duration. removeOnStop boolean false optional When true, the animations are removed after they stop playing. This will only affect the animation if options.loop is ModelAnimationLoop.NONE. multiplier number 1.0 optional Values greater than 1.0 increase the speed that the animations play relative to the scene clock speed; values less than 1.0 decrease the speed. reverse boolean false optional When true, the animations are played in reverse. loop [ModelAnimationLoop](global.html#ModelAnimationLoop) ModelAnimationLoop.NONE optional Determines if and how the animations are looped. animationTime [ModelAnimation.AnimationTimeCallback](ModelAnimation.html#.AnimationTimeCallback) optional If defined, computes the local animation time for all of the animations. |

##### Returns:

 An array of [ModelAnimation](ModelAnimation.html) objects, one for each animation added to the collection. If there are no glTF animations, the array is empty.

##### Throws:

* [DeveloperError](DeveloperError.html): Animations are not loaded. Wait for the [Model#ready](Model.html#ready) to return true.
* [DeveloperError](DeveloperError.html): options.multiplier must be greater than zero.

##### Example:

```javascript
model.activeAnimations.addAll({
  multiplier : 0.5,                            // Play at half-speed
  loop : Cesium.ModelAnimationLoop.REPEAT      // Loop the animations
});
```

#### [](#contains) contains(runtimeAnimation) → boolean 

[engine/Source/Scene/Model/ModelAnimationCollection.js 341](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L341) 

 Determines whether this collection contains a given animation.

| Name             | Type                                  | Description                         |
| ---------------- | ------------------------------------- | ----------------------------------- |
| runtimeAnimation | [ModelAnimation](ModelAnimation.html) | The runtime animation to check for. |

##### Returns:

`true` if this collection contains the animation, `false` otherwise.

#### [](#get) get(index) → [ModelAnimation](ModelAnimation.html) 

[engine/Source/Scene/Model/ModelAnimationCollection.js 366](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L366) 

 Returns the animation in the collection at the specified index. Indices are zero-based and increase as animations are added. Removing an animation shifts all animations after it to the left, changing their indices. This function is commonly used to iterate over all the animations in the collection.

| Name  | Type   | Description                            |
| ----- | ------ | -------------------------------------- |
| index | number | The zero-based index of the animation. |

##### Returns:

 The runtime animation at the specified index.

##### Example:

```javascript
// Output the names of all the animations in the collection.
const animations = model.activeAnimations;
const length = animations.length;
for (let i = 0; i < length; ++i) {
  console.log(animations.get(i).name);
}
```

#### [](#remove) remove(runtimeAnimation) → boolean 

[engine/Source/Scene/Model/ModelAnimationCollection.js 300](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L300) 

 Removes an animation from the collection.

This raises the [ModelAnimationCollection#animationRemoved](ModelAnimationCollection.html#animationRemoved) event so, for example, a UI can stay in sync.

An animation can also be implicitly removed from the collection by setting `ModelAnimationCollection#removeOnStop` to`true`. The [ModelAnimationCollection#animationRemoved](ModelAnimationCollection.html#animationRemoved) event is still fired when the animation is removed.

| Name             | Type                                  | Description                      |
| ---------------- | ------------------------------------- | -------------------------------- |
| runtimeAnimation | [ModelAnimation](ModelAnimation.html) | The runtime animation to remove. |

##### Returns:

`true` if the animation was removed; `false` if the animation was not found in the collection.

##### Example:

```javascript
const a = model.activeAnimations.add({
  name : 'animation name'
});
model.activeAnimations.remove(a); // Returns true
```

#### [](#removeAll) removeAll() 

[engine/Source/Scene/Model/ModelAnimationCollection.js 323](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelAnimationCollection.js#L323) 

 Removes all animations from the collection.

This raises the [ModelAnimationCollection#animationRemoved](ModelAnimationCollection.html#animationRemoved) event for each animation so, for example, a UI can stay in sync.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

