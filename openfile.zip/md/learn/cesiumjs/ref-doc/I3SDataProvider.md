# [![](Images/CesiumLogo.png)](index.html) I3SDataProvider 

#### [](#I3SDataProvider) new Cesium.I3SDataProvider(options) 

[engine/Source/Scene/I3SDataProvider.js 141](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L141) 

 An I3SDataProvider is the main public class for I3S support. The url option should return a scene object. Currently supported I3S versions are 1.6 and 1.7/1.8 (OGC I3S 1.2). I3SFeature and I3SNode classes implement the Object Model for I3S entities, with public interfaces.

This object is normally not instantiated directly, use [I3SDataProvider.fromUrl](I3SDataProvider.html#.fromUrl).

| Name    | Type                                                                           | Description                                 |
| ------- | ------------------------------------------------------------------------------ | ------------------------------------------- |
| options | [I3SDataProvider.ConstructorOptions](I3SDataProvider.html#.ConstructorOptions) | An object describing initialization options |

##### Examples:

```javascript
try {
  const i3sData = await I3SDataProvider.fromUrl(
    "https://tiles.arcgis.com/tiles/z2tnIkrLQ2BRzr6P/arcgis/rest/services/Frankfurt2017_vi3s_18/SceneServer/layers/0"
  );
  viewer.scene.primitives.add(i3sData);
} catch (error) {
  console.log(`There was an error creating the I3S Data Provider: ${error}`);
}
```

```javascript
try {
  const geoidService = await Cesium.ArcGISTiledElevationTerrainProvider.fromUrl(
    "https://tiles.arcgis.com/tiles/z2tnIkrLQ2BRzr6P/arcgis/rest/services/EGM2008/ImageServer"
  );
  const i3sData = await I3SDataProvider.fromUrl(
    "https://tiles.arcgis.com/tiles/z2tnIkrLQ2BRzr6P/arcgis/rest/services/Frankfurt2017_vi3s_18/SceneServer/layers/0", {
      geoidTiledTerrainProvider: geoidService
  });
  viewer.scene.primitives.add(i3sData);
} catch (error) {
  console.log(`There was an error creating the I3S Data Provider: ${error}`);
}
```

##### See:

* [I3SDataProvider.fromUrl](I3SDataProvider.html#.fromUrl)
* [ArcGISTiledElevationTerrainProvider](ArcGISTiledElevationTerrainProvider.html)

### Members

#### [](#adjustMaterialAlphaMode) readonly adjustMaterialAlphaMode : boolean 

[engine/Source/Scene/I3SDataProvider.js 300](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L300) 

 Determines if the alpha mode of the material will be adjusted depending on the color vertex attribute.

#### [](#applySymbology) readonly applySymbology : boolean 

[engine/Source/Scene/I3SDataProvider.js 312](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L312) 

 Determines if the I3S symbology will be parsed and applied for the layers.

#### [](#calculateNormals) readonly calculateNormals : boolean 

[engine/Source/Scene/I3SDataProvider.js 324](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L324) 

 Determines if the flat normals will be generated for I3S geometry without normals.

#### [](#data) readonly data : object 

[engine/Source/Scene/I3SDataProvider.js 252](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L252) 

 Gets the I3S data for this object.

#### [](#extent) readonly extent : [Rectangle](Rectangle.html) 

[engine/Source/Scene/I3SDataProvider.js 264](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L264) 

 Gets the extent covered by this I3S.

#### [](#geoidTiledTerrainProvider) readonly geoidTiledTerrainProvider : [ArcGISTiledElevationTerrainProvider](ArcGISTiledElevationTerrainProvider.html) 

[engine/Source/Scene/I3SDataProvider.js 216](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L216) 

 The terrain provider referencing the GEOID service to be used for orthometric to ellipsoidal conversion.

#### [](#layers) readonly layers : Array.<[I3SLayer](I3SLayer.html)\> 

[engine/Source/Scene/I3SDataProvider.js 228](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L228) 

 Gets the collection of layers.

#### [](#name) readonly name : string 

[engine/Source/Scene/I3SDataProvider.js 181](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L181) 

 Gets a human-readable name for this dataset.

#### [](#resource) readonly resource : [Resource](Resource.html) 

[engine/Source/Scene/I3SDataProvider.js 276](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L276) 

 The resource used to fetch the I3S dataset.

#### [](#show) show : boolean 

[engine/Source/Scene/I3SDataProvider.js 192](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L192) 

 Determines if the dataset will be shown.

#### [](#showFeatures) readonly showFeatures : boolean 

[engine/Source/Scene/I3SDataProvider.js 288](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L288) 

 Determines if the features will be shown.

#### [](#sublayers) readonly sublayers : Array.<[I3SSublayer](I3SSublayer.html)\> 

[engine/Source/Scene/I3SDataProvider.js 240](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L240) 

 Gets the collection of building sublayers.

### Methods

#### [](#.fromUrl) static Cesium.I3SDataProvider.fromUrl(url, options) → Promise.<[I3SDataProvider](I3SDataProvider.html)\> 

[engine/Source/Scene/I3SDataProvider.js 540](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L540) 

 Creates an I3SDataProvider. Currently supported I3S versions are 1.6 and 1.7/1.8 (OGC I3S 1.2).

| Name    | Type                                                                           | Description                                                         |
| ------- | ------------------------------------------------------------------------------ | ------------------------------------------------------------------- |
| url     | string\|[Resource](Resource.html)                                              | The url of the I3S dataset, which should return an I3S scene object |
| options | [I3SDataProvider.ConstructorOptions](I3SDataProvider.html#.ConstructorOptions) | An object describing initialization options                         |

##### Returns:

##### Examples:

```javascript
try {
  const i3sData = await I3SDataProvider.fromUrl(
    "https://tiles.arcgis.com/tiles/z2tnIkrLQ2BRzr6P/arcgis/rest/services/Frankfurt2017_vi3s_18/SceneServer/layers/0"
  );
  viewer.scene.primitives.add(i3sData);
} catch (error) {
  console.log(`There was an error creating the I3S Data Provider: ${error}`);
}
```

```javascript
try {
  const geoidService = await Cesium.ArcGISTiledElevationTerrainProvider.fromUrl(
    "https://tiles.arcgis.com/tiles/z2tnIkrLQ2BRzr6P/arcgis/rest/services/EGM2008/ImageServer"
  );
  const i3sData = await I3SDataProvider.fromUrl(
    "https://tiles.arcgis.com/tiles/z2tnIkrLQ2BRzr6P/arcgis/rest/services/Frankfurt2017_vi3s_18/SceneServer/layers/0", {
      geoidTiledTerrainProvider: geoidService
  });
  viewer.scene.primitives.add(i3sData);
} catch (error) {
  console.log(`There was an error creating the I3S Data Provider: ${error}`);
}
```

#### [](#destroy) destroy() 

[engine/Source/Scene/I3SDataProvider.js 344](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L344) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.

Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### See:

* [I3SDataProvider#isDestroyed](I3SDataProvider.html#isDestroyed)

#### [](#filterByAttributes) filterByAttributes(filters) → Promise.<void> 

[engine/Source/Scene/I3SDataProvider.js 856](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L856) 

 Filters the drawn elements of a scene to specific attribute names and values

| Name    | Type                                                              | Default | Description                                  |
| ------- | ----------------------------------------------------------------- | ------- | -------------------------------------------- |
| filters | Array.<[I3SNode.AttributeFilter](I3SNode.html#.AttributeFilter)\> | \[\]    | optional The collection of attribute filters |

##### Returns:

 A promise that is resolved when the filter is applied

#### [](#getAttributeNames) getAttributeNames() → Array.<string> 

[engine/Source/Scene/I3SDataProvider.js 824](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L824) 

 Returns the collection of names for all available attributes

##### Returns:

 The collection of attribute names

#### [](#getAttributeValues) getAttributeValues(name) → Array.<string> 

[engine/Source/Scene/I3SDataProvider.js 837](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L837) 

 Returns the collection of values for the attribute with the given name

| Name | Type   | Description        |
| ---- | ------ | ------------------ |
| name | string | The attribute name |

##### Returns:

 The collection of attribute values

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/I3SDataProvider.js 365](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L365) 

 Returns true if this object was destroyed; otherwise, false.

If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [I3SDataProvider#destroy](I3SDataProvider.html#destroy)

### Type Definitions

#### [](#.ConstructorOptions) Cesium.I3SDataProvider.ConstructorOptions

[engine/Source/Scene/I3SDataProvider.js 65](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SDataProvider.js#L65) 

 Initialization options for the I3SDataProvider constructor

##### Properties:

| Name                      | Type                                                                                                                                                                        | Attributes | Default | Description                                                                                                                                                                                                                                                                                   |
| ------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------- | ------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| name                      | string                                                                                                                                                                      | <optional> |         | The name of the I3S dataset.                                                                                                                                                                                                                                                                  |
| show                      | boolean                                                                                                                                                                     | <optional> | true    | Determines if the dataset will be shown.                                                                                                                                                                                                                                                      |
| geoidTiledTerrainProvider | [ArcGISTiledElevationTerrainProvider](ArcGISTiledElevationTerrainProvider.html)\|Promise.<[ArcGISTiledElevationTerrainProvider](ArcGISTiledElevationTerrainProvider.html)\> | <optional> |         | Tiled elevation provider describing an Earth Gravitational Model. If defined, geometry will be shifted based on the offsets given by this provider. Required to position I3S data sets with gravity-related height at the correct location.                                                   |
| cesium3dTilesetOptions    | [Cesium3DTileset.ConstructorOptions](Cesium3DTileset.html#.ConstructorOptions)                                                                                              | <optional> |         | Object containing options to pass to an internally created [Cesium3DTileset](Cesium3DTileset.html). See [Cesium3DTileset](Cesium3DTileset.html) for list of valid properties. All options can be used with the exception of url and show which are overridden by values from I3SDataProvider. |
| showFeatures              | boolean                                                                                                                                                                     | <optional> | false   | Determines if the features will be shown.                                                                                                                                                                                                                                                     |
| adjustMaterialAlphaMode   | boolean                                                                                                                                                                     | <optional> | false   | The option to adjust the alpha mode of the material based on the transparency of the vertex color. When true, the alpha mode of the material (if not defined) will be set to BLEND for geometry with any transparency in the color vertex attribute.                                          |
| applySymbology            | boolean                                                                                                                                                                     | <optional> | false   | Determines if the I3S symbology will be parsed and applied for the layers.                                                                                                                                                                                                                    |
| calculateNormals          | boolean                                                                                                                                                                     | <optional> | false   | Determines if the flat normals will be generated for I3S geometry without normals.                                                                                                                                                                                                            |

##### Examples:

```javascript
// Increase LOD by reducing SSE
const cesium3dTilesetOptions = {
  maximumScreenSpaceError: 1,
};
const i3sOptions = {
  cesium3dTilesetOptions: cesium3dTilesetOptions,
};
```

```javascript
// Set a custom outline color to replace the color defined in I3S symbology
const cesium3dTilesetOptions = {
  outlineColor: Cesium.Color.BLUE,
};
const i3sOptions = {
  cesium3dTilesetOptions: cesium3dTilesetOptions,
  applySymbology: true,
};
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

