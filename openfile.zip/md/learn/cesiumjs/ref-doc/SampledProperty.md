# [![](Images/CesiumLogo.png)](index.html) SampledProperty 

#### [](#SampledProperty) new Cesium.SampledProperty(type, derivativeTypes) 

[engine/Source/DataSources/SampledProperty.js 159](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L159) 

 A [Property](Property.html) whose value is interpolated for a given time from the provided set of samples and specified interpolation algorithm and degree.

| Name            | Type                               | Description                                                                                                |
| --------------- | ---------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| type            | number\|[Packable](Packable.html)  | The type of property.                                                                                      |
| derivativeTypes | Array.<[Packable](Packable.html)\> | optional When supplied, indicates that samples will contain derivative information of the specified types. |

##### Examples:

```javascript
//Create a linearly interpolated Cartesian2
const property = new Cesium.SampledProperty(Cesium.Cartesian2);

//Populate it with data
property.addSample(Cesium.JulianDate.fromIso8601('2012-08-01T00:00:00.00Z'), new Cesium.Cartesian2(0, 0));
property.addSample(Cesium.JulianDate.fromIso8601('2012-08-02T00:00:00.00Z'), new Cesium.Cartesian2(4, 7));

//Retrieve an interpolated value
const result = property.getValue(Cesium.JulianDate.fromIso8601('2012-08-01T12:00:00.00Z'));
```

```javascript
//Create a simple numeric SampledProperty that uses third degree Hermite Polynomial Approximation
const property = new Cesium.SampledProperty(Number);
property.setInterpolationOptions({
    interpolationDegree : 3,
    interpolationAlgorithm : Cesium.HermitePolynomialApproximation
});

//Populate it with data
property.addSample(Cesium.JulianDate.fromIso8601('2012-08-01T00:00:00.00Z'), 1.0);
property.addSample(Cesium.JulianDate.fromIso8601('2012-08-01T00:01:00.00Z'), 6.0);
property.addSample(Cesium.JulianDate.fromIso8601('2012-08-01T00:02:00.00Z'), 12.0);
property.addSample(Cesium.JulianDate.fromIso8601('2012-08-01T00:03:30.00Z'), 5.0);
property.addSample(Cesium.JulianDate.fromIso8601('2012-08-01T00:06:30.00Z'), 2.0);

//Samples can be added in any order.
property.addSample(Cesium.JulianDate.fromIso8601('2012-08-01T00:00:30.00Z'), 6.2);

//Retrieve an interpolated value
const result = property.getValue(Cesium.JulianDate.fromIso8601('2012-08-01T00:02:34.00Z'));
```

##### See:

* [SampledPositionProperty](SampledPositionProperty.html)

### Members

#### [](#backwardExtrapolationDuration) backwardExtrapolationDuration : number 

[engine/Source/DataSources/SampledProperty.js 349](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L349) 

 Gets or sets the amount of time to extrapolate backward before the property becomes undefined. A value of 0 will extrapolate forever.

Default Value: `0` 

#### [](#backwardExtrapolationType) backwardExtrapolationType : [ExtrapolationType](global.html#ExtrapolationType) 

[engine/Source/DataSources/SampledProperty.js 331](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L331) 

 Gets or sets the type of extrapolation to perform when a value is requested at a time before any available samples.

Default Value: `ExtrapolationType.NONE` 

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/SampledProperty.js 241](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L241) 

 Gets the event that is raised whenever the definition of this property changes. The definition is considered to have changed if a call to getValue would return a different result for the same time.

#### [](#derivativeTypes) derivativeTypes : Array.<[Packable](Packable.html)\> 

[engine/Source/DataSources/SampledProperty.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L261) 

 Gets the derivative types used by this property.

#### [](#forwardExtrapolationDuration) forwardExtrapolationDuration : number 

[engine/Source/DataSources/SampledProperty.js 313](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L313) 

 Gets or sets the amount of time to extrapolate forward before the property becomes undefined. A value of 0 will extrapolate forever.

Default Value: `0` 

#### [](#forwardExtrapolationType) forwardExtrapolationType : [ExtrapolationType](global.html#ExtrapolationType) 

[engine/Source/DataSources/SampledProperty.js 295](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L295) 

 Gets or sets the type of extrapolation to perform when a value is requested at a time after any available samples.

Default Value: `ExtrapolationType.NONE` 

#### [](#interpolationAlgorithm) interpolationAlgorithm : [InterpolationAlgorithm](InterpolationAlgorithm.html) 

[engine/Source/DataSources/SampledProperty.js 283](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L283) 

 Gets the interpolation algorithm to use when retrieving a value.

Default Value: `LinearApproximation` 

#### [](#interpolationDegree) interpolationDegree : number 

[engine/Source/DataSources/SampledProperty.js 272](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L272) 

 Gets the degree of interpolation to perform when retrieving a value.

Default Value: `1` 

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/SampledProperty.js 227](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L227) 

 Gets a value indicating if this property is constant. A property is considered constant if getValue always returns the same result for the current definition.

#### [](#type) type : \* 

[engine/Source/DataSources/SampledProperty.js 251](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L251) 

 Gets the type of property.

### Methods

#### [](#addSample) addSample(time, value, derivatives) 

[engine/Source/DataSources/SampledProperty.js 583](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L583) 

 Adds a new sample.

| Name        | Type                               | Description                                             |
| ----------- | ---------------------------------- | ------------------------------------------------------- |
| time        | [JulianDate](JulianDate.html)      | The sample time.                                        |
| value       | [Packable](Packable.html)          | The value at the provided time.                         |
| derivatives | Array.<[Packable](Packable.html)\> | optional The array of derivatives at the provided time. |

#### [](#addSamples) addSamples(times, values, derivativeValues) 

[engine/Source/DataSources/SampledProperty.js 627](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L627) 

 Adds an array of samples.

| Name             | Type                                   | Description                                                                                 |
| ---------------- | -------------------------------------- | ------------------------------------------------------------------------------------------- |
| times            | Array.<[JulianDate](JulianDate.html)\> | An array of JulianDate instances where each index is a sample time.                         |
| values           | Array.<[Packable](Packable.html)\>     | The array of values, where each value corresponds to the provided times index.              |
| derivativeValues | Array.<Array>                          | optional An array where each item is the array of derivatives at the equivalent time index. |

##### Throws:

* [DeveloperError](DeveloperError.html): times and values must be the same length.
* [DeveloperError](DeveloperError.html): times and derivativeValues must be the same length.

#### [](#addSamplesPackedArray) addSamplesPackedArray(packedSamples, epoch) 

[engine/Source/DataSources/SampledProperty.js 708](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L708) 

 Adds samples as a single packed array where each new sample is represented as a date, followed by the packed representation of the corresponding value and derivatives.

| Name          | Type                          | Description                                                                                                           |
| ------------- | ----------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| packedSamples | Array.<number>                | The array of packed samples.                                                                                          |
| epoch         | [JulianDate](JulianDate.html) | optional If any of the dates in packedSamples are numbers, they are considered an offset from this epoch, in seconds. |

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/SampledProperty.js 791](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L791) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getSample) getSample(index) → [JulianDate](JulianDate.html)|undefined 

[engine/Source/DataSources/SampledProperty.js 683](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L683) 

 Retrieves the time of the provided sample associated with the index. A negative index accesses the list of samples in reverse order.

| Name  | Type   | Description                |
| ----- | ------ | -------------------------- |
| index | number | The index of samples list. |

##### Returns:

 The JulianDate time of the sample, or undefined if failed.

#### [](#getValue) getValue(time, result) → object 

[engine/Source/DataSources/SampledProperty.js 371](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L371) 

 Gets the value of the property at the provided time.

| Name   | Type                          | Default          | Description                                                                                      |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | object                        |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

#### [](#removeSample) removeSample(time) → boolean 

[engine/Source/DataSources/SampledProperty.js 733](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L733) 

 Removes a sample at the given time, if present.

| Name | Type                          | Description      |
| ---- | ----------------------------- | ---------------- |
| time | [JulianDate](JulianDate.html) | The sample time. |

##### Returns:

`true` if a sample at time was removed, `false` otherwise.

#### [](#removeSamples) removeSamples(time) 

[engine/Source/DataSources/SampledProperty.js 762](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L762) 

 Removes all samples for the given time interval.

| Name | Type                              | Description                                        |
| ---- | --------------------------------- | -------------------------------------------------- |
| time | [TimeInterval](TimeInterval.html) | The time interval for which to remove all samples. |

#### [](#setInterpolationOptions) setInterpolationOptions(options) 

[engine/Source/DataSources/SampledProperty.js 544](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/SampledProperty.js#L544) 

 Sets the algorithm and degree to use when interpolating a value.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                 |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Description interpolationAlgorithm [InterpolationAlgorithm](InterpolationAlgorithm.html) optional The new interpolation algorithm. If undefined, the existing property will be unchanged. interpolationDegree number optional The new interpolation degree. If undefined, the existing property will be unchanged. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

