# [![](Images/CesiumLogo.png)](index.html) GeometryAttribute 

#### [](#GeometryAttribute) new Cesium.GeometryAttribute(options) 

[engine/Source/Core/GeometryAttribute.js 40](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryAttribute.js#L40) 

 Values and type information for geometry attributes. A [Geometry](Geometry.html)generally contains one or more attributes. All attributes together form the geometry's vertices.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description componentDatatype [ComponentDatatype](global.html#ComponentDatatype)  The datatype of each component in the attribute, e.g., individual elements in values. componentsPerAttribute number  A number between 1 and 4 that defines the number of components in an attributes. normalize boolean false optional When true and componentDatatype is an integer format, indicate that the components should be mapped to the range \[0, 1\] (unsigned) or \[-1, 1\] (signed) when they are accessed as floating-point for rendering. values Array.<number>\|Int8Array|Uint8Array|Int16Array|Uint16Array|Int32Array|Uint32Array|Float32Array|Float64Array  The values for the attributes stored in a typed array. |

##### Throws:

* [DeveloperError](DeveloperError.html): options.componentsPerAttribute must be between 1 and 4.

##### Example:

```javascript
const geometry = new Cesium.Geometry({
  attributes : {
    position : new Cesium.GeometryAttribute({
      componentDatatype : Cesium.ComponentDatatype.FLOAT,
      componentsPerAttribute : 3,
      values : new Float32Array([
        0.0, 0.0, 0.0,
        7500000.0, 0.0, 0.0,
        0.0, 7500000.0, 0.0
      ])
    })
  },
  primitiveType : Cesium.PrimitiveType.LINE_LOOP
});
```

##### See:

* [Geometry](Geometry.html)

### Members

#### [](#componentDatatype) componentDatatype : [ComponentDatatype](global.html#ComponentDatatype) 

[engine/Source/Core/GeometryAttribute.js 70](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryAttribute.js#L70) 

 The datatype of each component in the attribute, e.g., individual elements in[GeometryAttribute#values](GeometryAttribute.html#values).

#### [](#componentsPerAttribute) componentsPerAttribute : number 

[engine/Source/Core/GeometryAttribute.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryAttribute.js#L88) 

 A number between 1 and 4 that defines the number of components in an attributes. For example, a position attribute with x, y, and z components would have 3 as shown in the code example.

##### Example:

```javascript
attribute.componentDatatype = Cesium.ComponentDatatype.FLOAT;
attribute.componentsPerAttribute = 3;
attribute.values = new Float32Array([
  0.0, 0.0, 0.0,
  7500000.0, 0.0, 0.0,
  0.0, 7500000.0, 0.0
]);
```

#### [](#normalize) normalize : boolean 

[engine/Source/Core/GeometryAttribute.js 113](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryAttribute.js#L113) 

 When `true` and `componentDatatype` is an integer format, indicate that the components should be mapped to the range \[0, 1\] (unsigned) or \[-1, 1\] (signed) when they are accessed as floating-point for rendering.

This is commonly used when storing colors using [ComponentDatatype.UNSIGNED\_BYTE](global.html#ComponentDatatype#.UNSIGNED%5FBYTE).

Default Value: `false` 

##### Example:

```javascript
attribute.componentDatatype = Cesium.ComponentDatatype.UNSIGNED_BYTE;
attribute.componentsPerAttribute = 4;
attribute.normalize = true;
attribute.values = new Uint8Array([
  Cesium.Color.floatToByte(color.red),
  Cesium.Color.floatToByte(color.green),
  Cesium.Color.floatToByte(color.blue),
  Cesium.Color.floatToByte(color.alpha)
]);
```

#### [](#values) values : Array.<number>|Int8Array|Uint8Array|Int16Array|Uint16Array|Int32Array|Uint32Array|Float32Array|Float64Array 

[engine/Source/Core/GeometryAttribute.js 131](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryAttribute.js#L131) 

 The values for the attributes stored in a typed array. In the code example, every three elements in `values` defines one attributes since`componentsPerAttribute` is 3.

##### Example:

```javascript
attribute.componentDatatype = Cesium.ComponentDatatype.FLOAT;
attribute.componentsPerAttribute = 3;
attribute.values = new Float32Array([
  0.0, 0.0, 0.0,
  7500000.0, 0.0, 0.0,
  0.0, 7500000.0, 0.0
]);
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

