# [![](Images/CesiumLogo.png)](index.html) CallbackProperty 

#### [](#CallbackProperty) new Cesium.CallbackProperty(callback, isConstant) 

[engine/Source/DataSources/CallbackProperty.js 15](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackProperty.js#L15) 

 A [Property](Property.html) whose value is lazily evaluated by a callback function.

| Name       | Type                                                         | Description                                                                                        |
| ---------- | ------------------------------------------------------------ | -------------------------------------------------------------------------------------------------- |
| callback   | [CallbackProperty.Callback](CallbackProperty.html#.Callback) | The function to be called when the property is evaluated.                                          |
| isConstant | boolean                                                      | true when the callback function returns the same value every time, false if the value will change. |

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/CallbackProperty.js 43](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackProperty.js#L43) 

 Gets the event that is raised whenever the definition of this property changes. The definition is changed whenever setCallback is called.

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/CallbackProperty.js 30](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackProperty.js#L30) 

 Gets a value indicating if this property is constant.

### Methods

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/CallbackProperty.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackProperty.js#L100) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getValue) getValue(time, result) → object 

[engine/Source/DataSources/CallbackProperty.js 59](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackProperty.js#L59) 

 Gets the value of the property.

| Name   | Type                          | Default          | Description                                                                                      |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | object                        |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied or is unsupported.

#### [](#setCallback) setCallback(callback, isConstant) 

[engine/Source/DataSources/CallbackProperty.js 72](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackProperty.js#L72) 

 Sets the callback to be used.

| Name       | Type                                                         | Description                                                                                        |
| ---------- | ------------------------------------------------------------ | -------------------------------------------------------------------------------------------------- |
| callback   | [CallbackProperty.Callback](CallbackProperty.html#.Callback) | The function to be called when the property is evaluated.                                          |
| isConstant | boolean                                                      | true when the callback function returns the same value every time, false if the value will change. |

### Type Definitions

#### [](#.Callback) Cesium.CallbackProperty.Callback(time, result) → object 

[engine/Source/DataSources/CallbackProperty.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackProperty.js#L109) 

 A function that returns the value of the property.

| Name   | Type                          | Default          | Description                                                                                                  |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.              |
| result | object                        |                  | optional The object to store the value into. If omitted, the function must create and return a new instance. |

##### Returns:

 The modified result parameter, or a new instance if the result parameter was not supplied or is unsupported.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

