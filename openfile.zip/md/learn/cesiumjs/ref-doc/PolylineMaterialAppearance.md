# [![](Images/CesiumLogo.png)](index.html) PolylineMaterialAppearance 

#### [](#PolylineMaterialAppearance) new Cesium.PolylineMaterialAppearance(options) 

[engine/Source/Scene/PolylineMaterialAppearance.js 50](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L50) 

 An appearance for [PolylineGeometry](PolylineGeometry.html) that supports shading with materials.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description translucent boolean true optional When true, the geometry is expected to appear translucent so [PolylineMaterialAppearance#renderState](PolylineMaterialAppearance.html#renderState) has alpha blending enabled. material [Material](Material.html) Material.ColorType optional The material used to determine the fragment color. vertexShaderSource string optional Optional GLSL vertex shader source to override the default vertex shader. fragmentShaderSource string optional Optional GLSL fragment shader source to override the default fragment shader. renderState object optional Optional render state to override the default render state. |

##### Example:

```javascript
const primitive = new Cesium.Primitive({
  geometryInstances : new Cesium.GeometryInstance({
    geometry : new Cesium.PolylineGeometry({
      positions : Cesium.Cartesian3.fromDegreesArray([
        0.0, 0.0,
        5.0, 0.0
      ]),
      width : 10.0,
      vertexFormat : Cesium.PolylineMaterialAppearance.VERTEX_FORMAT
    })
  }),
  appearance : new Cesium.PolylineMaterialAppearance({
    material : Cesium.Material.fromType('Color')
  })
});
```

##### See:

* [Fabric](https://github.com/CesiumGS/cesium/wiki/Fabric)

### Members

#### [](#.VERTEX%5FFORMAT) static constant Cesium.PolylineMaterialAppearance.VERTEX\_FORMAT : [VertexFormat](VertexFormat.html) 

[engine/Source/Scene/PolylineMaterialAppearance.js 201](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L201) 

 The [VertexFormat](VertexFormat.html) that all [PolylineMaterialAppearance](PolylineMaterialAppearance.html) instances are compatible with. This requires `position` and `st` attributes.

#### [](#closed) readonly closed : boolean 

[engine/Source/Scene/PolylineMaterialAppearance.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L168) 

 When `true`, the geometry is expected to be closed so[PolylineMaterialAppearance#renderState](PolylineMaterialAppearance.html#renderState) has backface culling enabled. This is always `false` for `PolylineMaterialAppearance`.

Default Value: `false` 

#### [](#fragmentShaderSource) readonly fragmentShaderSource : string 

[engine/Source/Scene/PolylineMaterialAppearance.js 131](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L131) 

 The GLSL source code for the fragment shader.

#### [](#material) material : [Material](Material.html) 

[engine/Source/Scene/PolylineMaterialAppearance.js 67](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L67) 

 The material used to determine the fragment color. Unlike other [PolylineMaterialAppearance](PolylineMaterialAppearance.html)properties, this is not read-only, so an appearance's material can change on the fly.

Default Value: `[Material.ColorType](Material.html#.ColorType)` 

##### See:

* [Fabric](https://github.com/CesiumGS/cesium/wiki/Fabric)

#### [](#renderState) readonly renderState : object 

[engine/Source/Scene/PolylineMaterialAppearance.js 150](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L150) 

 The WebGL fixed-function state to use when rendering the geometry.

The render state can be explicitly defined when constructing a [PolylineMaterialAppearance](PolylineMaterialAppearance.html)instance, or it is set implicitly via [PolylineMaterialAppearance#translucent](PolylineMaterialAppearance.html#translucent)and [PolylineMaterialAppearance#closed](PolylineMaterialAppearance.html#closed).

#### [](#translucent) translucent : boolean 

[engine/Source/Scene/PolylineMaterialAppearance.js 79](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L79) 

 When `true`, the geometry is expected to appear translucent so[PolylineMaterialAppearance#renderState](PolylineMaterialAppearance.html#renderState) has alpha blending enabled.

Default Value: `true` 

#### [](#vertexFormat) readonly vertexFormat : [VertexFormat](VertexFormat.html) 

[engine/Source/Scene/PolylineMaterialAppearance.js 186](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L186) 

 The [VertexFormat](VertexFormat.html) that this appearance instance is compatible with. A geometry can have more vertex attributes and still be compatible - at a potential performance cost - but it can't have less.

Default Value: `[PolylineMaterialAppearance.VERTEX_FORMAT](PolylineMaterialAppearance.html#.VERTEX%5FFORMAT)` 

#### [](#vertexShaderSource) readonly vertexShaderSource : string 

[engine/Source/Scene/PolylineMaterialAppearance.js 110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L110) 

 The GLSL source code for the vertex shader.

### Methods

#### [](#getFragmentShaderSource) getFragmentShaderSource() → string 

[engine/Source/Scene/PolylineMaterialAppearance.js 211](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L211) 

 Procedurally creates the full GLSL fragment shader source. For [PolylineMaterialAppearance](PolylineMaterialAppearance.html), this is derived from [PolylineMaterialAppearance#fragmentShaderSource](PolylineMaterialAppearance.html#fragmentShaderSource) and [PolylineMaterialAppearance#material](PolylineMaterialAppearance.html#material).

##### Returns:

 The full GLSL fragment shader source.

#### [](#getRenderState) getRenderState() → object 

[engine/Source/Scene/PolylineMaterialAppearance.js 233](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L233) 

 Creates a render state. This is not the final render state instance; instead, it can contain a subset of render state properties identical to the render state created in the context.

##### Returns:

 The render state.

#### [](#isTranslucent) isTranslucent() → boolean 

[engine/Source/Scene/PolylineMaterialAppearance.js 221](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PolylineMaterialAppearance.js#L221) 

 Determines if the geometry is translucent based on [PolylineMaterialAppearance#translucent](PolylineMaterialAppearance.html#translucent) and [Material#isTranslucent](Material.html#isTranslucent).

##### Returns:

`true` if the appearance is translucent.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

