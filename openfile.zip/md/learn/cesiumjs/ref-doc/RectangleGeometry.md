# [![](Images/CesiumLogo.png)](index.html) RectangleGeometry 

#### [](#RectangleGeometry) new Cesium.RectangleGeometry(options) 

[engine/Source/Core/RectangleGeometry.js 1016](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RectangleGeometry.js#L1016) 

 A description of a cartographic rectangle on an ellipsoid centered at the origin. Rectangle geometry can be rendered with both [Primitive](Primitive.html) and [GroundPrimitive](GroundPrimitive.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description rectangle [Rectangle](Rectangle.html)  A cartographic rectangle with north, south, east and west properties in radians. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid on which the rectangle lies. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The distance, in radians, between each latitude and longitude. Determines the number of positions in the buffer. height number 0.0 optional The distance in meters between the rectangle and the ellipsoid surface. rotation number 0.0 optional The rotation of the rectangle, in radians. A positive rotation is counter-clockwise. stRotation number 0.0 optional The rotation of the texture coordinates, in radians. A positive rotation is counter-clockwise. extrudedHeight number optional The distance in meters between the rectangle's extruded face and the ellipsoid surface. |

##### Throws:

* [DeveloperError](DeveloperError.html): `options.rectangle.north` must be in the interval \[`-Pi/2`, `Pi/2`\].
* [DeveloperError](DeveloperError.html): `options.rectangle.south` must be in the interval \[`-Pi/2`, `Pi/2`\].
* [DeveloperError](DeveloperError.html): `options.rectangle.east` must be in the interval \[`-Pi`, `Pi`\].
* [DeveloperError](DeveloperError.html): `options.rectangle.west` must be in the interval \[`-Pi`, `Pi`\].
* [DeveloperError](DeveloperError.html): `options.rectangle.north` must be greater than `options.rectangle.south`.

##### Example:

```javascript
// 1. create a rectangle
const rectangle = new Cesium.RectangleGeometry({
  ellipsoid : Cesium.Ellipsoid.default,
  rectangle : Cesium.Rectangle.fromDegrees(-80.0, 39.0, -74.0, 42.0),
  height : 10000.0
});
const geometry = Cesium.RectangleGeometry.createGeometry(rectangle);

// 2. create an extruded rectangle without a top
const rectangle = new Cesium.RectangleGeometry({
  ellipsoid : Cesium.Ellipsoid.default,
  rectangle : Cesium.Rectangle.fromDegrees(-80.0, 39.0, -74.0, 42.0),
  height : 10000.0,
  extrudedHeight: 300000
});
const geometry = Cesium.RectangleGeometry.createGeometry(rectangle);
```

##### Demo:

* [Cesium Sandcastle Rectangle Demo](https://sandcastle.cesium.com/index.html?src=Rectangle.html)

##### See:

* RectangleGeometry#createGeometry

### Members

#### [](#.packedLength) static Cesium.RectangleGeometry.packedLength : number 

[engine/Source/Core/RectangleGeometry.js 1061](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RectangleGeometry.js#L1061) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.computeRectangle) static Cesium.RectangleGeometry.computeRectangle(options, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/RectangleGeometry.js 1195](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RectangleGeometry.js#L1195) 

 Computes the bounding rectangle based on the provided options

| Name    | Type                        | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object                      | Object with the following properties: Name Type Default Description rectangle [Rectangle](Rectangle.html)  A cartographic rectangle with north, south, east and west properties in radians. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid on which the rectangle lies. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The distance, in radians, between each latitude and longitude. Determines the number of positions in the buffer. rotation number 0.0 optional The rotation of the rectangle, in radians. A positive rotation is counter-clockwise. |
| result  | [Rectangle](Rectangle.html) | optional An object in which to store the result.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |

##### Returns:

 The result rectangle

#### [](#.createGeometry) static Cesium.RectangleGeometry.createGeometry(rectangleGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/RectangleGeometry.js 1231](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RectangleGeometry.js#L1231) 

 Computes the geometric representation of a rectangle, including its vertices, indices, and a bounding sphere.

| Name              | Type                                        | Description                     |
| ----------------- | ------------------------------------------- | ------------------------------- |
| rectangleGeometry | [RectangleGeometry](RectangleGeometry.html) | A description of the rectangle. |

##### Returns:

 The computed vertices and indices.

##### Throws:

* [DeveloperError](DeveloperError.html): Rotated rectangle is invalid.

#### [](#.pack) static Cesium.RectangleGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/RectangleGeometry.js 1076](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RectangleGeometry.js#L1076) 

 Stores the provided instance into the provided array.

| Name          | Type                                        | Default | Description                                                               |
| ------------- | ------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [RectangleGeometry](RectangleGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                              |         | The array to pack into.                                                   |
| startingIndex | number                                      | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.RectangleGeometry.unpack(array, startingIndex, result) → [RectangleGeometry](RectangleGeometry.html) 

[engine/Source/Core/RectangleGeometry.js 1127](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RectangleGeometry.js#L1127) 

 Retrieves an instance from a packed array.

| Name          | Type                                        | Default | Description                                                |
| ------------- | ------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                              |         | The packed array.                                          |
| startingIndex | number                                      | 0       | optional The starting index of the element to be unpacked. |
| result        | [RectangleGeometry](RectangleGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new RectangleGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

