# [![](Images/CesiumLogo.png)](index.html) EllipsoidGeometry 

#### [](#EllipsoidGeometry) new Cesium.EllipsoidGeometry(options) 

[engine/Source/Core/EllipsoidGeometry.js 57](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeometry.js#L57) 

 A description of an ellipsoid centered at the origin.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description radii [Cartesian3](Cartesian3.html) Cartesian3(1.0, 1.0, 1.0) optional The radii of the ellipsoid in the x, y, and z directions. innerRadii [Cartesian3](Cartesian3.html) options.radii optional The inner radii of the ellipsoid in the x, y, and z directions. minimumClock number 0.0 optional The minimum angle lying in the xy-plane measured from the positive x-axis and toward the positive y-axis. maximumClock number 2\*PI optional The maximum angle lying in the xy-plane measured from the positive x-axis and toward the positive y-axis. minimumCone number 0.0 optional The minimum angle measured from the positive z-axis and toward the negative z-axis. maximumCone number PI optional The maximum angle measured from the positive z-axis and toward the negative z-axis. stackPartitions number 64 optional The number of times to partition the ellipsoid into stacks. slicePartitions number 64 optional The number of times to partition the ellipsoid into radial slices. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. |

##### Throws:

* [DeveloperError](DeveloperError.html): options.slicePartitions cannot be less than three.
* [DeveloperError](DeveloperError.html): options.stackPartitions cannot be less than three.

##### Example:

```javascript
const ellipsoid = new Cesium.EllipsoidGeometry({
  vertexFormat : Cesium.VertexFormat.POSITION_ONLY,
  radii : new Cesium.Cartesian3(1000000.0, 500000.0, 500000.0)
});
const geometry = Cesium.EllipsoidGeometry.createGeometry(ellipsoid);
```

##### See:

* EllipsoidGeometry#createGeometry

### Members

#### [](#.packedLength) static Cesium.EllipsoidGeometry.packedLength : number 

[engine/Source/Core/EllipsoidGeometry.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeometry.js#L100) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.EllipsoidGeometry.createGeometry(ellipsoidGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/EllipsoidGeometry.js 231](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeometry.js#L231) 

 Computes the geometric representation of an ellipsoid, including its vertices, indices, and a bounding sphere.

| Name              | Type                                        | Description                     |
| ----------------- | ------------------------------------------- | ------------------------------- |
| ellipsoidGeometry | [EllipsoidGeometry](EllipsoidGeometry.html) | A description of the ellipsoid. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.EllipsoidGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/EllipsoidGeometry.js 112](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeometry.js#L112) 

 Stores the provided instance into the provided array.

| Name          | Type                                        | Default | Description                                                               |
| ------------- | ------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [EllipsoidGeometry](EllipsoidGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                              |         | The array to pack into.                                                   |
| startingIndex | number                                      | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.EllipsoidGeometry.unpack(array, startingIndex, result) → [EllipsoidGeometry](EllipsoidGeometry.html) 

[engine/Source/Core/EllipsoidGeometry.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeometry.js#L168) 

 Retrieves an instance from a packed array.

| Name          | Type                                        | Default | Description                                                |
| ------------- | ------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                              |         | The packed array.                                          |
| startingIndex | number                                      | 0       | optional The starting index of the element to be unpacked. |
| result        | [EllipsoidGeometry](EllipsoidGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new EllipsoidGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

