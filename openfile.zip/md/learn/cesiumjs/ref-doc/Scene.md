# [![](Images/CesiumLogo.png)](index.html) Scene 

#### [](#Scene) new Cesium.Scene(options) 

[engine/Source/Scene/Scene.js 129](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L129) 

 The container for all 3D graphical objects and state in a Cesium virtual scene. Generally, a scene is not created directly; instead, it is implicitly created by [CesiumWidget](CesiumWidget.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description canvas HTMLCanvasElement  The HTML canvas element to create the scene for. contextOptions [ContextOptions](global.html#ContextOptions) optional Context and WebGL creation properties. creditContainer Element optional The HTML element in which the credits will be displayed. creditViewport Element optional The HTML element in which to display the credit popup. If not specified, the viewport will be a added as a sibling of the canvas. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The default ellipsoid. If not specified, the default ellipsoid is used. mapProjection [MapProjection](MapProjection.html) new GeographicProjection(options.ellipsoid) optional The map projection to use in 2D and Columbus View modes. orderIndependentTranslucency boolean true optional If true and the configuration supports it, use order independent translucency. scene3DOnly boolean false optional If true, optimizes memory use and performance for 3D mode but disables the ability to use 2D or Columbus View. shadows boolean false optional Determines if shadows are cast by light sources. mapMode2D [MapMode2D](global.html#MapMode2D) MapMode2D.INFINITE\_SCROLL optional Determines if the 2D map is rotatable or can be scrolled infinitely in the horizontal direction. requestRenderMode boolean false optional If true, rendering a frame will only occur when needed as determined by changes within the scene. Enabling improves performance of the application, but requires using [Scene#requestRender](Scene.html#requestRender) to render a new frame explicitly in this mode. This will be necessary in many cases after making changes to the scene in other parts of the API. See [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/). maximumRenderTimeChange number 0.0 optional If requestRenderMode is true, this value defines the maximum change in simulation time allowed before a render is requested. See [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/). depthPlaneEllipsoidOffset number 0.0 optional Adjust the DepthPlane to address rendering artefacts below ellipsoid zero elevation. msaaSamples number 4 optional If provided, this value controls the rate of multisample antialiasing. Typical multisampling rates are 2, 4, and sometimes 8 samples per pixel. Higher sampling rates of MSAA may impact performance in exchange for improved visual quality. This value only applies to WebGL2 contexts that support multisample render targets. Set to 1 to disable MSAA. |

##### Throws:

* [DeveloperError](DeveloperError.html): options and options.canvas are required.

##### Example:

```javascript
// Create scene without anisotropic texture filtering
const scene = new Cesium.Scene({
  canvas : canvas,
  contextOptions : {
    allowTextureFilterAnisotropic : false
  }
});
```

##### See:

* [CesiumWidget](CesiumWidget.html)
* [WebGLContextAttributes](http://www.khronos.org/registry/webgl/specs/latest/#5.2)

### Members

#### [](#.defaultLogDepthBuffer) static Cesium.Scene.defaultLogDepthBuffer 

[engine/Source/Scene/Scene.js 770](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L770) 

 Use this to set the default value for [Scene#logarithmicDepthBuffer](Scene.html#logarithmicDepthBuffer) in newly constructed Scenes This property relies on fragmentDepth being supported.

#### [](#atmosphere) atmosphere : [Atmosphere](Atmosphere.html) 

[engine/Source/Scene/Scene.js 542](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L542) 

 Settings for atmosphere lighting effects affecting 3D Tiles and model rendering. This is not to be confused with[Scene#skyAtmosphere](Scene.html#skyAtmosphere) which is responsible for rendering the sky.

#### [](#backgroundColor) backgroundColor : [Color](Color.html) 

[engine/Source/Scene/Scene.js 327](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L327) 

 The background color, which is only visible if there is no sky box, i.e., [Scene#skyBox](Scene.html#skyBox) is undefined.

Default Value: `[Color.BLACK](Color.html#.BLACK)` 

##### See:

* [Scene#skyBox](Scene.html#skyBox)

#### [](#camera) readonly camera : [Camera](Camera.html) 

[engine/Source/Scene/Scene.js 1010](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1010) 

 Gets or sets the camera.

#### [](#cameraUnderground) readonly cameraUnderground : boolean 

[engine/Source/Scene/Scene.js 1633](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1633) 

 Whether or not the camera is underneath the globe.

Default Value: `false` 

#### [](#canvas) readonly canvas : HTMLCanvasElement 

[engine/Source/Scene/Scene.js 802](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L802) 

 Gets the canvas element to which this scene is bound.

#### [](#clampToHeightSupported) readonly clampToHeightSupported : boolean 

[engine/Source/Scene/Scene.js 909](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L909) 

 Returns `true` if the [Scene#clampToHeight](Scene.html#clampToHeight) and [Scene#clampToHeightMostDetailed](Scene.html#clampToHeightMostDetailed) functions are supported.

##### See:

* [Scene#clampToHeight](Scene.html#clampToHeight)
* [Scene#clampToHeightMostDetailed](Scene.html#clampToHeightMostDetailed)

#### [](#completeMorphOnUserInput) completeMorphOnUserInput : boolean 

[engine/Source/Scene/Scene.js 260](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L260) 

 Determines whether or not to instantly complete the scene transition animation on user input.

Default Value: `true` 

#### [](#debugCommandFilter) debugCommandFilter : function 

[engine/Source/Scene/Scene.js 425](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L425) 

 This property is for debugging only; it is not for production use.

A function that determines what commands are executed. As shown in the examples below, the function receives the command's `owner` as an argument, and returns a boolean indicating if the command should be executed.

The default is `undefined`, indicating that all commands are executed.

Default Value: `undefined` 

##### Example:

```javascript
// Do not execute any commands.
scene.debugCommandFilter = function(command) {
    return false;
};

// Execute only the billboard's commands.  That is, only draw the billboard.
const billboards = new Cesium.BillboardCollection();
scene.debugCommandFilter = function(command) {
    return command.owner === billboards;
};
```

#### [](#debugFrustumStatistics) readonly debugFrustumStatistics : object 

[engine/Source/Scene/Scene.js 1354](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1354) 

 This property is for debugging only; it is not for production use.

When `Scene.debugShowFrustums` is `true`, this contains properties with statistics about the number of command execute per frustum.`totalCommands` is the total number of commands executed, ignoring overlap. `commandsInFrustums` is an array with the number of times commands are executed redundantly, e.g., how many commands overlap two or three frustums.

Default Value: `undefined` 

#### [](#debugShowCommands) debugShowCommands : boolean 

[engine/Source/Scene/Scene.js 439](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L439) 

 This property is for debugging only; it is not for production use.

When `true`, commands are randomly shaded. This is useful for performance analysis to see what parts of a scene or model are command-dense and could benefit from batching.

Default Value: `false` 

#### [](#debugShowDepthFrustum) debugShowDepthFrustum : number 

[engine/Source/Scene/Scene.js 480](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L480) 

 This property is for debugging only; it is not for production use.

Indicates which frustum will have depth information displayed.

Default Value: `1` 

#### [](#debugShowFramesPerSecond) debugShowFramesPerSecond : boolean 

[engine/Source/Scene/Scene.js 468](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L468) 

 This property is for debugging only; it is not for production use.

Displays frames per second and time between frames.

Default Value: `false` 

#### [](#debugShowFrustumPlanes) debugShowFrustumPlanes : boolean 

[engine/Source/Scene/Scene.js 492](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L492) 

 This property is for debugging only; it is not for production use.

When `true`, draws outlines to show the boundaries of the camera frustums

Default Value: `false` 

#### [](#debugShowFrustums) debugShowFrustums : boolean 

[engine/Source/Scene/Scene.js 456](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L456) 

 This property is for debugging only; it is not for production use.

When `true`, commands are shaded based on the frustums they overlap. Commands in the closest frustum are tinted red, commands in the next closest are green, and commands in the farthest frustum are blue. If a command overlaps more than one frustum, the color components are combined, e.g., a command overlapping the first two frustums is tinted yellow.

Default Value: `false` 

#### [](#drawingBufferHeight) readonly drawingBufferHeight : number 

[engine/Source/Scene/Scene.js 817](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L817) 

 The drawingBufferHeight of the underlying GL context.

##### See:

* [drawingBufferHeight](https://www.khronos.org/registry/webgl/specs/1.0/#DOM-WebGLRenderingContext-drawingBufferHeight)

#### [](#drawingBufferWidth) readonly drawingBufferWidth : number 

[engine/Source/Scene/Scene.js 832](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L832) 

 The drawingBufferWidth of the underlying GL context.

##### See:

* [drawingBufferWidth](https://www.khronos.org/registry/webgl/specs/1.0/#DOM-WebGLRenderingContext-drawingBufferWidth)

#### [](#ellipsoid) readonly ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Scene/Scene.js 952](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L952) 

 The ellipsoid. If not specified, the default ellipsoid is used.

#### [](#eyeSeparation) eyeSeparation : number 

[engine/Source/Scene/Scene.js 607](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L607) 

 The eye separation distance in meters for use with cardboard or WebVR.

#### [](#farToNearRatio) farToNearRatio : number 

[engine/Source/Scene/Scene.js 355](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L355) 

 The far-to-near ratio of the multi-frustum when using a normal depth buffer.

This value is used to create the near and far values for each frustum of the multi-frustum. It is only used when [Scene#logarithmicDepthBuffer](Scene.html#logarithmicDepthBuffer) is `false`. When `logarithmicDepthBuffer` is`true`, use [Scene#logarithmicDepthFarToNearRatio](Scene.html#logarithmicDepthFarToNearRatio).

Default Value: `1000.0` 

#### [](#focalLength) focalLength : number 

[engine/Source/Scene/Scene.js 601](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L601) 

 The focal length for use when with cardboard or WebVR.

#### [](#fog) fog : [Fog](Fog.html) 

[engine/Source/Scene/Scene.js 551](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L551) 

 Blends the atmosphere to geometry far from the camera for horizon views. Allows for additional performance improvements by rendering less geometry and dispatching less terrain requests. Disbaled by default if an ellipsoid other than WGS84 is used.

#### [](#gamma) gamma : number 

[engine/Source/Scene/Scene.js 1579](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1579) 

 The value used for gamma correction. This is only used when rendering with high dynamic range.

Default Value: `2.2` 

#### [](#globe) globe : [Globe](Globe.html) 

[engine/Source/Scene/Scene.js 964](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L964) 

 Gets or sets the depth-test ellipsoid.

#### [](#groundPrimitives) readonly groundPrimitives : [PrimitiveCollection](PrimitiveCollection.html) 

[engine/Source/Scene/Scene.js 997](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L997) 

 Gets the collection of ground primitives.

#### [](#highDynamicRange) highDynamicRange : boolean 

[engine/Source/Scene/Scene.js 1594](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1594) 

 Whether or not to use high dynamic range rendering.

Default Value: `false` 

#### [](#highDynamicRangeSupported) readonly highDynamicRangeSupported : boolean 

[engine/Source/Scene/Scene.js 1616](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1616) 

 Whether or not high dynamic range rendering is supported.

Default Value: `true` 

#### [](#id) readonly id : string 

[engine/Source/Scene/Scene.js 1392](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1392) 

 Gets the unique identifier for this scene.

#### [](#imageryLayers) readonly imageryLayers : [ImageryLayerCollection](ImageryLayerCollection.html) 

[engine/Source/Scene/Scene.js 1164](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1164) 

 Gets the collection of image layers that will be rendered on the globe.

#### [](#invertClassification) invertClassification : boolean 

[engine/Source/Scene/Scene.js 581](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L581) 

 When `false`, 3D Tiles will render normally. When `true`, classified 3D Tile geometry will render normally and unclassified 3D Tile geometry will render with the color multiplied by [Scene#invertClassificationColor](Scene.html#invertClassificationColor).

Default Value: `false` 

#### [](#invertClassificationColor) invertClassificationColor : [Color](Color.html) 

[engine/Source/Scene/Scene.js 590](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L590) 

 The highlight color of unclassified 3D Tile geometry when [Scene#invertClassification](Scene.html#invertClassification) is `true`.

When the color's alpha is less than 1.0, the unclassified portions of the 3D Tiles will not blend correctly with the classified positions of the 3D Tiles.

Also, when the color's alpha is less than 1.0, the WEBGL\_depth\_texture and EXT\_frag\_depth WebGL extensions must be supported.

Default Value: `Color.WHITE` 

#### [](#invertClassificationSupported) readonly invertClassificationSupported : boolean 

[engine/Source/Scene/Scene.js 924](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L924) 

 Returns `true` if the [Scene#invertClassification](Scene.html#invertClassification) is supported.

##### See:

* [Scene#invertClassification](Scene.html#invertClassification)

#### [](#lastRenderTime) readonly lastRenderTime : [JulianDate](JulianDate.html) 

[engine/Source/Scene/Scene.js 1319](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1319) 

 Gets the simulation time when the scene was last rendered. Returns undefined if the scene has not yet been rendered.

#### [](#light) light : [Light](Light.html) 

[engine/Source/Scene/Scene.js 758](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L758) 

 The light source for shading. Defaults to a directional light from the Sun.

#### [](#logarithmicDepthBuffer) logarithmicDepthBuffer : boolean 

[engine/Source/Scene/Scene.js 1560](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1560) 

 Whether or not to use a logarithmic depth buffer. Enabling this option will allow for less frustums in the multi-frustum, increasing performance. This property relies on fragmentDepth being supported.

#### [](#logarithmicDepthFarToNearRatio) logarithmicDepthFarToNearRatio : number 

[engine/Source/Scene/Scene.js 368](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L368) 

 The far-to-near ratio of the multi-frustum when using a logarithmic depth buffer.

This value is used to create the near and far values for each frustum of the multi-frustum. It is only used when [Scene#logarithmicDepthBuffer](Scene.html#logarithmicDepthBuffer) is `true`. When `logarithmicDepthBuffer` is`false`, use [Scene#farToNearRatio](Scene.html#farToNearRatio).

Default Value: `1e9` 

#### [](#mapMode2D) readonly mapMode2D : [MapMode2D](global.html#MapMode2D) 

[engine/Source/Scene/Scene.js 1508](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1508) 

 Determines if the 2D map is rotatable or can be scrolled infinitely in the horizontal direction.

#### [](#mapProjection) readonly mapProjection : [MapProjection](MapProjection.html) 

[engine/Source/Scene/Scene.js 1091](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1091) 

 Get the map projection to use in 2D and Columbus View modes.

Default Value: `new GeographicProjection()` 

#### [](#maximumAliasedLineWidth) readonly maximumAliasedLineWidth : number 

[engine/Source/Scene/Scene.js 847](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L847) 

 The maximum aliased line width, in pixels, supported by this WebGL implementation. It will be at least one.

##### See:

* [glGet](https://www.khronos.org/opengles/sdk/docs/man/xhtml/glGet.xml) with `ALIASED_LINE_WIDTH_RANGE`.

#### [](#maximumCubeMapSize) readonly maximumCubeMapSize : number 

[engine/Source/Scene/Scene.js 862](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L862) 

 The maximum length in pixels of one edge of a cube map, supported by this WebGL implementation. It will be at least 16.

##### See:

* [glGet](https://www.khronos.org/opengles/sdk/docs/man/xhtml/glGet.xml) with `GL_MAX_CUBE_MAP_TEXTURE_SIZE`.

#### [](#maximumRenderTimeChange) maximumRenderTimeChange : number 

[engine/Source/Scene/Scene.js 687](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L687) 

 If [Scene#requestRenderMode](Scene.html#requestRenderMode) is `true`, this value defines the maximum change in simulation time allowed before a render is requested. Lower values increase the number of frames rendered and higher values decrease the number of frames rendered. If `undefined`, changes to the simulation time will never request a render. This value impacts the rate of rendering for changes in the scene like lighting, entity property updates, and animations.

Default Value: `0.0` 

##### See:

* [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/)
* [Scene#requestRenderMode](Scene.html#requestRenderMode)

#### [](#minimumDisableDepthTestDistance) minimumDisableDepthTestDistance : number 

[engine/Source/Scene/Scene.js 1538](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1538) 

 The distance from the camera at which to disable the depth test of billboards, labels and points to, for example, prevent clipping against terrain. When set to zero, the depth test should always be applied. When less than zero, the depth test should never be applied. Setting the disableDepthTestDistance property of a billboard, label or point will override this value.

Default Value: `0.0` 

#### [](#mode) mode : [SceneMode](global.html#SceneMode) 

[engine/Source/Scene/Scene.js 1404](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1404) 

 Gets or sets the current mode of the scene.

Default Value: `[SceneMode.SCENE3D](global.html#SceneMode#.SCENE3D)` 

#### [](#moon) moon : [Moon](Moon.html) 

[engine/Source/Scene/Scene.js 317](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L317) 

 The [Moon](Moon.html) 

Default Value: `undefined` 

#### [](#morphComplete) morphComplete : [Event](Event.html) 

[engine/Source/Scene/Scene.js 274](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L274) 

 The event fired at the completion of a scene transition.

Default Value: `Event()` 

#### [](#morphStart) morphStart : [Event](Event.html) 

[engine/Source/Scene/Scene.js 267](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L267) 

 The event fired at the beginning of a scene transition.

Default Value: `Event()` 

#### [](#morphTime) morphTime : number 

[engine/Source/Scene/Scene.js 342](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L342) 

 The current morph transition time between 2D/Columbus View and 3D, with 0.0 being 2D or Columbus View and 1.0 being 3D.

Default Value: `1.0` 

#### [](#msaaSamples) msaaSamples : number 

[engine/Source/Scene/Scene.js 1645](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1645) 

 The sample rate of multisample antialiasing (values greater than 1 enable MSAA).

Default Value: `4` 

#### [](#msaaSupported) readonly msaaSupported : boolean 

[engine/Source/Scene/Scene.js 1661](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1661) 

 Returns `true` if the Scene's context supports MSAA.

#### [](#nearToFarDistance2D) nearToFarDistance2D : number 

[engine/Source/Scene/Scene.js 378](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L378) 

 Determines the uniform depth size in meters of each frustum of the multifrustum in 2D. If a primitive or model close to the surface shows z-fighting, decreasing this will eliminate the artifact, but decrease performance. On the other hand, increasing this will increase performance but may cause z-fighting among primitives close to the surface.

Default Value: `1.75e6` 

#### [](#orderIndependentTranslucency) readonly orderIndependentTranslucency : boolean 

[engine/Source/Scene/Scene.js 1380](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1380) 

 Gets whether or not the scene has order independent translucency enabled. Note that this only reflects the original construction option, and there are other factors that could prevent OIT from functioning on a given system configuration.

#### [](#pickPositionSupported) readonly pickPositionSupported : boolean 

[engine/Source/Scene/Scene.js 877](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L877) 

 Returns `true` if the [Scene#pickPosition](Scene.html#pickPosition) function is supported.

##### See:

* [Scene#pickPosition](Scene.html#pickPosition)

#### [](#pickTranslucentDepth) pickTranslucentDepth : boolean 

[engine/Source/Scene/Scene.js 526](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L526) 

 When `true`, enables picking translucent geometry using the depth buffer. Note that [Scene#useDepthPicking](Scene.html#useDepthPicking) must also be true for enabling this to work.

There is a decrease in performance when enabled. There are extra draw calls to write depth for translucent geometry.

Default Value: `false` 

##### Example:

```javascript
// picking the position of a translucent primitive
viewer.screenSpaceEventHandler.setInputAction(function onLeftClick(movement) {
     const pickedFeature = viewer.scene.pick(movement.position);
     if (!Cesium.defined(pickedFeature)) {
         // nothing picked
         return;
     }
     const worldPosition = viewer.scene.pickPosition(movement.position);
}, Cesium.ScreenSpaceEventType.LEFT_CLICK);
```

#### [](#postProcessStages) postProcessStages : [PostProcessStageCollection](PostProcessStageCollection.html) 

[engine/Source/Scene/Scene.js 613](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L613) 

 Post processing effects applied to the final render.

#### [](#postRender) readonly postRender : [Event](Event.html) 

[engine/Source/Scene/Scene.js 1305](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1305) 

 Gets the event that will be raised immediately after the scene is rendered. Subscribers to the event receive the Scene instance as the first parameter and the current time as the second parameter.

##### See:

* [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/)
* [Scene#preUpdate](Scene.html#preUpdate)
* [Scene#postUpdate](Scene.html#postUpdate)
* [Scene#postRender](Scene.html#postRender)

#### [](#postUpdate) readonly postUpdate : [Event](Event.html) 

[engine/Source/Scene/Scene.js 1250](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1250) 

 Gets the event that will be raised immediately after the scene is updated and before the scene is rendered. Subscribers to the event receive the Scene instance as the first parameter and the current time as the second parameter.

##### See:

* [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/)
* [Scene#preUpdate](Scene.html#preUpdate)
* [Scene#preRender](Scene.html#preRender)
* [Scene#postRender](Scene.html#postRender)

#### [](#preRender) readonly preRender : [Event](Event.html) 

[engine/Source/Scene/Scene.js 1286](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1286) 

 Gets the event that will be raised after the scene is updated and immediately before the scene is rendered. Subscribers to the event receive the Scene instance as the first parameter and the current time as the second parameter.

##### See:

* [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/)
* [Scene#preUpdate](Scene.html#preUpdate)
* [Scene#postUpdate](Scene.html#postUpdate)
* [Scene#postRender](Scene.html#postRender)

#### [](#preUpdate) readonly preUpdate : [Event](Event.html) 

[engine/Source/Scene/Scene.js 1230](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1230) 

 Gets the event that will be raised before the scene is updated or rendered. Subscribers to the event receive the Scene instance as the first parameter and the current time as the second parameter.

##### See:

* [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/)
* [Scene#postUpdate](Scene.html#postUpdate)
* [Scene#preRender](Scene.html#preRender)
* [Scene#postRender](Scene.html#postRender)

#### [](#primitives) readonly primitives : [PrimitiveCollection](PrimitiveCollection.html) 

[engine/Source/Scene/Scene.js 984](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L984) 

 Gets the collection of primitives.

#### [](#renderError) readonly renderError : [Event](Event.html) 

[engine/Source/Scene/Scene.js 1266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1266) 

 Gets the event that will be raised when an error is thrown inside the `render` function. The Scene instance and the thrown error are the only two parameters passed to the event handler. By default, errors are not rethrown after this event is raised, but that can be changed by setting the `rethrowRenderErrors` property.

#### [](#requestRenderMode) requestRenderMode : boolean 

[engine/Source/Scene/Scene.js 670](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L670) 

 When `true`, rendering a frame will only occur when needed as determined by changes within the scene. Enabling improves performance of the application, but requires using [Scene#requestRender](Scene.html#requestRender)to render a new frame explicitly in this mode. This will be necessary in many cases after making changes to the scene in other parts of the API.

Default Value: `false` 

##### See:

* [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/)
* [Scene#maximumRenderTimeChange](Scene.html#maximumRenderTimeChange)
* [Scene#requestRender](Scene.html#requestRender)

#### [](#rethrowRenderErrors) rethrowRenderErrors : boolean 

[engine/Source/Scene/Scene.js 251](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L251) 

 Exceptions occurring in `render` are always caught in order to raise the`renderError` event. If this property is true, the error is rethrown after the event is raised. If this property is false, the `render` function returns normally after raising the event.

Default Value: `false` 

#### [](#sampleHeightSupported) readonly sampleHeightSupported : boolean 

[engine/Source/Scene/Scene.js 893](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L893) 

 Returns `true` if the [Scene#sampleHeight](Scene.html#sampleHeight) and [Scene#sampleHeightMostDetailed](Scene.html#sampleHeightMostDetailed) functions are supported.

##### See:

* [Scene#sampleHeight](Scene.html#sampleHeight)
* [Scene#sampleHeightMostDetailed](Scene.html#sampleHeightMostDetailed)

#### [](#scene3DOnly) readonly scene3DOnly : boolean 

[engine/Source/Scene/Scene.js 1366](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1366) 

 Gets whether or not the scene is optimized for 3D only viewing.

#### [](#screenSpaceCameraController) readonly screenSpaceCameraController : [ScreenSpaceCameraController](ScreenSpaceCameraController.html) 

[engine/Source/Scene/Scene.js 1076](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1076) 

 Gets the controller for camera input handling.

#### [](#shadowMap) shadowMap : [ShadowMap](ShadowMap.html) 

[engine/Source/Scene/Scene.js 569](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L569) 

 The shadow map for the scene's light source. When enabled, models, primitives, and the globe may cast and receive shadows.

#### [](#skyAtmosphere) skyAtmosphere : [SkyAtmosphere](SkyAtmosphere.html) 

[engine/Source/Scene/Scene.js 292](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L292) 

 The sky atmosphere drawn around the globe.

Default Value: `undefined` 

#### [](#skyBox) skyBox : [SkyBox](SkyBox.html) 

[engine/Source/Scene/Scene.js 284](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L284) 

 The [SkyBox](SkyBox.html) used to draw the stars.

Default Value: `undefined` 

##### See:

* [Scene#backgroundColor](Scene.html#backgroundColor)

#### [](#specularEnvironmentMaps) specularEnvironmentMaps : string 

[engine/Source/Scene/Scene.js 751](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L751) 

 The url to the KTX2 file containing the specular environment map and convoluted mipmaps for image-based lighting of PBR models.

#### [](#specularEnvironmentMapsSupported) readonly specularEnvironmentMapsSupported : boolean 

[engine/Source/Scene/Scene.js 939](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L939) 

 Returns `true` if specular environment maps are supported.

##### See:

* [Scene#specularEnvironmentMaps](Scene.html#specularEnvironmentMaps)

#### [](#sphericalHarmonicCoefficients) sphericalHarmonicCoefficients : Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Scene/Scene.js 745](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L745) 

 The spherical harmonic coefficients for image-based lighting of PBR models.

#### [](#splitPosition) splitPosition : number 

[engine/Source/Scene/Scene.js 1520](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1520) 

 Gets or sets the position of the splitter within the viewport. Valid values are between 0.0 and 1.0.

#### [](#sun) sun : [Sun](Sun.html) 

[engine/Source/Scene/Scene.js 300](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L300) 

 The [Sun](Sun.html).

Default Value: `undefined` 

#### [](#sunBloom) sunBloom : boolean 

[engine/Source/Scene/Scene.js 308](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L308) 

 Uses a bloom filter on the sun when enabled.

Default Value: `true` 

#### [](#terrainProvider) terrainProvider : [TerrainProvider](TerrainProvider.html) 

[engine/Source/Scene/Scene.js 1180](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1180) 

 The terrain provider providing surface geometry for the globe.

#### [](#terrainProviderChanged) readonly terrainProviderChanged : [Event](Event.html) 

[engine/Source/Scene/Scene.js 1207](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1207) 

 Gets an event that's raised when the terrain provider is changed

#### [](#useDepthPicking) useDepthPicking : boolean 

[engine/Source/Scene/Scene.js 502](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L502) 

 When `true`, enables picking using the depth buffer.

Default Value: `true` 

#### [](#useWebVR) useWebVR : boolean 

[engine/Source/Scene/Scene.js 1466](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1466) 

 When `true`, splits the scene into two viewports with steroscopic views for the left and right eyes. Used for cardboard and WebVR.

Default Value: `false` 

#### [](#verticalExaggeration) verticalExaggeration : number 

[engine/Source/Scene/Scene.js 387](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L387) 

 The vertical exaggeration of the scene. When set to 1.0, no exaggeration is applied.

Default Value: `1.0` 

#### [](#verticalExaggerationRelativeHeight) verticalExaggerationRelativeHeight : number 

[engine/Source/Scene/Scene.js 396](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L396) 

 The reference height for vertical exaggeration of the scene. When set to 0.0, the exaggeration is applied relative to the ellipsoid surface.

Default Value: `0.0` 

### Methods

#### [](#cartesianToCanvasCoordinates) cartesianToCanvasCoordinates(position, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/Scene.js 4906](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4906) 

 Transforms a position in cartesian coordinates to canvas coordinates. This is commonly used to place an HTML element at the same screen position as an object in the scene.

| Name     | Type                          | Description                                                                                 |
| -------- | ----------------------------- | ------------------------------------------------------------------------------------------- |
| position | [Cartesian3](Cartesian3.html) | The position in cartesian coordinates.                                                      |
| result   | [Cartesian2](Cartesian2.html) | optional An optional object to return the input position transformed to canvas coordinates. |

##### Returns:

 The modified result parameter or a new Cartesian2 instance if one was not provided. This may be `undefined` if the input position is near the center of the ellipsoid.

##### Example:

```javascript
// Output the canvas position of longitude/latitude (0, 0) every time the mouse moves.
const scene = widget.scene;
const position = Cesium.Cartesian3.fromDegrees(0.0, 0.0);
const handler = new Cesium.ScreenSpaceEventHandler(scene.canvas);
handler.setInputAction(function(movement) {
    console.log(scene.cartesianToCanvasCoordinates(position));
}, Cesium.ScreenSpaceEventType.MOUSE_MOVE);
```

#### [](#clampToHeight) clampToHeight(cartesian, objectsToExclude, width, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Scene.js 4793](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4793) 

 Clamps the given cartesian position to the scene geometry along the geodetic surface normal. Returns the clamped position or `undefined` if there was no scene geometry to clamp to. May be used to clamp objects to the globe, 3D Tiles, or primitives in the scene.

This function only clamps to globe tiles and 3D Tiles that are rendered in the current view. Clamps to all other primitives regardless of their visibility.

| Name             | Type                          | Default | Description                                                                    |
| ---------------- | ----------------------------- | ------- | ------------------------------------------------------------------------------ |
| cartesian        | [Cartesian3](Cartesian3.html) |         | The cartesian position.                                                        |
| objectsToExclude | Array.<Object>                |         | optional A list of primitives, entities, or 3D Tiles features to not clamp to. |
| width            | number                        | 0.1     | optional Width of the intersection volume in meters.                           |
| result           | [Cartesian3](Cartesian3.html) |         | optional An optional object to return the clamped position.                    |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if one was not provided. This may be `undefined` if there was no scene geometry to clamp to.

##### Throws:

* [DeveloperError](DeveloperError.html): clampToHeight is only supported in 3D mode.
* [DeveloperError](DeveloperError.html): clampToHeight requires depth texture support. Check clampToHeightSupported.

##### Example:

```javascript
// Clamp an entity to the underlying scene geometry
const position = entity.position.getValue(Cesium.JulianDate.now());
entity.position = viewer.scene.clampToHeight(position);
```

##### See:

* [Scene#sampleHeight](Scene.html#sampleHeight)
* [Scene#sampleHeightMostDetailed](Scene.html#sampleHeightMostDetailed)
* [Scene#clampToHeightMostDetailed](Scene.html#clampToHeightMostDetailed)

#### [](#clampToHeightMostDetailed) clampToHeightMostDetailed(cartesians, objectsToExclude, width) → Promise.<Array.<[Cartesian3](Cartesian3.html)\>> 

[engine/Source/Scene/Scene.js 4876](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4876) 

 Initiates an asynchronous [Scene#clampToHeight](Scene.html#clampToHeight) query for an array of [Cartesian3](Cartesian3.html) positions using the maximum level of detail for 3D Tilesets in the scene. Returns a promise that is resolved when the query completes. Each position is modified in place. If a position cannot be clamped because no geometry can be sampled at that location, or another error occurs, the element in the array is set to undefined.

| Name             | Type                                   | Default | Description                                                                    |
| ---------------- | -------------------------------------- | ------- | ------------------------------------------------------------------------------ |
| cartesians       | Array.<[Cartesian3](Cartesian3.html)\> |         | The cartesian positions to update with clamped positions.                      |
| objectsToExclude | Array.<Object>                         |         | optional A list of primitives, entities, or 3D Tiles features to not clamp to. |
| width            | number                                 | 0.1     | optional Width of the intersection volume in meters.                           |

##### Returns:

 A promise that resolves to the provided list of positions when the query has completed.

##### Throws:

* [DeveloperError](DeveloperError.html): clampToHeightMostDetailed is only supported in 3D mode.
* [DeveloperError](DeveloperError.html): clampToHeightMostDetailed requires depth texture support. Check clampToHeightSupported.

##### Example:

```javascript
const cartesians = [
    entities[0].position.getValue(Cesium.JulianDate.now()),
    entities[1].position.getValue(Cesium.JulianDate.now())
];
const promise = viewer.scene.clampToHeightMostDetailed(cartesians);
promise.then(function(updatedCartesians) {
    entities[0].position = updatedCartesians[0];
    entities[1].position = updatedCartesians[1];
}
```

##### See:

* [Scene#clampToHeight](Scene.html#clampToHeight)

#### [](#completeMorph) completeMorph() 

[engine/Source/Scene/Scene.js 4913](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4913) 

 Instantly completes an active transition.

#### [](#destroy) destroy() 

[engine/Source/Scene/Scene.js 5028](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L5028) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
scene = scene && scene.destroy();
```

##### See:

* [Scene#isDestroyed](Scene.html#isDestroyed)

#### [](#drillPick) drillPick(windowPosition, limit, width, height) → Array.<any> 

[engine/Source/Scene/Scene.js 4586](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4586) 

 Returns a list of objects, each containing a \`primitive\` property, for all primitives at a particular window coordinate position. Other properties may also be set depending on the type of primitive and may be used to further identify the picked object. The primitives in the list are ordered by their visual order in the scene (front to back).

| Name           | Type                          | Default | Description                                                           |
| -------------- | ----------------------------- | ------- | --------------------------------------------------------------------- |
| windowPosition | [Cartesian2](Cartesian2.html) |         | Window coordinates to perform picking on.                             |
| limit          | number                        |         | optional If supplied, stop drilling after collecting this many picks. |
| width          | number                        | 3       | optional Width of the pick rectangle.                                 |
| height         | number                        | 3       | optional Height of the pick rectangle.                                |

##### Returns:

 Array of objects, each containing 1 picked primitives.

##### Throws:

* [DeveloperError](DeveloperError.html): windowPosition is undefined.

##### Example:

```javascript
const pickedObjects = scene.drillPick(new Cesium.Cartesian2(100.0, 200.0));
```

##### See:

* [Scene#pick](Scene.html#pick)

#### [](#getCompressedTextureFormatSupported) getCompressedTextureFormatSupported(format) → boolean 

[engine/Source/Scene/Scene.js 1709](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L1709) 

 Determines if a compressed texture format is supported.

| Name   | Type   | Description                                                                                                                   |
| ------ | ------ | ----------------------------------------------------------------------------------------------------------------------------- |
| format | string | The texture format. May be the name of the format or the WebGL extension name, e.g. s3tc or WEBGL\_compressed\_texture\_s3tc. |

##### Returns:

 Whether or not the format is supported.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/Scene.js 5008](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L5008) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [Scene#destroy](Scene.html#destroy)

#### [](#morphTo2D) morphTo2D(duration) 

[engine/Source/Scene/Scene.js 4921](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4921) 

 Asynchronously transitions the scene to 2D.

| Name     | Type   | Default | Description                                                                     |
| -------- | ------ | ------- | ------------------------------------------------------------------------------- |
| duration | number | 2.0     | optional The amount of time, in seconds, for transition animations to complete. |

#### [](#morphTo3D) morphTo3D(duration) 

[engine/Source/Scene/Scene.js 4939](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4939) 

 Asynchronously transitions the scene to 3D.

| Name     | Type   | Default | Description                                                                     |
| -------- | ------ | ------- | ------------------------------------------------------------------------------- |
| duration | number | 2.0     | optional The amount of time, in seconds, for transition animations to complete. |

#### [](#morphToColumbusView) morphToColumbusView(duration) 

[engine/Source/Scene/Scene.js 4930](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4930) 

 Asynchronously transitions the scene to Columbus View.

| Name     | Type   | Default | Description                                                                     |
| -------- | ------ | ------- | ------------------------------------------------------------------------------- |
| duration | number | 2.0     | optional The amount of time, in seconds, for transition animations to complete. |

#### [](#pick) pick(windowPosition, width, height) → object 

[engine/Source/Scene/Scene.js 4362](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4362) 

 Returns an object with a \`primitive\` property that contains the first (top) primitive in the scene at a particular window coordinate or undefined if nothing is at the location. Other properties may potentially be set depending on the type of primitive and may be used to further identify the picked object.

When a feature of a 3D Tiles tileset is picked, `pick` returns a [Cesium3DTileFeature](Cesium3DTileFeature.html) object.

| Name           | Type                          | Default | Description                               |
| -------------- | ----------------------------- | ------- | ----------------------------------------- |
| windowPosition | [Cartesian2](Cartesian2.html) |         | Window coordinates to perform picking on. |
| width          | number                        | 3       | optional Width of the pick rectangle.     |
| height         | number                        | 3       | optional Height of the pick rectangle.    |

##### Returns:

 Object containing the picked primitive.

##### Example:

```javascript
// On mouse over, color the feature yellow.
handler.setInputAction(function(movement) {
    const feature = scene.pick(movement.endPosition);
    if (feature instanceof Cesium.Cesium3DTileFeature) {
        feature.color = Cesium.Color.YELLOW;
    }
}, Cesium.ScreenSpaceEventType.MOUSE_MOVE);
```

#### [](#pickMetadata) pickMetadata(windowPosition, schemaId, className, propertyName) → [MetadataValue](global.html#MetadataValue)|undefined 

[engine/Source/Scene/Scene.js 4435](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4435) 

 Pick a metadata value at the given window position.

| Name           | Type                          | Description                                                                                                                                                                                           |
| -------------- | ----------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| windowPosition | [Cartesian2](Cartesian2.html) | Window coordinates to perform picking on.                                                                                                                                                             |
| schemaId       | string\|undefined             | The ID of the metadata schema to pick values from. If this is \`undefined\`, then it will pick the values from the object that match the given class- and property name, regardless of the schema ID. |
| className      | string                        | The name of the metadata class to pick values from                                                                                                                                                    |
| propertyName   | string                        | The name of the metadata property to pick values from                                                                                                                                                 |

##### Returns:

 The metadata value, or \`undefined\` when no matching metadata was found at the given position

##### Experimental

This feature is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#pickMetadataSchema) pickMetadataSchema(windowPosition) → [MetadataSchema](MetadataSchema.html) 

[engine/Source/Scene/Scene.js 4504](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4504) 

 Pick the schema of the metadata of the object at the given position

| Name           | Type                          | Description                               |
| -------------- | ----------------------------- | ----------------------------------------- |
| windowPosition | [Cartesian2](Cartesian2.html) | Window coordinates to perform picking on. |

##### Returns:

 The metadata schema, or \`undefined\` if there is no object with associated metadata at the given position.

##### Experimental

This feature is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#pickPosition) pickPosition(windowPosition, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Scene.js 4563](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4563) 

 Returns the cartesian position reconstructed from the depth buffer and window position.

The position reconstructed from the depth buffer in 2D may be slightly different from those reconstructed in 3D and Columbus view. This is caused by the difference in the distribution of depth values of perspective and orthographic projection.

Set [Scene#pickTranslucentDepth](Scene.html#pickTranslucentDepth) to `true` to include the depth of translucent primitives; otherwise, this essentially picks through translucent primitives.

| Name           | Type                          | Description                                         |
| -------------- | ----------------------------- | --------------------------------------------------- |
| windowPosition | [Cartesian2](Cartesian2.html) | Window coordinates to perform picking on.           |
| result         | [Cartesian3](Cartesian3.html) | optional The object on which to restore the result. |

##### Returns:

 The cartesian position.

##### Throws:

* [DeveloperError](DeveloperError.html): Picking from the depth buffer is not supported. Check pickPositionSupported.

#### [](#pickVoxel) pickVoxel(windowPosition, width, height) → [VoxelCell](VoxelCell.html)|undefined 

[engine/Source/Scene/Scene.js 4386](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4386) 

 Returns a [VoxelCell](VoxelCell.html) for the voxel sample rendered at a particular window coordinate, or undefined if no voxel is rendered at that position.

| Name           | Type                          | Default | Description                               |
| -------------- | ----------------------------- | ------- | ----------------------------------------- |
| windowPosition | [Cartesian2](Cartesian2.html) |         | Window coordinates to perform picking on. |
| width          | number                        | 3       | optional Width of the pick rectangle.     |
| height         | number                        | 3       | optional Height of the pick rectangle.    |

##### Returns:

 Information about the voxel cell rendered at the picked position.

##### Example:

```javascript
On left click, report the value of the "color" property at that voxel sample.
handler.setInputAction(function(movement) {
  const voxelCell = scene.pickVoxel(movement.position);
  if (defined(voxelCell)) {
    console.log(voxelCell.getProperty("color"));
  }
}, Cesium.ScreenSpaceEventType.LEFT_CLICK);
```

##### Experimental

This feature is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#render) render(time) 

[engine/Source/Scene/Scene.js 4215](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4215) 

 Update and render the scene. It is usually not necessary to call this function directly because [CesiumWidget](CesiumWidget.html) will do it automatically.

| Name | Type                          | Description                                      |
| ---- | ----------------------------- | ------------------------------------------------ |
| time | [JulianDate](JulianDate.html) | optional The simulation time at which to render. |

#### [](#requestRender) requestRender() 

[engine/Source/Scene/Scene.js 4326](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4326) 

 Requests a new rendered frame when [Scene#requestRenderMode](Scene.html#requestRenderMode) is set to `true`. The render rate will not exceed the [CesiumWidget#targetFrameRate](CesiumWidget.html#targetFrameRate).

##### See:

* [Scene#requestRenderMode](Scene.html#requestRenderMode)

#### [](#sampleHeight) sampleHeight(position, objectsToExclude, width) → number 

[engine/Source/Scene/Scene.js 4762](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4762) 

 Returns the height of scene geometry at the given cartographic position or `undefined` if there was no scene geometry to sample height from. The height of the input position is ignored. May be used to clamp objects to the globe, 3D Tiles, or primitives in the scene.

This function only samples height from globe tiles and 3D Tiles that are rendered in the current view. Samples height from all other primitives regardless of their visibility.

| Name             | Type                              | Default | Description                                                                              |
| ---------------- | --------------------------------- | ------- | ---------------------------------------------------------------------------------------- |
| position         | [Cartographic](Cartographic.html) |         | The cartographic position to sample height from.                                         |
| objectsToExclude | Array.<Object>                    |         | optional A list of primitives, entities, or 3D Tiles features to not sample height from. |
| width            | number                            | 0.1     | optional Width of the intersection volume in meters.                                     |

##### Returns:

 The height. This may be `undefined` if there was no scene geometry to sample height from.

##### Throws:

* [DeveloperError](DeveloperError.html): sampleHeight is only supported in 3D mode.
* [DeveloperError](DeveloperError.html): sampleHeight requires depth texture support. Check sampleHeightSupported.

##### Example:

```javascript
const position = new Cesium.Cartographic(-1.31968, 0.698874);
const height = viewer.scene.sampleHeight(position);
console.log(height);
```

##### See:

* [Scene#clampToHeight](Scene.html#clampToHeight)
* [Scene#clampToHeightMostDetailed](Scene.html#clampToHeightMostDetailed)
* [Scene#sampleHeightMostDetailed](Scene.html#sampleHeightMostDetailed)

#### [](#sampleHeightMostDetailed) sampleHeightMostDetailed(positions, objectsToExclude, width) → Promise.<Array.<[Cartographic](Cartographic.html)\>> 

[engine/Source/Scene/Scene.js 4836](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4836) 

 Initiates an asynchronous [Scene#sampleHeight](Scene.html#sampleHeight) query for an array of [Cartographic](Cartographic.html) positions using the maximum level of detail for 3D Tilesets in the scene. The height of the input positions is ignored. Returns a promise that is resolved when the query completes. Each point height is modified in place. If a height cannot be determined because no geometry can be sampled at that location, or another error occurs, the height is set to undefined.

| Name             | Type                                       | Default | Description                                                                              |
| ---------------- | ------------------------------------------ | ------- | ---------------------------------------------------------------------------------------- |
| positions        | Array.<[Cartographic](Cartographic.html)\> |         | The cartographic positions to update with sampled heights.                               |
| objectsToExclude | Array.<Object>                             |         | optional A list of primitives, entities, or 3D Tiles features to not sample height from. |
| width            | number                                     | 0.1     | optional Width of the intersection volume in meters.                                     |

##### Returns:

 A promise that resolves to the provided list of positions when the query has completed.

##### Throws:

* [DeveloperError](DeveloperError.html): sampleHeightMostDetailed is only supported in 3D mode.
* [DeveloperError](DeveloperError.html): sampleHeightMostDetailed requires depth texture support. Check sampleHeightSupported.

##### Example:

```javascript
const positions = [
    new Cesium.Cartographic(-1.31968, 0.69887),
    new Cesium.Cartographic(-1.10489, 0.83923)
];
const promise = viewer.scene.sampleHeightMostDetailed(positions);
promise.then(function(updatedPosition) {
    // positions[0].height and positions[1].height have been updated.
    // updatedPositions is just a reference to positions.
}
```

##### See:

* [Scene#sampleHeight](Scene.html#sampleHeight)

#### [](#setTerrain) setTerrain(terrain) → [Terrain](Terrain.html) 

[engine/Source/Scene/Scene.js 4988](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L4988) 

 Update the terrain providing surface geometry for the globe.

| Name    | Type                    | Description                       |
| ------- | ----------------------- | --------------------------------- |
| terrain | [Terrain](Terrain.html) | The terrain provider async helper |

##### Returns:

 terrain The terrain provider async helper

##### Examples:

```javascript
// Use Cesium World Terrain
scene.setTerrain(Cesium.Terrain.fromWorldTerrain());
```

```javascript
// Use a custom terrain provider
const terrain = new Cesium.Terrain(Cesium.CesiumTerrainProvider.fromUrl("https://myTestTerrain.com"));
scene.setTerrain(terrain);

terrain.errorEvent.addEventListener(error => {
  alert(`Encountered an error while creating terrain! ${error}`);
});
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

