# [![](Images/CesiumLogo.png)](index.html) CorridorGeometry 

#### [](#CorridorGeometry) new Cesium.CorridorGeometry(options) 

[engine/Source/Core/CorridorGeometry.js 1072](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CorridorGeometry.js#L1072) 

 A description of a corridor. Corridor geometry can be rendered with both [Primitive](Primitive.html) and [GroundPrimitive](GroundPrimitive.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of positions that define the center of the corridor. width number  The distance between the edges of the corridor in meters. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid to be used as a reference. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The distance, in radians, between each latitude and longitude. Determines the number of positions in the buffer. height number 0 optional The distance in meters between the ellipsoid surface and the positions. extrudedHeight number optional The distance in meters between the ellipsoid surface and the extruded face. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. cornerType [CornerType](global.html#CornerType) CornerType.ROUNDED optional Determines the style of the corners. |

##### Example:

```javascript
const corridor = new Cesium.CorridorGeometry({
  vertexFormat : Cesium.VertexFormat.POSITION_ONLY,
  positions : Cesium.Cartesian3.fromDegreesArray([-72.0, 40.0, -70.0, 35.0]),
  width : 100000
});
```

##### Demo:

* [Cesium Sandcastle Corridor Demo](https://sandcastle.cesium.com/index.html?src=Corridor.html)

##### See:

* [CorridorGeometry.createGeometry](CorridorGeometry.html#.createGeometry)
* [Packable](Packable.html)

### Members

#### [](#packedLength) packedLength : number 

[engine/Source/Core/CorridorGeometry.js 1109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CorridorGeometry.js#L1109) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.computeRectangle) static Cesium.CorridorGeometry.computeRectangle(options, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/CorridorGeometry.js 1255](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CorridorGeometry.js#L1255) 

 Computes the bounding rectangle given the provided options

| Name    | Type                        | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | --------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object                      | Object with the following properties: Name Type Default Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of positions that define the center of the corridor. width number  The distance between the edges of the corridor in meters. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid to be used as a reference. cornerType [CornerType](global.html#CornerType) CornerType.ROUNDED optional Determines the style of the corners. |
| result  | [Rectangle](Rectangle.html) | optional An object in which to store the result.                                                                                                                                                                                                                                                                                                                                                                                                                                       |

##### Returns:

 The result rectangle.

#### [](#.createGeometry) static Cesium.CorridorGeometry.createGeometry(corridorGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/CorridorGeometry.js 1277](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CorridorGeometry.js#L1277) 

 Computes the geometric representation of a corridor, including its vertices, indices, and a bounding sphere.

| Name             | Type                                      | Description                    |
| ---------------- | ----------------------------------------- | ------------------------------ |
| corridorGeometry | [CorridorGeometry](CorridorGeometry.html) | A description of the corridor. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.CorridorGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/CorridorGeometry.js 1126](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CorridorGeometry.js#L1126) 

 Stores the provided instance into the provided array.

| Name          | Type                                      | Default | Description                                                               |
| ------------- | ----------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [CorridorGeometry](CorridorGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                            |         | The array to pack into.                                                   |
| startingIndex | number                                    | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.CorridorGeometry.unpack(array, startingIndex, result) → [CorridorGeometry](CorridorGeometry.html) 

[engine/Source/Core/CorridorGeometry.js 1182](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CorridorGeometry.js#L1182) 

 Retrieves an instance from a packed array.

| Name          | Type                                      | Default | Description                                                |
| ------------- | ----------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                            |         | The packed array.                                          |
| startingIndex | number                                    | 0       | optional The starting index of the element to be unpacked. |
| result        | [CorridorGeometry](CorridorGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new CorridorGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

