# [![](Images/CesiumLogo.png)](index.html) GoogleEarthEnterpriseImageryProvider 

#### [](#GoogleEarthEnterpriseImageryProvider) new Cesium.GoogleEarthEnterpriseImageryProvider(options) 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L88) 

To construct a GoogleEarthEnterpriseImageryProvider, call [GoogleEarthEnterpriseImageryProvider.fromMetadata](GoogleEarthEnterpriseImageryProvider.html#.fromMetadata). Do not call the constructor directly.

Provides tiled imagery using the Google Earth Enterprise REST API. Notes: This provider is for use with the 3D Earth API of Google Earth Enterprise,[GoogleEarthEnterpriseMapsProvider](GoogleEarthEnterpriseMapsProvider.html) should be used with 2D Maps API.

| Name    | Type                                                                                                                     | Description                                       |
| ------- | ------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------- |
| options | [GoogleEarthEnterpriseImageryProvider.ConstructorOptions](GoogleEarthEnterpriseImageryProvider.html#.ConstructorOptions) | optional Object describing initialization options |

##### Example:

```javascript
const geeMetadata = await GoogleEarthEnterpriseMetadata.fromUrl("http://www.example.com");
const gee = Cesium.GoogleEarthEnterpriseImageryProvider.fromMetadata(geeMetadata);
```

##### See:

* [GoogleEarthEnterpriseImageryProvider.fromMetadata](GoogleEarthEnterpriseImageryProvider.html#.fromMetadata)
* [GoogleEarthEnterpriseTerrainProvider](GoogleEarthEnterpriseTerrainProvider.html)
* [ArcGisMapServerImageryProvider](ArcGisMapServerImageryProvider.html)
* [GoogleEarthEnterpriseMapsProvider](GoogleEarthEnterpriseMapsProvider.html)
* [OpenStreetMapImageryProvider](OpenStreetMapImageryProvider.html)
* [SingleTileImageryProvider](SingleTileImageryProvider.html)
* [TileMapServiceImageryProvider](TileMapServiceImageryProvider.html)
* [WebMapServiceImageryProvider](WebMapServiceImageryProvider.html)
* [WebMapTileServiceImageryProvider](WebMapTileServiceImageryProvider.html)
* [UrlTemplateImageryProvider](UrlTemplateImageryProvider.html)
* [Cross-Origin Resource Sharing](http://www.w3.org/TR/cors/)

### Members

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 265](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L265) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 252](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L252) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 281](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L281) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. Setting this property to false reduces memory usage and texture upload time.

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 188](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L188) 

 Gets the maximum level-of-detail that can be requested.

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L200) 

 Gets the minimum level-of-detail that can be requested.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 152](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L152) 

 Gets the proxy used by this provider.

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 224](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L224) 

 Gets the rectangle, in radians, of the imagery provided by this instance.

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 238](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L238) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L176) 

 Gets the height of each tile, in pixels.

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 164](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L164) 

 Gets the width of each tile, in pixels.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 212](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L212) 

 Gets the tiling scheme used by this provider.

#### [](#url) readonly url : string 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 140](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L140) 

 Gets the name of the Google Earth Enterprise server url hosting the imagery.

### Methods

#### [](#.fromMetadata) static Cesium.GoogleEarthEnterpriseImageryProvider.fromMetadata(metadata, options) → [GoogleEarthEnterpriseImageryProvider](GoogleEarthEnterpriseImageryProvider.html) 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 300](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L300) 

 Creates a tiled imagery provider using the Google Earth Enterprise REST API.

| Name     | Type                                                                                                                     | Description                                                                                                |
| -------- | ------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------- |
| metadata | [GoogleEarthEnterpriseMetadata](GoogleEarthEnterpriseMetadata.html)                                                      | A metadata object that can be used to share metadata requests with a GoogleEarthEnterpriseTerrainProvider. |
| options  | [GoogleEarthEnterpriseImageryProvider.ConstructorOptions](GoogleEarthEnterpriseImageryProvider.html#.ConstructorOptions) | Object describing initialization options.                                                                  |

##### Returns:

##### Throws:

* [RuntimeError](RuntimeError.html): The metadata url does not have imagery

##### Example:

```javascript
const geeMetadata = await GoogleEarthEnterpriseMetadata.fromUrl("http://www.example.com");
const gee = Cesium.GoogleEarthEnterpriseImageryProvider.fromMetadata(geeMetadata);
```

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 325](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L325) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → undefined 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 431](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L431) 

 Picking features is not currently supported by this imagery provider, so this function simply returns undefined.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 Undefined since picking is not supported.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<[ImageryTypes](global.html#ImageryTypes)\>|undefined 

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 352](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L352) 

 Requests the image for a given tile.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the image that will resolve when the image is available, or undefined if there are too many active requests to the server, and the request should be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.GoogleEarthEnterpriseImageryProvider.ConstructorOptions

[engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js 43](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GoogleEarthEnterpriseImageryProvider.js#L43) 

 Initialization options for the GoogleEarthEnterpriseImageryProvider constructor

##### Properties:

| Name              | Type                                        | Attributes | Default           | Description                                                                                                                                                   |
| ----------------- | ------------------------------------------- | ---------- | ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ellipsoid         | [Ellipsoid](Ellipsoid.html)                 | <optional> | Ellipsoid.default | The ellipsoid. If not specified, the default ellipsoid is used.                                                                                               |
| tileDiscardPolicy | [TileDiscardPolicy](TileDiscardPolicy.html) | <optional> |                   | The policy that determines if a tile is invalid and should be discarded. If this value is not specified, a default is to discard tiles that fail to download. |
| credit            | [Credit](Credit.html)\|string               | <optional> |                   | A credit for the data source, which is displayed on the canvas.                                                                                               |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

