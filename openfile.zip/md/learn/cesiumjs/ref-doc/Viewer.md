# [![](Images/CesiumLogo.png)](index.html) Viewer 

#### [](#Viewer) new Cesium.Viewer(container, options) 

[widgets/Source/Viewer/Viewer.js 396](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L396) 

 A base widget for building applications. It composites all of the standard Cesium widgets into one reusable package. The widget can always be extended by using mixins, which add functionality useful for a variety of applications.

| Name      | Type                                                         | Description                                         |
| --------- | ------------------------------------------------------------ | --------------------------------------------------- |
| container | Element\|string                                              | The DOM element or ID that will contain the widget. |
| options   | [Viewer.ConstructorOptions](Viewer.html#.ConstructorOptions) | optional Object describing initialization options   |

##### Throws:

* [DeveloperError](DeveloperError.html): Element with id "container" does not exist in the document.
* [DeveloperError](DeveloperError.html): options.selectedImageryProviderViewModel is not available when not using the BaseLayerPicker widget, specify options.baseLayer instead.
* [DeveloperError](DeveloperError.html): options.selectedTerrainProviderViewModel is not available when not using the BaseLayerPicker widget, specify options.terrainProvider instead.

##### Example:

```javascript
// Initialize the viewer widget with several custom options and mixins.
try {
  const viewer = new Cesium.Viewer("cesiumContainer", {
    // Start in Columbus Viewer
    sceneMode: Cesium.SceneMode.COLUMBUS_VIEW,
    // Use Cesium World Terrain
    terrain: Cesium.Terrain.fromWorldTerrain(),
    // Hide the base layer picker
    baseLayerPicker: false,
    // Use OpenStreetMaps
    baseLayer: new Cesium.ImageryLayer(new Cesium.OpenStreetMapImageryProvider({
      url: "https://tile.openstreetmap.org/"
    })),
    skyBox: new Cesium.SkyBox({
      sources: {
        positiveX: "stars/TychoSkymapII.t3_08192x04096_80_px.jpg",
        negativeX: "stars/TychoSkymapII.t3_08192x04096_80_mx.jpg",
        positiveY: "stars/TychoSkymapII.t3_08192x04096_80_py.jpg",
        negativeY: "stars/TychoSkymapII.t3_08192x04096_80_my.jpg",
        positiveZ: "stars/TychoSkymapII.t3_08192x04096_80_pz.jpg",
        negativeZ: "stars/TychoSkymapII.t3_08192x04096_80_mz.jpg"
      }
    }),
    // Show Columbus View map with Web Mercator projection
    mapProjection: new Cesium.WebMercatorProjection()
  });
} catch (error) {
  console.log(error);
}

// Add basic drag and drop functionality
viewer.extend(Cesium.viewerDragDropMixin);

// Show a pop-up alert if we encounter an error when processing a dropped file
viewer.dropError.addEventListener(function(dropHandler, name, error) {
  console.log(error);
  window.alert(error);
});
```

##### Demo:

* [Cesium Sandcastle Hello World Demo](https://sandcastle.cesium.com/index.html?src=Hello%2520World.html)

##### See:

* [Animation](Animation.html)
* [BaseLayerPicker](BaseLayerPicker.html)
* [CesiumWidget](CesiumWidget.html)
* [FullscreenButton](FullscreenButton.html)
* [HomeButton](HomeButton.html)
* [SceneModePicker](SceneModePicker.html)
* [Timeline](Timeline.html)
* [viewerDragDropMixin](global.html#viewerDragDropMixin)

### Members

#### [](#allowDataSourcesToSuspendAnimation) allowDataSourcesToSuspendAnimation : boolean 

[widgets/Source/Viewer/Viewer.js 1428](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1428) 

 Gets or sets whether or not data sources can temporarily pause animation in order to avoid showing an incomplete picture to the user. For example, if asynchronous primitives are being processed in the background, the clock will not advance until the geometry is ready.

#### [](#animation) readonly animation : [Animation](Animation.html) 

[widgets/Source/Viewer/Viewer.js 1088](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1088) 

 Gets the Animation widget.

#### [](#baseLayerPicker) readonly baseLayerPicker : [BaseLayerPicker](BaseLayerPicker.html) 

[widgets/Source/Viewer/Viewer.js 1064](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1064) 

 Gets the BaseLayerPicker.

#### [](#bottomContainer) readonly bottomContainer : Element 

[widgets/Source/Viewer/Viewer.js 968](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L968) 

 Gets the DOM element for the area at the bottom of the window containing the[CreditDisplay](CreditDisplay.html) and potentially other things.

#### [](#camera) readonly camera : [Camera](Camera.html) 

[widgets/Source/Viewer/Viewer.js 1266](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1266) 

 Gets the camera.

#### [](#canvas) readonly canvas : HTMLCanvasElement 

[widgets/Source/Viewer/Viewer.js 1173](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1173) 

 Gets the canvas.

#### [](#cesiumWidget) readonly cesiumWidget : [CesiumWidget](CesiumWidget.html) 

[widgets/Source/Viewer/Viewer.js 980](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L980) 

 Gets the CesiumWidget.

#### [](#clock) readonly clock : [Clock](Clock.html) 

[widgets/Source/Viewer/Viewer.js 1305](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1305) 

 Gets the clock.

#### [](#clockTrackedDataSource) clockTrackedDataSource : [DataSource](DataSource.html) 

[widgets/Source/Viewer/Viewer.js 1508](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1508) 

 Gets or sets the data source to track with the viewer's clock.

#### [](#clockViewModel) readonly clockViewModel : [ClockViewModel](ClockViewModel.html) 

[widgets/Source/Viewer/Viewer.js 1317](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1317) 

 Gets the clock view model.

#### [](#container) readonly container : Element 

[widgets/Source/Viewer/Viewer.js 943](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L943) 

 Gets the parent container.

#### [](#creditDisplay) creditDisplay : [CreditDisplay](CreditDisplay.html) 

[widgets/Source/Viewer/Viewer.js 955](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L955) 

 Manages the list of credits to display on screen and in the lightbox.

#### [](#dataSourceDisplay) readonly dataSourceDisplay : [DataSourceDisplay](DataSourceDisplay.html) 

[widgets/Source/Viewer/Viewer.js 1136](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1136) 

 Gets the display used for [DataSource](DataSource.html) visualization.

#### [](#dataSources) readonly dataSources : [DataSourceCollection](DataSourceCollection.html) 

[widgets/Source/Viewer/Viewer.js 1161](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1161) 

 Gets the set of [DataSource](DataSource.html) instances to be visualized.

#### [](#ellipsoid) readonly ellipsoid : [Ellipsoid](Ellipsoid.html) 

[widgets/Source/Viewer/Viewer.js 1280](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1280) 

 Gets the default ellipsoid for the scene.

Default Value: `Ellipsoid.default` 

#### [](#entities) readonly entities : [EntityCollection](EntityCollection.html) 

[widgets/Source/Viewer/Viewer.js 1149](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1149) 

 Gets the collection of entities not tied to a particular data source. This is a shortcut to [dataSourceDisplay.defaultDataSource.entities](Viewer.html#dataSourceDisplay).

#### [](#fullscreenButton) readonly fullscreenButton : [FullscreenButton](FullscreenButton.html) 

[widgets/Source/Viewer/Viewer.js 1112](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1112) 

 Gets the FullscreenButton.

#### [](#geocoder) readonly geocoder : [Geocoder](Geocoder.html) 

[widgets/Source/Viewer/Viewer.js 1016](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1016) 

 Gets the Geocoder.

#### [](#homeButton) readonly homeButton : [HomeButton](HomeButton.html) 

[widgets/Source/Viewer/Viewer.js 1028](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1028) 

 Gets the HomeButton.

#### [](#imageryLayers) readonly imageryLayers : [ImageryLayerCollection](ImageryLayerCollection.html) 

[widgets/Source/Viewer/Viewer.js 1238](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1238) 

 Gets the collection of image layers that will be rendered on the globe.

#### [](#infoBox) readonly infoBox : [InfoBox](InfoBox.html) 

[widgets/Source/Viewer/Viewer.js 1004](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1004) 

 Gets the info box.

#### [](#navigationHelpButton) readonly navigationHelpButton : [NavigationHelpButton](NavigationHelpButton.html) 

[widgets/Source/Viewer/Viewer.js 1076](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1076) 

 Gets the NavigationHelpButton.

#### [](#postProcessStages) readonly postProcessStages : [PostProcessStageCollection](PostProcessStageCollection.html) 

[widgets/Source/Viewer/Viewer.js 1293](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1293) 

 Gets the post-process stages.

#### [](#projectionPicker) readonly projectionPicker : [ProjectionPicker](ProjectionPicker.html) 

[widgets/Source/Viewer/Viewer.js 1052](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1052) 

 Gets the ProjectionPicker.

#### [](#resolutionScale) resolutionScale : number 

[widgets/Source/Viewer/Viewer.js 1388](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1388) 

 Gets or sets a scaling factor for rendering resolution. Values less than 1.0 can improve performance on less powerful devices while values greater than 1.0 will render at a higher resolution and then scale down, resulting in improved visual fidelity. For example, if the widget is laid out at a size of 640x480, setting this value to 0.5 will cause the scene to be rendered at 320x240 and then scaled up while setting it to 2.0 will cause the scene to be rendered at 1280x960 and then scaled down.

Default Value: `1.0` 

#### [](#scene) readonly scene : [Scene](Scene.html) 

[widgets/Source/Viewer/Viewer.js 1185](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1185) 

 Gets the scene.

#### [](#sceneModePicker) readonly sceneModePicker : [SceneModePicker](SceneModePicker.html) 

[widgets/Source/Viewer/Viewer.js 1040](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1040) 

 Gets the SceneModePicker.

#### [](#screenSpaceEventHandler) readonly screenSpaceEventHandler : [ScreenSpaceEventHandler](ScreenSpaceEventHandler.html) 

[widgets/Source/Viewer/Viewer.js 1329](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1329) 

 Gets the screen space event handler.

#### [](#selectedEntity) selectedEntity : [Entity](Entity.html)|undefined 

[widgets/Source/Viewer/Viewer.js 1459](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1459) 

 Gets or sets the object instance for which to display a selection indicator. If a user interactively picks a Cesium3DTilesFeature instance, then this property will contain a transient Entity instance with a property named "feature" that is the instance that was picked.

#### [](#selectedEntityChanged) readonly selectedEntityChanged : [Event](Event.html) 

[widgets/Source/Viewer/Viewer.js 1487](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1487) 

 Gets the event that is raised when the selected entity changes.

#### [](#selectionIndicator) readonly selectionIndicator : [SelectionIndicator](SelectionIndicator.html) 

[widgets/Source/Viewer/Viewer.js 992](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L992) 

 Gets the selection indicator.

#### [](#shadowMap) readonly shadowMap : [ShadowMap](ShadowMap.html) 

[widgets/Source/Viewer/Viewer.js 1225](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1225) 

 Get the scene's shadow map

#### [](#shadows) shadows : boolean 

[widgets/Source/Viewer/Viewer.js 1196](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1196) 

 Determines if shadows are cast by light sources.

#### [](#targetFrameRate) targetFrameRate : number 

[widgets/Source/Viewer/Viewer.js 1344](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1344) 

 Gets or sets the target frame rate of the widget when `useDefaultRenderLoop`is true. If undefined, the browser's requestAnimationFrame implementation determines the frame rate. If defined, this value must be greater than 0\. A value higher than the underlying requestAnimationFrame implementation will have no effect.

#### [](#terrainProvider) terrainProvider : [TerrainProvider](TerrainProvider.html) 

[widgets/Source/Viewer/Viewer.js 1250](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1250) 

 The terrain provider providing surface geometry for the globe.

#### [](#terrainShadows) terrainShadows : [ShadowMode](global.html#ShadowMode) 

[widgets/Source/Viewer/Viewer.js 1210](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1210) 

 Determines if the terrain casts or shadows from light sources.

#### [](#timeline) readonly timeline : [Timeline](Timeline.html) 

[widgets/Source/Viewer/Viewer.js 1100](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1100) 

 Gets the Timeline widget.

#### [](#trackedEntity) trackedEntity : [Entity](Entity.html)|undefined 

[widgets/Source/Viewer/Viewer.js 1442](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1442) 

 Gets or sets the Entity instance currently being tracked by the camera.

#### [](#trackedEntityChanged) readonly trackedEntityChanged : [Event](Event.html) 

[widgets/Source/Viewer/Viewer.js 1498](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1498) 

 Gets the event that is raised when the tracked entity changes.

#### [](#useBrowserRecommendedResolution) useBrowserRecommendedResolution : boolean 

[widgets/Source/Viewer/Viewer.js 1409](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1409) 

 Boolean flag indicating if the browser's recommended resolution is used. If true, the browser's device pixel ratio is ignored and 1.0 is used instead, effectively rendering based on CSS pixels instead of device pixels. This can improve performance on less powerful devices that have high pixel density. When false, rendering will be in device pixels. [Viewer#resolutionScale](Viewer.html#resolutionScale) will still take effect whether this flag is true or false.

Default Value: `true` 

#### [](#useDefaultRenderLoop) useDefaultRenderLoop : boolean 

[widgets/Source/Viewer/Viewer.js 1367](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1367) 

 Gets or sets whether or not this widget should control the render loop. If true the widget will use requestAnimationFrame to perform rendering and resizing of the widget, as well as drive the simulation clock. If set to false, you must manually call the`resize`, `render` methods as part of a custom render loop. If an error occurs during rendering, [Scene](Scene.html)'s`renderError` event will be raised and this property will be set to false. It must be set back to true to continue rendering after the error.

#### [](#vrButton) readonly vrButton : [VRButton](VRButton.html) 

[widgets/Source/Viewer/Viewer.js 1124](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1124) 

 Gets the VRButton.

### Methods

#### [](#destroy) destroy() 

[widgets/Source/Viewer/Viewer.js 1679](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1679) 

 Destroys the widget. Should be called if permanently removing the widget from layout.

#### [](#extend) extend(mixin, options) 

[widgets/Source/Viewer/Viewer.js 1531](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1531) 

 Extends the base viewer functionality with the provided mixin. A mixin may add additional properties, functions, or other behavior to the provided viewer instance.

| Name    | Type                                           | Description                                                     |
| ------- | ---------------------------------------------- | --------------------------------------------------------------- |
| mixin   | [Viewer.ViewerMixin](Viewer.html#.ViewerMixin) | The Viewer mixin to add to this instance.                       |
| options | object                                         | optional The options object to be passed to the mixin function. |

##### See:

* [viewerDragDropMixin](global.html#viewerDragDropMixin)

#### [](#flyTo) flyTo(target, options) → Promise.<boolean> 

[widgets/Source/Viewer/Viewer.js 2024](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L2024) 

 Flies the camera to the provided entity, entities, or data source. If the data source is still in the process of loading or the visualization is otherwise still loading, this method waits for the data to be ready before performing the flight.

The offset is heading/pitch/range in the local east-north-up reference frame centered at the center of the bounding sphere. The heading and the pitch angles are defined in the local east-north-up reference frame. The heading is the angle from y axis and increasing towards the x axis. Pitch is the rotation from the xy-plane. Positive pitch angles are above the plane. Negative pitch angles are below the plane. The range is the distance from the center. If the range is zero, a range will be computed such that the whole bounding sphere is visible.

In 2D, there must be a top down view. The camera will be placed above the target looking down. The height above the target will be the range. The heading will be determined from the offset. If the heading cannot be determined from the offset, the heading will be north.

| Name    | Type                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Description                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| target  | [Entity](Entity.html)\|Array.<[Entity](Entity.html)\>|[EntityCollection](EntityCollection.html)|[DataSource](DataSource.html)|[ImageryLayer](ImageryLayer.html)|[Cesium3DTileset](Cesium3DTileset.html)|[TimeDynamicPointCloud](TimeDynamicPointCloud.html)|Promise.<([Entity](Entity.html)|Array.<[Entity](Entity.html)\>|[EntityCollection](EntityCollection.html)|[DataSource](DataSource.html)|[ImageryLayer](ImageryLayer.html)|[Cesium3DTileset](Cesium3DTileset.html)|[TimeDynamicPointCloud](TimeDynamicPointCloud.html)|[VoxelPrimitive](VoxelPrimitive.html))> | The entity, array of entities, entity collection, data source, Cesium3DTileset, point cloud, or imagery layer to view. You can also pass a promise that resolves to one of the previously mentioned types.                                                                                                                                                                             |
| options | object                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | optional Object with the following properties: Name Type Default Description duration number 3.0 optional The duration of the flight in seconds. maximumHeight number optional The maximum height at the peak of the flight. offset [HeadingPitchRange](HeadingPitchRange.html) optional The offset from the target in the local east-north-up reference frame centered at the target. |

##### Returns:

 A Promise that resolves to true if the flight was successful or false if the target is not currently visualized in the scene or the flight was cancelled. //TODO: Cleanup entity mentions

#### [](#forceResize) forceResize() 

[widgets/Source/Viewer/Viewer.js 1655](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1655) 

 This forces the widget to re-think its layout, including widget sizes and credit placement.

#### [](#isDestroyed) isDestroyed() → boolean 

[widgets/Source/Viewer/Viewer.js 1671](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1671) 

##### Returns:

 true if the object has been destroyed, false otherwise.

#### [](#render) render() 

[widgets/Source/Viewer/Viewer.js 1664](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1664) 

 Renders the scene. This function is called automatically unless `useDefaultRenderLoop` is set to false;

#### [](#resize) resize() 

[widgets/Source/Viewer/Viewer.js 1546](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1546) 

 Resizes the widget to match the container size. This function is called automatically as needed unless`useDefaultRenderLoop` is set to false.

#### [](#zoomTo) zoomTo(target, offset) → Promise.<boolean> 

[widgets/Source/Viewer/Viewer.js 1998](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L1998) 

 Asynchronously sets the camera to view the provided entity, entities, or data source. If the data source is still in the process of loading or the visualization is otherwise still loading, this method waits for the data to be ready before performing the zoom.

The offset is heading/pitch/range in the local east-north-up reference frame centered at the center of the bounding sphere. The heading and the pitch angles are defined in the local east-north-up reference frame. The heading is the angle from y axis and increasing towards the x axis. Pitch is the rotation from the xy-plane. Positive pitch angles are above the plane. Negative pitch angles are below the plane. The range is the distance from the center. If the range is zero, a range will be computed such that the whole bounding sphere is visible.

In 2D, there must be a top down view. The camera will be placed above the target looking down. The height above the target will be the range. The heading will be determined from the offset. If the heading cannot be determined from the offset, the heading will be north.

| Name   | Type                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Description                                                                                                                                                                                                |
| ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| target | [Entity](Entity.html)\|Array.<[Entity](Entity.html)\>|[EntityCollection](EntityCollection.html)|[DataSource](DataSource.html)|[ImageryLayer](ImageryLayer.html)|[Cesium3DTileset](Cesium3DTileset.html)|[TimeDynamicPointCloud](TimeDynamicPointCloud.html)|Promise.<([Entity](Entity.html)|Array.<[Entity](Entity.html)\>|[EntityCollection](EntityCollection.html)|[DataSource](DataSource.html)|[ImageryLayer](ImageryLayer.html)|[Cesium3DTileset](Cesium3DTileset.html)|[TimeDynamicPointCloud](TimeDynamicPointCloud.html)|[VoxelPrimitive](VoxelPrimitive.html))> | The entity, array of entities, entity collection, data source, Cesium3DTileset, point cloud, or imagery layer to view. You can also pass a promise that resolves to one of the previously mentioned types. |
| offset | [HeadingPitchRange](HeadingPitchRange.html)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | optional The offset from the center of the entity in the local east-north-up reference frame.                                                                                                              |

##### Returns:

 A Promise that resolves to true if the zoom was successful or false if the target is not currently visualized in the scene or the zoom was cancelled.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.Viewer.ConstructorOptions

[widgets/Source/Viewer/Viewer.js 275](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L275) 

 Initialization options for the Viewer constructor

##### Properties:

| Name                                   | Type                                                                                                                   | Attributes | Default                                     | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| -------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- | ---------- | ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| animation                              | boolean                                                                                                                | <optional> | true                                        | If set to false, the Animation widget will not be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| baseLayerPicker                        | boolean                                                                                                                | <optional> | true                                        | If set to false, the BaseLayerPicker widget will not be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| fullscreenButton                       | boolean                                                                                                                | <optional> | true                                        | If set to false, the FullscreenButton widget will not be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| vrButton                               | boolean                                                                                                                | <optional> | false                                       | If set to true, the VRButton widget will be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| geocoder                               | boolean\|[IonGeocodeProviderType](global.html#IonGeocodeProviderType)|Array.<[GeocoderService](GeocoderService.html)\> | <optional> | IonGeocodeProviderType.DEFAULT              | The geocoding service or services to use when searching with the Geocoder widget. If set to false, the Geocoder widget will not be created.                                                                                                                                                                                                                                                                                                                                                                                                |
| homeButton                             | boolean                                                                                                                | <optional> | true                                        | If set to false, the HomeButton widget will not be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| infoBox                                | boolean                                                                                                                | <optional> | true                                        | If set to false, the InfoBox widget will not be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| sceneModePicker                        | boolean                                                                                                                | <optional> | true                                        | If set to false, the SceneModePicker widget will not be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| selectionIndicator                     | boolean                                                                                                                | <optional> | true                                        | If set to false, the SelectionIndicator widget will not be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| timeline                               | boolean                                                                                                                | <optional> | true                                        | If set to false, the Timeline widget will not be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| navigationHelpButton                   | boolean                                                                                                                | <optional> | true                                        | If set to false, the navigation help button will not be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| navigationInstructionsInitiallyVisible | boolean                                                                                                                | <optional> | true                                        | True if the navigation instructions should initially be visible, or false if the should not be shown until the user explicitly clicks the button.                                                                                                                                                                                                                                                                                                                                                                                          |
| scene3DOnly                            | boolean                                                                                                                | <optional> | false                                       | When true, each geometry instance will only be rendered in 3D to save GPU memory.                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| shouldAnimate                          | boolean                                                                                                                | <optional> | false                                       | true if the clock should attempt to advance simulation time by default, false otherwise. This option takes precedence over setting [Viewer#clockViewModel](Viewer.html#clockViewModel).                                                                                                                                                                                                                                                                                                                                                    |
| clockViewModel                         | [ClockViewModel](ClockViewModel.html)                                                                                  | <optional> | new ClockViewModel(clock)                   | The clock view model to use to control current time.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| selectedImageryProviderViewModel       | [ProviderViewModel](ProviderViewModel.html)                                                                            | <optional> |                                             | The view model for the current base imagery layer, if not supplied the first available base layer is used. This value is only valid if \`baseLayerPicker\` is set to true.                                                                                                                                                                                                                                                                                                                                                                 |
| imageryProviderViewModels              | Array.<[ProviderViewModel](ProviderViewModel.html)\>                                                                   | <optional> | createDefaultImageryProviderViewModels()    | The array of ProviderViewModels to be selectable from the BaseLayerPicker. This value is only valid if \`baseLayerPicker\` is set to true.                                                                                                                                                                                                                                                                                                                                                                                                 |
| selectedTerrainProviderViewModel       | [ProviderViewModel](ProviderViewModel.html)                                                                            | <optional> |                                             | The view model for the current base terrain layer, if not supplied the first available base layer is used. This value is only valid if \`baseLayerPicker\` is set to true.                                                                                                                                                                                                                                                                                                                                                                 |
| terrainProviderViewModels              | Array.<[ProviderViewModel](ProviderViewModel.html)\>                                                                   | <optional> | createDefaultTerrainProviderViewModels()    | The array of ProviderViewModels to be selectable from the BaseLayerPicker. This value is only valid if \`baseLayerPicker\` is set to true.                                                                                                                                                                                                                                                                                                                                                                                                 |
| baseLayer                              | [ImageryLayer](ImageryLayer.html)\|false                                                                               | <optional> | ImageryLayer.fromWorldImagery()             | The bottommost imagery layer applied to the globe. If set to false, no imagery provider will be added. This value is only valid if \`baseLayerPicker\` is set to false. Cannot be used when \`globe\` is set to false.                                                                                                                                                                                                                                                                                                                     |
| ellipsoid                              | [Ellipsoid](Ellipsoid.html)                                                                                            | <optional> | Ellipsoid.default                           | The default ellipsoid.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| terrainProvider                        | [TerrainProvider](TerrainProvider.html)                                                                                | <optional> | new EllipsoidTerrainProvider()              | The terrain provider to use                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| terrain                                | [Terrain](Terrain.html)                                                                                                | <optional> |                                             | A terrain object which handles asynchronous terrain provider. Can only specify if options.terrainProvider is undefined.                                                                                                                                                                                                                                                                                                                                                                                                                    |
| skyBox                                 | [SkyBox](SkyBox.html)\|false                                                                                           | <optional> |                                             | The skybox used to render the stars. When undefined and the WGS84 ellipsoid used, the default stars are used. If set to false, no skyBox, Sun, or Moon will be added.                                                                                                                                                                                                                                                                                                                                                                      |
| skyAtmosphere                          | [SkyAtmosphere](SkyAtmosphere.html)\|false                                                                             | <optional> |                                             | Blue sky, and the glow around the Earth's limb. Enabled when the WGS84 ellipsoid used. Set to false to turn it off.                                                                                                                                                                                                                                                                                                                                                                                                                        |
| fullscreenElement                      | Element\|string                                                                                                        | <optional> | document.body                               | The element or id to be placed into fullscreen mode when the full screen button is pressed.                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| useDefaultRenderLoop                   | boolean                                                                                                                | <optional> | true                                        | True if this widget should control the render loop, false otherwise.                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| targetFrameRate                        | number                                                                                                                 | <optional> |                                             | The target frame rate when using the default render loop.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| showRenderLoopErrors                   | boolean                                                                                                                | <optional> | true                                        | If true, this widget will automatically display an HTML panel to the user containing the error, if a render loop error occurs.                                                                                                                                                                                                                                                                                                                                                                                                             |
| useBrowserRecommendedResolution        | boolean                                                                                                                | <optional> | true                                        | If true, render at the browser's recommended resolution and ignore window.devicePixelRatio.                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| automaticallyTrackDataSourceClocks     | boolean                                                                                                                | <optional> | true                                        | If true, this widget will automatically track the clock settings of newly added DataSources, updating if the DataSource's clock changes. Set this to false if you want to configure the clock independently.                                                                                                                                                                                                                                                                                                                               |
| contextOptions                         | [ContextOptions](global.html#ContextOptions)                                                                           | <optional> |                                             | Context and WebGL creation properties passed to [Scene](Scene.html).                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| sceneMode                              | [SceneMode](global.html#SceneMode)                                                                                     | <optional> | SceneMode.SCENE3D                           | The initial scene mode.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| mapProjection                          | [MapProjection](MapProjection.html)                                                                                    | <optional> | new GeographicProjection(options.ellipsoid) | The map projection to use in 2D and Columbus View modes.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| globe                                  | [Globe](Globe.html)\|false                                                                                             | <optional> | new Globe(options.ellipsoid)                | The globe to use in the scene. If set to false, no globe will be added and the sky atmosphere will be hidden by default.                                                                                                                                                                                                                                                                                                                                                                                                                   |
| orderIndependentTranslucency           | boolean                                                                                                                | <optional> | true                                        | If true and the configuration supports it, use order independent translucency.                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| creditContainer                        | Element\|string                                                                                                        | <optional> |                                             | The DOM element or ID that will contain the [CreditDisplay](CreditDisplay.html). If not specified, the credits are added to the bottom of the widget itself.                                                                                                                                                                                                                                                                                                                                                                               |
| creditViewport                         | Element\|string                                                                                                        | <optional> |                                             | The DOM element or ID that will contain the credit pop up created by the [CreditDisplay](CreditDisplay.html). If not specified, it will appear over the widget itself.                                                                                                                                                                                                                                                                                                                                                                     |
| dataSources                            | [DataSourceCollection](DataSourceCollection.html)                                                                      | <optional> | new DataSourceCollection()                  | The collection of data sources visualized by the widget. If this parameter is provided, the instance is assumed to be owned by the caller and will not be destroyed when the viewer is destroyed.                                                                                                                                                                                                                                                                                                                                          |
| shadows                                | boolean                                                                                                                | <optional> | false                                       | Determines if shadows are cast by light sources.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| terrainShadows                         | [ShadowMode](global.html#ShadowMode)                                                                                   | <optional> | ShadowMode.RECEIVE\_ONLY                    | Determines if the terrain casts or receives shadows from light sources.                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| mapMode2D                              | [MapMode2D](global.html#MapMode2D)                                                                                     | <optional> | MapMode2D.INFINITE\_SCROLL                  | Determines if the 2D map is rotatable or can be scrolled infinitely in the horizontal direction.                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| projectionPicker                       | boolean                                                                                                                | <optional> | false                                       | If set to true, the ProjectionPicker widget will be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| blurActiveElementOnCanvasFocus         | boolean                                                                                                                | <optional> | true                                        | If true, the active element will blur when the viewer's canvas is clicked. Setting this to false is useful for cases when the canvas is clicked only for retrieving position or an entity data without actually meaning to set the canvas to be the active element.                                                                                                                                                                                                                                                                        |
| requestRenderMode                      | boolean                                                                                                                | <optional> | false                                       | If true, rendering a frame will only occur when needed as determined by changes within the scene. Enabling reduces the CPU/GPU usage of your application and uses less battery on mobile, but requires using [Scene#requestRender](Scene.html#requestRender) to render a new frame explicitly in this mode. This will be necessary in many cases after making changes to the scene in other parts of the API. See [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/). |
| maximumRenderTimeChange                | number                                                                                                                 | <optional> | 0.0                                         | If requestRenderMode is true, this value defines the maximum change in simulation time allowed before a render is requested. See [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/).                                                                                                                                                                                                                                                                                  |
| depthPlaneEllipsoidOffset              | number                                                                                                                 | <optional> | 0.0                                         | Adjust the DepthPlane to address rendering artefacts below ellipsoid zero elevation.                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| msaaSamples                            | number                                                                                                                 | <optional> | 4                                           | If provided, this value controls the rate of multisample antialiasing. Typical multisampling rates are 2, 4, and sometimes 8 samples per pixel. Higher sampling rates of MSAA may impact performance in exchange for improved visual quality. This value only applies to WebGL2 contexts that support multisample render targets. Set to 1 to disable MSAA.                                                                                                                                                                                |

#### [](#.ViewerMixin) Cesium.Viewer.ViewerMixin(viewer, options) 

[widgets/Source/Viewer/Viewer.js 2028](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/Viewer.js#L2028) 

 A function that augments a Viewer instance with additional functionality.

| Name    | Type                  | Description                                        |
| ------- | --------------------- | -------------------------------------------------- |
| viewer  | [Viewer](Viewer.html) | The viewer instance.                               |
| options | object                | Options object to be passed to the mixin function. |

##### See:

* [Viewer#extend](Viewer.html#extend)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

