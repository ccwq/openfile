# [![](Images/CesiumLogo.png)](index.html) EllipsoidSurfaceAppearance 

#### [](#EllipsoidSurfaceAppearance) new Cesium.EllipsoidSurfaceAppearance(options) 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 44](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L44) 

 An appearance for geometry on the surface of the ellipsoid like [PolygonGeometry](PolygonGeometry.html)and [RectangleGeometry](RectangleGeometry.html), which supports all materials like [MaterialAppearance](MaterialAppearance.html)with [MaterialAppearance.MaterialSupport.ALL](MaterialAppearance.MaterialSupport.html#.ALL). However, this appearance requires fewer vertex attributes since the fragment shader can procedurally compute `normal`,`tangent`, and `bitangent`.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | optional Object with the following properties: Name Type Default Description flat boolean false optional When true, flat shading is used in the fragment shader, which means lighting is not taking into account. faceForward boolean options.aboveGround optional When true, the fragment shader flips the surface normal as needed to ensure that the normal faces the viewer to avoid dark spots. This is useful when both sides of a geometry should be shaded like [WallGeometry](WallGeometry.html). translucent boolean true optional When true, the geometry is expected to appear translucent so [EllipsoidSurfaceAppearance#renderState](EllipsoidSurfaceAppearance.html#renderState) has alpha blending enabled. aboveGround boolean false optional When true, the geometry is expected to be on the ellipsoid's surface - not at a constant height above it - so [EllipsoidSurfaceAppearance#renderState](EllipsoidSurfaceAppearance.html#renderState) has backface culling enabled. material [Material](Material.html) Material.ColorType optional The material used to determine the fragment color. vertexShaderSource string optional Optional GLSL vertex shader source to override the default vertex shader. fragmentShaderSource string optional Optional GLSL fragment shader source to override the default fragment shader. renderState object optional Optional render state to override the default render state. |

##### Example:

```javascript
const primitive = new Cesium.Primitive({
  geometryInstances : new Cesium.GeometryInstance({
    geometry : new Cesium.PolygonGeometry({
      vertexFormat : Cesium.EllipsoidSurfaceAppearance.VERTEX_FORMAT,
      // ...
    })
  }),
  appearance : new Cesium.EllipsoidSurfaceAppearance({
    material : Cesium.Material.fromType('Stripe')
  })
});
```

##### See:

* [Fabric](https://github.com/CesiumGS/cesium/wiki/Fabric)

### Members

#### [](#.VERTEX%5FFORMAT) static constant Cesium.EllipsoidSurfaceAppearance.VERTEX\_FORMAT : [VertexFormat](VertexFormat.html) 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 247](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L247) 

 The [VertexFormat](VertexFormat.html) that all [EllipsoidSurfaceAppearance](EllipsoidSurfaceAppearance.html) instances are compatible with, which requires only `position` and `st`attributes. Other attributes are procedurally computed in the fragment shader.

#### [](#aboveGround) readonly aboveGround : boolean 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 231](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L231) 

 When `true`, the geometry is expected to be on the ellipsoid's surface - not at a constant height above it - so [EllipsoidSurfaceAppearance#renderState](EllipsoidSurfaceAppearance.html#renderState)has backface culling enabled.

Default Value: `false` 

#### [](#closed) readonly closed : boolean 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 158](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L158) 

 When `true`, the geometry is expected to be closed so[EllipsoidSurfaceAppearance#renderState](EllipsoidSurfaceAppearance.html#renderState) has backface culling enabled. If the viewer enters the geometry, it will not be visible.

Default Value: `false` 

#### [](#faceForward) readonly faceForward : boolean 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 212](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L212) 

 When `true`, the fragment shader flips the surface normal as needed to ensure that the normal faces the viewer to avoid dark spots. This is useful when both sides of a geometry should be shaded like [WallGeometry](WallGeometry.html).

Default Value: `true` 

#### [](#flat) readonly flat : boolean 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 193](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L193) 

 When `true`, flat shading is used in the fragment shader, which means lighting is not taking into account.

Default Value: `false` 

#### [](#fragmentShaderSource) readonly fragmentShaderSource : string 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L121) 

 The GLSL source code for the fragment shader. The full fragment shader source is built procedurally taking into account [EllipsoidSurfaceAppearance#material](EllipsoidSurfaceAppearance.html#material),[EllipsoidSurfaceAppearance#flat](EllipsoidSurfaceAppearance.html#flat), and [EllipsoidSurfaceAppearance#faceForward](EllipsoidSurfaceAppearance.html#faceForward). Use [EllipsoidSurfaceAppearance#getFragmentShaderSource](EllipsoidSurfaceAppearance.html#getFragmentShaderSource) to get the full source.

#### [](#material) material : [Material](Material.html) 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L60) 

 The material used to determine the fragment color. Unlike other [EllipsoidSurfaceAppearance](EllipsoidSurfaceAppearance.html)properties, this is not read-only, so an appearance's material can change on the fly.

Default Value: `[Material.ColorType](Material.html#.ColorType)` 

##### See:

* [Fabric](https://github.com/CesiumGS/cesium/wiki/Fabric)

#### [](#renderState) readonly renderState : object 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 140](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L140) 

 The WebGL fixed-function state to use when rendering the geometry.

The render state can be explicitly defined when constructing a [EllipsoidSurfaceAppearance](EllipsoidSurfaceAppearance.html)instance, or it is set implicitly via [EllipsoidSurfaceAppearance#translucent](EllipsoidSurfaceAppearance.html#translucent)and [EllipsoidSurfaceAppearance#aboveGround](EllipsoidSurfaceAppearance.html#aboveGround).

#### [](#translucent) translucent : boolean 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 71](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L71) 

 When `true`, the geometry is expected to appear translucent.

Default Value: `true` 

#### [](#vertexFormat) readonly vertexFormat : [VertexFormat](VertexFormat.html) 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L176) 

 The [VertexFormat](VertexFormat.html) that this appearance instance is compatible with. A geometry can have more vertex attributes and still be compatible - at a potential performance cost - but it can't have less.

Default Value: `[EllipsoidSurfaceAppearance.VERTEX_FORMAT](EllipsoidSurfaceAppearance.html#.VERTEX%5FFORMAT)` 

#### [](#vertexShaderSource) readonly vertexShaderSource : string 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 104](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L104) 

 The GLSL source code for the vertex shader.

### Methods

#### [](#getFragmentShaderSource) getFragmentShaderSource() → string 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 258](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L258) 

 Procedurally creates the full GLSL fragment shader source. For [EllipsoidSurfaceAppearance](EllipsoidSurfaceAppearance.html), this is derived from [EllipsoidSurfaceAppearance#fragmentShaderSource](EllipsoidSurfaceAppearance.html#fragmentShaderSource), [EllipsoidSurfaceAppearance#flat](EllipsoidSurfaceAppearance.html#flat), and [EllipsoidSurfaceAppearance#faceForward](EllipsoidSurfaceAppearance.html#faceForward).

##### Returns:

 The full GLSL fragment shader source.

#### [](#getRenderState) getRenderState() → object 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 280](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L280) 

 Creates a render state. This is not the final render state instance; instead, it can contain a subset of render state properties identical to the render state created in the context.

##### Returns:

 The render state.

#### [](#isTranslucent) isTranslucent() → boolean 

[engine/Source/Scene/EllipsoidSurfaceAppearance.js 268](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/EllipsoidSurfaceAppearance.js#L268) 

 Determines if the geometry is translucent based on [EllipsoidSurfaceAppearance#translucent](EllipsoidSurfaceAppearance.html#translucent) and [Material#isTranslucent](Material.html#isTranslucent).

##### Returns:

`true` if the appearance is translucent.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

