# [![](Images/CesiumLogo.png)](index.html) IonImageryProvider 

#### [](#IonImageryProvider) new Cesium.IonImageryProvider(options) 

[engine/Source/Scene/IonImageryProvider.js 84](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L84) 

To construct a IonImageryProvider, call [IonImageryProvider.fromAssetId](IonImageryProvider.html#.fromAssetId). Do not call the constructor directly.

Provides tiled imagery using the Cesium ion REST API.

| Name    | Type                                                                                 | Description                                       |
| ------- | ------------------------------------------------------------------------------------ | ------------------------------------------------- |
| options | [IonImageryProvider.ConstructorOptions](IonImageryProvider.html#.ConstructorOptions) | optional Object describing initialization options |

##### Example:

```javascript
const imageryLayer = Cesium.ImageryLayer.fromProviderAsync(Cesium.IonImageryProvider.fromAssetId(3812));
viewer.imageryLayers.add(imageryLayer);
```

##### See:

* [IonImageryProvider.fromAssetId](IonImageryProvider.html#.fromAssetId)

### Members

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/IonImageryProvider.js 214](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L214) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/IonImageryProvider.js 201](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L201) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/IonImageryProvider.js 230](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L230) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. When this property is false, memory usage and texture upload time are reduced.

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/IonImageryProvider.js 145](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L145) 

 Gets the maximum level-of-detail that can be requested.

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/IonImageryProvider.js 161](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L161) 

 Gets the minimum level-of-detail that can be requested. Generally, a minimum level should only be used when the rectangle of the imagery is small enough that the number of tiles at the minimum level is small. An imagery provider with more than a few tiles at the minimum level will lead to rendering problems.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/IonImageryProvider.js 243](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L243) 

 Gets the proxy used by this provider.

Default Value: `undefined` 

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/IonImageryProvider.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L109) 

 Gets the rectangle, in radians, of the imagery provided by the instance.

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/IonImageryProvider.js 187](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L187) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/IonImageryProvider.js 133](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L133) 

 Gets the height of each tile, in pixels.

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/IonImageryProvider.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L121) 

 Gets the width of each tile, in pixels.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/IonImageryProvider.js 173](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L173) 

 Gets the tiling scheme used by the provider.

### Methods

#### [](#.fromAssetId) static Cesium.IonImageryProvider.fromAssetId(assetId, options) → Promise.<[IonImageryProvider](IonImageryProvider.html)\> 

[engine/Source/Scene/IonImageryProvider.js 264](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L264) 

 Creates a provider for tiled imagery using the Cesium ion REST API.

| Name    | Type                                                                                 | Description                                        |
| ------- | ------------------------------------------------------------------------------------ | -------------------------------------------------- |
| assetId | Number                                                                               | An ion imagery asset ID.                           |
| options | [IonImageryProvider.ConstructorOptions](IonImageryProvider.html#.ConstructorOptions) | optional Object describing initialization options. |

##### Returns:

 A promise which resolves to the created IonImageryProvider.

##### Throws:

* [RuntimeError](RuntimeError.html): Cesium ion assetId is not an imagery asset
* [RuntimeError](RuntimeError.html): Unrecognized Cesium ion imagery type

##### Example:

```javascript
const imageryLayer = Cesium.ImageryLayer.fromProviderAsync(Cesium.IonImageryProvider.fromAssetId(3812));
viewer.imageryLayers.add(imageryLayer);
```

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/IonImageryProvider.js 342](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L342) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → Promise.<Array.<[ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html)\>>|undefined 

[engine/Source/Scene/IonImageryProvider.js 382](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L382) 

 Asynchronously determines what features, if any, are located at a given longitude and latitude within a tile. This function is optional, so it may not exist on all ImageryProviders.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 A promise for the picked features that will resolve when the asynchronous picking completes. The resolved value is an array of [ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html) instances. The array may be empty if no features are found at the given location. It may also be undefined if picking is not supported.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<[ImageryTypes](global.html#ImageryTypes)\>|undefined 

[engine/Source/Scene/IonImageryProvider.js 362](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L362) 

 Requests the image for a given tile.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the image that will resolve when the image is available, or undefined if there are too many active requests to the server, and the request should be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.IonImageryProvider.ConstructorOptions

[engine/Source/Scene/IonImageryProvider.js 57](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonImageryProvider.js#L57) 

 Initialization options for the TileMapServiceImageryProvider constructor

##### Properties:

| Name        | Type                              | Attributes | Default                | Description                                |
| ----------- | --------------------------------- | ---------- | ---------------------- | ------------------------------------------ |
| accessToken | string                            | <optional> | Ion.defaultAccessToken | The access token to use.                   |
| server      | string\|[Resource](Resource.html) | <optional> | Ion.defaultServer      | The resource to the Cesium ion API server. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

