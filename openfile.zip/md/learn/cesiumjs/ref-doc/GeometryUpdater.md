# [![](Images/CesiumLogo.png)](index.html) GeometryUpdater 

#### [](#GeometryUpdater) new Cesium.GeometryUpdater(options) 

[engine/Source/DataSources/GeometryUpdater.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L41) 

 An abstract class for updating geometry entities.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | An object with the following properties: Name Type Description entity [Entity](Entity.html)  The entity containing the geometry to be visualized. scene [Scene](Scene.html)  The scene where visualization is taking place. geometryOptions object  Options for the geometry geometryPropertyName string  The geometry property name observedPropertyNames Array.<string>  The entity properties this geometry cares about |

### Members

#### [](#classificationTypeProperty) readonly classificationTypeProperty : [Property](Property.html) 

[engine/Source/DataSources/GeometryUpdater.js 228](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L228) 

 Gets or sets the [ClassificationType](global.html#ClassificationType) Property specifying if this geometry will classify terrain, 3D Tiles, or both when on the ground.

#### [](#distanceDisplayConditionProperty) readonly distanceDisplayConditionProperty : [Property](Property.html) 

[engine/Source/DataSources/GeometryUpdater.js 216](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L216) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this geometry will be displayed.

#### [](#entity) readonly entity : [Entity](Entity.html) 

[engine/Source/DataSources/GeometryUpdater.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L96) 

 Gets the entity associated with this geometry.

#### [](#fillEnabled) readonly fillEnabled : boolean 

[engine/Source/DataSources/GeometryUpdater.js 108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L108) 

 Gets a value indicating if the geometry has a fill component.

#### [](#fillMaterialProperty) readonly fillMaterialProperty : [MaterialProperty](MaterialProperty.html) 

[engine/Source/DataSources/GeometryUpdater.js 137](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L137) 

 Gets the material property used to fill the geometry.

#### [](#geometryChanged) readonly geometryChanged : boolean 

[engine/Source/DataSources/GeometryUpdater.js 279](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L279) 

 Gets an event that is raised whenever the public properties of this updater change.

#### [](#hasConstantFill) readonly hasConstantFill : boolean 

[engine/Source/DataSources/GeometryUpdater.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L120) 

 Gets a value indicating if fill visibility varies with simulation time.

#### [](#hasConstantOutline) readonly hasConstantOutline : boolean 

[engine/Source/DataSources/GeometryUpdater.js 161](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L161) 

 Gets a value indicating if the geometry has an outline component.

#### [](#id) readonly id : string 

[engine/Source/DataSources/GeometryUpdater.js 84](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L84) 

 Gets the unique ID associated with this updater

#### [](#isClosed) readonly isClosed : boolean 

[engine/Source/DataSources/GeometryUpdater.js 254](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L254) 

 Gets a value indicating if the geometry is closed. This property is only valid for static geometry.

#### [](#isDynamic) readonly isDynamic : boolean 

[engine/Source/DataSources/GeometryUpdater.js 241](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L241) 

 Gets a value indicating if the geometry is time-varying.

#### [](#outlineColorProperty) readonly outlineColorProperty : [Property](Property.html) 

[engine/Source/DataSources/GeometryUpdater.js 178](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L178) 

 Gets the [Color](Color.html) property for the geometry outline.

#### [](#outlineEnabled) readonly outlineEnabled : boolean 

[engine/Source/DataSources/GeometryUpdater.js 149](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L149) 

 Gets a value indicating if the geometry has an outline component.

#### [](#outlineWidth) readonly outlineWidth : number 

[engine/Source/DataSources/GeometryUpdater.js 191](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L191) 

 Gets the constant with of the geometry outline, in pixels. This value is only valid if isDynamic is false.

#### [](#shadowsProperty) readonly shadowsProperty : [Property](Property.html) 

[engine/Source/DataSources/GeometryUpdater.js 204](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L204) 

 Gets the property specifying whether the geometry casts or receives shadows from light sources.

### Methods

#### [](#createFillGeometryInstance) createFillGeometryInstance(time) → [GeometryInstance](GeometryInstance.html) 

[engine/Source/DataSources/GeometryUpdater.js 327](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L327) 

 Creates the geometry instance which represents the fill of the geometry.

| Name | Type                          | Description                                               |
| ---- | ----------------------------- | --------------------------------------------------------- |
| time | [JulianDate](JulianDate.html) | The time to use when retrieving initial attribute values. |

##### Returns:

 The geometry instance representing the filled portion of the geometry.

##### Throws:

* [DeveloperError](DeveloperError.html): This instance does not represent a filled geometry.

#### [](#createOutlineGeometryInstance) createOutlineGeometryInstance(time) → [GeometryInstance](GeometryInstance.html) 

[engine/Source/DataSources/GeometryUpdater.js 339](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L339) 

 Creates the geometry instance which represents the outline of the geometry.

| Name | Type                          | Description                                               |
| ---- | ----------------------------- | --------------------------------------------------------- |
| time | [JulianDate](JulianDate.html) | The time to use when retrieving initial attribute values. |

##### Returns:

 The geometry instance representing the outline portion of the geometry.

##### Throws:

* [DeveloperError](DeveloperError.html): This instance does not represent an outlined geometry.

#### [](#destroy) destroy() 

[engine/Source/DataSources/GeometryUpdater.js 356](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L356) 

 Destroys and resources used by the object. Once an object is destroyed, it should not be used.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/DataSources/GeometryUpdater.js 347](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L347) 

 Returns true if this object was destroyed; otherwise, false.

##### Returns:

 True if this object was destroyed; otherwise, false.

#### [](#isFilled) isFilled(time) → boolean 

[engine/Source/DataSources/GeometryUpdater.js 308](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L308) 

 Checks if the geometry is filled at the provided time.

| Name | Type                          | Description                                |
| ---- | ----------------------------- | ------------------------------------------ |
| time | [JulianDate](JulianDate.html) | The time for which to retrieve visibility. |

##### Returns:

 true if geometry is filled at the provided time, false otherwise.

#### [](#isOutlineVisible) isOutlineVisible(time) → boolean 

[engine/Source/DataSources/GeometryUpdater.js 292](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdater.js#L292) 

 Checks if the geometry is outlined at the provided time.

| Name | Type                          | Description                                |
| ---- | ----------------------------- | ------------------------------------------ |
| time | [JulianDate](JulianDate.html) | The time for which to retrieve visibility. |

##### Returns:

 true if geometry is outlined at the provided time, false otherwise.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

