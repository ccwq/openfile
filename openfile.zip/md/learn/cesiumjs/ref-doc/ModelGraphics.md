# [![](Images/CesiumLogo.png)](index.html) ModelGraphics 

#### [](#ModelGraphics) new Cesium.ModelGraphics(options) 

[engine/Source/DataSources/ModelGraphics.js 71](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L71) 

 A 3D model based on [glTF](https://github.com/KhronosGroup/glTF), the runtime asset format for WebGL, OpenGL ES, and OpenGL. The position and orientation of the model is determined by the containing [Entity](Entity.html).

Cesium includes support for glTF geometry, materials, animations, and skinning. Cameras and lights are not currently supported.

| Name    | Type                                                                       | Description                                       |
| ------- | -------------------------------------------------------------------------- | ------------------------------------------------- |
| options | [ModelGraphics.ConstructorOptions](ModelGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle 3D Models Demo](https://sandcastle.cesium.com/index.html?src=3D%2520Models.html)

### Members

#### [](#articulations) articulations : [PropertyBag](PropertyBag.html) 

[engine/Source/DataSources/ModelGraphics.js 335](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L335) 

 Gets or sets the set of articulation values to apply to this model. This is represented as an [PropertyBag](PropertyBag.html), where keys are composed as the name of the articulation, a single space, and the name of the stage.

#### [](#clampAnimations) clampAnimations : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 219](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L219) 

 Gets or sets the boolean Property specifying if glTF animations should hold the last pose for time durations with no keyframes.

Default Value: `true` 

#### [](#clippingPlanes) clippingPlanes : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 346](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L346) 

 A property specifying the [ClippingPlaneCollection](ClippingPlaneCollection.html) used to selectively disable rendering the model.

#### [](#color) color : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 260](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L260) 

 Gets or sets the Property specifying the [Color](Color.html) that blends with the model's rendered color.

Default Value: `Color.WHITE` 

#### [](#colorBlendAmount) colorBlendAmount : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 278](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L278) 

 A numeric Property specifying the color strength when the `colorBlendMode` is MIX. A value of 0.0 results in the model's rendered color while a value of 1.0 results in a solid color, with any value in-between resulting in a mix of the two.

Default Value: `0.5` 

#### [](#colorBlendMode) colorBlendMode : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 268](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L268) 

 Gets or sets the enum Property specifying how the color blends with the model.

Default Value: `ColorBlendMode.HIGHLIGHT` 

#### [](#customShader) customShader : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 353](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L353) 

 Gets or sets the [CustomShader](CustomShader.html) to apply to this model. When `undefined`, no custom shader code is used.

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/ModelGraphics.js 134](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L134) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 312](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L312) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this model will be displayed.

#### [](#enableVerticalExaggeration) enableVerticalExaggeration : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 171](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L171) 

 Gets or sets the boolean Property specifying if the model is exaggerated along the ellipsoid normal when `Scene.verticalExaggeration` is set to a value other than `1.0`.

Default Value: `true` 

#### [](#environmentMapOptions) environmentMapOptions : [PropertyBag](PropertyBag.html) 

[engine/Source/DataSources/ModelGraphics.js 294](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L294) 

 Gets or sets the [DynamicEnvironmentMapManager.ConstructorOptions](DynamicEnvironmentMapManager.html#.ConstructorOptions) to apply to this model. This is represented as an [PropertyBag](PropertyBag.html).

#### [](#heightReference) heightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 236](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L236) 

 Gets or sets the Property specifying the [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#imageBasedLightingFactor) imageBasedLightingFactor : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 285](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L285) 

 A property specifying the [Cartesian2](Cartesian2.html) used to scale the diffuse and specular image-based lighting contribution to the final color.

#### [](#incrementallyLoadTextures) incrementallyLoadTextures : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 201](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L201) 

 Get or sets the boolean Property specifying whether textures may continue to stream in after the model is loaded.

#### [](#lightColor) lightColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 305](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L305) 

 A property specifying the [Cartesian3](Cartesian3.html) light color when shading the model. When `undefined` the scene's light color is used instead.

#### [](#maximumScale) maximumScale : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 193](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L193) 

 Gets or sets the numeric Property specifying the maximum scale size of a model. This property is used as an upper limit for[ModelGraphics#minimumPixelSize](ModelGraphics.html#minimumPixelSize).

#### [](#minimumPixelSize) minimumPixelSize : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 184](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L184) 

 Gets or sets the numeric Property specifying the approximate minimum pixel size of the model regardless of zoom. This can be used to ensure that a model is visible even when the viewer zooms out. When `0.0`, no minimum size is enforced.

Default Value: `0.0` 

#### [](#nodeTransformations) nodeTransformations : [PropertyBag](PropertyBag.html) 

[engine/Source/DataSources/ModelGraphics.js 323](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L323) 

 Gets or sets the set of node transformations to apply to this model. This is represented as an [PropertyBag](PropertyBag.html), where keys are names of nodes, and values are [TranslationRotationScale](TranslationRotationScale.html) Properties describing the transformation to apply to that node. The transformation is applied after the node's existing transformation as specified in the glTF, and does not replace the node's existing transformation.

#### [](#runAnimations) runAnimations : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 211](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L211) 

 Gets or sets the boolean Property specifying if glTF animations should be run.

Default Value: `true` 

#### [](#scale) scale : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 163](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L163) 

 Gets or sets the numeric Property specifying a uniform linear scale for this model. Values greater than 1.0 increase the size of the model while values less than 1.0 decrease it.

Default Value: `1.0` 

#### [](#shadows) shadows : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 228](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L228) 

 Get or sets the enum Property specifying whether the model casts or receives shadows from light sources.

Default Value: `ShadowMode.ENABLED` 

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 146](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L146) 

 Gets or sets the boolean Property specifying the visibility of the model.

Default Value: `true` 

#### [](#silhouetteColor) silhouetteColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 244](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L244) 

 Gets or sets the Property specifying the [Color](Color.html) of the silhouette.

Default Value: `Color.RED` 

#### [](#silhouetteSize) silhouetteSize : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 252](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L252) 

 Gets or sets the numeric Property specifying the size of the silhouette in pixels.

Default Value: `0.0` 

#### [](#uri) uri : [Property](Property.html)|undefined 

[engine/Source/DataSources/ModelGraphics.js 153](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L153) 

 Gets or sets the string Property specifying the URI of the glTF asset.

### Methods

#### [](#clone) clone(result) → [ModelGraphics](ModelGraphics.html) 

[engine/Source/DataSources/ModelGraphics.js 362](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L362) 

 Duplicates this instance.

| Name   | Type                                | Description                                         |
| ------ | ----------------------------------- | --------------------------------------------------- |
| result | [ModelGraphics](ModelGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/ModelGraphics.js 398](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L398) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                | Description                               |
| ------ | ----------------------------------- | ----------------------------------------- |
| source | [ModelGraphics](ModelGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.ModelGraphics.ConstructorOptions

[engine/Source/DataSources/ModelGraphics.js 25](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ModelGraphics.js#L25) 

 Initialization options for the ModelGraphics constructor

##### Properties:

| Name                       | Type                                                                                                         | Attributes | Default                  | Description                                                                                                                                                                                                                                                                                                                                  |
| -------------------------- | ------------------------------------------------------------------------------------------------------------ | ---------- | ------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| show                       | [Property](Property.html)\|boolean                                                                           | <optional> | true                     | A boolean Property specifying the visibility of the model.                                                                                                                                                                                                                                                                                   |
| uri                        | [Property](Property.html)\|string|[Resource](Resource.html)                                                  | <optional> |                          | A string or Resource Property specifying the URI of the glTF asset.                                                                                                                                                                                                                                                                          |
| scale                      | [Property](Property.html)\|number                                                                            | <optional> | 1.0                      | A numeric Property specifying a uniform linear scale.                                                                                                                                                                                                                                                                                        |
| enableVerticalExaggeration | [Property](Property.html)\|boolean                                                                           | <optional> | true                     | A boolean Property specifying if the model is exaggerated along the ellipsoid normal when Scene.verticalExaggeration is set to a value other than 1.0.                                                                                                                                                                                       |
| minimumPixelSize           | [Property](Property.html)\|number                                                                            | <optional> | 0.0                      | A numeric Property specifying the approximate minimum pixel size of the model regardless of zoom.                                                                                                                                                                                                                                            |
| maximumScale               | [Property](Property.html)\|number                                                                            | <optional> |                          | The maximum scale size of a model. An upper limit for minimumPixelSize.                                                                                                                                                                                                                                                                      |
| incrementallyLoadTextures  | [Property](Property.html)\|boolean                                                                           | <optional> | true                     | Determine if textures may continue to stream in after the model is loaded.                                                                                                                                                                                                                                                                   |
| runAnimations              | [Property](Property.html)\|boolean                                                                           | <optional> | true                     | A boolean Property specifying if glTF animations specified in the model should be started.                                                                                                                                                                                                                                                   |
| clampAnimations            | [Property](Property.html)\|boolean                                                                           | <optional> | true                     | A boolean Property specifying if glTF animations should hold the last pose for time durations with no keyframes.                                                                                                                                                                                                                             |
| shadows                    | [Property](Property.html)\|[ShadowMode](global.html#ShadowMode)                                              | <optional> | ShadowMode.ENABLED       | An enum Property specifying whether the model casts or receives shadows from light sources.                                                                                                                                                                                                                                                  |
| heightReference            | [Property](Property.html)\|[HeightReference](global.html#HeightReference)                                    | <optional> | HeightReference.NONE     | A Property specifying what the height is relative to.                                                                                                                                                                                                                                                                                        |
| silhouetteColor            | [Property](Property.html)\|[Color](Color.html)                                                               | <optional> | Color.RED                | A Property specifying the [Color](Color.html) of the silhouette.                                                                                                                                                                                                                                                                             |
| silhouetteSize             | [Property](Property.html)\|number                                                                            | <optional> | 0.0                      | A numeric Property specifying the size of the silhouette in pixels.                                                                                                                                                                                                                                                                          |
| color                      | [Property](Property.html)\|[Color](Color.html)                                                               | <optional> | Color.WHITE              | A Property specifying the [Color](Color.html) that blends with the model's rendered color.                                                                                                                                                                                                                                                   |
| colorBlendMode             | [Property](Property.html)\|[ColorBlendMode](global.html#ColorBlendMode)                                      | <optional> | ColorBlendMode.HIGHLIGHT | An enum Property specifying how the color blends with the model.                                                                                                                                                                                                                                                                             |
| colorBlendAmount           | [Property](Property.html)\|number                                                                            | <optional> | 0.5                      | A numeric Property specifying the color strength when the colorBlendMode is MIX. A value of 0.0 results in the model's rendered color while a value of 1.0 results in a solid color, with any value in-between resulting in a mix of the two.                                                                                                |
| imageBasedLightingFactor   | [Property](Property.html)\|[Cartesian2](Cartesian2.html)                                                     | <optional> | new Cartesian2(1.0, 1.0) | A property specifying the contribution from diffuse and specular image-based lighting.                                                                                                                                                                                                                                                       |
| environmentMapOptions      | [PropertyBag](PropertyBag.html)\|Object.<string, \*>                                                         | <optional> |                          | The properties for managing dynamic environment maps on this entity.                                                                                                                                                                                                                                                                         |
| lightColor                 | [Property](Property.html)\|[Color](Color.html)                                                               | <optional> |                          | A property specifying the light color when shading the model. When undefined the scene's light color is used instead.                                                                                                                                                                                                                        |
| distanceDisplayCondition   | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html)                         | <optional> |                          | A Property specifying at what distance from the camera that this model will be displayed.                                                                                                                                                                                                                                                    |
| nodeTransformations        | [PropertyBag](PropertyBag.html)\|Object.<string, [TranslationRotationScale](TranslationRotationScale.html)\> | <optional> |                          | An object, where keys are names of nodes, and values are [TranslationRotationScale](TranslationRotationScale.html) Properties describing the transformation to apply to that node. The transformation is applied after the node's existing transformation as specified in the glTF, and does not replace the node's existing transformation. |
| articulations              | [PropertyBag](PropertyBag.html)\|Object.<string, number>                                                     | <optional> |                          | An object, where keys are composed of an articulation name, a single space, and a stage name, and the values are numeric properties.                                                                                                                                                                                                         |
| clippingPlanes             | [Property](Property.html)\|[ClippingPlaneCollection](ClippingPlaneCollection.html)                           | <optional> |                          | A property specifying the [ClippingPlaneCollection](ClippingPlaneCollection.html) used to selectively disable rendering the model.                                                                                                                                                                                                           |
| customShader               | [Property](Property.html)\|[CustomShader](CustomShader.html)                                                 | <optional> |                          | A property specifying the [CustomShader](CustomShader.html) to apply to this model.                                                                                                                                                                                                                                                          |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

