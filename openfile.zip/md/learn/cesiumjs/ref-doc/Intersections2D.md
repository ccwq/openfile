# [![](Images/CesiumLogo.png)](index.html) Intersections2D 

[engine/Source/Core/Intersections2D.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Intersections2D.js#L7) 

Contains functions for operating on 2D triangles.

### Methods

#### [](#.clipTriangleAtAxisAlignedThreshold) static Cesium.Intersections2D.clipTriangleAtAxisAlignedThreshold(threshold, keepAbove, u0, u1, u2, result) → Array.<number> 

[engine/Source/Core/Intersections2D.js 40](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Intersections2D.js#L40) 

 Splits a 2D triangle at given axis-aligned threshold value and returns the resulting polygon on a given side of the threshold. The resulting polygon may have 0, 1, 2, 3, or 4 vertices.

| Name      | Type           | Description                                                                                                                   |
| --------- | -------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| threshold | number         | The threshold coordinate value at which to clip the triangle.                                                                 |
| keepAbove | boolean        | true to keep the portion of the triangle above the threshold, or false to keep the portion below.                             |
| u0        | number         | The coordinate of the first vertex in the triangle, in counter-clockwise order.                                               |
| u1        | number         | The coordinate of the second vertex in the triangle, in counter-clockwise order.                                              |
| u2        | number         | The coordinate of the third vertex in the triangle, in counter-clockwise order.                                               |
| result    | Array.<number> | optional The array into which to copy the result. If this parameter is not supplied, a new array is constructed and returned. |

##### Returns:

 The polygon that results after the clip, specified as a list of vertices. The vertices are specified in counter-clockwise order. Each vertex is either an index from the existing list (identified as a 0, 1, or 2) or -1 indicating a new vertex not in the original triangle. For new vertices, the -1 is followed by three additional numbers: the index of each of the two original vertices forming the line segment that the new vertex lies on, and the fraction of the distance from the first vertex to the second one.

##### Example:

```javascript
const result = Cesium.Intersections2D.clipTriangleAtAxisAlignedThreshold(0.5, false, 0.2, 0.6, 0.4);
// result === [2, 0, -1, 1, 0, 0.25, -1, 1, 2, 0.5]
```

#### [](#.computeBarycentricCoordinates) static Cesium.Intersections2D.computeBarycentricCoordinates(x, y, x1, y1, x2, y2, x3, y3, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Intersections2D.js 236](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Intersections2D.js#L236) 

 Compute the barycentric coordinates of a 2D position within a 2D triangle.

| Name   | Type                          | Description                                                                                                                     |
| ------ | ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| x      | number                        | The x coordinate of the position for which to find the barycentric coordinates.                                                 |
| y      | number                        | The y coordinate of the position for which to find the barycentric coordinates.                                                 |
| x1     | number                        | The x coordinate of the triangle's first vertex.                                                                                |
| y1     | number                        | The y coordinate of the triangle's first vertex.                                                                                |
| x2     | number                        | The x coordinate of the triangle's second vertex.                                                                               |
| y2     | number                        | The y coordinate of the triangle's second vertex.                                                                               |
| x3     | number                        | The x coordinate of the triangle's third vertex.                                                                                |
| y3     | number                        | The y coordinate of the triangle's third vertex.                                                                                |
| result | [Cartesian3](Cartesian3.html) | optional The instance into to which to copy the result. If this parameter is undefined, a new instance is created and returned. |

##### Returns:

 The barycentric coordinates of the position within the triangle.

##### Example:

```javascript
const result = Cesium.Intersections2D.computeBarycentricCoordinates(0.0, 0.0, 0.0, 1.0, -1, -0.5, 1, -0.5);
// result === new Cesium.Cartesian3(1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0);
```

#### [](#.computeLineSegmentLineSegmentIntersection) static Cesium.Intersections2D.computeLineSegmentLineSegmentIntersection(x00, y00, x01, y01, x10, y10, x11, y11, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Intersections2D.js 313](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Intersections2D.js#L313) 

 Compute the intersection between 2 line segments

| Name   | Type                          | Description                                                                                                                     |
| ------ | ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| x00    | number                        | The x coordinate of the first line's first vertex.                                                                              |
| y00    | number                        | The y coordinate of the first line's first vertex.                                                                              |
| x01    | number                        | The x coordinate of the first line's second vertex.                                                                             |
| y01    | number                        | The y coordinate of the first line's second vertex.                                                                             |
| x10    | number                        | The x coordinate of the second line's first vertex.                                                                             |
| y10    | number                        | The y coordinate of the second line's first vertex.                                                                             |
| x11    | number                        | The x coordinate of the second line's second vertex.                                                                            |
| y11    | number                        | The y coordinate of the second line's second vertex.                                                                            |
| result | [Cartesian2](Cartesian2.html) | optional The instance into to which to copy the result. If this parameter is undefined, a new instance is created and returned. |

##### Returns:

 The intersection point, undefined if there is no intersection point or lines are coincident.

##### Example:

```javascript
const result = Cesium.Intersections2D.computeLineSegmentLineSegmentIntersection(0.0, 0.0, 0.0, 2.0, -1, 1, 1, 1);
// result === new Cesium.Cartesian2(0.0, 1.0);
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

