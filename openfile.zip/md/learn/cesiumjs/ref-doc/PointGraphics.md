# [![](Images/CesiumLogo.png)](index.html) PointGraphics 

#### [](#PointGraphics) new Cesium.PointGraphics(options) 

[engine/Source/DataSources/PointGraphics.js 33](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L33) 

 Describes a graphical point located at the position of the containing [Entity](Entity.html).

| Name    | Type                                                                       | Description                                       |
| ------- | -------------------------------------------------------------------------- | ------------------------------------------------- |
| options | [PointGraphics.ConstructorOptions](PointGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

### Members

#### [](#color) color : [Property](Property.html)|undefined 

[engine/Source/DataSources/PointGraphics.js 105](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L105) 

 Gets or sets the Property specifying the [Color](Color.html) of the point.

Default Value: `Color.WHITE` 

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/PointGraphics.js 69](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L69) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#disableDepthTestDistance) disableDepthTestDistance : [Property](Property.html)|undefined 

[engine/Source/DataSources/PointGraphics.js 157](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L157) 

 Gets or sets the distance from the camera at which to disable the depth test to, for example, prevent clipping against terrain. When set to zero, the depth test is always applied. When set to Number.POSITIVE\_INFINITY, the depth test is never applied.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/PointGraphics.js 147](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L147) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this point will be displayed.

#### [](#heightReference) heightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/PointGraphics.js 97](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L97) 

 Gets or sets the Property specifying the [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/PointGraphics.js 113](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L113) 

 Gets or sets the Property specifying the [Color](Color.html) of the outline.

Default Value: `Color.BLACK` 

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/PointGraphics.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L121) 

 Gets or sets the numeric Property specifying the the outline width in pixels.

Default Value: `0` 

#### [](#pixelSize) pixelSize : [Property](Property.html)|undefined 

[engine/Source/DataSources/PointGraphics.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L89) 

 Gets or sets the numeric Property specifying the size in pixels.

Default Value: `1` 

#### [](#scaleByDistance) scaleByDistance : [Property](Property.html)|undefined 

[engine/Source/DataSources/PointGraphics.js 129](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L129) 

 Gets or sets the [NearFarScalar](NearFarScalar.html) Property used to scale the point based on distance. If undefined, a constant size is used.

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/PointGraphics.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L81) 

 Gets or sets the boolean Property specifying the visibility of the point.

Default Value: `true` 

#### [](#splitDirection) splitDirection : [Property](Property.html)|undefined 

[engine/Source/DataSources/PointGraphics.js 167](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L167) 

 Gets or sets the Property specifying the [SplitDirection](global.html#SplitDirection) of this point.

Default Value: `SplitDirection.NONE` 

#### [](#translucencyByDistance) translucencyByDistance : [Property](Property.html)|undefined 

[engine/Source/DataSources/PointGraphics.js 140](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L140) 

 Gets or sets [NearFarScalar](NearFarScalar.html) Property specifying the translucency of the point based on the distance from the camera. A point's translucency will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the points's translucency remains clamped to the nearest bound.

### Methods

#### [](#clone) clone(result) → [PointGraphics](PointGraphics.html) 

[engine/Source/DataSources/PointGraphics.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L176) 

 Duplicates this instance.

| Name   | Type                                | Description                                         |
| ------ | ----------------------------------- | --------------------------------------------------- |
| result | [PointGraphics](PointGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/PointGraphics.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L200) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                | Description                               |
| ------ | ----------------------------------- | ----------------------------------------- |
| source | [PointGraphics](PointGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.PointGraphics.ConstructorOptions

[engine/Source/DataSources/PointGraphics.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PointGraphics.js#L7) 

 Initialization options for the PointGraphics constructor

##### Properties:

| Name                     | Type                                                                                 | Attributes | Default              | Description                                                                                                |
| ------------------------ | ------------------------------------------------------------------------------------ | ---------- | -------------------- | ---------------------------------------------------------------------------------------------------------- |
| show                     | [Property](Property.html)\|boolean                                                   | <optional> | true                 | A boolean Property specifying the visibility of the point.                                                 |
| pixelSize                | [Property](Property.html)\|number                                                    | <optional> | 1                    | A numeric Property specifying the size in pixels.                                                          |
| heightReference          | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE | A Property specifying what the height is relative to.                                                      |
| color                    | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.WHITE          | A Property specifying the [Color](Color.html) of the point.                                                |
| outlineColor             | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.BLACK          | A Property specifying the [Color](Color.html) of the outline.                                              |
| outlineWidth             | [Property](Property.html)\|number                                                    | <optional> | 0                    | A numeric Property specifying the the outline width in pixels.                                             |
| scaleByDistance          | [Property](Property.html)\|[NearFarScalar](NearFarScalar.html)                       | <optional> |                      | A [NearFarScalar](NearFarScalar.html) Property used to scale the point based on distance.                  |
| translucencyByDistance   | [Property](Property.html)\|[NearFarScalar](NearFarScalar.html)                       | <optional> |                      | A [NearFarScalar](NearFarScalar.html) Property used to set translucency based on distance from the camera. |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                      | A Property specifying at what distance from the camera that this point will be displayed.                  |
| disableDepthTestDistance | [Property](Property.html)\|number                                                    | <optional> |                      | A Property specifying the distance from the camera at which to disable the depth test to.                  |
| splitDirection           | [Property](Property.html)\|[SplitDirection](global.html#SplitDirection)              | <optional> |                      | A Property specifying the [SplitDirection](global.html#SplitDirection) split to apply to this point.       |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

