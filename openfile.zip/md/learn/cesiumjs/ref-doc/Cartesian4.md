# [![](Images/CesiumLogo.png)](index.html) Cartesian4 

#### [](#Cartesian4) new Cesium.Cartesian4(x, y, z, w) 

[engine/Source/Core/Cartesian4.js 21](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L21) 

 A 4D Cartesian point.

| Name | Type   | Default | Description               |
| ---- | ------ | ------- | ------------------------- |
| x    | number | 0.0     | optional The X component. |
| y    | number | 0.0     | optional The Y component. |
| z    | number | 0.0     | optional The Z component. |
| w    | number | 0.0     | optional The W component. |

##### See:

* [Cartesian2](Cartesian2.html)
* [Cartesian3](Cartesian3.html)
* [Packable](Packable.html)

### Members

#### [](#w) w : number 

[engine/Source/Core/Cartesian4.js 48](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L48) 

 The W component.

Default Value: `0.0` 

#### [](#x) x : number 

[engine/Source/Core/Cartesian4.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L27) 

 The X component.

Default Value: `0.0` 

#### [](#y) y : number 

[engine/Source/Core/Cartesian4.js 34](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L34) 

 The Y component.

Default Value: `0.0` 

#### [](#z) z : number 

[engine/Source/Core/Cartesian4.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L41) 

 The Z component.

Default Value: `0.0` 

#### [](#.ONE) static constant Cesium.Cartesian4.ONE : [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 824](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L824) 

 An immutable Cartesian4 instance initialized to (1.0, 1.0, 1.0, 1.0).

#### [](#.packedLength) static Cesium.Cartesian4.packedLength : number 

[engine/Source/Core/Cartesian4.js 123](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L123) 

 The number of elements used to pack the object into an array.

#### [](#.UNIT%5FW) static constant Cesium.Cartesian4.UNIT\_W : [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 856](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L856) 

 An immutable Cartesian4 instance initialized to (0.0, 0.0, 0.0, 1.0).

#### [](#.UNIT%5FX) static constant Cesium.Cartesian4.UNIT\_X : [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 832](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L832) 

 An immutable Cartesian4 instance initialized to (1.0, 0.0, 0.0, 0.0).

#### [](#.UNIT%5FY) static constant Cesium.Cartesian4.UNIT\_Y : [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 840](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L840) 

 An immutable Cartesian4 instance initialized to (0.0, 1.0, 0.0, 0.0).

#### [](#.UNIT%5FZ) static constant Cesium.Cartesian4.UNIT\_Z : [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 848](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L848) 

 An immutable Cartesian4 instance initialized to (0.0, 0.0, 1.0, 0.0).

#### [](#.ZERO) static constant Cesium.Cartesian4.ZERO : [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 816](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L816) 

 An immutable Cartesian4 instance initialized to (0.0, 0.0, 0.0, 0.0).

### Methods

#### [](#clone) clone(result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 864](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L864) 

 Duplicates this Cartesian4 instance.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| result | [Cartesian4](Cartesian4.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian4 instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/Cartesian4.js 875](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L875) 

 Compares this Cartesian against the provided Cartesian componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                          | Description                             |
| ----- | ----------------------------- | --------------------------------------- |
| right | [Cartesian4](Cartesian4.html) | optional The right hand side Cartesian. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(right, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/Cartesian4.js 889](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L889) 

 Compares this Cartesian against the provided Cartesian componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                          | Default         | Description                                                          |
| --------------- | ----------------------------- | --------------- | -------------------------------------------------------------------- |
| right           | [Cartesian4](Cartesian4.html) |                 | optional The right hand side Cartesian.                              |
| relativeEpsilon | number                        | 0               | optional The relative epsilon tolerance to use for equality testing. |
| absoluteEpsilon | number                        | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if they are within the provided epsilon, `false` otherwise.

#### [](#toString) toString() → string 

[engine/Source/Core/Cartesian4.js 907](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L907) 

 Creates a string representing this Cartesian in the format '(x, y, z, w)'.

##### Returns:

 A string representing the provided Cartesian in the format '(x, y, z, w)'.

#### [](#.abs) static Cesium.Cartesian4.abs(cartesian, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 650](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L650) 

 Computes the absolute value of the provided Cartesian.

| Name      | Type                          | Description                                           |
| --------- | ----------------------------- | ----------------------------------------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian whose absolute value is to be computed. |
| result    | [Cartesian4](Cartesian4.html) | The object onto which to store the result.            |

##### Returns:

 The modified result parameter.

#### [](#.add) static Cesium.Cartesian4.add(left, right, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 543](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L543) 

 Computes the componentwise sum of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian4](Cartesian4.html) | The first Cartesian.                       |
| right  | [Cartesian4](Cartesian4.html) | The second Cartesian.                      |
| result | [Cartesian4](Cartesian4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.clamp) static Cesium.Cartesian4.clamp(value, min, max, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 340](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L340) 

 Constrain a value to lie between two values.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| value  | [Cartesian4](Cartesian4.html) | The value to clamp.                        |
| min    | [Cartesian4](Cartesian4.html) | The minimum bound.                         |
| max    | [Cartesian4](Cartesian4.html) | The maximum bound.                         |
| result | [Cartesian4](Cartesian4.html) | The object into which to store the result. |

##### Returns:

 The clamped value such that min <= result <= max.

#### [](#.clone) static Cesium.Cartesian4.clone(cartesian, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 103](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L103) 

 Duplicates a Cartesian4 instance.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian to duplicate.                         |
| result    | [Cartesian4](Cartesian4.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian4 instance if one was not provided. (Returns undefined if cartesian is undefined)

#### [](#.distance) static Cesium.Cartesian4.distance(left, right) → number 

[engine/Source/Core/Cartesian4.js 405](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L405) 

 Computes the 4-space distance between two points.

| Name  | Type                          | Description                                   |
| ----- | ----------------------------- | --------------------------------------------- |
| left  | [Cartesian4](Cartesian4.html) | The first point to compute the distance from. |
| right | [Cartesian4](Cartesian4.html) | The second point to compute the distance to.  |

##### Returns:

 The distance between two points.

##### Example:

```javascript
// Returns 1.0
const d = Cesium.Cartesian4.distance(
  new Cesium.Cartesian4(1.0, 0.0, 0.0, 0.0),
  new Cesium.Cartesian4(2.0, 0.0, 0.0, 0.0));
```

#### [](#.distanceSquared) static Cesium.Cartesian4.distanceSquared(left, right) → number 

[engine/Source/Core/Cartesian4.js 429](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L429) 

 Computes the squared distance between two points. Comparing squared distances using this function is more efficient than comparing distances using `Cartesian4#distance`.

| Name  | Type                          | Description                                   |
| ----- | ----------------------------- | --------------------------------------------- |
| left  | [Cartesian4](Cartesian4.html) | The first point to compute the distance from. |
| right | [Cartesian4](Cartesian4.html) | The second point to compute the distance to.  |

##### Returns:

 The distance between two points.

##### Example:

```javascript
// Returns 4.0, not 2.0
const d = Cesium.Cartesian4.distance(
  new Cesium.Cartesian4(1.0, 0.0, 0.0, 0.0),
  new Cesium.Cartesian4(3.0, 0.0, 0.0, 0.0));
```

#### [](#.divideByScalar) static Cesium.Cartesian4.divideByScalar(cartesian, scalar, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 609](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L609) 

 Divides the provided Cartesian componentwise by the provided scalar.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian to be divided.               |
| scalar    | number                        | The scalar to divide by.                   |
| result    | [Cartesian4](Cartesian4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.divideComponents) static Cesium.Cartesian4.divideComponents(left, right, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 521](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L521) 

 Computes the componentwise quotient of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian4](Cartesian4.html) | The first Cartesian.                       |
| right  | [Cartesian4](Cartesian4.html) | The second Cartesian.                      |
| result | [Cartesian4](Cartesian4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.dot) static Cesium.Cartesian4.dot(left, right) → number 

[engine/Source/Core/Cartesian4.js 480](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L480) 

 Computes the dot (scalar) product of two Cartesians.

| Name  | Type                          | Description           |
| ----- | ----------------------------- | --------------------- |
| left  | [Cartesian4](Cartesian4.html) | The first Cartesian.  |
| right | [Cartesian4](Cartesian4.html) | The second Cartesian. |

##### Returns:

 The dot product.

#### [](#.equals) static Cesium.Cartesian4.equals(left, right) → boolean 

[engine/Source/Core/Cartesian4.js 738](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L738) 

 Compares the provided Cartesians componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                          | Description                    |
| ----- | ----------------------------- | ------------------------------ |
| left  | [Cartesian4](Cartesian4.html) | optional The first Cartesian.  |
| right | [Cartesian4](Cartesian4.html) | optional The second Cartesian. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.equalsEpsilon) static Cesium.Cartesian4.equalsEpsilon(left, right, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/Cartesian4.js 773](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L773) 

 Compares the provided Cartesians componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                          | Default         | Description                                                          |
| --------------- | ----------------------------- | --------------- | -------------------------------------------------------------------- |
| left            | [Cartesian4](Cartesian4.html) |                 | optional The first Cartesian.                                        |
| right           | [Cartesian4](Cartesian4.html) |                 | optional The second Cartesian.                                       |
| relativeEpsilon | number                        | 0               | optional The relative epsilon tolerance to use for equality testing. |
| absoluteEpsilon | number                        | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if left and right are within the provided epsilon, `false` otherwise.

#### [](#.fromArray) static Cesium.Cartesian4.fromArray(array, startingIndex, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 255](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L255) 

 Creates a Cartesian4 from four consecutive elements in an array.

| Name          | Type                          | Default | Description                                                                                          |
| ------------- | ----------------------------- | ------- | ---------------------------------------------------------------------------------------------------- |
| array         | Array.<number>                |         | The array whose four consecutive elements correspond to the x, y, z, and w components, respectively. |
| startingIndex | number                        | 0       | optional The offset into the array of the first element, which corresponds to the x component.       |
| result        | [Cartesian4](Cartesian4.html) |         | optional The object onto which to store the result.                                                  |

##### Returns:

 The modified result parameter or a new Cartesian4 instance if one was not provided.

##### Example:

```javascript
// Create a Cartesian4 with (1.0, 2.0, 3.0, 4.0)
const v = [1.0, 2.0, 3.0, 4.0];
const p = Cesium.Cartesian4.fromArray(v);

// Create a Cartesian4 with (1.0, 2.0, 3.0, 4.0) using an offset into an array
const v2 = [0.0, 0.0, 1.0, 2.0, 3.0, 4.0];
const p2 = Cesium.Cartesian4.fromArray(v2, 2);
```

#### [](#.fromColor) static Cesium.Cartesian4.fromColor(color, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L81) 

 Creates a Cartesian4 instance from a [Color](Color.html). `red`, `green`, `blue`, and `alpha` map to `x`, `y`, `z`, and `w`, respectively.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| color  | [Color](Color.html)           | The source color.                                   |
| result | [Cartesian4](Cartesian4.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian4 instance if one was not provided.

#### [](#.fromElements) static Cesium.Cartesian4.fromElements(x, y, z, w, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 61](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L61) 

 Creates a Cartesian4 instance from x, y, z and w coordinates.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| x      | number                        | The x coordinate.                                   |
| y      | number                        | The y coordinate.                                   |
| z      | number                        | The z coordinate.                                   |
| w      | number                        | The w coordinate.                                   |
| result | [Cartesian4](Cartesian4.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian4 instance if one was not provided.

#### [](#.lerp) static Cesium.Cartesian4.lerp(start, end, t, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 673](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L673) 

 Computes the linear interpolation or extrapolation at t using the provided cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| start  | [Cartesian4](Cartesian4.html) | The value corresponding to t at 0.0.       |
| end    | [Cartesian4](Cartesian4.html) | The value corresponding to t at 1.0.       |
| t      | number                        | The point along t at which to interpolate. |
| result | [Cartesian4](Cartesian4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.magnitude) static Cesium.Cartesian4.magnitude(cartesian) → number 

[engine/Source/Core/Cartesian4.js 386](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L386) 

 Computes the Cartesian's magnitude (length).

| Name      | Type                          | Description                                               |
| --------- | ----------------------------- | --------------------------------------------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian instance whose magnitude is to be computed. |

##### Returns:

 The magnitude.

#### [](#.magnitudeSquared) static Cesium.Cartesian4.magnitudeSquared(cartesian) → number 

[engine/Source/Core/Cartesian4.js 367](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L367) 

 Computes the provided Cartesian's squared magnitude.

| Name      | Type                          | Description                                                       |
| --------- | ----------------------------- | ----------------------------------------------------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian instance whose squared magnitude is to be computed. |

##### Returns:

 The squared magnitude.

#### [](#.maximumByComponent) static Cesium.Cartesian4.maximumByComponent(first, second, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 316](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L316) 

 Compares two Cartesians and computes a Cartesian which contains the maximum components of the supplied Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| first  | [Cartesian4](Cartesian4.html) | A cartesian to compare.                    |
| second | [Cartesian4](Cartesian4.html) | A cartesian to compare.                    |
| result | [Cartesian4](Cartesian4.html) | The object into which to store the result. |

##### Returns:

 A cartesian with the maximum components.

#### [](#.maximumComponent) static Cesium.Cartesian4.maximumComponent(cartesian) → number 

[engine/Source/Core/Cartesian4.js 263](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L263) 

 Computes the value of the maximum component for the supplied Cartesian.

| Name      | Type                          | Description           |
| --------- | ----------------------------- | --------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The cartesian to use. |

##### Returns:

 The value of the maximum component.

#### [](#.minimumByComponent) static Cesium.Cartesian4.minimumByComponent(first, second, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 293](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L293) 

 Compares two Cartesians and computes a Cartesian which contains the minimum components of the supplied Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| first  | [Cartesian4](Cartesian4.html) | A cartesian to compare.                    |
| second | [Cartesian4](Cartesian4.html) | A cartesian to compare.                    |
| result | [Cartesian4](Cartesian4.html) | The object into which to store the result. |

##### Returns:

 A cartesian with the minimum components.

#### [](#.minimumComponent) static Cesium.Cartesian4.minimumComponent(cartesian) → number 

[engine/Source/Core/Cartesian4.js 277](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L277) 

 Computes the value of the minimum component for the supplied Cartesian.

| Name      | Type                          | Description           |
| --------- | ----------------------------- | --------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The cartesian to use. |

##### Returns:

 The value of the minimum component.

#### [](#.mostOrthogonalAxis) static Cesium.Cartesian4.mostOrthogonalAxis(cartesian, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 694](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L694) 

 Returns the axis that is most orthogonal to the provided Cartesian.

| Name      | Type                          | Description                                              |
| --------- | ----------------------------- | -------------------------------------------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian on which to find the most orthogonal axis. |
| result    | [Cartesian4](Cartesian4.html) | The object onto which to store the result.               |

##### Returns:

 The most orthogonal axis.

#### [](#.multiplyByScalar) static Cesium.Cartesian4.multiplyByScalar(cartesian, scalar, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 587](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L587) 

 Multiplies the provided Cartesian componentwise by the provided scalar.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian to be scaled.                |
| scalar    | number                        | The scalar to multiply with.               |
| result    | [Cartesian4](Cartesian4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiplyComponents) static Cesium.Cartesian4.multiplyComponents(left, right, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 499](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L499) 

 Computes the componentwise product of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian4](Cartesian4.html) | The first Cartesian.                       |
| right  | [Cartesian4](Cartesian4.html) | The second Cartesian.                      |
| result | [Cartesian4](Cartesian4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.negate) static Cesium.Cartesian4.negate(cartesian, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 630](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L630) 

 Negates the provided Cartesian.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian to be negated.               |
| result    | [Cartesian4](Cartesian4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.normalize) static Cesium.Cartesian4.normalize(cartesian, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 446](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L446) 

 Computes the normalized form of the supplied Cartesian.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian to be normalized.            |
| result    | [Cartesian4](Cartesian4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.pack) static Cesium.Cartesian4.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/Cartesian4.js 134](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L134) 

 Stores the provided instance into the provided array.

| Name          | Type                          | Default | Description                                                               |
| ------------- | ----------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [Cartesian4](Cartesian4.html) |         | The value to pack.                                                        |
| array         | Array.<number>                |         | The array to pack into.                                                   |
| startingIndex | number                        | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.packArray) static Cesium.Cartesian4.packArray(array, result) → Array.<number> 

[engine/Source/Core/Cartesian4.js 182](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L182) 

 Flattens an array of Cartesian4s into an array of components.

| Name   | Type                                   | Description                                                                                                                                                                                                                                                             |
| ------ | -------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| array  | Array.<[Cartesian4](Cartesian4.html)\> | The array of cartesians to pack.                                                                                                                                                                                                                                        |
| result | Array.<number>                         | optional The array onto which to store the result. If this is a typed array, it must have array.length \* 4 components, else a [DeveloperError](DeveloperError.html) will be thrown. If it is a regular array, it will be resized to have (array.length \* 4) elements. |

##### Returns:

 The packed array.

#### [](#.packFloat) static Cesium.Cartesian4.packFloat(value, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 926](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L926) 

 Packs an arbitrary floating point value to 4 values representable using uint8.

| Name   | Type                          | Description                                                 |
| ------ | ----------------------------- | ----------------------------------------------------------- |
| value  | number                        | A floating point number.                                    |
| result | [Cartesian4](Cartesian4.html) | optional The Cartesian4 that will contain the packed float. |

##### Returns:

 A Cartesian4 representing the float packed to values in x, y, z, and w.

#### [](#.subtract) static Cesium.Cartesian4.subtract(left, right, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 565](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L565) 

 Computes the componentwise difference of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian4](Cartesian4.html) | The first Cartesian.                       |
| right  | [Cartesian4](Cartesian4.html) | The second Cartesian.                      |
| result | [Cartesian4](Cartesian4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.unpack) static Cesium.Cartesian4.unpack(array, startingIndex, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Cartesian4.js 158](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L158) 

 Retrieves an instance from a packed array.

| Name          | Type                          | Default | Description                                                |
| ------------- | ----------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                |         | The packed array.                                          |
| startingIndex | number                        | 0       | optional The starting index of the element to be unpacked. |
| result        | [Cartesian4](Cartesian4.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new Cartesian4 instance if one was not provided.

#### [](#.unpackArray) static Cesium.Cartesian4.unpackArray(array, result) → Array.<[Cartesian4](Cartesian4.html)\> 

[engine/Source/Core/Cartesian4.js 214](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian4.js#L214) 

 Unpacks an array of cartesian components into an array of Cartesian4s.

| Name   | Type                                   | Description                                        |
| ------ | -------------------------------------- | -------------------------------------------------- |
| array  | Array.<number>                         | The array of components to unpack.                 |
| result | Array.<[Cartesian4](Cartesian4.html)\> | optional The array onto which to store the result. |

##### Returns:

 The unpacked array.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

