# [![](Images/CesiumLogo.png)](index.html) HeadingPitchRoll 

#### [](#HeadingPitchRoll) new Cesium.HeadingPitchRoll(heading, pitch, roll) 

[engine/Source/Core/HeadingPitchRoll.js 17](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L17) 

 A rotation expressed as a heading, pitch, and roll. Heading is the rotation about the negative z axis. Pitch is the rotation about the negative y axis. Roll is the rotation about the positive x axis.

| Name    | Type   | Default | Description                                |
| ------- | ------ | ------- | ------------------------------------------ |
| heading | number | 0.0     | optional The heading component in radians. |
| pitch   | number | 0.0     | optional The pitch component in radians.   |
| roll    | number | 0.0     | optional The roll component in radians.    |

### Members

#### [](#heading) heading : number 

[engine/Source/Core/HeadingPitchRoll.js 23](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L23) 

 Gets or sets the heading.

Default Value: `0.0` 

#### [](#pitch) pitch : number 

[engine/Source/Core/HeadingPitchRoll.js 29](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L29) 

 Gets or sets the pitch.

Default Value: `0.0` 

#### [](#roll) roll : number 

[engine/Source/Core/HeadingPitchRoll.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L35) 

 Gets or sets the roll.

Default Value: `0.0` 

### Methods

#### [](#.clone) static Cesium.HeadingPitchRoll.clone(headingPitchRoll, result) → [HeadingPitchRoll](HeadingPitchRoll.html) 

[engine/Source/Core/HeadingPitchRoll.js 106](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L106) 

 Duplicates a HeadingPitchRoll instance.

| Name             | Type                                      | Description                                         |
| ---------------- | ----------------------------------------- | --------------------------------------------------- |
| headingPitchRoll | [HeadingPitchRoll](HeadingPitchRoll.html) | The HeadingPitchRoll to duplicate.                  |
| result           | [HeadingPitchRoll](HeadingPitchRoll.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new HeadingPitchRoll instance if one was not provided. (Returns undefined if headingPitchRoll is undefined)

#### [](#.equals) static Cesium.HeadingPitchRoll.equals(left, right) → boolean 

[engine/Source/Core/HeadingPitchRoll.js 131](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L131) 

 Compares the provided HeadingPitchRolls componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                      | Description                           |
| ----- | ----------------------------------------- | ------------------------------------- |
| left  | [HeadingPitchRoll](HeadingPitchRoll.html) | optional The first HeadingPitchRoll.  |
| right | [HeadingPitchRoll](HeadingPitchRoll.html) | optional The second HeadingPitchRoll. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.equalsEpsilon) static Cesium.HeadingPitchRoll.equalsEpsilon(left, right, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/HeadingPitchRoll.js 153](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L153) 

 Compares the provided HeadingPitchRolls componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                                      | Default         | Description                                                          |
| --------------- | ----------------------------------------- | --------------- | -------------------------------------------------------------------- |
| left            | [HeadingPitchRoll](HeadingPitchRoll.html) |                 | optional The first HeadingPitchRoll.                                 |
| right           | [HeadingPitchRoll](HeadingPitchRoll.html) |                 | optional The second HeadingPitchRoll.                                |
| relativeEpsilon | number                                    | 0               | optional The relative epsilon tolerance to use for equality testing. |
| absoluteEpsilon | number                                    | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if left and right are within the provided epsilon, `false` otherwise.

#### [](#.fromDegrees) static Cesium.HeadingPitchRoll.fromDegrees(heading, pitch, roll, result) → [HeadingPitchRoll](HeadingPitchRoll.html) 

[engine/Source/Core/HeadingPitchRoll.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L78) 

 Returns a new HeadingPitchRoll instance from angles given in degrees.

| Name    | Type                                      | Description                                                                                                |
| ------- | ----------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| heading | number                                    | the heading in degrees                                                                                     |
| pitch   | number                                    | the pitch in degrees                                                                                       |
| roll    | number                                    | the heading in degrees                                                                                     |
| result  | [HeadingPitchRoll](HeadingPitchRoll.html) | optional The object in which to store the result. If not provided, a new instance is created and returned. |

##### Returns:

 A new HeadingPitchRoll instance

#### [](#.fromQuaternion) static Cesium.HeadingPitchRoll.fromQuaternion(quaternion, result) → [HeadingPitchRoll](HeadingPitchRoll.html) 

[engine/Source/Core/HeadingPitchRoll.js 45](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L45) 

 Computes the heading, pitch and roll from a quaternion (see http://en.wikipedia.org/wiki/Conversion\_between\_quaternions\_and\_Euler\_angles )

| Name       | Type                                      | Description                                                                                                |
| ---------- | ----------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| quaternion | [Quaternion](Quaternion.html)             | The quaternion from which to retrieve heading, pitch, and roll, all expressed in radians.                  |
| result     | [HeadingPitchRoll](HeadingPitchRoll.html) | optional The object in which to store the result. If not provided, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new HeadingPitchRoll instance if one was not provided.

#### [](#clone) clone(result) → [HeadingPitchRoll](HeadingPitchRoll.html) 

[engine/Source/Core/HeadingPitchRoll.js 190](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L190) 

 Duplicates this HeadingPitchRoll instance.

| Name   | Type                                      | Description                                         |
| ------ | ----------------------------------------- | --------------------------------------------------- |
| result | [HeadingPitchRoll](HeadingPitchRoll.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new HeadingPitchRoll instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/HeadingPitchRoll.js 201](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L201) 

 Compares this HeadingPitchRoll against the provided HeadingPitchRoll componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                      | Description                                    |
| ----- | ----------------------------------------- | ---------------------------------------------- |
| right | [HeadingPitchRoll](HeadingPitchRoll.html) | optional The right hand side HeadingPitchRoll. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(right, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/HeadingPitchRoll.js 215](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L215) 

 Compares this HeadingPitchRoll against the provided HeadingPitchRoll componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                                      | Default         | Description                                                          |
| --------------- | ----------------------------------------- | --------------- | -------------------------------------------------------------------- |
| right           | [HeadingPitchRoll](HeadingPitchRoll.html) |                 | optional The right hand side HeadingPitchRoll.                       |
| relativeEpsilon | number                                    | 0               | optional The relative epsilon tolerance to use for equality testing. |
| absoluteEpsilon | number                                    | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if they are within the provided epsilon, `false` otherwise.

#### [](#toString) toString() → string 

[engine/Source/Core/HeadingPitchRoll.js 233](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeadingPitchRoll.js#L233) 

 Creates a string representing this HeadingPitchRoll in the format '(heading, pitch, roll)' in radians.

##### Returns:

 A string representing the provided HeadingPitchRoll in the format '(heading, pitch, roll)'.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

