# [![](Images/CesiumLogo.png)](index.html) EntityCollection 

#### [](#EntityCollection) new Cesium.EntityCollection(owner) 

[engine/Source/DataSources/EntityCollection.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L55) 

 An observable collection of [Entity](Entity.html) instances where each entity has a unique id.

| Name  | Type                                                                                       | Description                                                                              |
| ----- | ------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------- |
| owner | [DataSource](DataSource.html)\|[CompositeEntityCollection](CompositeEntityCollection.html) | optional The data source (or composite entity collection) which created this collection. |

### Members

#### [](#collectionChanged) readonly collectionChanged : [Event](Event.html).<[EntityCollection.CollectionChangedEventCallback](EntityCollection.html#.CollectionChangedEventCallback)\> 

[engine/Source/DataSources/EntityCollection.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L121) 

 Gets the event that is fired when entities are added or removed from the collection. The generated event is a [EntityCollection.CollectionChangedEventCallback](EntityCollection.html#.CollectionChangedEventCallback).

#### [](#id) readonly id : string 

[engine/Source/DataSources/EntityCollection.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L132) 

 Gets a globally unique identifier for this collection.

#### [](#owner) readonly owner : [DataSource](DataSource.html)|[CompositeEntityCollection](CompositeEntityCollection.html) 

[engine/Source/DataSources/EntityCollection.js 210](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L210) 

 Gets the owner of this entity collection, ie. the data source or composite entity collection which created it.

#### [](#show) show : boolean 

[engine/Source/DataSources/EntityCollection.js 156](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L156) 

 Gets whether or not this entity collection should be displayed. When true, each entity is only displayed if its own show property is also true.

#### [](#values) readonly values : Array.<[Entity](Entity.html)\> 

[engine/Source/DataSources/EntityCollection.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L144) 

 Gets the array of Entity instances in the collection. This array should not be modified directly.

### Methods

#### [](#add) add(entity) → [Entity](Entity.html) 

[engine/Source/DataSources/EntityCollection.js 269](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L269) 

 Add an entity to the collection.

| Name   | Type                                                                                | Description             |
| ------ | ----------------------------------------------------------------------------------- | ----------------------- |
| entity | [Entity](Entity.html)\|[Entity.ConstructorOptions](Entity.html#.ConstructorOptions) | The entity to be added. |

##### Returns:

 The entity that was added.

##### Throws:

[DeveloperError](DeveloperError.html): An entity with  already exists in this collection. 

#### [](#computeAvailability) computeAvailability() → [TimeInterval](TimeInterval.html) 

[engine/Source/DataSources/EntityCollection.js 225](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L225) 

 Computes the maximum availability of the entities in the collection. If the collection contains a mix of infinitely available data and non-infinite data, it will return the interval pertaining to the non-infinite data only. If all data is infinite, an infinite interval will be returned.

##### Returns:

 The availability of entities in the collection.

#### [](#contains) contains(entity) → boolean 

[engine/Source/DataSources/EntityCollection.js 322](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L322) 

 Returns true if the provided entity is in this collection, false otherwise.

| Name   | Type                  | Description |
| ------ | --------------------- | ----------- |
| entity | [Entity](Entity.html) | The entity. |

##### Returns:

 true if the provided entity is in this collection, false otherwise.

#### [](#getById) getById(id) → [Entity](Entity.html)|undefined 

[engine/Source/DataSources/EntityCollection.js 400](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L400) 

 Gets an entity with the specified id.

| Name | Type   | Description                       |
| ---- | ------ | --------------------------------- |
| id   | string | The id of the entity to retrieve. |

##### Returns:

 The entity with the provided id or undefined if the id did not exist in the collection.

#### [](#getOrCreateEntity) getOrCreateEntity(id) → [Entity](Entity.html) 

[engine/Source/DataSources/EntityCollection.js 416](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L416) 

 Gets an entity with the specified id or creates it and adds it to the collection if it does not exist.

| Name | Type   | Description                                 |
| ---- | ------ | ------------------------------------------- |
| id   | string | The id of the entity to retrieve or create. |

##### Returns:

 The new or existing object.

#### [](#remove) remove(entity) → boolean 

[engine/Source/DataSources/EntityCollection.js 309](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L309) 

 Removes an entity from the collection.

| Name   | Type                  | Description               |
| ------ | --------------------- | ------------------------- |
| entity | [Entity](Entity.html) | The entity to be removed. |

##### Returns:

 true if the item was removed, false if it did not exist in the collection.

#### [](#removeAll) removeAll() 

[engine/Source/DataSources/EntityCollection.js 365](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L365) 

 Removes all Entities from the collection.

#### [](#removeById) removeById(id) → boolean 

[engine/Source/DataSources/EntityCollection.js 337](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L337) 

 Removes an entity with the provided id from the collection.

| Name | Type   | Description                     |
| ---- | ------ | ------------------------------- |
| id   | string | The id of the entity to remove. |

##### Returns:

 true if the item was removed, false if no item with the provided id existed in the collection.

#### [](#resumeEvents) resumeEvents() 

[engine/Source/DataSources/EntityCollection.js 90](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L90) 

 Resumes raising [EntityCollection#collectionChanged](EntityCollection.html#collectionChanged) events immediately when an item is added or removed. Any modifications made while while events were suspended will be triggered as a single event when this function is called. This function is reference counted and can safely be called multiple times as long as there are corresponding calls to [EntityCollection#resumeEvents](EntityCollection.html#resumeEvents).

##### Throws:

* [DeveloperError](DeveloperError.html): resumeEvents can not be called before suspendEvents.

#### [](#suspendEvents) suspendEvents() 

[engine/Source/DataSources/EntityCollection.js 77](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L77) 

 Prevents [EntityCollection#collectionChanged](EntityCollection.html#collectionChanged) events from being raised until a corresponding call is made to [EntityCollection#resumeEvents](EntityCollection.html#resumeEvents), at which point a single event will be raised that covers all suspended operations. This allows for many items to be added and removed efficiently. This function can be safely called multiple times as long as there are corresponding calls to [EntityCollection#resumeEvents](EntityCollection.html#resumeEvents).

### Type Definitions

#### [](#.CollectionChangedEventCallback) Cesium.EntityCollection.CollectionChangedEventCallback(collection, added, removed, changed) 

[engine/Source/DataSources/EntityCollection.js 103](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCollection.js#L103) 

 The signature of the event generated by [EntityCollection#collectionChanged](EntityCollection.html#collectionChanged).

| Name       | Type                                      | Description                                                                              |
| ---------- | ----------------------------------------- | ---------------------------------------------------------------------------------------- |
| collection | [EntityCollection](EntityCollection.html) | The collection that triggered the event.                                                 |
| added      | Array.<[Entity](Entity.html)\>            | The array of [Entity](Entity.html) instances that have been added to the collection.     |
| removed    | Array.<[Entity](Entity.html)\>            | The array of [Entity](Entity.html) instances that have been removed from the collection. |
| changed    | Array.<[Entity](Entity.html)\>            | The array of [Entity](Entity.html) instances that have been modified.                    |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

