# [![](Images/CesiumLogo.png)](index.html) Cesium3DTilePointFeature 

#### [](#Cesium3DTilePointFeature) new Cesium.Cesium3DTilePointFeature() 

[engine/Source/Scene/Cesium3DTilePointFeature.js 44](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L44) 

 A point feature of a [Cesium3DTileset](Cesium3DTileset.html).

Provides access to a feature's properties stored in the tile's batch table, as well as the ability to show/hide a feature and change its point properties

Modifications to a `Cesium3DTilePointFeature` object have the lifetime of the tile's content. If the tile's content is unloaded, e.g., due to it going out of view and needing to free space in the cache for visible tiles, listen to the [Cesium3DTileset#tileUnload](Cesium3DTileset.html#tileUnload) event to save any modifications. Also listen to the [Cesium3DTileset#tileVisible](Cesium3DTileset.html#tileVisible) event to reapply any modifications.

Do not construct this directly. Access it through [Cesium3DTileContent#getFeature](Cesium3DTileContent.html#getFeature)or picking using [Scene#pick](Scene.html#pick) and [Scene#pickPosition](Scene.html#pickPosition).

##### Example:

```javascript
// On mouse over, display all the properties for a feature in the console log.
handler.setInputAction(function(movement) {
    const feature = scene.pick(movement.endPosition);
    if (feature instanceof Cesium.Cesium3DTilePointFeature) {
        const propertyIds = feature.getPropertyIds();
        const length = propertyIds.length;
        for (let i = 0; i < length; ++i) {
            const propertyId = propertyIds[i];
            console.log(`{propertyId}: ${feature.getProperty(propertyId)}`);
        }
    }
}, Cesium.ScreenSpaceEventType.MOUSE_MOVE);
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

### Members

#### [](#anchorLineColor) anchorLineColor : [Color](Color.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 461](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L461) 

 Gets or sets the color for the anchor line.

Only applied when `heightOffset` is defined.

#### [](#anchorLineEnabled) anchorLineEnabled : boolean 

[engine/Source/Scene/Cesium3DTilePointFeature.js 442](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L442) 

 Gets or sets whether the anchor line is displayed.

Only applied when `heightOffset` is defined.

#### [](#backgroundColor) backgroundColor : [Color](Color.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 303](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L303) 

 Gets or sets the background color of the text for this feature.

Only applied when `labelText` is defined.

#### [](#backgroundEnabled) backgroundEnabled : boolean 

[engine/Source/Scene/Cesium3DTilePointFeature.js 341](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L341) 

 Gets or sets whether to display the background of the text for this feature.

Only applied when `labelText` is defined.

#### [](#backgroundPadding) backgroundPadding : [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 322](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L322) 

 Gets or sets the background padding of the text for this feature.

Only applied when `labelText` is defined.

#### [](#color) color : [Color](Color.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L108) 

 Gets or sets the color of the point of this feature.

Only applied when `image` is `undefined`.

#### [](#disableDepthTestDistance) disableDepthTestDistance : number 

[engine/Source/Scene/Cesium3DTilePointFeature.js 500](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L500) 

 Gets or sets the distance where depth testing will be disabled.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [DistanceDisplayCondition](DistanceDisplayCondition.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 391](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L391) 

 Gets or sets the condition specifying at what distance from the camera that this feature will be displayed.

#### [](#font) font : string 

[engine/Source/Scene/Cesium3DTilePointFeature.js 246](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L246) 

 Gets or sets the font of this feature.

Only applied when the `labelText` is defined.

#### [](#heightOffset) heightOffset : number 

[engine/Source/Scene/Cesium3DTilePointFeature.js 409](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L409) 

 Gets or sets the height offset in meters of this feature.

#### [](#horizontalOrigin) horizontalOrigin : [HorizontalOrigin](global.html#HorizontalOrigin) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 518](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L518) 

 Gets or sets the horizontal origin of this point, which determines if the point is to the left, center, or right of its anchor position.

#### [](#image) image : string 

[engine/Source/Scene/Cesium3DTilePointFeature.js 480](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L480) 

 Gets or sets the image of this feature.

#### [](#labelColor) labelColor : [Color](Color.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 188](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L188) 

 Gets or sets the label color of this feature.

The color will be applied to the label if `labelText` is defined.

#### [](#labelHorizontalOrigin) labelHorizontalOrigin : [HorizontalOrigin](global.html#HorizontalOrigin) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 552](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L552) 

 Gets or sets the horizontal origin of this point's text, which determines if the point's text is to the left, center, or right of its anchor position.

#### [](#labelOutlineColor) labelOutlineColor : [Color](Color.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 208](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L208) 

 Gets or sets the label outline color of this feature.

The outline color will be applied to the label if `labelText` is defined.

#### [](#labelOutlineWidth) labelOutlineWidth : number 

[engine/Source/Scene/Cesium3DTilePointFeature.js 227](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L227) 

 Gets or sets the outline width in pixels of this feature.

The outline width will be applied to the point if `labelText` is defined.

#### [](#labelStyle) labelStyle : [LabelStyle](global.html#LabelStyle) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 265](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L265) 

 Gets or sets the fill and outline style of this feature.

Only applied when `labelText` is defined.

#### [](#labelText) labelText : string 

[engine/Source/Scene/Cesium3DTilePointFeature.js 281](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L281) 

 Gets or sets the text for this feature.

#### [](#labelVerticalOrigin) labelVerticalOrigin : [VerticalOrigin](global.html#VerticalOrigin) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 569](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L569) 

 Get or sets the vertical origin of this point's text, which determines if the point's text is to the bottom, center, top, or baseline of it's anchor point.

#### [](#pointOutlineColor) pointOutlineColor : [Color](Color.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 148](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L148) 

 Gets or sets the point outline color of this feature.

Only applied when `image` is `undefined`.

#### [](#pointOutlineWidth) pointOutlineWidth : number 

[engine/Source/Scene/Cesium3DTilePointFeature.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L168) 

 Gets or sets the point outline width in pixels of this feature.

Only applied when `image` is `undefined`.

#### [](#pointSize) pointSize : number 

[engine/Source/Scene/Cesium3DTilePointFeature.js 128](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L128) 

 Gets or sets the point size of this feature.

Only applied when `image` is `undefined`.

#### [](#primitive) readonly primitive : [Cesium3DTileset](Cesium3DTileset.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 619](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L619) 

 All objects returned by [Scene#pick](Scene.html#pick) have a `primitive` property. This returns the tileset containing the feature.

#### [](#scaleByDistance) scaleByDistance : [NearFarScalar](NearFarScalar.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 357](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L357) 

 Gets or sets the near and far scaling properties for this feature.

#### [](#show) show : boolean 

[engine/Source/Scene/Cesium3DTilePointFeature.js 87](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L87) 

 Gets or sets if the feature will be shown. This is set for all features when a style's show is evaluated.

Default Value: `true` 

#### [](#tileset) readonly tileset : [Cesium3DTileset](Cesium3DTileset.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 603](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L603) 

 Gets the tileset containing the feature.

#### [](#translucencyByDistance) translucencyByDistance : [NearFarScalar](NearFarScalar.html) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 374](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L374) 

 Gets or sets the near and far translucency properties for this feature.

#### [](#verticalOrigin) verticalOrigin : [VerticalOrigin](global.html#VerticalOrigin) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 535](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L535) 

 Gets or sets the vertical origin of this point, which determines if the point is to the bottom, center, or top of its anchor position.

### Methods

#### [](#getProperty) getProperty(name) → \* 

[engine/Source/Scene/Cesium3DTilePointFeature.js 760](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L760) 

 Returns a copy of the value of the feature's property with the given name. This includes properties from this feature's class and inherited classes when using a batch table hierarchy.

| Name | Type   | Description                              |
| ---- | ------ | ---------------------------------------- |
| name | string | The case-sensitive name of the property. |

##### Returns:

 The value of the property or `undefined` if the feature does not have this property.

##### Example:

```javascript
// Display all the properties for a feature in the console log.
const propertyIds = feature.getPropertyIds();
const length = propertyIds.length;
for (let i = 0; i < length; ++i) {
    const propertyId = propertyIds[i];
    console.log(`{propertyId} : ${feature.getProperty(propertyId)}`);
}
```

##### See:

* <https://github.com/CesiumGS/3d-tiles/tree/main/extensions/3DTILES%5Fbatch%5Ftable%5Fhierarchy>

#### [](#getPropertyIds) getPropertyIds(results) → Array.<string> 

[engine/Source/Scene/Cesium3DTilePointFeature.js 738](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L738) 

 Returns an array of property IDs for the feature. This includes properties from this feature's class and inherited classes when using a batch table hierarchy.

| Name    | Type           | Description                                        |
| ------- | -------------- | -------------------------------------------------- |
| results | Array.<string> | optional An array into which to store the results. |

##### Returns:

 The IDs of the feature's properties.

##### See:

* <https://github.com/CesiumGS/3d-tiles/tree/main/extensions/3DTILES%5Fbatch%5Ftable%5Fhierarchy>

#### [](#hasProperty) hasProperty(name) → boolean 

[engine/Source/Scene/Cesium3DTilePointFeature.js 725](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L725) 

 Returns whether the feature contains this property. This includes properties from this feature's class and inherited classes when using a batch table hierarchy.

| Name | Type   | Description                              |
| ---- | ------ | ---------------------------------------- |
| name | string | The case-sensitive name of the property. |

##### Returns:

 Whether the feature contains this property.

##### See:

* <https://github.com/CesiumGS/3d-tiles/tree/main/extensions/3DTILES%5Fbatch%5Ftable%5Fhierarchy>

#### [](#setProperty) setProperty(name, value) 

[engine/Source/Scene/Cesium3DTilePointFeature.js 811](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTilePointFeature.js#L811) 

 Sets the value of the feature's property with the given name.

If a property with the given name doesn't exist, it is created.

| Name  | Type   | Description                                    |
| ----- | ------ | ---------------------------------------------- |
| name  | string | The case-sensitive name of the property.       |
| value | \*     | The value of the property that will be copied. |

##### Throws:

* [DeveloperError](DeveloperError.html): Inherited batch table hierarchy property is read only.

##### Examples:

```javascript
const height = feature.getProperty('Height'); // e.g., the height of a building
```

```javascript
const name = 'clicked';
if (feature.getProperty(name)) {
    console.log('already clicked');
} else {
    feature.setProperty(name, true);
    console.log('first click');
}
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

