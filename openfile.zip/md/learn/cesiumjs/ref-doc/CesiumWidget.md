# [![](Images/CesiumLogo.png)](index.html) CesiumWidget 

#### [](#CesiumWidget) new Cesium.CesiumWidget(container, options) 

[engine/Source/Widget/CesiumWidget.js 206](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L206) 

 A widget containing a Cesium scene.

| Name      | Type            | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| --------- | --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| container | Element\|string | The DOM element or ID that will contain the widget.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| options   | object          | optional Object with the following properties: Name Type Default Description clock [Clock](Clock.html) new Clock() optional The clock to use to control current time. shouldAnimate boolean false optional true if the clock should attempt to advance simulation time by default, false otherwise. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The default ellipsoid. baseLayer [ImageryLayer](ImageryLayer.html)\|false ImageryLayer.fromWorldImagery() optional The bottommost imagery layer applied to the globe. If set to false, no imagery provider will be added. terrainProvider [TerrainProvider](TerrainProvider.html) new EllipsoidTerrainProvider(options.ellipsoid) optional The terrain provider. terrain [Terrain](Terrain.html) optional A terrain object which handles asynchronous terrain provider. Can only specify if options.terrainProvider is undefined. skyBox [SkyBox](SkyBox.html)|false optional The skybox used to render the stars. When undefined and the WGS84 ellipsoid used, the default stars are used. If set to false, no skyBox, Sun, or Moon will be added. skyAtmosphere [SkyAtmosphere](SkyAtmosphere.html)|false optional Blue sky, and the glow around the Earth's limb. Enabled when the default ellipsoid used. Set to false to turn it off. sceneMode [SceneMode](global.html#SceneMode) SceneMode.SCENE3D optional The initial scene mode. scene3DOnly boolean false optional When true, each geometry instance will only be rendered in 3D to save GPU memory. orderIndependentTranslucency boolean true optional If true and the configuration supports it, use order independent translucency. mapProjection [MapProjection](MapProjection.html) new GeographicProjection(options.ellipsoid) optional The map projection to use in 2D and Columbus View modes. globe [Globe](Globe.html)|false new Globe(options.ellipsoid) optional The globe to use in the scene. If set to false, no globe will be added and the sky atmosphere will be hidden by default. useDefaultRenderLoop boolean true optional True if this widget should control the render loop, false otherwise. useBrowserRecommendedResolution boolean true optional If true, render at the browser's recommended resolution and ignore window.devicePixelRatio. targetFrameRate number optional The target frame rate when using the default render loop. showRenderLoopErrors boolean true optional If true, this widget will automatically display an HTML panel to the user containing the error, if a render loop error occurs. automaticallyTrackDataSourceClocks boolean true optional If true, this widget will automatically track the clock settings of newly added DataSources, updating if the DataSource's clock changes. Set this to false if you want to configure the clock independently. contextOptions [ContextOptions](global.html#ContextOptions) optional Context and WebGL creation properties passed to [Scene](Scene.html). creditContainer Element|string optional The DOM element or ID that will contain the [CreditDisplay](CreditDisplay.html). If not specified, the credits are added to the bottom of the widget itself. creditViewport Element|string optional The DOM element or ID that will contain the credit pop up created by the [CreditDisplay](CreditDisplay.html). If not specified, it will appear over the widget itself. dataSources [DataSourceCollection](DataSourceCollection.html) new DataSourceCollection() optional The collection of data sources visualized by the widget. If this parameter is provided, the instance is assumed to be owned by the caller and will not be destroyed when the widget is destroyed. shadows boolean false optional Determines if shadows are cast by light sources. terrainShadows [ShadowMode](global.html#ShadowMode) ShadowMode.RECEIVE\_ONLY optional Determines if the terrain casts or receives shadows from light sources. mapMode2D [MapMode2D](global.html#MapMode2D) MapMode2D.INFINITE\_SCROLL optional Determines if the 2D map is rotatable or can be scrolled infinitely in the horizontal direction. blurActiveElementOnCanvasFocus boolean true optional If true, the active element will blur when the widget's canvas is clicked. Setting this to false is useful for cases when the canvas is clicked only for retrieving position or an entity data without actually meaning to set the canvas to be the active element. requestRenderMode boolean false optional If true, rendering a frame will only occur when needed as determined by changes within the scene. Enabling improves performance of the application, but requires using [Scene#requestRender](Scene.html#requestRender) to render a new frame explicitly in this mode. This will be necessary in many cases after making changes to the scene in other parts of the API. See [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/). maximumRenderTimeChange number 0.0 optional If requestRenderMode is true, this value defines the maximum change in simulation time allowed before a render is requested. See [Improving Performance with Explicit Rendering](https://cesium.com/blog/2018/01/24/cesium-scene-rendering-performance/). msaaSamples number 4 optional If provided, this value controls the rate of multisample antialiasing. Typical multisampling rates are 2, 4, and sometimes 8 samples per pixel. Higher sampling rates of MSAA may impact performance in exchange for improved visual quality. This value only applies to WebGL2 contexts that support multisample render targets. Set to 1 to disable MSAA. |

##### Throws:

* [DeveloperError](DeveloperError.html): Element with id "container" does not exist in the document.

##### Example:

```javascript
// For each example, include a link to CesiumWidget.css stylesheet in HTML head,
// and in the body, include: <div id="cesiumContainer"></div>

// Widget with no terrain and default Bing Maps imagery provider.
const widget = new Cesium.CesiumWidget("cesiumContainer");

// Widget with ion imagery and Cesium World Terrain.
const widget2 = new Cesium.CesiumWidget("cesiumContainer", {
    baseLayer: Cesium.ImageryLayer.fromWorldTerrain(),
    terrain: Cesium.Terrain.fromWorldTerrain()
    skyBox: new Cesium.SkyBox({
      sources: {
        positiveX: "stars/TychoSkymapII.t3_08192x04096_80_px.jpg",
        negativeX: "stars/TychoSkymapII.t3_08192x04096_80_mx.jpg",
        positiveY: "stars/TychoSkymapII.t3_08192x04096_80_py.jpg",
        negativeY: "stars/TychoSkymapII.t3_08192x04096_80_my.jpg",
        positiveZ: "stars/TychoSkymapII.t3_08192x04096_80_pz.jpg",
        negativeZ: "stars/TychoSkymapII.t3_08192x04096_80_mz.jpg"
      }
    }),
    // Show Columbus View map with Web Mercator projection
    sceneMode: Cesium.SceneMode.COLUMBUS_VIEW,
    mapProjection: new Cesium.WebMercatorProjection()
});
```

##### Demo:

* [Cesium Sandcastle Cesium Widget Demo](https://sandcastle.cesium.com/index.html?src=Cesium%2520Widget.html)

### Members

#### [](#allowDataSourcesToSuspendAnimation) allowDataSourcesToSuspendAnimation : boolean 

[engine/Source/Widget/CesiumWidget.js 821](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L821) 

 Gets or sets whether or not data sources can temporarily pause animation in order to avoid showing an incomplete picture to the user. For example, if asynchronous primitives are being processed in the background, the clock will not advance until the geometry is ready.

#### [](#camera) readonly camera : [Camera](Camera.html) 

[engine/Source/Widget/CesiumWidget.js 660](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L660) 

 Gets the camera.

#### [](#canvas) readonly canvas : HTMLCanvasElement 

[engine/Source/Widget/CesiumWidget.js 531](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L531) 

 Gets the canvas.

#### [](#clock) readonly clock : [Clock](Clock.html) 

[engine/Source/Widget/CesiumWidget.js 686](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L686) 

 Gets the clock.

#### [](#clockTrackedDataSource) clockTrackedDataSource : [DataSource](DataSource.html) 

[engine/Source/Widget/CesiumWidget.js 897](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L897) 

 Gets or sets the data source to track with the widget's clock.

#### [](#container) readonly container : Element 

[engine/Source/Widget/CesiumWidget.js 518](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L518) 

 Gets the parent container.

#### [](#creditContainer) readonly creditContainer : Element 

[engine/Source/Widget/CesiumWidget.js 544](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L544) 

 Gets the credit container.

#### [](#creditDisplay) creditDisplay : [CreditDisplay](CreditDisplay.html) 

[engine/Source/Widget/CesiumWidget.js 610](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L610) 

 Manages the list of credits to display on screen and in the lightbox.

#### [](#creditViewport) readonly creditViewport : Element 

[engine/Source/Widget/CesiumWidget.js 557](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L557) 

 Gets the credit viewport

#### [](#dataSourceDisplay) readonly dataSourceDisplay : [DataSourceDisplay](DataSourceDisplay.html) 

[engine/Source/Widget/CesiumWidget.js 622](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L622) 

 Gets the display used for [DataSource](DataSource.html) visualization.

#### [](#dataSources) readonly dataSources : [DataSourceCollection](DataSourceCollection.html) 

[engine/Source/Widget/CesiumWidget.js 647](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L647) 

 Gets the set of [DataSource](DataSource.html) instances to be visualized.

#### [](#ellipsoid) readonly ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Widget/CesiumWidget.js 673](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L673) 

 Gets the default ellipsoid for the scene.

#### [](#entities) readonly entities : [EntityCollection](EntityCollection.html) 

[engine/Source/Widget/CesiumWidget.js 635](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L635) 

 Gets the collection of entities not tied to a particular data source. This is a shortcut to [dataSourceDisplay.defaultDataSource.entities](CesiumWidget.html#dataSourceDisplay).

#### [](#imageryLayers) readonly imageryLayers : [ImageryLayerCollection](ImageryLayerCollection.html) 

[engine/Source/Widget/CesiumWidget.js 583](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L583) 

 Gets the collection of image layers that will be rendered on the globe.

#### [](#resolutionScale) resolutionScale : number 

[engine/Source/Widget/CesiumWidget.js 770](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L770) 

 Gets or sets a scaling factor for rendering resolution. Values less than 1.0 can improve performance on less powerful devices while values greater than 1.0 will render at a higher resolution and then scale down, resulting in improved visual fidelity. For example, if the widget is laid out at a size of 640x480, setting this value to 0.5 will cause the scene to be rendered at 320x240 and then scaled up while setting it to 2.0 will cause the scene to be rendered at 1280x960 and then scaled down.

Default Value: `1.0` 

#### [](#scene) readonly scene : [Scene](Scene.html) 

[engine/Source/Widget/CesiumWidget.js 570](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L570) 

 Gets the scene.

#### [](#screenSpaceEventHandler) readonly screenSpaceEventHandler : [ScreenSpaceEventHandler](ScreenSpaceEventHandler.html) 

[engine/Source/Widget/CesiumWidget.js 699](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L699) 

 Gets the screen space event handler.

#### [](#targetFrameRate) targetFrameRate : number 

[engine/Source/Widget/CesiumWidget.js 714](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L714) 

 Gets or sets the target frame rate of the widget when `useDefaultRenderLoop`is true. If undefined, the browser's requestAnimationFrame implementation determines the frame rate. If defined, this value must be greater than 0\. A value higher than the underlying requestAnimationFrame implementation will have no effect.

#### [](#terrainProvider) terrainProvider : [TerrainProvider](TerrainProvider.html) 

[engine/Source/Widget/CesiumWidget.js 595](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L595) 

 The terrain provider providing surface geometry for the globe.

#### [](#trackedEntity) trackedEntity : [Entity](Entity.html)|undefined 

[engine/Source/Widget/CesiumWidget.js 835](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L835) 

 Gets or sets the Entity instance currently being tracked by the camera.

#### [](#trackedEntityChanged) readonly trackedEntityChanged : [Event](Event.html) 

[engine/Source/Widget/CesiumWidget.js 886](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L886) 

 Gets the event that is raised when the tracked entity changes.

#### [](#useBrowserRecommendedResolution) useBrowserRecommendedResolution : boolean 

[engine/Source/Widget/CesiumWidget.js 799](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L799) 

 Boolean flag indicating if the browser's recommended resolution is used. If true, the browser's device pixel ratio is ignored and 1.0 is used instead, effectively rendering based on CSS pixels instead of device pixels. This can improve performance on less powerful devices that have high pixel density. When false, rendering will be in device pixels. [CesiumWidget#resolutionScale](CesiumWidget.html#resolutionScale) will still take effect whether this flag is true or false.

Default Value: `true` 

#### [](#useDefaultRenderLoop) useDefaultRenderLoop : boolean 

[engine/Source/Widget/CesiumWidget.js 744](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L744) 

 Gets or sets whether or not this widget should control the render loop. If true the widget will use requestAnimationFrame to perform rendering and resizing of the widget, as well as drive the simulation clock. If set to false, you must manually call the`resize`, `render` methods as part of a custom render loop. If an error occurs during rendering, [Scene](Scene.html)'s`renderError` event will be raised and this property will be set to false. It must be set back to true to continue rendering after the error.

### Methods

#### [](#destroy) destroy() 

[engine/Source/Widget/CesiumWidget.js 1030](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L1030) 

 Destroys the widget. Should be called if permanently removing the widget from layout.

#### [](#flyTo) flyTo(target, options) → Promise.<boolean> 

[engine/Source/Widget/CesiumWidget.js 1285](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L1285) 

 Flies the camera to the provided entity, entities, or data source. If the data source is still in the process of loading or the visualization is otherwise still loading, this method waits for the data to be ready before performing the flight.

The offset is heading/pitch/range in the local east-north-up reference frame centered at the center of the bounding sphere. The heading and the pitch angles are defined in the local east-north-up reference frame. The heading is the angle from y axis and increasing towards the x axis. Pitch is the rotation from the xy-plane. Positive pitch angles are above the plane. Negative pitch angles are below the plane. The range is the distance from the center. If the range is zero, a range will be computed such that the whole bounding sphere is visible.

In 2D, there must be a top down view. The camera will be placed above the target looking down. The height above the target will be the range. The heading will be determined from the offset. If the heading cannot be determined from the offset, the heading will be north.

| Name    | Type                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Description                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| target  | [Entity](Entity.html)\|Array.<[Entity](Entity.html)\>|[EntityCollection](EntityCollection.html)|[DataSource](DataSource.html)|[ImageryLayer](ImageryLayer.html)|[Cesium3DTileset](Cesium3DTileset.html)|[TimeDynamicPointCloud](TimeDynamicPointCloud.html)|Promise.<([Entity](Entity.html)|Array.<[Entity](Entity.html)\>|[EntityCollection](EntityCollection.html)|[DataSource](DataSource.html)|[ImageryLayer](ImageryLayer.html)|[Cesium3DTileset](Cesium3DTileset.html)|[TimeDynamicPointCloud](TimeDynamicPointCloud.html)|[VoxelPrimitive](VoxelPrimitive.html))> | The entity, array of entities, entity collection, data source, Cesium3DTileset, point cloud, or imagery layer to view. You can also pass a promise that resolves to one of the previously mentioned types.                                                                                                                                                                             |
| options | object                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | optional Object with the following properties: Name Type Default Description duration number 3.0 optional The duration of the flight in seconds. maximumHeight number optional The maximum height at the peak of the flight. offset [HeadingPitchRange](HeadingPitchRange.html) optional The offset from the target in the local east-north-up reference frame centered at the target. |

##### Returns:

 A Promise that resolves to true if the flight was successful or false if the target is not currently visualized in the scene or the flight was cancelled. //TODO: Cleanup entity mentions

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Widget/CesiumWidget.js 1022](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L1022) 

##### Returns:

 true if the object has been destroyed, false otherwise.

#### [](#render) render() 

[engine/Source/Widget/CesiumWidget.js 1084](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L1084) 

 Renders the scene. This function is called automatically unless `useDefaultRenderLoop` is set to false;

#### [](#resize) resize() 

[engine/Source/Widget/CesiumWidget.js 1062](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L1062) 

 Updates the canvas size, camera aspect ratio, and viewport size. This function is called automatically as needed unless`useDefaultRenderLoop` is set to false.

#### [](#showErrorPanel) showErrorPanel(title, message, error) 

[engine/Source/Widget/CesiumWidget.js 920](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L920) 

 Show an error panel to the user containing a title and a longer error message, which can be dismissed using an OK button. This panel is displayed automatically when a render loop error occurs, if showRenderLoopErrors was not false when the widget was constructed.

| Name    | Type   | Description                                                                                                                                              |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| title   | string | The title to be displayed on the error panel. This string is interpreted as text.                                                                        |
| message | string | optional A helpful, user-facing message to display prior to the detailed error information. This string is interpreted as HTML.                          |
| error   | string | optional The error to be displayed on the error panel. This string is formatted using [formatError](global.html#formatError) and then displayed as text. |

#### [](#zoomTo) zoomTo(target, offset) → Promise.<boolean> 

[engine/Source/Widget/CesiumWidget.js 1256](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Widget/CesiumWidget.js#L1256) 

 Asynchronously sets the camera to view the provided entity, entities, or data source. If the data source is still in the process of loading or the visualization is otherwise still loading, this method waits for the data to be ready before performing the zoom.

The offset is heading/pitch/range in the local east-north-up reference frame centered at the center of the bounding sphere. The heading and the pitch angles are defined in the local east-north-up reference frame. The heading is the angle from y axis and increasing towards the x axis. Pitch is the rotation from the xy-plane. Positive pitch angles are above the plane. Negative pitch angles are below the plane. The range is the distance from the center. If the range is zero, a range will be computed such that the whole bounding sphere is visible.

In 2D, there must be a top down view. The camera will be placed above the target looking down. The height above the target will be the range. The heading will be determined from the offset. If the heading cannot be determined from the offset, the heading will be north.

| Name   | Type                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Description                                                                                                                                                                                                |
| ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| target | [Entity](Entity.html)\|Array.<[Entity](Entity.html)\>|[EntityCollection](EntityCollection.html)|[DataSource](DataSource.html)|[ImageryLayer](ImageryLayer.html)|[Cesium3DTileset](Cesium3DTileset.html)|[TimeDynamicPointCloud](TimeDynamicPointCloud.html)|Promise.<([Entity](Entity.html)|Array.<[Entity](Entity.html)\>|[EntityCollection](EntityCollection.html)|[DataSource](DataSource.html)|[ImageryLayer](ImageryLayer.html)|[Cesium3DTileset](Cesium3DTileset.html)|[TimeDynamicPointCloud](TimeDynamicPointCloud.html)|[VoxelPrimitive](VoxelPrimitive.html))> | The entity, array of entities, entity collection, data source, Cesium3DTileset, point cloud, or imagery layer to view. You can also pass a promise that resolves to one of the previously mentioned types. |
| offset | [HeadingPitchRange](HeadingPitchRange.html)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | optional The offset from the center of the entity in the local east-north-up reference frame.                                                                                                              |

##### Returns:

 A Promise that resolves to true if the zoom was successful or false if the target is not currently visualized in the scene or the zoom was cancelled.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

