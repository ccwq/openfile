# [![](Images/CesiumLogo.png)](index.html) Plane 

#### [](#Plane) new Cesium.Plane(normal, distance) 

[engine/Source/Core/Plane.js 34](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L34) 

 A plane in Hessian Normal Form defined by


ax + by + cz + d = 0

where (a, b, c) is the plane's `normal`, d is the signed`distance` to the plane, and (x, y, z) is any point on the plane.

| Name     | Type                          | Description                                                                                                                                                                                                                                                                                                                              |
| -------- | ----------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| normal   | [Cartesian3](Cartesian3.html) | The plane's normal (normalized).                                                                                                                                                                                                                                                                                                         |
| distance | number                        | The shortest distance from the origin to the plane. The sign ofdistance determines which side of the plane the origin is on. If distance is positive, the origin is in the half-space in the direction of the normal; if negative, the origin is in the half-space opposite to the normal; if zero, the plane passes through the origin. |

##### Throws:

* [DeveloperError](DeveloperError.html): Normal must be normalized

##### Example:

```javascript
// The plane x=0
const plane = new Cesium.Plane(Cesium.Cartesian3.UNIT_X, 0.0);
```

### Members

#### [](#.ORIGIN%5FXY%5FPLANE) static constant Cesium.Plane.ORIGIN\_XY\_PLANE : [Plane](Plane.html) 

[engine/Source/Core/Plane.js 295](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L295) 

 A constant initialized to the XY plane passing through the origin, with normal in positive Z.

#### [](#.ORIGIN%5FYZ%5FPLANE) static constant Cesium.Plane.ORIGIN\_YZ\_PLANE : [Plane](Plane.html) 

[engine/Source/Core/Plane.js 303](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L303) 

 A constant initialized to the YZ plane passing through the origin, with normal in positive X.

#### [](#.ORIGIN%5FZX%5FPLANE) static constant Cesium.Plane.ORIGIN\_ZX\_PLANE : [Plane](Plane.html) 

[engine/Source/Core/Plane.js 311](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L311) 

 A constant initialized to the ZX plane passing through the origin, with normal in positive Y.

#### [](#distance) distance : number 

[engine/Source/Core/Plane.js 65](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L65) 

 The shortest distance from the origin to the plane. The sign of`distance` determines which side of the plane the origin is on. If `distance` is positive, the origin is in the half-space in the direction of the normal; if negative, the origin is in the half-space opposite to the normal; if zero, the plane passes through the origin.

#### [](#normal) normal : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Plane.js 54](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L54) 

 The plane's normal.

### Methods

#### [](#.clone) static Cesium.Plane.clone(plane, result) → [Plane](Plane.html) 

[engine/Source/Core/Plane.js 254](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L254) 

 Duplicates a Plane instance.

| Name   | Type                | Description                                         |
| ------ | ------------------- | --------------------------------------------------- |
| plane  | [Plane](Plane.html) | The plane to duplicate.                             |
| result | [Plane](Plane.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Plane instance if one was not provided.

#### [](#.equals) static Cesium.Plane.equals(left, right) → boolean 

[engine/Source/Core/Plane.js 277](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L277) 

 Compares the provided Planes by normal and distance and returns`true` if they are equal, `false` otherwise.

| Name  | Type                | Description       |
| ----- | ------------------- | ----------------- |
| left  | [Plane](Plane.html) | The first plane.  |
| right | [Plane](Plane.html) | The second plane. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.fromCartesian4) static Cesium.Plane.fromCartesian4(coefficients, result) → [Plane](Plane.html) 

[engine/Source/Core/Plane.js 119](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L119) 

 Creates a plane from the general equation

| Name         | Type                          | Description                                         |
| ------------ | ----------------------------- | --------------------------------------------------- |
| coefficients | [Cartesian4](Cartesian4.html) | The plane's normal (normalized).                    |
| result       | [Plane](Plane.html)           | optional The object onto which to store the result. |

##### Returns:

 A new plane instance or the modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): Normal must be normalized

#### [](#.fromPointNormal) static Cesium.Plane.fromPointNormal(point, normal, result) → [Plane](Plane.html) 

[engine/Source/Core/Plane.js 83](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L83) 

 Creates a plane from a normal and a point on the plane.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| point  | [Cartesian3](Cartesian3.html) | The point on the plane.                             |
| normal | [Cartesian3](Cartesian3.html) | The plane's normal (normalized).                    |
| result | [Plane](Plane.html)           | optional The object onto which to store the result. |

##### Returns:

 A new plane instance or the modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): Normal must be normalized

##### Example:

```javascript
const point = Cesium.Cartesian3.fromDegrees(-72.0, 40.0);
const normal = ellipsoid.geodeticSurfaceNormal(point);
const tangentPlane = Cesium.Plane.fromPointNormal(point, normal);
```

#### [](#.getPointDistance) static Cesium.Plane.getPointDistance(plane, point) → number 

[engine/Source/Core/Plane.js 158](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L158) 

 Computes the signed shortest distance of a point to a plane. The sign of the distance determines which side of the plane the point is on. If the distance is positive, the point is in the half-space in the direction of the normal; if negative, the point is in the half-space opposite to the normal; if zero, the plane passes through the point.

| Name  | Type                          | Description |
| ----- | ----------------------------- | ----------- |
| plane | [Plane](Plane.html)           | The plane.  |
| point | [Cartesian3](Cartesian3.html) | The point.  |

##### Returns:

 The signed shortest distance of the point to the plane.

#### [](#.projectPointOntoPlane) static Cesium.Plane.projectPointOntoPlane(plane, point, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Plane.js 175](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L175) 

 Projects a point onto the plane.

| Name   | Type                          | Description                                                                |
| ------ | ----------------------------- | -------------------------------------------------------------------------- |
| plane  | [Plane](Plane.html)           | The plane to project the point onto                                        |
| point  | [Cartesian3](Cartesian3.html) | The point to project onto the plane                                        |
| result | [Cartesian3](Cartesian3.html) | optional The result point. If undefined, a new Cartesian3 will be created. |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if one was not provided.

#### [](#.transform) static Cesium.Plane.transform(plane, transform, result) → [Plane](Plane.html) 

[engine/Source/Core/Plane.js 207](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Plane.js#L207) 

 Transforms the plane by the given transformation matrix.

| Name      | Type                    | Description                                         |
| --------- | ----------------------- | --------------------------------------------------- |
| plane     | [Plane](Plane.html)     | The plane.                                          |
| transform | [Matrix4](Matrix4.html) | The transformation matrix.                          |
| result    | [Plane](Plane.html)     | optional The object into which to store the result. |

##### Returns:

 The plane transformed by the given transformation matrix.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

