# [![](Images/CesiumLogo.png)](index.html) Occluder 

#### [](#Occluder) new Cesium.Occluder(occluderBoundingSphere, cameraPosition) 

[engine/Source/Core/Occluder.js 29](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Occluder.js#L29) 

 Creates an Occluder derived from an object's position and radius, as well as the camera position. The occluder can be used to determine whether or not other objects are visible or hidden behind the visible horizon defined by the occluder and camera position.

| Name                   | Type                                  | Description                                   |
| ---------------------- | ------------------------------------- | --------------------------------------------- |
| occluderBoundingSphere | [BoundingSphere](BoundingSphere.html) | The bounding sphere surrounding the occluder. |
| cameraPosition         | [Cartesian3](Cartesian3.html)         | The coordinate of the viewer/camera.          |

##### Example:

```javascript
// Construct an occluder one unit away from the origin with a radius of one.
const cameraPosition = Cesium.Cartesian3.ZERO;
const occluderBoundingSphere = new Cesium.BoundingSphere(new Cesium.Cartesian3(0, 0, -1), 1);
const occluder = new Cesium.Occluder(occluderBoundingSphere, cameraPosition);
```

### Members

#### [](#cameraPosition) cameraPosition : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Occluder.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Occluder.js#L81) 

 The position of the camera.

#### [](#position) position : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Occluder.js 59](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Occluder.js#L59) 

 The position of the occluder.

#### [](#radius) radius : number 

[engine/Source/Core/Occluder.js 70](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Occluder.js#L70) 

 The radius of the occluder.

### Methods

#### [](#.computeOccludeePoint) static Cesium.Occluder.computeOccludeePoint(occluderBoundingSphere, occludeePosition, positions) → object 

[engine/Source/Core/Occluder.js 404](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Occluder.js#L404) 

 Computes a point that can be used as the occludee position to the visibility functions. Use a radius of zero for the occludee radius. Typically, a user computes a bounding sphere around an object that is used for visibility; however it is also possible to compute a point that if seen/not seen would also indicate if an object is visible/not visible. This function is better called for objects that do not move relative to the occluder and is large, such as a chunk of terrain. You are better off not calling this and using the object's bounding sphere for objects such as a satellite or ground vehicle.

| Name                   | Type                                   | Description                                                              |
| ---------------------- | -------------------------------------- | ------------------------------------------------------------------------ |
| occluderBoundingSphere | [BoundingSphere](BoundingSphere.html)  | The bounding sphere surrounding the occluder.                            |
| occludeePosition       | [Cartesian3](Cartesian3.html)          | The point where the occludee (bounding sphere of radius 0) is located.   |
| positions              | Array.<[Cartesian3](Cartesian3.html)\> | List of altitude points on the horizon near the surface of the occluder. |

##### Returns:

 An object containing two attributes: `occludeePoint` and `valid`which is a boolean value.

##### Throws:

* [DeveloperError](DeveloperError.html): `positions` must contain at least one element.
* [DeveloperError](DeveloperError.html): `occludeePosition` must have a value other than `occluderBoundingSphere.center`.

##### Example:

```javascript
const cameraPosition = new Cesium.Cartesian3(0, 0, 0);
const occluderBoundingSphere = new Cesium.BoundingSphere(new Cesium.Cartesian3(0, 0, -8), 2);
const occluder = new Cesium.Occluder(occluderBoundingSphere, cameraPosition);
const positions = [new Cesium.Cartesian3(-0.25, 0, -5.3), new Cesium.Cartesian3(0.25, 0, -5.3)];
const tileOccluderSphere = Cesium.BoundingSphere.fromPoints(positions);
const occludeePosition = tileOccluderSphere.center;
const occludeePt = Cesium.Occluder.computeOccludeePoint(occluderBoundingSphere, occludeePosition, positions);
```

#### [](#.computeOccludeePointFromRectangle) static Cesium.Occluder.computeOccludeePointFromRectangle(rectangle, ellipsoid) → object 

[engine/Source/Core/Occluder.js 503](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Occluder.js#L503) 

 Computes a point that can be used as the occludee position to the visibility functions from a rectangle.

| Name      | Type                        | Default           | Description                                                          |
| --------- | --------------------------- | ----------------- | -------------------------------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html) |                   | The rectangle used to create a bounding sphere.                      |
| ellipsoid | [Ellipsoid](Ellipsoid.html) | Ellipsoid.default | optional The ellipsoid used to determine positions of the rectangle. |

##### Returns:

 An object containing two attributes: `occludeePoint` and `valid`which is a boolean value.

#### [](#.fromBoundingSphere) static Cesium.Occluder.fromBoundingSphere(occluderBoundingSphere, cameraPosition, result) → [Occluder](Occluder.html) 

[engine/Source/Core/Occluder.js 145](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Occluder.js#L145) 

 Creates an occluder from a bounding sphere and the camera position.

| Name                   | Type                                  | Description                                         |
| ---------------------- | ------------------------------------- | --------------------------------------------------- |
| occluderBoundingSphere | [BoundingSphere](BoundingSphere.html) | The bounding sphere surrounding the occluder.       |
| cameraPosition         | [Cartesian3](Cartesian3.html)         | The coordinate of the viewer/camera.                |
| result                 | [Occluder](Occluder.html)             | optional The object onto which to store the result. |

##### Returns:

 The occluder derived from an object's position and radius, as well as the camera position.

#### [](#computeVisibility) computeVisibility(occludeeBS) → [Visibility](global.html#Visibility) 

[engine/Source/Core/Occluder.js 304](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Occluder.js#L304) 

 Determine to what extent an occludee is visible (not visible, partially visible, or fully visible).

| Name       | Type                                  | Description                          |
| ---------- | ------------------------------------- | ------------------------------------ |
| occludeeBS | [BoundingSphere](BoundingSphere.html) | The bounding sphere of the occludee. |

##### Returns:

 Visibility.NONE if the occludee is not visible, Visibility.PARTIAL if the occludee is partially visible, or Visibility.FULL if the occludee is fully visible.

##### Example:

```javascript
const sphere1 = new Cesium.BoundingSphere(new Cesium.Cartesian3(0, 0, -1.5), 0.5);
const sphere2 = new Cesium.BoundingSphere(new Cesium.Cartesian3(0, 0, -2.5), 0.5);
const cameraPosition = new Cesium.Cartesian3(0, 0, 0);
const occluder = new Cesium.Occluder(sphere1, cameraPosition);
occluder.computeVisibility(sphere2); //returns Visibility.NONE
```

#### [](#isBoundingSphereVisible) isBoundingSphereVisible(occludee) → boolean 

[engine/Source/Core/Occluder.js 225](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Occluder.js#L225) 

 Determines whether or not a sphere, the `occludee`, is hidden from view by the occluder.

| Name     | Type                                  | Description                                          |
| -------- | ------------------------------------- | ---------------------------------------------------- |
| occludee | [BoundingSphere](BoundingSphere.html) | The bounding sphere surrounding the occludee object. |

##### Returns:

`true` if the occludee is visible; otherwise `false`.

##### Example:

```javascript
const cameraPosition = new Cesium.Cartesian3(0, 0, 0);
const littleSphere = new Cesium.BoundingSphere(new Cesium.Cartesian3(0, 0, -1), 0.25);
const occluder = new Cesium.Occluder(littleSphere, cameraPosition);
const bigSphere = new Cesium.BoundingSphere(new Cesium.Cartesian3(0, 0, -3), 1);
occluder.isBoundingSphereVisible(bigSphere); //returns true
```

##### See:

* [Occluder#computeVisibility](Occluder.html#computeVisibility)

#### [](#isPointVisible) isPointVisible(occludee) → boolean 

[engine/Source/Core/Occluder.js 189](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Occluder.js#L189) 

 Determines whether or not a point, the `occludee`, is hidden from view by the occluder.

| Name     | Type                          | Description                                |
| -------- | ----------------------------- | ------------------------------------------ |
| occludee | [Cartesian3](Cartesian3.html) | The point surrounding the occludee object. |

##### Returns:

`true` if the occludee is visible; otherwise `false`.

##### Example:

```javascript
const cameraPosition = new Cesium.Cartesian3(0, 0, 0);
const littleSphere = new Cesium.BoundingSphere(new Cesium.Cartesian3(0, 0, -1), 0.25);
const occluder = new Cesium.Occluder(littleSphere, cameraPosition);
const point = new Cesium.Cartesian3(0, 0, -3);
occluder.isPointVisible(point); //returns true
```

##### See:

* [Occluder#computeVisibility](Occluder.html#computeVisibility)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

