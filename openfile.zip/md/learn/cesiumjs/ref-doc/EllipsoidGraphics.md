# [![](Images/CesiumLogo.png)](index.html) EllipsoidGraphics 

#### [](#EllipsoidGraphics) new Cesium.EllipsoidGraphics(options) 

[engine/Source/DataSources/EllipsoidGraphics.js 43](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L43) 

 Describe an ellipsoid or sphere. The center position and orientation are determined by the containing [Entity](Entity.html).

| Name    | Type                                                                               | Description                                       |
| ------- | ---------------------------------------------------------------------------------- | ------------------------------------------------- |
| options | [EllipsoidGraphics.ConstructorOptions](EllipsoidGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle Spheres and Ellipsoids Demo](https://sandcastle.cesium.com/index.html?src=Spheres%2520and%2520Ellipsoids.html)

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/EllipsoidGraphics.js 93](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L93) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 243](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L243) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this ellipsoid will be displayed.

#### [](#fill) fill : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L168) 

 Gets or sets the boolean Property specifying whether the ellipsoid is filled with the provided material.

Default Value: `true` 

#### [](#heightReference) heightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 160](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L160) 

 Gets or sets the Property specifying the [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#innerRadii) innerRadii : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L120) 

 Gets or sets the [Cartesian3](Cartesian3.html) [Property](Property.html) specifying the inner radii of the ellipsoid.

Default Value: `radii` 

#### [](#material) material : [MaterialProperty](MaterialProperty.html) 

[engine/Source/DataSources/EllipsoidGraphics.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L176) 

 Gets or sets the Property specifying the material used to fill the ellipsoid.

Default Value: `Color.WHITE` 

#### [](#maximumClock) maximumClock : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 136](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L136) 

 Gets or sets the Property specifying the maximum clock angle of the ellipsoid.

Default Value: `2*PI` 

#### [](#maximumCone) maximumCone : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 152](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L152) 

 Gets or sets the Property specifying the maximum cone angle of the ellipsoid.

Default Value: `PI` 

#### [](#minimumClock) minimumClock : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 128](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L128) 

 Gets or sets the Property specifying the minimum clock angle of the ellipsoid.

Default Value: `0.0` 

#### [](#minimumCone) minimumCone : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L144) 

 Gets or sets the Property specifying the minimum cone angle of the ellipsoid.

Default Value: `0.0` 

#### [](#outline) outline : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 184](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L184) 

 Gets or sets the Property specifying whether the ellipsoid is outlined.

Default Value: `false` 

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 192](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L192) 

 Gets or sets the Property specifying the [Color](Color.html) of the outline.

Default Value: `Color.BLACK` 

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 203](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L203) 

 Gets or sets the numeric Property specifying the width of the outline.

Note: This property will be ignored on all major browsers on Windows platforms. For details, see (@link https://github.com/CesiumGS/cesium/issues/40}.

Default Value: `1.0` 

#### [](#radii) radii : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 112](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L112) 

 Gets or sets the [Cartesian3](Cartesian3.html) [Property](Property.html) specifying the radii of the ellipsoid.

#### [](#shadows) shadows : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 236](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L236) 

 Get or sets the enum Property specifying whether the ellipsoid casts or receives shadows from light sources.

Default Value: `ShadowMode.DISABLED` 

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 105](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L105) 

 Gets or sets the boolean Property specifying the visibility of the ellipsoid.

Default Value: `true` 

#### [](#slicePartitions) slicePartitions : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 219](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L219) 

 Gets or sets the Property specifying the number of radial slices per 360 degrees.

Default Value: `64` 

#### [](#stackPartitions) stackPartitions : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 211](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L211) 

 Gets or sets the Property specifying the number of stacks.

Default Value: `64` 

#### [](#subdivisions) subdivisions : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipsoidGraphics.js 227](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L227) 

 Gets or sets the Property specifying the number of samples per outline ring, determining the granularity of the curvature.

Default Value: `128` 

### Methods

#### [](#clone) clone(result) → [EllipsoidGraphics](EllipsoidGraphics.html) 

[engine/Source/DataSources/EllipsoidGraphics.js 254](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L254) 

 Duplicates this instance.

| Name   | Type                                        | Description                                         |
| ------ | ------------------------------------------- | --------------------------------------------------- |
| result | [EllipsoidGraphics](EllipsoidGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/EllipsoidGraphics.js 285](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L285) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                        | Description                               |
| ------ | ------------------------------------------- | ----------------------------------------- |
| source | [EllipsoidGraphics](EllipsoidGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.EllipsoidGraphics.ConstructorOptions

[engine/Source/DataSources/EllipsoidGraphics.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipsoidGraphics.js#L8) 

 Initialization options for the EllipsoidGraphics constructor

##### Properties:

| Name                     | Type                                                                                 | Attributes | Default              | Description                                                                                                 |
| ------------------------ | ------------------------------------------------------------------------------------ | ---------- | -------------------- | ----------------------------------------------------------------------------------------------------------- |
| show                     | [Property](Property.html)\|boolean                                                   | <optional> | true                 | A boolean Property specifying the visibility of the ellipsoid.                                              |
| radii                    | [Property](Property.html)\|[Cartesian3](Cartesian3.html)                             | <optional> |                      | A [Cartesian3](Cartesian3.html) Property specifying the radii of the ellipsoid.                             |
| innerRadii               | [Property](Property.html)\|[Cartesian3](Cartesian3.html)                             | <optional> |                      | A [Cartesian3](Cartesian3.html) Property specifying the inner radii of the ellipsoid.                       |
| minimumClock             | [Property](Property.html)\|number                                                    | <optional> | 0.0                  | A Property specifying the minimum clock angle of the ellipsoid.                                             |
| maximumClock             | [Property](Property.html)\|number                                                    | <optional> | 2\*PI                | A Property specifying the maximum clock angle of the ellipsoid.                                             |
| minimumCone              | [Property](Property.html)\|number                                                    | <optional> | 0.0                  | A Property specifying the minimum cone angle of the ellipsoid.                                              |
| maximumCone              | [Property](Property.html)\|number                                                    | <optional> | PI                   | A Property specifying the maximum cone angle of the ellipsoid.                                              |
| heightReference          | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE | A Property specifying what the height from the entity position is relative to.                              |
| fill                     | [Property](Property.html)\|boolean                                                   | <optional> | true                 | A boolean Property specifying whether the ellipsoid is filled with the provided material.                   |
| material                 | [MaterialProperty](MaterialProperty.html)\|[Color](Color.html)                       | <optional> | Color.WHITE          | A Property specifying the material used to fill the ellipsoid.                                              |
| outline                  | [Property](Property.html)\|boolean                                                   | <optional> | false                | A boolean Property specifying whether the ellipsoid is outlined.                                            |
| outlineColor             | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.BLACK          | A Property specifying the [Color](Color.html) of the outline.                                               |
| outlineWidth             | [Property](Property.html)\|number                                                    | <optional> | 1.0                  | A numeric Property specifying the width of the outline.                                                     |
| stackPartitions          | [Property](Property.html)\|number                                                    | <optional> | 64                   | A Property specifying the number of stacks.                                                                 |
| slicePartitions          | [Property](Property.html)\|number                                                    | <optional> | 64                   | A Property specifying the number of radial slices.                                                          |
| subdivisions             | [Property](Property.html)\|number                                                    | <optional> | 128                  | A Property specifying the number of samples per outline ring, determining the granularity of the curvature. |
| shadows                  | [Property](Property.html)\|[ShadowMode](global.html#ShadowMode)                      | <optional> | ShadowMode.DISABLED  | An enum Property specifying whether the ellipsoid casts or receives shadows from light sources.             |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                      | A Property specifying at what distance from the camera that this ellipsoid will be displayed.               |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

