# [![](Images/CesiumLogo.png)](index.html) EasingFunction 

[engine/Source/Core/EasingFunction.js 10](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L10) 

Easing functions for use with TweenCollection. These function are from[Tween.js](https://github.com/sole/tween.js/) and Robert Penner. See the[Tween.js graphs for each function](http://sole.github.io/tween.js/examples/03%5Fgraphs.html).

### Members

#### [](#.BACK%5FIN) static constant Cesium.EasingFunction.BACK\_IN : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 201](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L201) 

 Back in.

#### [](#.BACK%5FIN%5FOUT) static constant Cesium.EasingFunction.BACK\_IN\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 215](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L215) 

 Back in then out.

#### [](#.BACK%5FOUT) static constant Cesium.EasingFunction.BACK\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 208](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L208) 

 Back out.

#### [](#.BOUNCE%5FIN) static constant Cesium.EasingFunction.BOUNCE\_IN : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 223](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L223) 

 Bounce in.

#### [](#.BOUNCE%5FIN%5FOUT) static constant Cesium.EasingFunction.BOUNCE\_IN\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 237](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L237) 

 Bounce in then out.

#### [](#.BOUNCE%5FOUT) static constant Cesium.EasingFunction.BOUNCE\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 230](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L230) 

 Bounce out.

#### [](#.CIRCULAR%5FIN) static constant Cesium.EasingFunction.CIRCULAR\_IN : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 157](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L157) 

 Circular in.

#### [](#.CIRCULAR%5FIN%5FOUT) static constant Cesium.EasingFunction.CIRCULAR\_IN\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 171](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L171) 

 Circular in then out.

#### [](#.CIRCULAR%5FOUT) static constant Cesium.EasingFunction.CIRCULAR\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 164](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L164) 

 Circular out.

#### [](#.CUBIC%5FIN) static constant Cesium.EasingFunction.CUBIC\_IN : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 47](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L47) 

 Cubic in.

#### [](#.CUBIC%5FIN%5FOUT) static constant Cesium.EasingFunction.CUBIC\_IN\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 61](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L61) 

 Cubic in then out.

#### [](#.CUBIC%5FOUT) static constant Cesium.EasingFunction.CUBIC\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 54](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L54) 

 Cubic out.

#### [](#.ELASTIC%5FIN) static constant Cesium.EasingFunction.ELASTIC\_IN : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 179](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L179) 

 Elastic in.

#### [](#.ELASTIC%5FIN%5FOUT) static constant Cesium.EasingFunction.ELASTIC\_IN\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 193](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L193) 

 Elastic in then out.

#### [](#.ELASTIC%5FOUT) static constant Cesium.EasingFunction.ELASTIC\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 186](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L186) 

 Elastic out.

#### [](#.EXPONENTIAL%5FIN) static constant Cesium.EasingFunction.EXPONENTIAL\_IN : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 135](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L135) 

 Exponential in.

#### [](#.EXPONENTIAL%5FIN%5FOUT) static constant Cesium.EasingFunction.EXPONENTIAL\_IN\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 149](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L149) 

 Exponential in then out.

#### [](#.EXPONENTIAL%5FOUT) static constant Cesium.EasingFunction.EXPONENTIAL\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 142](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L142) 

 Exponential out.

#### [](#.LINEAR%5FNONE) static constant Cesium.EasingFunction.LINEAR\_NONE : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 17](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L17) 

 Linear easing.

#### [](#.QUADRATIC%5FIN) static constant Cesium.EasingFunction.QUADRATIC\_IN : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 25](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L25) 

 Quadratic in.

#### [](#.QUADRATIC%5FIN%5FOUT) static constant Cesium.EasingFunction.QUADRATIC\_IN\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L39) 

 Quadratic in then out.

#### [](#.QUADRATIC%5FOUT) static constant Cesium.EasingFunction.QUADRATIC\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 32](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L32) 

 Quadratic out.

#### [](#.QUARTIC%5FIN) static constant Cesium.EasingFunction.QUARTIC\_IN : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 69](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L69) 

 Quartic in.

#### [](#.QUARTIC%5FIN%5FOUT) static constant Cesium.EasingFunction.QUARTIC\_IN\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 83](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L83) 

 Quartic in then out.

#### [](#.QUARTIC%5FOUT) static constant Cesium.EasingFunction.QUARTIC\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L76) 

 Quartic out.

#### [](#.QUINTIC%5FIN) static constant Cesium.EasingFunction.QUINTIC\_IN : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 91](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L91) 

 Quintic in.

#### [](#.QUINTIC%5FIN%5FOUT) static constant Cesium.EasingFunction.QUINTIC\_IN\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 105](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L105) 

 Quintic in then out.

#### [](#.QUINTIC%5FOUT) static constant Cesium.EasingFunction.QUINTIC\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 98](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L98) 

 Quintic out.

#### [](#.SINUSOIDAL%5FIN) static constant Cesium.EasingFunction.SINUSOIDAL\_IN : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 113](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L113) 

 Sinusoidal in.

#### [](#.SINUSOIDAL%5FIN%5FOUT) static constant Cesium.EasingFunction.SINUSOIDAL\_IN\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 127](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L127) 

 Sinusoidal in then out.

#### [](#.SINUSOIDAL%5FOUT) static constant Cesium.EasingFunction.SINUSOIDAL\_OUT : [EasingFunction.Callback](EasingFunction.html#.Callback) 

[engine/Source/Core/EasingFunction.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L120) 

 Sinusoidal out.

### Type Definitions

#### [](#.Callback) Cesium.EasingFunction.Callback(time) → number 

[engine/Source/Core/EasingFunction.js 240](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EasingFunction.js#L240) 

 Function interface for implementing a custom easing function.

| Name | Type   | Description                     |
| ---- | ------ | ------------------------------- |
| time | number | The time in the range \[0, 1\]. |

##### Returns:

 The value of the function at the given time.

##### Examples:

```javascript
function quadraticIn(time) {
    return time * time;
}
```

```javascript
function quadraticOut(time) {
    return time * (2.0 - time);
}
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

