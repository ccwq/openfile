# [![](Images/CesiumLogo.png)](index.html) Clock 

#### [](#Clock) new Cesium.Clock(options) 

[engine/Source/Core/Clock.js 43](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L43) 

 A simple clock for keeping track of simulated time.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | optional Object with the following properties: Name Type Default Description startTime [JulianDate](JulianDate.html) optional The start time of the clock. stopTime [JulianDate](JulianDate.html) optional The stop time of the clock. currentTime [JulianDate](JulianDate.html) optional The current time. multiplier number 1.0 optional Determines how much time advances when [Clock#tick](Clock.html#tick) is called, negative values allow for advancing backwards. clockStep [ClockStep](global.html#ClockStep) ClockStep.SYSTEM\_CLOCK\_MULTIPLIER optional Determines if calls to [Clock#tick](Clock.html#tick) are frame dependent or system clock dependent. clockRange [ClockRange](global.html#ClockRange) ClockRange.UNBOUNDED optional Determines how the clock should behave when [Clock#startTime](Clock.html#startTime) or [Clock#stopTime](Clock.html#stopTime) is reached. canAnimate boolean true optional Indicates whether [Clock#tick](Clock.html#tick) can advance time. This could be false if data is being buffered, for example. The clock will only tick when both [Clock#canAnimate](Clock.html#canAnimate) and [Clock#shouldAnimate](Clock.html#shouldAnimate) are true. shouldAnimate boolean false optional Indicates whether [Clock#tick](Clock.html#tick) should attempt to advance time. The clock will only tick when both [Clock#canAnimate](Clock.html#canAnimate) and [Clock#shouldAnimate](Clock.html#shouldAnimate) are true. |

##### Throws:

* [DeveloperError](DeveloperError.html): startTime must come before stopTime.

##### Example:

```javascript
// Create a clock that loops on Christmas day 2013 and runs in real-time.
const clock = new Cesium.Clock({
   startTime : Cesium.JulianDate.fromIso8601("2013-12-25"),
   currentTime : Cesium.JulianDate.fromIso8601("2013-12-25"),
   stopTime : Cesium.JulianDate.fromIso8601("2013-12-26"),
   clockRange : Cesium.ClockRange.LOOP_STOP,
   clockStep : Cesium.ClockStep.SYSTEM_CLOCK_MULTIPLIER
});
```

##### See:

* [ClockStep](global.html#ClockStep)
* [ClockRange](global.html#ClockRange)
* [JulianDate](JulianDate.html)

### Members

#### [](#canAnimate) canAnimate : boolean 

[engine/Source/Core/Clock.js 115](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L115) 

 Indicates whether [Clock#tick](Clock.html#tick) can advance time. This could be false if data is being buffered, for example. The clock will only advance time when both[Clock#canAnimate](Clock.html#canAnimate) and [Clock#shouldAnimate](Clock.html#shouldAnimate) are true.

Default Value: `true` 

#### [](#clockRange) clockRange : [ClockRange](global.html#ClockRange) 

[engine/Source/Core/Clock.js 106](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L106) 

 Determines how the clock should behave when[Clock#startTime](Clock.html#startTime) or [Clock#stopTime](Clock.html#stopTime)is reached.

Default Value: `[ClockRange.UNBOUNDED](global.html#ClockRange#.UNBOUNDED)` 

#### [](#clockStep) clockStep : [ClockStep](global.html#ClockStep) 

[engine/Source/Core/Clock.js 210](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L210) 

 Determines if calls to [Clock#tick](Clock.html#tick) are frame dependent or system clock dependent. Changing this property to [ClockStep.SYSTEM\_CLOCK](global.html#ClockStep#.SYSTEM%5FCLOCK) will set[Clock#multiplier](Clock.html#multiplier) to 1.0, [Clock#shouldAnimate](Clock.html#shouldAnimate) to true, and[Clock#currentTime](Clock.html#currentTime) to the current system clock time.

Default Value: `[ClockStep.SYSTEM_CLOCK_MULTIPLIER](global.html#ClockStep#.SYSTEM%5FCLOCK%5FMULTIPLIER)` 

#### [](#currentTime) currentTime : [JulianDate](JulianDate.html) 

[engine/Source/Core/Clock.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L155) 

 The current time. Changing this property will change[Clock#clockStep](Clock.html#clockStep) from [ClockStep.SYSTEM\_CLOCK](global.html#ClockStep#.SYSTEM%5FCLOCK) to[ClockStep.SYSTEM\_CLOCK\_MULTIPLIER](global.html#ClockStep#.SYSTEM%5FCLOCK%5FMULTIPLIER).

#### [](#multiplier) multiplier : number 

[engine/Source/Core/Clock.js 184](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L184) 

 Gets or sets how much time advances when [Clock#tick](Clock.html#tick) is called. Negative values allow for advancing backwards. If [Clock#clockStep](Clock.html#clockStep) is set to [ClockStep.TICK\_DEPENDENT](global.html#ClockStep#.TICK%5FDEPENDENT), this is the number of seconds to advance. If [Clock#clockStep](Clock.html#clockStep) is set to [ClockStep.SYSTEM\_CLOCK\_MULTIPLIER](global.html#ClockStep#.SYSTEM%5FCLOCK%5FMULTIPLIER), this value is multiplied by the elapsed system time since the last call to [Clock#tick](Clock.html#tick). Changing this property will change[Clock#clockStep](Clock.html#clockStep) from [ClockStep.SYSTEM\_CLOCK](global.html#ClockStep#.SYSTEM%5FCLOCK) to[ClockStep.SYSTEM\_CLOCK\_MULTIPLIER](global.html#ClockStep#.SYSTEM%5FCLOCK%5FMULTIPLIER).

Default Value: `1.0` 

#### [](#onStop) onStop : [Event](Event.html) 

[engine/Source/Core/Clock.js 126](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L126) 

 An [Event](Event.html) that is fired whenever [Clock#stopTime](Clock.html#stopTime) is reached.

#### [](#onTick) onTick : [Event](Event.html) 

[engine/Source/Core/Clock.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L121) 

 An [Event](Event.html) that is fired whenever [Clock#tick](Clock.html#tick) is called.

#### [](#shouldAnimate) shouldAnimate : boolean 

[engine/Source/Core/Clock.js 236](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L236) 

 Indicates whether [Clock#tick](Clock.html#tick) should attempt to advance time. The clock will only advance time when both[Clock#canAnimate](Clock.html#canAnimate) and [Clock#shouldAnimate](Clock.html#shouldAnimate) are true. Changing this property will change[Clock#clockStep](Clock.html#clockStep) from [ClockStep.SYSTEM\_CLOCK](global.html#ClockStep#.SYSTEM%5FCLOCK) to[ClockStep.SYSTEM\_CLOCK\_MULTIPLIER](global.html#ClockStep#.SYSTEM%5FCLOCK%5FMULTIPLIER).

Default Value: `false` 

#### [](#startTime) startTime : [JulianDate](JulianDate.html) 

[engine/Source/Core/Clock.js 91](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L91) 

 The start time of the clock.

#### [](#stopTime) stopTime : [JulianDate](JulianDate.html) 

[engine/Source/Core/Clock.js 97](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L97) 

 The stop time of the clock.

### Methods

#### [](#tick) tick() → [JulianDate](JulianDate.html) 

[engine/Source/Core/Clock.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Clock.js#L261) 

 Advances the clock from the current time based on the current configuration options. tick should be called every frame, regardless of whether animation is taking place or not. To control animation, use the [Clock#shouldAnimate](Clock.html#shouldAnimate) property.

##### Returns:

 The new value of the [Clock#currentTime](Clock.html#currentTime) property.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

