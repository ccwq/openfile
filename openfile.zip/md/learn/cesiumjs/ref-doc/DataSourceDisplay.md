# [![](Images/CesiumLogo.png)](index.html) DataSourceDisplay 

#### [](#DataSourceDisplay) new Cesium.DataSourceDisplay(options) 

[engine/Source/DataSources/DataSourceDisplay.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceDisplay.js#L35) 

 Visualizes a collection of [DataSource](DataSource.html) instances.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | Object with the following properties: Name Type Default Description scene [Scene](Scene.html)  The scene in which to display the data. dataSourceCollection [DataSourceCollection](DataSourceCollection.html)  The data sources to display. visualizersCallback [DataSourceDisplay.VisualizersCallback](DataSourceDisplay.html#.VisualizersCallback) DataSourceDisplay.defaultVisualizersCallback optional A function which creates an array of visualizers used for visualization. If undefined, all standard visualizers are used. |

### Members

#### [](#dataSources) dataSources : [DataSourceCollection](DataSourceCollection.html) 

[engine/Source/DataSources/DataSourceDisplay.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceDisplay.js#L200) 

 Gets the collection of data sources to display.

#### [](#defaultDataSource) defaultDataSource : [CustomDataSource](CustomDataSource.html) 

[engine/Source/DataSources/DataSourceDisplay.js 213](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceDisplay.js#L213) 

 Gets the default data source instance which can be used to manually create and visualize entities not tied to a specific data source. This instance is always available and does not appear in the list dataSources collection.

#### [](#ready) readonly ready : boolean 

[engine/Source/DataSources/DataSourceDisplay.js 225](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceDisplay.js#L225) 

 Gets a value indicating whether or not all entities in the data source are ready

#### [](#scene) scene : [Scene](Scene.html) 

[engine/Source/DataSources/DataSourceDisplay.js 190](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceDisplay.js#L190) 

 Gets the scene associated with this display.

### Methods

#### [](#.defaultVisualizersCallback) static Cesium.DataSourceDisplay.defaultVisualizersCallback() 

[engine/Source/DataSources/DataSourceDisplay.js 153](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceDisplay.js#L153) 

 Gets or sets the default function which creates an array of visualizers used for visualization. By default, this function uses all standard visualizers.

#### [](#destroy) destroy() 

[engine/Source/DataSources/DataSourceDisplay.js 262](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceDisplay.js#L262) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
dataSourceDisplay = dataSourceDisplay.destroy();
```

##### See:

* [DataSourceDisplay#isDestroyed](DataSourceDisplay.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/DataSources/DataSourceDisplay.js 242](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceDisplay.js#L242) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

 True if this object was destroyed; otherwise, false.

##### See:

* [DataSourceDisplay#destroy](DataSourceDisplay.html#destroy)

#### [](#update) update(time) → boolean 

[engine/Source/DataSources/DataSourceDisplay.js 291](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceDisplay.js#L291) 

 Updates the display to the provided time.

| Name | Type                          | Description          |
| ---- | ----------------------------- | -------------------- |
| time | [JulianDate](JulianDate.html) | The simulation time. |

##### Returns:

 True if all data sources are ready to be displayed, false otherwise.

### Type Definitions

#### [](#.VisualizersCallback) Cesium.DataSourceDisplay.VisualizersCallback(scene, entityCluster, dataSource) → Array.<[Visualizer](Visualizer.html)\> 

[engine/Source/DataSources/DataSourceDisplay.js 532](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceDisplay.js#L532) 

 A function which creates an array of visualizers used for visualization.

| Name          | Type                                | Description                                   |
| ------------- | ----------------------------------- | --------------------------------------------- |
| scene         | [Scene](Scene.html)                 | The scene to create visualizers for.          |
| entityCluster | [EntityCluster](EntityCluster.html) | The entity cluster to create visualizers for. |
| dataSource    | [DataSource](DataSource.html)       | The data source to create visualizers for.    |

##### Returns:

 An array of visualizers used for visualization.

##### Example:

```javascript
function createVisualizers(scene, entityCluster, dataSource) {
    return [new Cesium.BillboardVisualizer(entityCluster, dataSource.entities)];
}
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

