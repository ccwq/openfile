# [![](Images/CesiumLogo.png)](index.html) PolylineGlowMaterialProperty 

#### [](#PolylineGlowMaterialProperty) new Cesium.PolylineGlowMaterialProperty(options) 

[engine/Source/DataSources/PolylineGlowMaterialProperty.js 23](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGlowMaterialProperty.js#L23) 

 A [MaterialProperty](MaterialProperty.html) that maps to polyline glow [Material](Material.html) uniforms.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description color [Property](Property.html)\|[Color](Color.html) Color.WHITE optional A Property specifying the [Color](Color.html) of the line. glowPower [Property](Property.html)|number 0.25 optional A numeric Property specifying the strength of the glow, as a percentage of the total line width. taperPower [Property](Property.html)|number 1.0 optional A numeric Property specifying the strength of the tapering effect, as a percentage of the total line length. If 1.0 or higher, no taper effect is used. |

### Members

#### [](#color) color : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineGlowMaterialProperty.js 72](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGlowMaterialProperty.js#L72) 

 Gets or sets the Property specifying the [Color](Color.html) of the line.

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/PolylineGlowMaterialProperty.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGlowMaterialProperty.js#L62) 

 Gets the event that is raised whenever the definition of this property changes. The definition is considered to have changed if a call to getValue would return a different result for the same time.

#### [](#glowPower) glowPower : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineGlowMaterialProperty.js 79](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGlowMaterialProperty.js#L79) 

 Gets or sets the numeric Property specifying the strength of the glow, as a percentage of the total line width (less than 1.0).

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/PolylineGlowMaterialProperty.js 47](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGlowMaterialProperty.js#L47) 

 Gets a value indicating if this property is constant. A property is considered constant if getValue always returns the same result for the current definition.

#### [](#taperPower) taperPower : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolylineGlowMaterialProperty.js 86](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGlowMaterialProperty.js#L86) 

 Gets or sets the numeric Property specifying the strength of the tapering effect, as a percentage of the total line length. If 1.0 or higher, no taper effect is used.

### Methods

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/PolylineGlowMaterialProperty.js 143](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGlowMaterialProperty.js#L143) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getType) getType(time) → string 

[engine/Source/DataSources/PolylineGlowMaterialProperty.js 95](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGlowMaterialProperty.js#L95) 

 Gets the [Material](Material.html) type at the provided time.

| Name | Type                          | Description                              |
| ---- | ----------------------------- | ---------------------------------------- |
| time | [JulianDate](JulianDate.html) | The time for which to retrieve the type. |

##### Returns:

 The type of material.

#### [](#getValue) getValue(time, result) → object 

[engine/Source/DataSources/PolylineGlowMaterialProperty.js 108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolylineGlowMaterialProperty.js#L108) 

 Gets the value of the property at the provided time.

| Name   | Type                          | Default          | Description                                                                                      |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | object                        |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

