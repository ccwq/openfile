# [![](Images/CesiumLogo.png)](index.html) Terrain 

#### [](#Terrain) new Cesium.Terrain(terrainProviderPromise) 

[engine/Source/Scene/Terrain.js 43](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Terrain.js#L43) 

 A helper to manage async operations of a terrain provider.

| Name                   | Type                                               | Description                                    |
| ---------------------- | -------------------------------------------------- | ---------------------------------------------- |
| terrainProviderPromise | Promise.<[TerrainProvider](TerrainProvider.html)\> | A promise which resolves to a terrain provider |

##### Examples:

```javascript
// Create
const viewer = new Cesium.Viewer("cesiumContainer", {
  terrain: new Cesium.Terrain(Cesium.CesiumTerrainProvider.fromUrl("https://myTestTerrain.com"));
});
```

```javascript
// Handle loading events
const terrain = new Cesium.Terrain(Cesium.CesiumTerrainProvider.fromUrl("https://myTestTerrain.com"));

scene.setTerrain(terrain);

terrain.readyEvent.addEventListener(provider => {
  scene.globe.enableLighting = true;

  terrain.provider.errorEvent.addEventListener(error => {
    alert(`Encountered an error while loading terrain tiles! ${error}`);
  });
});

terrain.errorEvent.addEventListener(error => {
  alert(`Encountered an error while creating terrain! ${error}`);
});
```

##### See:

* [Terrain.fromWorldTerrain](Terrain.html#.fromWorldTerrain)
* [CesiumTerrainProvider](CesiumTerrainProvider.html)
* [VRTheWorldTerrainProvider](VRTheWorldTerrainProvider.html)
* [GoogleEarthEnterpriseTerrainProvider](GoogleEarthEnterpriseTerrainProvider.html)

### Members

#### [](#errorEvent) readonly errorEvent : [Event](Event.html).<[Terrain.ErrorEventCallback](Terrain.html#.ErrorEventCallback)\> 

[engine/Source/Scene/Terrain.js 65](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Terrain.js#L65) 

 Gets an event that is raised when the terrain provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of the thrown error.

#### [](#provider) readonly provider : [TerrainProvider](TerrainProvider.html) 

[engine/Source/Scene/Terrain.js 104](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Terrain.js#L104) 

 The terrain provider providing surface geometry to a globe. Do not use until `Terrain.readyEvent` is raised.

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/Terrain.js 91](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Terrain.js#L91) 

 Returns true when the terrain provider has been successfully created. Otherwise, returns false.

#### [](#readyEvent) readonly readyEvent : [Event](Event.html).<[Terrain.ReadyEventCallback](Terrain.html#.ReadyEventCallback)\> 

[engine/Source/Scene/Terrain.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Terrain.js#L78) 

 Gets an event that is raised when the terrain provider has been successfully created. Event listeners are passed the created instance of [TerrainProvider](TerrainProvider.html).

### Methods

#### [](#.fromWorldBathymetry) static Cesium.Terrain.fromWorldBathymetry(options) → [Terrain](Terrain.html) 

[engine/Source/Scene/Terrain.js 204](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Terrain.js#L204) 

 Creates a [Terrain](Terrain.html) instance for [Cesium World Bathymetry](https://cesium.com/content/#cesium-world-bathymetry).

| Name    | Type   | Description                                                                                                                                                                                                                             |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | Object | optional Object with the following properties: Name Type Default Description requestVertexNormals Boolean false optional Flag that indicates if the client should request additional lighting information from the server if available. |

##### Returns:

 An asynchronous helper object for a CesiumTerrainProvider

##### Examples:

```javascript
// Create Cesium World Bathymetry with default settings
const viewer = new Cesium.Viewer("cesiumContainer", {
  terrain: Cesium.Terrain.fromWorldBathymetry)
});
```

```javascript
// Create Cesium World Terrain with normals.
const viewer1 = new Cesium.Viewer("cesiumContainer", {
  terrain: Cesium.Terrain.fromWorldBathymetry({
     requestVertexNormals: true
   });
});
```

```javascript
// Handle loading events
const bathymetry = Cesium.Terrain.fromWorldBathymetry();

scene.setTerrain(bathymetry);

bathymetry.readyEvent.addEventListener(provider => {
  scene.globe.enableLighting = true;

  bathymetry.provider.errorEvent.addEventListener(error => {
    alert(`Encountered an error while loading bathymetric terrain tiles! ${error}`);
  });
});

bathymetry.errorEvent.addEventListener(error => {
  alert(`Encountered an error while creating bathymetric terrain! ${error}`);
});
```

##### See:

* [Ion](Ion.html)
* [createWorldBathymetryAsync](global.html#createWorldBathymetryAsync)

#### [](#.fromWorldTerrain) static Cesium.Terrain.fromWorldTerrain(options) → [Terrain](Terrain.html) 

[engine/Source/Scene/Terrain.js 156](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Terrain.js#L156) 

 Creates a [Terrain](Terrain.html) instance for [Cesium World Terrain](https://cesium.com/content/#cesium-world-terrain).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                         |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | Object | optional Object with the following properties: Name Type Default Description requestVertexNormals Boolean false optional Flag that indicates if the client should request additional lighting information from the server if available. requestWaterMask Boolean false optional Flag that indicates if the client should request per tile water masks from the server if available. |

##### Returns:

 An asynchronous helper object for a CesiumTerrainProvider

##### Examples:

```javascript
// Create Cesium World Terrain with default settings
const viewer = new Cesium.Viewer("cesiumContainer", {
  terrain: Cesium.Terrain.fromWorldTerrain()
});
```

```javascript
// Create Cesium World Terrain with water and normals.
const viewer1 = new Cesium.Viewer("cesiumContainer", {
  terrain: Cesium.Terrain.fromWorldTerrain({
     requestWaterMask: true,
     requestVertexNormals: true
   });
});
```

```javascript
// Handle loading events
const terrain = Cesium.Terrain.fromWorldTerrain();

scene.setTerrain(terrain);

terrain.readyEvent.addEventListener(provider => {
  scene.globe.enableLighting = true;

  terrain.provider.errorEvent.addEventListener(error => {
    alert(`Encountered an error while loading terrain tiles! ${error}`);
  });
});

terrain.errorEvent.addEventListener(error => {
  alert(`Encountered an error while creating terrain! ${error}`);
});
```

##### See:

* [Ion](Ion.html)
* [createWorldTerrainAsync](global.html#createWorldTerrainAsync)

### Type Definitions

#### [](#.ErrorEventCallback) Cesium.Terrain.ErrorEventCallback(err) 

[engine/Source/Scene/Terrain.js 231](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Terrain.js#L231) 

 A function that is called when an error occurs.

##### This:

* [Terrain](Terrain.html)

| Name | Type  | Description                                              |
| ---- | ----- | -------------------------------------------------------- |
| err  | Error | An object holding details about the error that occurred. |

#### [](#.ReadyEventCallback) Cesium.Terrain.ReadyEventCallback(provider) 

[engine/Source/Scene/Terrain.js 239](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Terrain.js#L239) 

 A function that is called when the provider has been created

##### This:

* [Terrain](Terrain.html)

| Name     | Type                                    | Description                   |
| -------- | --------------------------------------- | ----------------------------- |
| provider | [TerrainProvider](TerrainProvider.html) | The created terrain provider. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

