# [![](Images/CesiumLogo.png)](index.html) Color 

#### [](#Color) new Cesium.Color(red, green, blue, alpha) 

[engine/Source/Core/Color.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L39) 

 A color, specified using red, green, blue, and alpha values, which range from `0` (no intensity) to `1.0` (full intensity).

| Name  | Type   | Default | Description                   |
| ----- | ------ | ------- | ----------------------------- |
| red   | number | 1.0     | optional The red component.   |
| green | number | 1.0     | optional The green component. |
| blue  | number | 1.0     | optional The blue component.  |
| alpha | number | 1.0     | optional The alpha component. |

##### See:

* [Packable](Packable.html)

### Members

#### [](#.ALICEBLUE) static constant Cesium.Color.ALICEBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 952](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L952) 

 An immutable Color instance initialized to CSS color #F0F8FF 

#### [](#.ANTIQUEWHITE) static constant Cesium.Color.ANTIQUEWHITE : [Color](Color.html) 

[engine/Source/Core/Color.js 961](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L961) 

 An immutable Color instance initialized to CSS color #FAEBD7 

#### [](#.AQUA) static constant Cesium.Color.AQUA : [Color](Color.html) 

[engine/Source/Core/Color.js 970](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L970) 

 An immutable Color instance initialized to CSS color #00FFFF 

#### [](#.AQUAMARINE) static constant Cesium.Color.AQUAMARINE : [Color](Color.html) 

[engine/Source/Core/Color.js 979](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L979) 

 An immutable Color instance initialized to CSS color #7FFFD4 

#### [](#.AZURE) static constant Cesium.Color.AZURE : [Color](Color.html) 

[engine/Source/Core/Color.js 988](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L988) 

 An immutable Color instance initialized to CSS color #F0FFFF 

#### [](#.BEIGE) static constant Cesium.Color.BEIGE : [Color](Color.html) 

[engine/Source/Core/Color.js 997](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L997) 

 An immutable Color instance initialized to CSS color #F5F5DC 

#### [](#.BISQUE) static constant Cesium.Color.BISQUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1006](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1006) 

 An immutable Color instance initialized to CSS color #FFE4C4 

#### [](#.BLACK) static constant Cesium.Color.BLACK : [Color](Color.html) 

[engine/Source/Core/Color.js 1015](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1015) 

 An immutable Color instance initialized to CSS color #000000 

#### [](#.BLANCHEDALMOND) static constant Cesium.Color.BLANCHEDALMOND : [Color](Color.html) 

[engine/Source/Core/Color.js 1024](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1024) 

 An immutable Color instance initialized to CSS color #FFEBCD 

#### [](#.BLUE) static constant Cesium.Color.BLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1033](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1033) 

 An immutable Color instance initialized to CSS color #0000FF 

#### [](#.BLUEVIOLET) static constant Cesium.Color.BLUEVIOLET : [Color](Color.html) 

[engine/Source/Core/Color.js 1042](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1042) 

 An immutable Color instance initialized to CSS color #8A2BE2 

#### [](#.BROWN) static constant Cesium.Color.BROWN : [Color](Color.html) 

[engine/Source/Core/Color.js 1051](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1051) 

 An immutable Color instance initialized to CSS color #A52A2A 

#### [](#.BURLYWOOD) static constant Cesium.Color.BURLYWOOD : [Color](Color.html) 

[engine/Source/Core/Color.js 1060](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1060) 

 An immutable Color instance initialized to CSS color #DEB887 

#### [](#.CADETBLUE) static constant Cesium.Color.CADETBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1069](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1069) 

 An immutable Color instance initialized to CSS color #5F9EA0 

#### [](#.CHARTREUSE) static constant Cesium.Color.CHARTREUSE : [Color](Color.html) 

[engine/Source/Core/Color.js 1077](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1077) 

 An immutable Color instance initialized to CSS color #7FFF00 

#### [](#.CHOCOLATE) static constant Cesium.Color.CHOCOLATE : [Color](Color.html) 

[engine/Source/Core/Color.js 1086](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1086) 

 An immutable Color instance initialized to CSS color #D2691E 

#### [](#.CORAL) static constant Cesium.Color.CORAL : [Color](Color.html) 

[engine/Source/Core/Color.js 1095](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1095) 

 An immutable Color instance initialized to CSS color #FF7F50 

#### [](#.CORNFLOWERBLUE) static constant Cesium.Color.CORNFLOWERBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1104](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1104) 

 An immutable Color instance initialized to CSS color #6495ED 

#### [](#.CORNSILK) static constant Cesium.Color.CORNSILK : [Color](Color.html) 

[engine/Source/Core/Color.js 1113](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1113) 

 An immutable Color instance initialized to CSS color #FFF8DC 

#### [](#.CRIMSON) static constant Cesium.Color.CRIMSON : [Color](Color.html) 

[engine/Source/Core/Color.js 1122](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1122) 

 An immutable Color instance initialized to CSS color #DC143C 

#### [](#.CYAN) static constant Cesium.Color.CYAN : [Color](Color.html) 

[engine/Source/Core/Color.js 1131](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1131) 

 An immutable Color instance initialized to CSS color #00FFFF 

#### [](#.DARKBLUE) static constant Cesium.Color.DARKBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1140](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1140) 

 An immutable Color instance initialized to CSS color #00008B 

#### [](#.DARKCYAN) static constant Cesium.Color.DARKCYAN : [Color](Color.html) 

[engine/Source/Core/Color.js 1149](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1149) 

 An immutable Color instance initialized to CSS color #008B8B 

#### [](#.DARKGOLDENROD) static constant Cesium.Color.DARKGOLDENROD : [Color](Color.html) 

[engine/Source/Core/Color.js 1158](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1158) 

 An immutable Color instance initialized to CSS color #B8860B 

#### [](#.DARKGRAY) static constant Cesium.Color.DARKGRAY : [Color](Color.html) 

[engine/Source/Core/Color.js 1167](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1167) 

 An immutable Color instance initialized to CSS color #A9A9A9 

#### [](#.DARKGREEN) static constant Cesium.Color.DARKGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1176) 

 An immutable Color instance initialized to CSS color #006400 

#### [](#.DARKGREY) static constant Cesium.Color.DARKGREY : [Color](Color.html) 

[engine/Source/Core/Color.js 1185](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1185) 

 An immutable Color instance initialized to CSS color #A9A9A9 

#### [](#.DARKKHAKI) static constant Cesium.Color.DARKKHAKI : [Color](Color.html) 

[engine/Source/Core/Color.js 1194](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1194) 

 An immutable Color instance initialized to CSS color #BDB76B 

#### [](#.DARKMAGENTA) static constant Cesium.Color.DARKMAGENTA : [Color](Color.html) 

[engine/Source/Core/Color.js 1203](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1203) 

 An immutable Color instance initialized to CSS color #8B008B 

#### [](#.DARKOLIVEGREEN) static constant Cesium.Color.DARKOLIVEGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1212](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1212) 

 An immutable Color instance initialized to CSS color #556B2F 

#### [](#.DARKORANGE) static constant Cesium.Color.DARKORANGE : [Color](Color.html) 

[engine/Source/Core/Color.js 1221](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1221) 

 An immutable Color instance initialized to CSS color #FF8C00 

#### [](#.DARKORCHID) static constant Cesium.Color.DARKORCHID : [Color](Color.html) 

[engine/Source/Core/Color.js 1230](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1230) 

 An immutable Color instance initialized to CSS color #9932CC 

#### [](#.DARKRED) static constant Cesium.Color.DARKRED : [Color](Color.html) 

[engine/Source/Core/Color.js 1239](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1239) 

 An immutable Color instance initialized to CSS color #8B0000 

#### [](#.DARKSALMON) static constant Cesium.Color.DARKSALMON : [Color](Color.html) 

[engine/Source/Core/Color.js 1248](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1248) 

 An immutable Color instance initialized to CSS color #E9967A 

#### [](#.DARKSEAGREEN) static constant Cesium.Color.DARKSEAGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1257](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1257) 

 An immutable Color instance initialized to CSS color #8FBC8F 

#### [](#.DARKSLATEBLUE) static constant Cesium.Color.DARKSLATEBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1266) 

 An immutable Color instance initialized to CSS color #483D8B 

#### [](#.DARKSLATEGRAY) static constant Cesium.Color.DARKSLATEGRAY : [Color](Color.html) 

[engine/Source/Core/Color.js 1275](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1275) 

 An immutable Color instance initialized to CSS color #2F4F4F 

#### [](#.DARKSLATEGREY) static constant Cesium.Color.DARKSLATEGREY : [Color](Color.html) 

[engine/Source/Core/Color.js 1284](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1284) 

 An immutable Color instance initialized to CSS color #2F4F4F 

#### [](#.DARKTURQUOISE) static constant Cesium.Color.DARKTURQUOISE : [Color](Color.html) 

[engine/Source/Core/Color.js 1293](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1293) 

 An immutable Color instance initialized to CSS color #00CED1 

#### [](#.DARKVIOLET) static constant Cesium.Color.DARKVIOLET : [Color](Color.html) 

[engine/Source/Core/Color.js 1302](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1302) 

 An immutable Color instance initialized to CSS color #9400D3 

#### [](#.DEEPPINK) static constant Cesium.Color.DEEPPINK : [Color](Color.html) 

[engine/Source/Core/Color.js 1311](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1311) 

 An immutable Color instance initialized to CSS color #FF1493 

#### [](#.DEEPSKYBLUE) static constant Cesium.Color.DEEPSKYBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1320](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1320) 

 An immutable Color instance initialized to CSS color #00BFFF 

#### [](#.DIMGRAY) static constant Cesium.Color.DIMGRAY : [Color](Color.html) 

[engine/Source/Core/Color.js 1329](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1329) 

 An immutable Color instance initialized to CSS color #696969 

#### [](#.DIMGREY) static constant Cesium.Color.DIMGREY : [Color](Color.html) 

[engine/Source/Core/Color.js 1338](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1338) 

 An immutable Color instance initialized to CSS color #696969 

#### [](#.DODGERBLUE) static constant Cesium.Color.DODGERBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1347](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1347) 

 An immutable Color instance initialized to CSS color #1E90FF 

#### [](#.FIREBRICK) static constant Cesium.Color.FIREBRICK : [Color](Color.html) 

[engine/Source/Core/Color.js 1356](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1356) 

 An immutable Color instance initialized to CSS color #B22222 

#### [](#.FLORALWHITE) static constant Cesium.Color.FLORALWHITE : [Color](Color.html) 

[engine/Source/Core/Color.js 1365](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1365) 

 An immutable Color instance initialized to CSS color #FFFAF0 

#### [](#.FORESTGREEN) static constant Cesium.Color.FORESTGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1374](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1374) 

 An immutable Color instance initialized to CSS color #228B22 

#### [](#.FUCHSIA) static constant Cesium.Color.FUCHSIA : [Color](Color.html) 

[engine/Source/Core/Color.js 1383](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1383) 

 An immutable Color instance initialized to CSS color #FF00FF 

#### [](#.GAINSBORO) static constant Cesium.Color.GAINSBORO : [Color](Color.html) 

[engine/Source/Core/Color.js 1392](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1392) 

 An immutable Color instance initialized to CSS color #DCDCDC 

#### [](#.GHOSTWHITE) static constant Cesium.Color.GHOSTWHITE : [Color](Color.html) 

[engine/Source/Core/Color.js 1401](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1401) 

 An immutable Color instance initialized to CSS color #F8F8FF 

#### [](#.GOLD) static constant Cesium.Color.GOLD : [Color](Color.html) 

[engine/Source/Core/Color.js 1410](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1410) 

 An immutable Color instance initialized to CSS color #FFD700 

#### [](#.GOLDENROD) static constant Cesium.Color.GOLDENROD : [Color](Color.html) 

[engine/Source/Core/Color.js 1419](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1419) 

 An immutable Color instance initialized to CSS color #DAA520 

#### [](#.GRAY) static constant Cesium.Color.GRAY : [Color](Color.html) 

[engine/Source/Core/Color.js 1428](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1428) 

 An immutable Color instance initialized to CSS color #808080 

#### [](#.GREEN) static constant Cesium.Color.GREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1437](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1437) 

 An immutable Color instance initialized to CSS color #008000 

#### [](#.GREENYELLOW) static constant Cesium.Color.GREENYELLOW : [Color](Color.html) 

[engine/Source/Core/Color.js 1446](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1446) 

 An immutable Color instance initialized to CSS color #ADFF2F 

#### [](#.GREY) static constant Cesium.Color.GREY : [Color](Color.html) 

[engine/Source/Core/Color.js 1455](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1455) 

 An immutable Color instance initialized to CSS color #808080 

#### [](#.HONEYDEW) static constant Cesium.Color.HONEYDEW : [Color](Color.html) 

[engine/Source/Core/Color.js 1464](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1464) 

 An immutable Color instance initialized to CSS color #F0FFF0 

#### [](#.HOTPINK) static constant Cesium.Color.HOTPINK : [Color](Color.html) 

[engine/Source/Core/Color.js 1473](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1473) 

 An immutable Color instance initialized to CSS color #FF69B4 

#### [](#.INDIANRED) static constant Cesium.Color.INDIANRED : [Color](Color.html) 

[engine/Source/Core/Color.js 1482](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1482) 

 An immutable Color instance initialized to CSS color #CD5C5C 

#### [](#.INDIGO) static constant Cesium.Color.INDIGO : [Color](Color.html) 

[engine/Source/Core/Color.js 1491](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1491) 

 An immutable Color instance initialized to CSS color #4B0082 

#### [](#.IVORY) static constant Cesium.Color.IVORY : [Color](Color.html) 

[engine/Source/Core/Color.js 1500](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1500) 

 An immutable Color instance initialized to CSS color #FFFFF0 

#### [](#.KHAKI) static constant Cesium.Color.KHAKI : [Color](Color.html) 

[engine/Source/Core/Color.js 1509](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1509) 

 An immutable Color instance initialized to CSS color #F0E68C 

#### [](#.LAVENDAR%5FBLUSH) static constant Cesium.Color.LAVENDAR\_BLUSH : [Color](Color.html) 

[engine/Source/Core/Color.js 1527](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1527) 

 An immutable Color instance initialized to CSS color #FFF0F5 

#### [](#.LAVENDER) static constant Cesium.Color.LAVENDER : [Color](Color.html) 

[engine/Source/Core/Color.js 1518](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1518) 

 An immutable Color instance initialized to CSS color #E6E6FA 

#### [](#.LAWNGREEN) static constant Cesium.Color.LAWNGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1536](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1536) 

 An immutable Color instance initialized to CSS color #7CFC00 

#### [](#.LEMONCHIFFON) static constant Cesium.Color.LEMONCHIFFON : [Color](Color.html) 

[engine/Source/Core/Color.js 1545](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1545) 

 An immutable Color instance initialized to CSS color #FFFACD 

#### [](#.LIGHTBLUE) static constant Cesium.Color.LIGHTBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1554](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1554) 

 An immutable Color instance initialized to CSS color #ADD8E6 

#### [](#.LIGHTCORAL) static constant Cesium.Color.LIGHTCORAL : [Color](Color.html) 

[engine/Source/Core/Color.js 1563](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1563) 

 An immutable Color instance initialized to CSS color #F08080 

#### [](#.LIGHTCYAN) static constant Cesium.Color.LIGHTCYAN : [Color](Color.html) 

[engine/Source/Core/Color.js 1572](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1572) 

 An immutable Color instance initialized to CSS color #E0FFFF 

#### [](#.LIGHTGOLDENRODYELLOW) static constant Cesium.Color.LIGHTGOLDENRODYELLOW : [Color](Color.html) 

[engine/Source/Core/Color.js 1581](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1581) 

 An immutable Color instance initialized to CSS color #FAFAD2 

#### [](#.LIGHTGRAY) static constant Cesium.Color.LIGHTGRAY : [Color](Color.html) 

[engine/Source/Core/Color.js 1590](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1590) 

 An immutable Color instance initialized to CSS color #D3D3D3 

#### [](#.LIGHTGREEN) static constant Cesium.Color.LIGHTGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1599](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1599) 

 An immutable Color instance initialized to CSS color #90EE90 

#### [](#.LIGHTGREY) static constant Cesium.Color.LIGHTGREY : [Color](Color.html) 

[engine/Source/Core/Color.js 1608](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1608) 

 An immutable Color instance initialized to CSS color #D3D3D3 

#### [](#.LIGHTPINK) static constant Cesium.Color.LIGHTPINK : [Color](Color.html) 

[engine/Source/Core/Color.js 1617](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1617) 

 An immutable Color instance initialized to CSS color #FFB6C1 

#### [](#.LIGHTSEAGREEN) static constant Cesium.Color.LIGHTSEAGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1626](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1626) 

 An immutable Color instance initialized to CSS color #20B2AA 

#### [](#.LIGHTSKYBLUE) static constant Cesium.Color.LIGHTSKYBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1635](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1635) 

 An immutable Color instance initialized to CSS color #87CEFA 

#### [](#.LIGHTSLATEGRAY) static constant Cesium.Color.LIGHTSLATEGRAY : [Color](Color.html) 

[engine/Source/Core/Color.js 1644](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1644) 

 An immutable Color instance initialized to CSS color #778899 

#### [](#.LIGHTSLATEGREY) static constant Cesium.Color.LIGHTSLATEGREY : [Color](Color.html) 

[engine/Source/Core/Color.js 1653](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1653) 

 An immutable Color instance initialized to CSS color #778899 

#### [](#.LIGHTSTEELBLUE) static constant Cesium.Color.LIGHTSTEELBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1662](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1662) 

 An immutable Color instance initialized to CSS color #B0C4DE 

#### [](#.LIGHTYELLOW) static constant Cesium.Color.LIGHTYELLOW : [Color](Color.html) 

[engine/Source/Core/Color.js 1671](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1671) 

 An immutable Color instance initialized to CSS color #FFFFE0 

#### [](#.LIME) static constant Cesium.Color.LIME : [Color](Color.html) 

[engine/Source/Core/Color.js 1680](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1680) 

 An immutable Color instance initialized to CSS color #00FF00 

#### [](#.LIMEGREEN) static constant Cesium.Color.LIMEGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1689](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1689) 

 An immutable Color instance initialized to CSS color #32CD32 

#### [](#.LINEN) static constant Cesium.Color.LINEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1698](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1698) 

 An immutable Color instance initialized to CSS color #FAF0E6 

#### [](#.MAGENTA) static constant Cesium.Color.MAGENTA : [Color](Color.html) 

[engine/Source/Core/Color.js 1707](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1707) 

 An immutable Color instance initialized to CSS color #FF00FF 

#### [](#.MAROON) static constant Cesium.Color.MAROON : [Color](Color.html) 

[engine/Source/Core/Color.js 1716](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1716) 

 An immutable Color instance initialized to CSS color #800000 

#### [](#.MEDIUMAQUAMARINE) static constant Cesium.Color.MEDIUMAQUAMARINE : [Color](Color.html) 

[engine/Source/Core/Color.js 1725](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1725) 

 An immutable Color instance initialized to CSS color #66CDAA 

#### [](#.MEDIUMBLUE) static constant Cesium.Color.MEDIUMBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1734](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1734) 

 An immutable Color instance initialized to CSS color #0000CD 

#### [](#.MEDIUMORCHID) static constant Cesium.Color.MEDIUMORCHID : [Color](Color.html) 

[engine/Source/Core/Color.js 1743](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1743) 

 An immutable Color instance initialized to CSS color #BA55D3 

#### [](#.MEDIUMPURPLE) static constant Cesium.Color.MEDIUMPURPLE : [Color](Color.html) 

[engine/Source/Core/Color.js 1752](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1752) 

 An immutable Color instance initialized to CSS color #9370DB 

#### [](#.MEDIUMSEAGREEN) static constant Cesium.Color.MEDIUMSEAGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1761](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1761) 

 An immutable Color instance initialized to CSS color #3CB371 

#### [](#.MEDIUMSLATEBLUE) static constant Cesium.Color.MEDIUMSLATEBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1770](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1770) 

 An immutable Color instance initialized to CSS color #7B68EE 

#### [](#.MEDIUMSPRINGGREEN) static constant Cesium.Color.MEDIUMSPRINGGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1779](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1779) 

 An immutable Color instance initialized to CSS color #00FA9A 

#### [](#.MEDIUMTURQUOISE) static constant Cesium.Color.MEDIUMTURQUOISE : [Color](Color.html) 

[engine/Source/Core/Color.js 1788](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1788) 

 An immutable Color instance initialized to CSS color #48D1CC 

#### [](#.MEDIUMVIOLETRED) static constant Cesium.Color.MEDIUMVIOLETRED : [Color](Color.html) 

[engine/Source/Core/Color.js 1797](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1797) 

 An immutable Color instance initialized to CSS color #C71585 

#### [](#.MIDNIGHTBLUE) static constant Cesium.Color.MIDNIGHTBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1806](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1806) 

 An immutable Color instance initialized to CSS color #191970 

#### [](#.MINTCREAM) static constant Cesium.Color.MINTCREAM : [Color](Color.html) 

[engine/Source/Core/Color.js 1815](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1815) 

 An immutable Color instance initialized to CSS color #F5FFFA 

#### [](#.MISTYROSE) static constant Cesium.Color.MISTYROSE : [Color](Color.html) 

[engine/Source/Core/Color.js 1824](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1824) 

 An immutable Color instance initialized to CSS color #FFE4E1 

#### [](#.MOCCASIN) static constant Cesium.Color.MOCCASIN : [Color](Color.html) 

[engine/Source/Core/Color.js 1833](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1833) 

 An immutable Color instance initialized to CSS color #FFE4B5 

#### [](#.NAVAJOWHITE) static constant Cesium.Color.NAVAJOWHITE : [Color](Color.html) 

[engine/Source/Core/Color.js 1842](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1842) 

 An immutable Color instance initialized to CSS color #FFDEAD 

#### [](#.NAVY) static constant Cesium.Color.NAVY : [Color](Color.html) 

[engine/Source/Core/Color.js 1851](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1851) 

 An immutable Color instance initialized to CSS color #000080 

#### [](#.OLDLACE) static constant Cesium.Color.OLDLACE : [Color](Color.html) 

[engine/Source/Core/Color.js 1860](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1860) 

 An immutable Color instance initialized to CSS color #FDF5E6 

#### [](#.OLIVE) static constant Cesium.Color.OLIVE : [Color](Color.html) 

[engine/Source/Core/Color.js 1869](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1869) 

 An immutable Color instance initialized to CSS color #808000 

#### [](#.OLIVEDRAB) static constant Cesium.Color.OLIVEDRAB : [Color](Color.html) 

[engine/Source/Core/Color.js 1878](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1878) 

 An immutable Color instance initialized to CSS color #6B8E23 

#### [](#.ORANGE) static constant Cesium.Color.ORANGE : [Color](Color.html) 

[engine/Source/Core/Color.js 1887](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1887) 

 An immutable Color instance initialized to CSS color #FFA500 

#### [](#.ORANGERED) static constant Cesium.Color.ORANGERED : [Color](Color.html) 

[engine/Source/Core/Color.js 1896](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1896) 

 An immutable Color instance initialized to CSS color #FF4500 

#### [](#.ORCHID) static constant Cesium.Color.ORCHID : [Color](Color.html) 

[engine/Source/Core/Color.js 1905](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1905) 

 An immutable Color instance initialized to CSS color #DA70D6 

#### [](#.packedLength) static Cesium.Color.packedLength : number 

[engine/Source/Core/Color.js 443](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L443) 

 The number of elements used to pack the object into an array.

#### [](#.PALEGOLDENROD) static constant Cesium.Color.PALEGOLDENROD : [Color](Color.html) 

[engine/Source/Core/Color.js 1914](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1914) 

 An immutable Color instance initialized to CSS color #EEE8AA 

#### [](#.PALEGREEN) static constant Cesium.Color.PALEGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 1923](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1923) 

 An immutable Color instance initialized to CSS color #98FB98 

#### [](#.PALETURQUOISE) static constant Cesium.Color.PALETURQUOISE : [Color](Color.html) 

[engine/Source/Core/Color.js 1932](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1932) 

 An immutable Color instance initialized to CSS color #AFEEEE 

#### [](#.PALEVIOLETRED) static constant Cesium.Color.PALEVIOLETRED : [Color](Color.html) 

[engine/Source/Core/Color.js 1941](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1941) 

 An immutable Color instance initialized to CSS color #DB7093 

#### [](#.PAPAYAWHIP) static constant Cesium.Color.PAPAYAWHIP : [Color](Color.html) 

[engine/Source/Core/Color.js 1950](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1950) 

 An immutable Color instance initialized to CSS color #FFEFD5 

#### [](#.PEACHPUFF) static constant Cesium.Color.PEACHPUFF : [Color](Color.html) 

[engine/Source/Core/Color.js 1959](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1959) 

 An immutable Color instance initialized to CSS color #FFDAB9 

#### [](#.PERU) static constant Cesium.Color.PERU : [Color](Color.html) 

[engine/Source/Core/Color.js 1968](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1968) 

 An immutable Color instance initialized to CSS color #CD853F 

#### [](#.PINK) static constant Cesium.Color.PINK : [Color](Color.html) 

[engine/Source/Core/Color.js 1977](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1977) 

 An immutable Color instance initialized to CSS color #FFC0CB 

#### [](#.PLUM) static constant Cesium.Color.PLUM : [Color](Color.html) 

[engine/Source/Core/Color.js 1986](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1986) 

 An immutable Color instance initialized to CSS color #DDA0DD 

#### [](#.POWDERBLUE) static constant Cesium.Color.POWDERBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 1995](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L1995) 

 An immutable Color instance initialized to CSS color #B0E0E6 

#### [](#.PURPLE) static constant Cesium.Color.PURPLE : [Color](Color.html) 

[engine/Source/Core/Color.js 2004](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2004) 

 An immutable Color instance initialized to CSS color #800080 

#### [](#.RED) static constant Cesium.Color.RED : [Color](Color.html) 

[engine/Source/Core/Color.js 2013](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2013) 

 An immutable Color instance initialized to CSS color #FF0000 

#### [](#.ROSYBROWN) static constant Cesium.Color.ROSYBROWN : [Color](Color.html) 

[engine/Source/Core/Color.js 2022](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2022) 

 An immutable Color instance initialized to CSS color #BC8F8F 

#### [](#.ROYALBLUE) static constant Cesium.Color.ROYALBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 2031](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2031) 

 An immutable Color instance initialized to CSS color #4169E1 

#### [](#.SADDLEBROWN) static constant Cesium.Color.SADDLEBROWN : [Color](Color.html) 

[engine/Source/Core/Color.js 2040](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2040) 

 An immutable Color instance initialized to CSS color #8B4513 

#### [](#.SALMON) static constant Cesium.Color.SALMON : [Color](Color.html) 

[engine/Source/Core/Color.js 2049](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2049) 

 An immutable Color instance initialized to CSS color #FA8072 

#### [](#.SANDYBROWN) static constant Cesium.Color.SANDYBROWN : [Color](Color.html) 

[engine/Source/Core/Color.js 2058](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2058) 

 An immutable Color instance initialized to CSS color #F4A460 

#### [](#.SEAGREEN) static constant Cesium.Color.SEAGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 2067](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2067) 

 An immutable Color instance initialized to CSS color #2E8B57 

#### [](#.SEASHELL) static constant Cesium.Color.SEASHELL : [Color](Color.html) 

[engine/Source/Core/Color.js 2076](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2076) 

 An immutable Color instance initialized to CSS color #FFF5EE 

#### [](#.SIENNA) static constant Cesium.Color.SIENNA : [Color](Color.html) 

[engine/Source/Core/Color.js 2085](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2085) 

 An immutable Color instance initialized to CSS color #A0522D 

#### [](#.SILVER) static constant Cesium.Color.SILVER : [Color](Color.html) 

[engine/Source/Core/Color.js 2094](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2094) 

 An immutable Color instance initialized to CSS color #C0C0C0 

#### [](#.SKYBLUE) static constant Cesium.Color.SKYBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 2103](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2103) 

 An immutable Color instance initialized to CSS color #87CEEB 

#### [](#.SLATEBLUE) static constant Cesium.Color.SLATEBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 2112](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2112) 

 An immutable Color instance initialized to CSS color #6A5ACD 

#### [](#.SLATEGRAY) static constant Cesium.Color.SLATEGRAY : [Color](Color.html) 

[engine/Source/Core/Color.js 2121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2121) 

 An immutable Color instance initialized to CSS color #708090 

#### [](#.SLATEGREY) static constant Cesium.Color.SLATEGREY : [Color](Color.html) 

[engine/Source/Core/Color.js 2130](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2130) 

 An immutable Color instance initialized to CSS color #708090 

#### [](#.SNOW) static constant Cesium.Color.SNOW : [Color](Color.html) 

[engine/Source/Core/Color.js 2139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2139) 

 An immutable Color instance initialized to CSS color #FFFAFA 

#### [](#.SPRINGGREEN) static constant Cesium.Color.SPRINGGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 2148](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2148) 

 An immutable Color instance initialized to CSS color #00FF7F 

#### [](#.STEELBLUE) static constant Cesium.Color.STEELBLUE : [Color](Color.html) 

[engine/Source/Core/Color.js 2157](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2157) 

 An immutable Color instance initialized to CSS color #4682B4 

#### [](#.TAN) static constant Cesium.Color.TAN : [Color](Color.html) 

[engine/Source/Core/Color.js 2166](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2166) 

 An immutable Color instance initialized to CSS color #D2B48C 

#### [](#.TEAL) static constant Cesium.Color.TEAL : [Color](Color.html) 

[engine/Source/Core/Color.js 2175](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2175) 

 An immutable Color instance initialized to CSS color #008080 

#### [](#.THISTLE) static constant Cesium.Color.THISTLE : [Color](Color.html) 

[engine/Source/Core/Color.js 2184](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2184) 

 An immutable Color instance initialized to CSS color #D8BFD8 

#### [](#.TOMATO) static constant Cesium.Color.TOMATO : [Color](Color.html) 

[engine/Source/Core/Color.js 2193](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2193) 

 An immutable Color instance initialized to CSS color #FF6347 

#### [](#.TRANSPARENT) static constant Cesium.Color.TRANSPARENT : [Color](Color.html) 

[engine/Source/Core/Color.js 2265](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2265) 

 An immutable Color instance initialized to CSS transparent. 

#### [](#.TURQUOISE) static constant Cesium.Color.TURQUOISE : [Color](Color.html) 

[engine/Source/Core/Color.js 2202](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2202) 

 An immutable Color instance initialized to CSS color #40E0D0 

#### [](#.VIOLET) static constant Cesium.Color.VIOLET : [Color](Color.html) 

[engine/Source/Core/Color.js 2211](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2211) 

 An immutable Color instance initialized to CSS color #EE82EE 

#### [](#.WHEAT) static constant Cesium.Color.WHEAT : [Color](Color.html) 

[engine/Source/Core/Color.js 2220](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2220) 

 An immutable Color instance initialized to CSS color #F5DEB3 

#### [](#.WHITE) static constant Cesium.Color.WHITE : [Color](Color.html) 

[engine/Source/Core/Color.js 2229](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2229) 

 An immutable Color instance initialized to CSS color #FFFFFF 

#### [](#.WHITESMOKE) static constant Cesium.Color.WHITESMOKE : [Color](Color.html) 

[engine/Source/Core/Color.js 2238](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2238) 

 An immutable Color instance initialized to CSS color #F5F5F5 

#### [](#.YELLOW) static constant Cesium.Color.YELLOW : [Color](Color.html) 

[engine/Source/Core/Color.js 2247](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2247) 

 An immutable Color instance initialized to CSS color #FFFF00 

#### [](#.YELLOWGREEN) static constant Cesium.Color.YELLOWGREEN : [Color](Color.html) 

[engine/Source/Core/Color.js 2256](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L2256) 

 An immutable Color instance initialized to CSS color #9ACD32 

#### [](#alpha) alpha : number 

[engine/Source/Core/Color.js 63](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L63) 

 The alpha component.

Default Value: `1.0` 

#### [](#blue) blue : number 

[engine/Source/Core/Color.js 57](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L57) 

 The blue component.

Default Value: `1.0` 

#### [](#green) green : number 

[engine/Source/Core/Color.js 51](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L51) 

 The green component.

Default Value: `1.0` 

#### [](#red) red : number 

[engine/Source/Core/Color.js 45](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L45) 

 The red component.

Default Value: `1.0` 

### Methods

#### [](#.add) static Cesium.Color.add(left, right, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 775](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L775) 

 Computes the componentwise sum of two Colors.

| Name   | Type                | Description                                |
| ------ | ------------------- | ------------------------------------------ |
| left   | [Color](Color.html) | The first Color.                           |
| right  | [Color](Color.html) | The second Color.                          |
| result | [Color](Color.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.byteToFloat) static Cesium.Color.byteToFloat(number) → number 

[engine/Source/Core/Color.js 500](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L500) 

 Converts a 'byte' color component in the range of 0 to 255 into a 'float' color component in the range of 0 to 1.0.

| Name   | Type   | Description                 |
| ------ | ------ | --------------------------- |
| number | number | The number to be converted. |

##### Returns:

 The converted number.

#### [](#.clone) static Cesium.Color.clone(color, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 522](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L522) 

 Duplicates a Color.

| Name   | Type                | Description                                                                              |
| ------ | ------------------- | ---------------------------------------------------------------------------------------- |
| color  | [Color](Color.html) | The Color to duplicate.                                                                  |
| result | [Color](Color.html) | optional The object to store the result in, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter or a new instance if result was undefined. (Returns undefined if color is undefined)

#### [](#.divide) static Cesium.Color.divide(left, right, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 841](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L841) 

 Computes the componentwise quotient of two Colors.

| Name   | Type                | Description                                |
| ------ | ------------------- | ------------------------------------------ |
| left   | [Color](Color.html) | The first Color.                           |
| right  | [Color](Color.html) | The second Color.                          |
| result | [Color](Color.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.divideByScalar) static Cesium.Color.divideByScalar(color, scalar, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 931](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L931) 

 Divides the provided Color componentwise by the provided scalar.

| Name   | Type                | Description                                |
| ------ | ------------------- | ------------------------------------------ |
| color  | [Color](Color.html) | The Color to be divided.                   |
| scalar | number              | The scalar to divide with.                 |
| result | [Color](Color.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.equals) static Cesium.Color.equals(left, right) → boolean 

[engine/Source/Core/Color.js 543](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L543) 

 Returns true if the first Color equals the second color.

| Name  | Type                | Description                                        |
| ----- | ------------------- | -------------------------------------------------- |
| left  | [Color](Color.html) | optional The first Color to compare for equality.  |
| right | [Color](Color.html) | optional The second Color to compare for equality. |

##### Returns:

`true` if the Colors are equal; otherwise, `false`.

#### [](#.floatToByte) static Cesium.Color.floatToByte(number) → number 

[engine/Source/Core/Color.js 511](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L511) 

 Converts a 'float' color component in the range of 0 to 1.0 into a 'byte' color component in the range of 0 to 255.

| Name   | Type   | Description                 |
| ------ | ------ | --------------------------- |
| number | number | The number to be converted. |

##### Returns:

 The converted number.

#### [](#.fromAlpha) static Cesium.Color.fromAlpha(color, alpha, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 129](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L129) 

 Creates a new Color that has the same red, green, and blue components of the specified color, but with the specified alpha value.

| Name   | Type                | Description                                         |
| ------ | ------------------- | --------------------------------------------------- |
| color  | [Color](Color.html) | The base color                                      |
| alpha  | number              | The new alpha component.                            |
| result | [Color](Color.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Color instance if one was not provided.

##### Example:

```javascript
const translucentRed = Cesium.Color.fromAlpha(Cesium.Color.RED, 0.9);
```

#### [](#.fromBytes) static Cesium.Color.fromBytes(red, green, blue, alpha, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 101](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L101) 

 Creates a new Color specified using red, green, blue, and alpha values that are in the range of 0 to 255, converting them internally to a range of 0.0 to 1.0.

| Name   | Type                | Default | Description                                         |
| ------ | ------------------- | ------- | --------------------------------------------------- |
| red    | number              | 255     | optional The red component.                         |
| green  | number              | 255     | optional The green component.                       |
| blue   | number              | 255     | optional The blue component.                        |
| alpha  | number              | 255     | optional The alpha component.                       |
| result | [Color](Color.html) |         | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Color instance if one was not provided.

#### [](#.fromCartesian4) static Cesium.Color.fromCartesian4(cartesian, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 74](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L74) 

 Creates a Color instance from a [Cartesian4](Cartesian4.html). `x`, `y`, `z`, and `w` map to `red`, `green`, `blue`, and `alpha`, respectively.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The source cartesian.                               |
| result    | [Color](Color.html)           | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Color instance if one was not provided.

#### [](#.fromCssColorString) static Cesium.Color.fromCssColorString(color, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 376](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L376) 

 Creates a Color instance from a CSS color value.

| Name   | Type                | Description                                                                                     |
| ------ | ------------------- | ----------------------------------------------------------------------------------------------- |
| color  | string              | The CSS color value in #rgb, #rgba, #rrggbb, #rrggbbaa, rgb(), rgba(), hsl(), or hsla() format. |
| result | [Color](Color.html) | optional The object to store the result in, if undefined a new instance will be created.        |

##### Returns:

 The color object, or undefined if the string was not a valid CSS color.

##### Example:

```javascript
const cesiumBlue = Cesium.Color.fromCssColorString('#67ADDF');
const green = Cesium.Color.fromCssColorString('green');
```

##### See:

* [CSS color values](http://www.w3.org/TR/css3-color)

#### [](#.fromHsl) static Cesium.Color.fromHsl(hue, saturation, lightness, alpha, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 192](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L192) 

 Creates a Color instance from hue, saturation, and lightness.

| Name       | Type                | Default | Description                                                                              |
| ---------- | ------------------- | ------- | ---------------------------------------------------------------------------------------- |
| hue        | number              | 0       | optional The hue angle 0...1                                                             |
| saturation | number              | 0       | optional The saturation value 0...1                                                      |
| lightness  | number              | 0       | optional The lightness value 0...1                                                       |
| alpha      | number              | 1.0     | optional The alpha component 0...1                                                       |
| result     | [Color](Color.html) |         | optional The object to store the result in, if undefined a new instance will be created. |

##### Returns:

 The color object.

##### See:

* [CSS color values](http://www.w3.org/TR/css3-color/#hsl-color)

#### [](#.fromRandom) static Cesium.Color.fromRandom(options, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 271](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L271) 

 Creates a random color using the provided options. For reproducible random colors, you should call `CesiumMath#setRandomNumberSeed` once at the beginning of your application.

| Name    | Type                | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| ------- | ------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object              | optional Object with the following properties: Name Type Default Description red number optional If specified, the red component to use instead of a randomized value. minimumRed number 0.0 optional The maximum red value to generate if none was specified. maximumRed number 1.0 optional The minimum red value to generate if none was specified. green number optional If specified, the green component to use instead of a randomized value. minimumGreen number 0.0 optional The maximum green value to generate if none was specified. maximumGreen number 1.0 optional The minimum green value to generate if none was specified. blue number optional If specified, the blue component to use instead of a randomized value. minimumBlue number 0.0 optional The maximum blue value to generate if none was specified. maximumBlue number 1.0 optional The minimum blue value to generate if none was specified. alpha number optional If specified, the alpha component to use instead of a randomized value. minimumAlpha number 0.0 optional The maximum alpha value to generate if none was specified. maximumAlpha number 1.0 optional The minimum alpha value to generate if none was specified. |
| result  | [Color](Color.html) | optional The object to store the result in, if undefined a new instance will be created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |

##### Returns:

 The modified result parameter or a new instance if result was undefined.

##### Throws:

* [DeveloperError](DeveloperError.html): minimumRed must be less than or equal to maximumRed.
* [DeveloperError](DeveloperError.html): minimumGreen must be less than or equal to maximumGreen.
* [DeveloperError](DeveloperError.html): minimumBlue must be less than or equal to maximumBlue.
* [DeveloperError](DeveloperError.html): minimumAlpha must be less than or equal to maximumAlpha.

##### Example:

```javascript
//Create a completely random color
const color = Cesium.Color.fromRandom();

//Create a random shade of yellow.
const color1 = Cesium.Color.fromRandom({
    red : 1.0,
    green : 1.0,
    alpha : 1.0
});

//Create a random bright color.
const color2 = Cesium.Color.fromRandom({
    minimumRed : 0.75,
    minimumGreen : 0.75,
    minimumBlue : 0.75,
    alpha : 1.0
});
```

#### [](#.fromRgba) static Cesium.Color.fromRgba(rgba, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L168) 

 Creates a new Color from a single numeric unsigned 32-bit RGBA value, using the endianness of the system.

| Name   | Type                | Description                                                                              |
| ------ | ------------------- | ---------------------------------------------------------------------------------------- |
| rgba   | number              | A single numeric unsigned 32-bit RGBA value.                                             |
| result | [Color](Color.html) | optional The object to store the result in, if undefined a new instance will be created. |

##### Returns:

 The color object.

##### Example:

```javascript
const color = Cesium.Color.fromRgba(0x67ADDFFF);
```

##### See:

* [Color#toRgba](Color.html#toRgba)

#### [](#.lerp) static Cesium.Color.lerp(start, end, t, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 886](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L886) 

 Computes the linear interpolation or extrapolation at t between the provided colors.

| Name   | Type                | Description                                |
| ------ | ------------------- | ------------------------------------------ |
| start  | [Color](Color.html) | The color corresponding to t at 0.0.       |
| end    | [Color](Color.html) | The color corresponding to t at 1.0.       |
| t      | number              | The point along t at which to interpolate. |
| result | [Color](Color.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.mod) static Cesium.Color.mod(left, right, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 863](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L863) 

 Computes the componentwise modulus of two Colors.

| Name   | Type                | Description                                |
| ------ | ------------------- | ------------------------------------------ |
| left   | [Color](Color.html) | The first Color.                           |
| right  | [Color](Color.html) | The second Color.                          |
| result | [Color](Color.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiply) static Cesium.Color.multiply(left, right, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 819](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L819) 

 Computes the componentwise product of two Colors.

| Name   | Type                | Description                                |
| ------ | ------------------- | ------------------------------------------ |
| left   | [Color](Color.html) | The first Color.                           |
| right  | [Color](Color.html) | The second Color.                          |
| result | [Color](Color.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiplyByScalar) static Cesium.Color.multiplyByScalar(color, scalar, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 909](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L909) 

 Multiplies the provided Color componentwise by the provided scalar.

| Name   | Type                | Description                                |
| ------ | ------------------- | ------------------------------------------ |
| color  | [Color](Color.html) | The Color to be scaled.                    |
| scalar | number              | The scalar to multiply with.               |
| result | [Color](Color.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.pack) static Cesium.Color.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/Color.js 454](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L454) 

 Stores the provided instance into the provided array.

| Name          | Type                | Default | Description                                                               |
| ------------- | ------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [Color](Color.html) |         | The value to pack.                                                        |
| array         | Array.<number>      |         | The array to pack into.                                                   |
| startingIndex | number              | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.subtract) static Cesium.Color.subtract(left, right, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 797](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L797) 

 Computes the componentwise difference of two Colors.

| Name   | Type                | Description                                |
| ------ | ------------------- | ------------------------------------------ |
| left   | [Color](Color.html) | The first Color.                           |
| right  | [Color](Color.html) | The second Color.                          |
| result | [Color](Color.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.unpack) static Cesium.Color.unpack(array, startingIndex, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 477](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L477) 

 Retrieves an instance from a packed array.

| Name          | Type                | Default | Description                                                |
| ------------- | ------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>      |         | The packed array.                                          |
| startingIndex | number              | 0       | optional The starting index of the element to be unpacked. |
| result        | [Color](Color.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new Color instance if one was not provided.

#### [](#brighten) brighten(magnitude, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 713](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L713) 

 Brightens this color by the provided magnitude.

| Name      | Type                | Description                                          |
| --------- | ------------------- | ---------------------------------------------------- |
| magnitude | number              | A positive number indicating the amount to brighten. |
| result    | [Color](Color.html) | The object onto which to store the result.           |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
const brightBlue = Cesium.Color.BLUE.brighten(0.5, new Cesium.Color());
```

#### [](#clone) clone(result) → [Color](Color.html) 

[engine/Source/Core/Color.js 573](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L573) 

 Returns a duplicate of a Color instance.

| Name   | Type                | Description                                                                              |
| ------ | ------------------- | ---------------------------------------------------------------------------------------- |
| result | [Color](Color.html) | optional The object to store the result in, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter or a new instance if result was undefined.

#### [](#darken) darken(magnitude, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 738](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L738) 

 Darkens this color by the provided magnitude.

| Name      | Type                | Description                                        |
| --------- | ------------------- | -------------------------------------------------- |
| magnitude | number              | A positive number indicating the amount to darken. |
| result    | [Color](Color.html) | The object onto which to store the result.         |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
const darkBlue = Cesium.Color.BLUE.darken(0.5, new Cesium.Color());
```

#### [](#equals) equals(other) → boolean 

[engine/Source/Core/Color.js 583](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L583) 

 Returns true if this Color equals other.

| Name  | Type                | Description                                 |
| ----- | ------------------- | ------------------------------------------- |
| other | [Color](Color.html) | optional The Color to compare for equality. |

##### Returns:

`true` if the Colors are equal; otherwise, `false`.

#### [](#equalsEpsilon) equalsEpsilon(other, epsilon) → boolean 

[engine/Source/Core/Color.js 594](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L594) 

 Returns `true` if this Color equals other componentwise within the specified epsilon.

| Name    | Type                | Default | Description                                       |
| ------- | ------------------- | ------- | ------------------------------------------------- |
| other   | [Color](Color.html) |         | The Color to compare for equality.                |
| epsilon | number              | 0.0     | optional The epsilon to use for equality testing. |

##### Returns:

`true` if the Colors are equal within the specified epsilon; otherwise, `false`.

#### [](#toBytes) toBytes(result) → Array.<number> 

[engine/Source/Core/Color.js 666](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L666) 

 Converts this color to an array of red, green, blue, and alpha values that are in the range of 0 to 255.

| Name   | Type           | Description                                                                             |
| ------ | -------------- | --------------------------------------------------------------------------------------- |
| result | Array.<number> | optional The array to store the result in, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter or a new instance if result was undefined.

#### [](#toCssColorString) toCssColorString() → string 

[engine/Source/Core/Color.js 621](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L621) 

 Creates a string containing the CSS color value for this color.

##### Returns:

 The CSS equivalent of this color.

##### See:

* [CSS RGB or RGBA color values](http://www.w3.org/TR/css3-color/#rgba-color)

#### [](#toCssHexString) toCssHexString() → string 

[engine/Source/Core/Color.js 636](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L636) 

 Creates a string containing CSS hex string color value for this color.

##### Returns:

 The CSS hex string equivalent of this color.

#### [](#toRgba) toRgba() → number 

[engine/Source/Core/Color.js 694](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L694) 

 Converts this color to a single numeric unsigned 32-bit RGBA value, using the endianness of the system.

##### Returns:

 A single numeric unsigned 32-bit RGBA value.

##### Example:

```javascript
const rgba = Cesium.Color.BLUE.toRgba();
```

##### See:

* [Color.fromRgba](Color.html#.fromRgba)

#### [](#toString) toString() → string 

[engine/Source/Core/Color.js 610](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L610) 

 Creates a string representing this Color in the format '(red, green, blue, alpha)'.

##### Returns:

 A string representing this Color in the format '(red, green, blue, alpha)'.

#### [](#withAlpha) withAlpha(alpha, result) → [Color](Color.html) 

[engine/Source/Core/Color.js 763](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Color.js#L763) 

 Creates a new Color that has the same red, green, and blue components as this Color, but with the specified alpha value.

| Name   | Type                | Description                                         |
| ------ | ------------------- | --------------------------------------------------- |
| alpha  | number              | The new alpha component.                            |
| result | [Color](Color.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Color instance if one was not provided.

##### Example:

```javascript
const translucentRed = Cesium.Color.RED.withAlpha(0.9);
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

