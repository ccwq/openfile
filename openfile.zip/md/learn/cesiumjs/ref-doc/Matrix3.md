# [![](Images/CesiumLogo.png)](index.html) Matrix3 

#### [](#Matrix3) new Cesium.Matrix3(column0Row0, column1Row0, column2Row0, column0Row1, column1Row1, column2Row1, column0Row2, column1Row2, column2Row2) 

[engine/Source/Core/Matrix3.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L39) 

 A 3x3 matrix, indexable as a column-major order array. Constructor parameters are in row-major order for code readability.

| Name        | Type   | Default | Description                             |
| ----------- | ------ | ------- | --------------------------------------- |
| column0Row0 | number | 0.0     | optional The value for column 0, row 0. |
| column1Row0 | number | 0.0     | optional The value for column 1, row 0. |
| column2Row0 | number | 0.0     | optional The value for column 2, row 0. |
| column0Row1 | number | 0.0     | optional The value for column 0, row 1. |
| column1Row1 | number | 0.0     | optional The value for column 1, row 1. |
| column2Row1 | number | 0.0     | optional The value for column 2, row 1. |
| column0Row2 | number | 0.0     | optional The value for column 0, row 2. |
| column1Row2 | number | 0.0     | optional The value for column 1, row 2. |
| column2Row2 | number | 0.0     | optional The value for column 2, row 2. |

##### See:

* [Matrix3.fromArray](Matrix3.html#.fromArray)
* [Matrix3.fromColumnMajorArray](Matrix3.html#.fromColumnMajorArray)
* [Matrix3.fromRowMajorArray](Matrix3.html#.fromRowMajorArray)
* [Matrix3.fromQuaternion](Matrix3.html#.fromQuaternion)
* [Matrix3.fromHeadingPitchRoll](Matrix3.html#.fromHeadingPitchRoll)
* [Matrix3.fromScale](Matrix3.html#.fromScale)
* [Matrix3.fromUniformScale](Matrix3.html#.fromUniformScale)
* [Matrix3.fromCrossProduct](Matrix3.html#.fromCrossProduct)
* [Matrix3.fromRotationX](Matrix3.html#.fromRotationX)
* [Matrix3.fromRotationY](Matrix3.html#.fromRotationY)
* [Matrix3.fromRotationZ](Matrix3.html#.fromRotationZ)
* [Matrix2](Matrix2.html)
* [Matrix4](Matrix4.html)

### Members

#### [](#length) length : number 

[engine/Source/Core/Matrix3.js 1768](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1768) 

 Gets the number of items in the collection.

#### [](#.COLUMN0ROW0) static constant Cesium.Matrix3.COLUMN0ROW0 : number 

[engine/Source/Core/Matrix3.js 1695](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1695) 

 The index into Matrix3 for column 0, row 0.

#### [](#.COLUMN0ROW1) static constant Cesium.Matrix3.COLUMN0ROW1 : number 

[engine/Source/Core/Matrix3.js 1703](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1703) 

 The index into Matrix3 for column 0, row 1.

#### [](#.COLUMN0ROW2) static constant Cesium.Matrix3.COLUMN0ROW2 : number 

[engine/Source/Core/Matrix3.js 1711](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1711) 

 The index into Matrix3 for column 0, row 2.

#### [](#.COLUMN1ROW0) static constant Cesium.Matrix3.COLUMN1ROW0 : number 

[engine/Source/Core/Matrix3.js 1719](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1719) 

 The index into Matrix3 for column 1, row 0.

#### [](#.COLUMN1ROW1) static constant Cesium.Matrix3.COLUMN1ROW1 : number 

[engine/Source/Core/Matrix3.js 1727](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1727) 

 The index into Matrix3 for column 1, row 1.

#### [](#.COLUMN1ROW2) static constant Cesium.Matrix3.COLUMN1ROW2 : number 

[engine/Source/Core/Matrix3.js 1735](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1735) 

 The index into Matrix3 for column 1, row 2.

#### [](#.COLUMN2ROW0) static constant Cesium.Matrix3.COLUMN2ROW0 : number 

[engine/Source/Core/Matrix3.js 1743](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1743) 

 The index into Matrix3 for column 2, row 0.

#### [](#.COLUMN2ROW1) static constant Cesium.Matrix3.COLUMN2ROW1 : number 

[engine/Source/Core/Matrix3.js 1751](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1751) 

 The index into Matrix3 for column 2, row 1.

#### [](#.COLUMN2ROW2) static constant Cesium.Matrix3.COLUMN2ROW2 : number 

[engine/Source/Core/Matrix3.js 1759](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1759) 

 The index into Matrix3 for column 2, row 2.

#### [](#.IDENTITY) static constant Cesium.Matrix3.IDENTITY : [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1675](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1675) 

 An immutable Matrix3 instance initialized to the identity matrix.

#### [](#.packedLength) static Cesium.Matrix3.packedLength : number 

[engine/Source/Core/Matrix3.js 65](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L65) 

 The number of elements used to pack the object into an array.

#### [](#.ZERO) static constant Cesium.Matrix3.ZERO : [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1685](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1685) 

 An immutable Matrix3 instance initialized to the zero matrix.

### Methods

#### [](#clone) clone(result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1781](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1781) 

 Duplicates the provided Matrix3 instance.

| Name   | Type                    | Description                                         |
| ------ | ----------------------- | --------------------------------------------------- |
| result | [Matrix3](Matrix3.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Matrix3 instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/Matrix3.js 1792](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1792) 

 Compares this matrix to the provided matrix componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                    | Description                          |
| ----- | ----------------------- | ------------------------------------ |
| right | [Matrix3](Matrix3.html) | optional The right hand side matrix. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(right, epsilon) → boolean 

[engine/Source/Core/Matrix3.js 1822](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1822) 

 Compares this matrix to the provided matrix componentwise and returns`true` if they are within the provided epsilon,`false` otherwise.

| Name    | Type                    | Default | Description                                       |
| ------- | ----------------------- | ------- | ------------------------------------------------- |
| right   | [Matrix3](Matrix3.html) |         | optional The right hand side matrix.              |
| epsilon | number                  | 0       | optional The epsilon to use for equality testing. |

##### Returns:

`true` if they are within the provided epsilon, `false` otherwise.

#### [](#toString) toString() → string 

[engine/Source/Core/Matrix3.js 1832](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1832) 

 Creates a string representing this Matrix with each row being on a separate line and in the format '(column0, column1, column2)'.

##### Returns:

 A string representing the provided Matrix with each row being on a separate line and in the format '(column0, column1, column2)'.

#### [](#.abs) static Cesium.Matrix3.abs(matrix, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1500](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1500) 

 Computes a matrix, which contains the absolute (unsigned) values of the provided matrix's elements.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix3](Matrix3.html) | The matrix with signed elements.           |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.add) static Cesium.Matrix3.add(left, right, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1091](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1091) 

 Computes the sum of two matrices.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| left   | [Matrix3](Matrix3.html) | The first matrix.                          |
| right  | [Matrix3](Matrix3.html) | The second matrix.                         |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.clone) static Cesium.Matrix3.clone(matrix, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 198](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L198) 

 Duplicates a Matrix3 instance.

| Name   | Type                    | Description                                         |
| ------ | ----------------------- | --------------------------------------------------- |
| matrix | [Matrix3](Matrix3.html) | The matrix to duplicate.                            |
| result | [Matrix3](Matrix3.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Matrix3 instance if one was not provided. (Returns undefined if matrix is undefined)

#### [](#.computeEigenDecomposition) static Cesium.Matrix3.computeEigenDecomposition(matrix, result) → object 

[engine/Source/Core/Matrix3.js 1451](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1451) 

 Computes the eigenvectors and eigenvalues of a symmetric matrix.

Returns a diagonal matrix and unitary matrix such that:`matrix = unitary matrix * diagonal matrix * transpose(unitary matrix)` 

The values along the diagonal of the diagonal matrix are the eigenvalues. The columns of the unitary matrix are the corresponding eigenvectors.

| Name   | Type                    | Description                                                                                                |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------------- |
| matrix | [Matrix3](Matrix3.html) | The matrix to decompose into diagonal and unitary matrix. Expected to be symmetric.                        |
| result | object                  | optional An object with unitary and diagonal properties which are matrices onto which to store the result. |

##### Returns:

 An object with unitary and diagonal properties which are the unitary and diagonal matrices, respectively.

##### Example:

```javascript
const a = //... symetric matrix
const result = {
    unitary : new Cesium.Matrix3(),
    diagonal : new Cesium.Matrix3()
};
Cesium.Matrix3.computeEigenDecomposition(a, result);

const unitaryTranspose = Cesium.Matrix3.transpose(result.unitary, new Cesium.Matrix3());
const b = Cesium.Matrix3.multiply(result.unitary, result.diagonal, new Cesium.Matrix3());
Cesium.Matrix3.multiply(b, unitaryTranspose, b); // b is now equal to a

const lambda = Cesium.Matrix3.getColumn(result.diagonal, 0, new Cesium.Cartesian3()).x;  // first eigenvalue
const v = Cesium.Matrix3.getColumn(result.unitary, 0, new Cesium.Cartesian3());          // first eigenvector
const c = Cesium.Cartesian3.multiplyByScalar(v, lambda, new Cesium.Cartesian3());        // equal to Cesium.Matrix3.multiplyByVector(a, v)
```

#### [](#.determinant) static Cesium.Matrix3.determinant(matrix) → number 

[engine/Source/Core/Matrix3.js 1525](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1525) 

 Computes the determinant of the provided matrix.

| Name   | Type                    | Description        |
| ------ | ----------------------- | ------------------ |
| matrix | [Matrix3](Matrix3.html) | The matrix to use. |

##### Returns:

 The value of the determinant of the matrix.

#### [](#.equals) static Cesium.Matrix3.equals(left, right) → boolean 

[engine/Source/Core/Matrix3.js 1623](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1623) 

 Compares the provided matrices componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                    | Description                 |
| ----- | ----------------------- | --------------------------- |
| left  | [Matrix3](Matrix3.html) | optional The first matrix.  |
| right | [Matrix3](Matrix3.html) | optional The second matrix. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.equalsEpsilon) static Cesium.Matrix3.equalsEpsilon(left, right, epsilon) → boolean 

[engine/Source/Core/Matrix3.js 1650](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1650) 

 Compares the provided matrices componentwise and returns`true` if they are within the provided epsilon,`false` otherwise.

| Name    | Type                    | Default | Description                                       |
| ------- | ----------------------- | ------- | ------------------------------------------------- |
| left    | [Matrix3](Matrix3.html) |         | optional The first matrix.                        |
| right   | [Matrix3](Matrix3.html) |         | optional The second matrix.                       |
| epsilon | number                  | 0       | optional The epsilon to use for equality testing. |

##### Returns:

`true` if left and right are within the provided epsilon, `false` otherwise.

#### [](#.fromArray) static Cesium.Matrix3.fromArray(array, startingIndex, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L249) 

 Creates a Matrix3 from 9 consecutive elements in an array.

| Name          | Type                    | Default | Description                                                                                                                  |
| ------------- | ----------------------- | ------- | ---------------------------------------------------------------------------------------------------------------------------- |
| array         | Array.<number>          |         | The array whose 9 consecutive elements correspond to the positions of the matrix. Assumes column-major order.                |
| startingIndex | number                  | 0       | optional The offset into the array of the first element, which corresponds to first column first row position in the matrix. |
| result        | [Matrix3](Matrix3.html) |         | optional The object onto which to store the result.                                                                          |

##### Returns:

 The modified result parameter or a new Matrix3 instance if one was not provided.

##### Example:

```javascript
// Create the Matrix3:
// [1.0, 2.0, 3.0]
// [1.0, 2.0, 3.0]
// [1.0, 2.0, 3.0]

const v = [1.0, 1.0, 1.0, 2.0, 2.0, 2.0, 3.0, 3.0, 3.0];
const m = Cesium.Matrix3.fromArray(v);

// Create same Matrix3 with using an offset into an array
const v2 = [0.0, 0.0, 1.0, 1.0, 1.0, 2.0, 2.0, 2.0, 3.0, 3.0, 3.0];
const m2 = Cesium.Matrix3.fromArray(v2, 2);
```

#### [](#.fromColumnMajorArray) static Cesium.Matrix3.fromColumnMajorArray(values, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 258](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L258) 

 Creates a Matrix3 instance from a column-major order array.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| values | Array.<number>          | The column-major order array.                                                                        |
| result | [Matrix3](Matrix3.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix3 instance if one was not provided.

#### [](#.fromCrossProduct) static Cesium.Matrix3.fromCrossProduct(vector, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 484](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L484) 

 Computes a Matrix3 instance representing the cross product equivalent matrix of a Cartesian3 vector.

| Name   | Type                          | Description                                                                                          |
| ------ | ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| vector | [Cartesian3](Cartesian3.html) | the vector on the left hand side of the cross product operation.                                     |
| result | [Matrix3](Matrix3.html)       | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix3 instance if one was not provided.

##### Example:

```javascript
// Creates
//   [0.0, -9.0,  8.0]
//   [9.0,  0.0, -7.0]
//   [-8.0, 7.0,  0.0]
const m = Cesium.Matrix3.fromCrossProduct(new Cesium.Cartesian3(7.0, 8.0, 9.0));
```

#### [](#.fromHeadingPitchRoll) static Cesium.Matrix3.fromHeadingPitchRoll(headingPitchRoll, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 361](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L361) 

 Computes a 3x3 rotation matrix from the provided headingPitchRoll. (see http://en.wikipedia.org/wiki/Conversion\_between\_quaternions\_and\_Euler\_angles )

| Name             | Type                                      | Description                                                                                          |
| ---------------- | ----------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| headingPitchRoll | [HeadingPitchRoll](HeadingPitchRoll.html) | the headingPitchRoll to use.                                                                         |
| result           | [Matrix3](Matrix3.html)                   | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The 3x3 rotation matrix from this headingPitchRoll.

#### [](#.fromQuaternion) static Cesium.Matrix3.fromQuaternion(quaternion, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 311](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L311) 

 Computes a 3x3 rotation matrix from the provided quaternion.

| Name       | Type                          | Description                                                                                          |
| ---------- | ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| quaternion | [Quaternion](Quaternion.html) | the quaternion to use.                                                                               |
| result     | [Matrix3](Matrix3.html)       | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The 3x3 rotation matrix from this quaternion.

#### [](#.fromRotationX) static Cesium.Matrix3.fromRotationX(angle, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 528](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L528) 

 Creates a rotation matrix around the x-axis.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| angle  | number                  | The angle, in radians, of the rotation. Positive angles are counterclockwise.                        |
| result | [Matrix3](Matrix3.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix3 instance if one was not provided.

##### Example:

```javascript
// Rotate a point 45 degrees counterclockwise around the x-axis.
const p = new Cesium.Cartesian3(5, 6, 7);
const m = Cesium.Matrix3.fromRotationX(Cesium.Math.toRadians(45.0));
const rotated = Cesium.Matrix3.multiplyByVector(m, p, new Cesium.Cartesian3());
```

#### [](#.fromRotationY) static Cesium.Matrix3.fromRotationY(angle, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 576](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L576) 

 Creates a rotation matrix around the y-axis.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| angle  | number                  | The angle, in radians, of the rotation. Positive angles are counterclockwise.                        |
| result | [Matrix3](Matrix3.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix3 instance if one was not provided.

##### Example:

```javascript
// Rotate a point 45 degrees counterclockwise around the y-axis.
const p = new Cesium.Cartesian3(5, 6, 7);
const m = Cesium.Matrix3.fromRotationY(Cesium.Math.toRadians(45.0));
const rotated = Cesium.Matrix3.multiplyByVector(m, p, new Cesium.Cartesian3());
```

#### [](#.fromRotationZ) static Cesium.Matrix3.fromRotationZ(angle, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 624](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L624) 

 Creates a rotation matrix around the z-axis.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| angle  | number                  | The angle, in radians, of the rotation. Positive angles are counterclockwise.                        |
| result | [Matrix3](Matrix3.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix3 instance if one was not provided.

##### Example:

```javascript
// Rotate a point 45 degrees counterclockwise around the z-axis.
const p = new Cesium.Cartesian3(5, 6, 7);
const m = Cesium.Matrix3.fromRotationZ(Cesium.Math.toRadians(45.0));
const rotated = Cesium.Matrix3.multiplyByVector(m, p, new Cesium.Cartesian3());
```

#### [](#.fromRowMajorArray) static Cesium.Matrix3.fromRowMajorArray(values, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 274](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L274) 

 Creates a Matrix3 instance from a row-major order array. The resulting matrix will be in column-major order.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| values | Array.<number>          | The row-major order array.                                                                           |
| result | [Matrix3](Matrix3.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix3 instance if one was not provided.

#### [](#.fromScale) static Cesium.Matrix3.fromScale(scale, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 414](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L414) 

 Computes a Matrix3 instance representing a non-uniform scale.

| Name   | Type                          | Description                                                                                          |
| ------ | ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| scale  | [Cartesian3](Cartesian3.html) | The x, y, and z scale factors.                                                                       |
| result | [Matrix3](Matrix3.html)       | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix3 instance if one was not provided.

##### Example:

```javascript
// Creates
//   [7.0, 0.0, 0.0]
//   [0.0, 8.0, 0.0]
//   [0.0, 0.0, 9.0]
const m = Cesium.Matrix3.fromScale(new Cesium.Cartesian3(7.0, 8.0, 9.0));
```

#### [](#.fromUniformScale) static Cesium.Matrix3.fromUniformScale(scale, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 449](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L449) 

 Computes a Matrix3 instance representing a uniform scale.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| scale  | number                  | The uniform scale factor.                                                                            |
| result | [Matrix3](Matrix3.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix3 instance if one was not provided.

##### Example:

```javascript
// Creates
//   [2.0, 0.0, 0.0]
//   [0.0, 2.0, 0.0]
//   [0.0, 0.0, 2.0]
const m = Cesium.Matrix3.fromUniformScale(2.0);
```

#### [](#.getColumn) static Cesium.Matrix3.getColumn(matrix, index, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Matrix3.js 734](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L734) 

 Retrieves a copy of the matrix column at the provided index as a Cartesian3 instance.

| Name   | Type                          | Description                                     |
| ------ | ----------------------------- | ----------------------------------------------- |
| matrix | [Matrix3](Matrix3.html)       | The matrix to use.                              |
| index  | number                        | The zero-based index of the column to retrieve. |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result.      |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0, 1, or 2.

#### [](#.getElementIndex) static Cesium.Matrix3.getElementIndex(column, row) → number 

[engine/Source/Core/Matrix3.js 713](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L713) 

 Computes the array index of the element at the provided row and column.

| Name   | Type   | Description                         |
| ------ | ------ | ----------------------------------- |
| column | number | The zero-based index of the column. |
| row    | number | The zero-based index of the row.    |

##### Returns:

 The index of the element at the provided row and column.

##### Throws:

* [DeveloperError](DeveloperError.html): row must be 0, 1, or 2.
* [DeveloperError](DeveloperError.html): column must be 0, 1, or 2.

##### Example:

```javascript
const myMatrix = new Cesium.Matrix3();
const column1Row0Index = Cesium.Matrix3.getElementIndex(1, 0);
const column1Row0 = myMatrix[column1Row0Index]
myMatrix[column1Row0Index] = 10.0;
```

#### [](#.getMaximumScale) static Cesium.Matrix3.getMaximumScale(matrix) → number 

[engine/Source/Core/Matrix3.js 965](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L965) 

 Computes the maximum scale assuming the matrix is an affine transformation. The maximum scale is the maximum length of the column vectors.

| Name   | Type                    | Description |
| ------ | ----------------------- | ----------- |
| matrix | [Matrix3](Matrix3.html) | The matrix. |

##### Returns:

 The maximum scale.

#### [](#.getRotation) static Cesium.Matrix3.getRotation(matrix, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1014](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1014) 

 Extracts the rotation matrix assuming the matrix is an affine transformation.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix3](Matrix3.html) | The matrix.                                |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix3.setRotation](Matrix3.html#.setRotation)

#### [](#.getRow) static Cesium.Matrix3.getRow(matrix, index, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Matrix3.js 791](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L791) 

 Retrieves a copy of the matrix row at the provided index as a Cartesian3 instance.

| Name   | Type                          | Description                                  |
| ------ | ----------------------------- | -------------------------------------------- |
| matrix | [Matrix3](Matrix3.html)       | The matrix to use.                           |
| index  | number                        | The zero-based index of the row to retrieve. |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result.   |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0, 1, or 2.

#### [](#.getScale) static Cesium.Matrix3.getScale(matrix, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Matrix3.js 938](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L938) 

 Extracts the non-uniform scale assuming the matrix is an affine transformation.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| matrix | [Matrix3](Matrix3.html)       | The matrix.                                |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix3.multiplyByScale](Matrix3.html#.multiplyByScale)
* [Matrix3.multiplyByUniformScale](Matrix3.html#.multiplyByUniformScale)
* [Matrix3.fromScale](Matrix3.html#.fromScale)
* [Matrix3.fromUniformScale](Matrix3.html#.fromUniformScale)
* [Matrix3.setScale](Matrix3.html#.setScale)
* [Matrix3.setUniformScale](Matrix3.html#.setUniformScale)

#### [](#.inverse) static Cesium.Matrix3.inverse(matrix, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1556](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1556) 

 Computes the inverse of the provided matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix3](Matrix3.html) | The matrix to invert.                      |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): matrix is not invertible.

#### [](#.inverseTranspose) static Cesium.Matrix3.inverseTranspose(matrix, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1603](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1603) 

 Computes the inverse transpose of a matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix3](Matrix3.html) | The matrix to transpose and invert.        |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiply) static Cesium.Matrix3.multiply(left, right, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1043](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1043) 

 Computes the product of two matrices.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| left   | [Matrix3](Matrix3.html) | The first matrix.                          |
| right  | [Matrix3](Matrix3.html) | The second matrix.                         |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiplyByScalar) static Cesium.Matrix3.multiplyByScalar(matrix, scalar, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1174](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1174) 

 Computes the product of a matrix and a scalar.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix3](Matrix3.html) | The matrix.                                |
| scalar | number                  | The number to multiply by.                 |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiplyByScale) static Cesium.Matrix3.multiplyByScale(matrix, scale, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1213](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1213) 

 Computes the product of a matrix times a (non-uniform) scale, as if the scale were a scale matrix.

| Name   | Type                          | Description                                   |
| ------ | ----------------------------- | --------------------------------------------- |
| matrix | [Matrix3](Matrix3.html)       | The matrix on the left-hand side.             |
| scale  | [Cartesian3](Cartesian3.html) | The non-uniform scale on the right-hand side. |
| result | [Matrix3](Matrix3.html)       | The object onto which to store the result.    |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
// Instead of Cesium.Matrix3.multiply(m, Cesium.Matrix3.fromScale(scale), m);
Cesium.Matrix3.multiplyByScale(m, scale, m);
```

##### See:

* [Matrix3.multiplyByUniformScale](Matrix3.html#.multiplyByUniformScale)
* [Matrix3.fromScale](Matrix3.html#.fromScale)
* [Matrix3.fromUniformScale](Matrix3.html#.fromUniformScale)
* [Matrix3.setScale](Matrix3.html#.setScale)
* [Matrix3.setUniformScale](Matrix3.html#.setUniformScale)
* [Matrix3.getScale](Matrix3.html#.getScale)

#### [](#.multiplyByUniformScale) static Cesium.Matrix3.multiplyByUniformScale(matrix, scale, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1252](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1252) 

 Computes the product of a matrix times a uniform scale, as if the scale were a scale matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix3](Matrix3.html) | The matrix on the left-hand side.          |
| scale  | number                  | The uniform scale on the right-hand side.  |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
// Instead of Cesium.Matrix3.multiply(m, Cesium.Matrix3.fromUniformScale(scale), m);
Cesium.Matrix3.multiplyByUniformScale(m, scale, m);
```

##### See:

* [Matrix3.multiplyByScale](Matrix3.html#.multiplyByScale)
* [Matrix3.fromScale](Matrix3.html#.fromScale)
* [Matrix3.fromUniformScale](Matrix3.html#.fromUniformScale)
* [Matrix3.setScale](Matrix3.html#.setScale)
* [Matrix3.setUniformScale](Matrix3.html#.setUniformScale)
* [Matrix3.getScale](Matrix3.html#.getScale)

#### [](#.multiplyByVector) static Cesium.Matrix3.multiplyByVector(matrix, cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Matrix3.js 1145](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1145) 

 Computes the product of a matrix and a column vector.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| matrix    | [Matrix3](Matrix3.html)       | The matrix.                                |
| cartesian | [Cartesian3](Cartesian3.html) | The column.                                |
| result    | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.negate) static Cesium.Matrix3.negate(matrix, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1279](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1279) 

 Creates a negated copy of the provided matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix3](Matrix3.html) | The matrix to negate.                      |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.pack) static Cesium.Matrix3.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/Matrix3.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L76) 

 Stores the provided instance into the provided array.

| Name          | Type                    | Default | Description                                                               |
| ------------- | ----------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [Matrix3](Matrix3.html) |         | The value to pack.                                                        |
| array         | Array.<number>          |         | The array to pack into.                                                   |
| startingIndex | number                  | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.packArray) static Cesium.Matrix3.packArray(array, result) → Array.<number> 

[engine/Source/Core/Matrix3.js 136](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L136) 

 Flattens an array of Matrix3s into an array of components. The components are stored in column-major order.

| Name   | Type                             | Description                                                                                                                                                                                                                                                             |
| ------ | -------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| array  | Array.<[Matrix3](Matrix3.html)\> | The array of matrices to pack.                                                                                                                                                                                                                                          |
| result | Array.<number>                   | optional The array onto which to store the result. If this is a typed array, it must have array.length \* 9 components, else a [DeveloperError](DeveloperError.html) will be thrown. If it is a regular array, it will be resized to have (array.length \* 9) elements. |

##### Returns:

 The packed array.

#### [](#.setColumn) static Cesium.Matrix3.setColumn(matrix, index, cartesian, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 764](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L764) 

 Computes a new matrix that replaces the specified column in the provided matrix with the provided Cartesian3 instance.

| Name      | Type                          | Description                                                          |
| --------- | ----------------------------- | -------------------------------------------------------------------- |
| matrix    | [Matrix3](Matrix3.html)       | The matrix to use.                                                   |
| index     | number                        | The zero-based index of the column to set.                           |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian whose values will be assigned to the specified column. |
| result    | [Matrix3](Matrix3.html)       | The object onto which to store the result.                           |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0, 1, or 2.

#### [](#.setRotation) static Cesium.Matrix3.setRotation(matrix, rotation, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 982](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L982) 

 Sets the rotation assuming the matrix is an affine transformation.

| Name     | Type                    | Description                                |
| -------- | ----------------------- | ------------------------------------------ |
| matrix   | [Matrix3](Matrix3.html) | The matrix.                                |
| rotation | [Matrix3](Matrix3.html) | The rotation matrix.                       |
| result   | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix3.getRotation](Matrix3.html#.getRotation)

#### [](#.setRow) static Cesium.Matrix3.setRow(matrix, index, cartesian, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 820](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L820) 

 Computes a new matrix that replaces the specified row in the provided matrix with the provided Cartesian3 instance.

| Name      | Type                          | Description                                                       |
| --------- | ----------------------------- | ----------------------------------------------------------------- |
| matrix    | [Matrix3](Matrix3.html)       | The matrix to use.                                                |
| index     | number                        | The zero-based index of the row to set.                           |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian whose values will be assigned to the specified row. |
| result    | [Matrix3](Matrix3.html)       | The object onto which to store the result.                        |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0, 1, or 2.

#### [](#.setScale) static Cesium.Matrix3.setScale(matrix, scale, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 854](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L854) 

 Computes a new matrix that replaces the scale with the provided scale. This assumes the matrix is an affine transformation.

| Name   | Type                          | Description                                               |
| ------ | ----------------------------- | --------------------------------------------------------- |
| matrix | [Matrix3](Matrix3.html)       | The matrix to use.                                        |
| scale  | [Cartesian3](Cartesian3.html) | The scale that replaces the scale of the provided matrix. |
| result | [Matrix3](Matrix3.html)       | The object onto which to store the result.                |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix3.setUniformScale](Matrix3.html#.setUniformScale)
* [Matrix3.fromScale](Matrix3.html#.fromScale)
* [Matrix3.fromUniformScale](Matrix3.html#.fromUniformScale)
* [Matrix3.multiplyByScale](Matrix3.html#.multiplyByScale)
* [Matrix3.multiplyByUniformScale](Matrix3.html#.multiplyByUniformScale)
* [Matrix3.getScale](Matrix3.html#.getScale)

#### [](#.setUniformScale) static Cesium.Matrix3.setUniformScale(matrix, scale, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 897](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L897) 

 Computes a new matrix that replaces the scale with the provided uniform scale. This assumes the matrix is an affine transformation.

| Name   | Type                    | Description                                                       |
| ------ | ----------------------- | ----------------------------------------------------------------- |
| matrix | [Matrix3](Matrix3.html) | The matrix to use.                                                |
| scale  | number                  | The uniform scale that replaces the scale of the provided matrix. |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result.                        |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix3.setScale](Matrix3.html#.setScale)
* [Matrix3.fromScale](Matrix3.html#.fromScale)
* [Matrix3.fromUniformScale](Matrix3.html#.fromUniformScale)
* [Matrix3.multiplyByScale](Matrix3.html#.multiplyByScale)
* [Matrix3.multiplyByUniformScale](Matrix3.html#.multiplyByUniformScale)
* [Matrix3.getScale](Matrix3.html#.getScale)

#### [](#.subtract) static Cesium.Matrix3.subtract(left, right, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1118](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1118) 

 Computes the difference of two matrices.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| left   | [Matrix3](Matrix3.html) | The first matrix.                          |
| right  | [Matrix3](Matrix3.html) | The second matrix.                         |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.toArray) static Cesium.Matrix3.toArray(matrix, result) → Array.<number> 

[engine/Source/Core/Matrix3.js 667](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L667) 

 Creates an Array from the provided Matrix3 instance. The array will be in column-major order.

| Name   | Type                    | Description                                        |
| ------ | ----------------------- | -------------------------------------------------- |
| matrix | [Matrix3](Matrix3.html) | The matrix to use..                                |
| result | Array.<number>          | optional The Array onto which to store the result. |

##### Returns:

 The modified Array parameter or a new Array instance if one was not provided.

#### [](#.transpose) static Cesium.Matrix3.transpose(matrix, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 1304](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L1304) 

 Computes the transpose of the provided matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix3](Matrix3.html) | The matrix to transpose.                   |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.unpack) static Cesium.Matrix3.unpack(array, startingIndex, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix3.js 105](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L105) 

 Retrieves an instance from a packed array.

| Name          | Type                    | Default | Description                                                |
| ------------- | ----------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>          |         | The packed array.                                          |
| startingIndex | number                  | 0       | optional The starting index of the element to be unpacked. |
| result        | [Matrix3](Matrix3.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new Matrix3 instance if one was not provided.

#### [](#.unpackArray) static Cesium.Matrix3.unpackArray(array, result) → Array.<[Matrix3](Matrix3.html)\> 

[engine/Source/Core/Matrix3.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix3.js#L168) 

 Unpacks an array of column-major matrix components into an array of Matrix3s.

| Name   | Type                             | Description                                        |
| ------ | -------------------------------- | -------------------------------------------------- |
| array  | Array.<number>                   | The array of components to unpack.                 |
| result | Array.<[Matrix3](Matrix3.html)\> | optional The array onto which to store the result. |

##### Returns:

 The unpacked array.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

