# [![](Images/CesiumLogo.png)](index.html) CoplanarPolygonOutlineGeometry 

#### [](#CoplanarPolygonOutlineGeometry) new Cesium.CoplanarPolygonOutlineGeometry(options) 

[engine/Source/Core/CoplanarPolygonOutlineGeometry.js 73](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonOutlineGeometry.js#L73) 

 A description of the outline of a polygon composed of arbitrary coplanar positions.

| Name    | Type   | Description                                                                                                                                                         |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description polygonHierarchy [PolygonHierarchy](PolygonHierarchy.html)  A polygon hierarchy that can include holes. |

##### Example:

```javascript
const polygonOutline = new Cesium.CoplanarPolygonOutlineGeometry({
  positions : Cesium.Cartesian3.fromDegreesArrayHeights([
     -90.0, 30.0, 0.0,
     -90.0, 30.0, 1000.0,
     -80.0, 30.0, 1000.0,
     -80.0, 30.0, 0.0
  ])
});
const geometry = Cesium.CoplanarPolygonOutlineGeometry.createGeometry(polygonOutline);
```

##### See:

* [CoplanarPolygonOutlineGeometry.createGeometry](CoplanarPolygonOutlineGeometry.html#.createGeometry)

### Members

#### [](#packedLength) packedLength : number 

[engine/Source/Core/CoplanarPolygonOutlineGeometry.js 87](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonOutlineGeometry.js#L87) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.CoplanarPolygonOutlineGeometry.createGeometry(polygonGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/CoplanarPolygonOutlineGeometry.js 192](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonOutlineGeometry.js#L192) 

 Computes the geometric representation of an arbitrary coplanar polygon, including its vertices, indices, and a bounding sphere.

| Name            | Type                                                                  | Description                   |
| --------------- | --------------------------------------------------------------------- | ----------------------------- |
| polygonGeometry | [CoplanarPolygonOutlineGeometry](CoplanarPolygonOutlineGeometry.html) | A description of the polygon. |

##### Returns:

 The computed vertices and indices.

#### [](#.fromPositions) static Cesium.CoplanarPolygonOutlineGeometry.fromPositions(options) → [CoplanarPolygonOutlineGeometry](CoplanarPolygonOutlineGeometry.html) 

[engine/Source/Core/CoplanarPolygonOutlineGeometry.js 101](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonOutlineGeometry.js#L101) 

 A description of a coplanar polygon outline from an array of positions.

| Name    | Type   | Description                                                                                                                                                                        |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of positions that defined the corner points of the polygon. |

##### Returns:

#### [](#.pack) static Cesium.CoplanarPolygonOutlineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/CoplanarPolygonOutlineGeometry.js 125](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonOutlineGeometry.js#L125) 

 Stores the provided instance into the provided array.

| Name          | Type                                                                  | Default | Description                                                               |
| ------------- | --------------------------------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [CoplanarPolygonOutlineGeometry](CoplanarPolygonOutlineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                                        |         | The array to pack into.                                                   |
| startingIndex | number                                                                | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.CoplanarPolygonOutlineGeometry.unpack(array, startingIndex, result) → [CoplanarPolygonOutlineGeometry](CoplanarPolygonOutlineGeometry.html) 

[engine/Source/Core/CoplanarPolygonOutlineGeometry.js 156](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonOutlineGeometry.js#L156) 

 Retrieves an instance from a packed array.

| Name          | Type                                                                  | Default | Description                                                |
| ------------- | --------------------------------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                                        |         | The packed array.                                          |
| startingIndex | number                                                                | 0       | optional The starting index of the element to be unpacked. |
| result        | [CoplanarPolygonOutlineGeometry](CoplanarPolygonOutlineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new CoplanarPolygonOutlineGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

