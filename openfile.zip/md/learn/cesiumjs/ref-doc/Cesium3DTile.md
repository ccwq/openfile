# [![](Images/CesiumLogo.png)](index.html) Cesium3DTile 

#### [](#Cesium3DTile) new Cesium.Cesium3DTile(tileset, baseResource, header, parent) 

[engine/Source/Scene/Cesium3DTile.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L62) 

 A tile in a [Cesium3DTileset](Cesium3DTileset.html). When a tile is first created, its content is not loaded; the content is loaded on-demand when needed based on the view.

Do not construct this directly, instead access tiles through [Cesium3DTileset#tileVisible](Cesium3DTileset.html#tileVisible).

| Name         | Type                                    | Description                       |
| ------------ | --------------------------------------- | --------------------------------- |
| tileset      | [Cesium3DTileset](Cesium3DTileset.html) | The tileset                       |
| baseResource | [Resource](Resource.html)               | The base resource for the tileset |
| header       | object                                  | The JSON header for the tile      |
| parent       | [Cesium3DTile](Cesium3DTile.html)       | The parent tile of the new tile   |

### Members

#### [](#boundingSphere) readonly boundingSphere : [BoundingSphere](BoundingSphere.html) 

[engine/Source/Scene/Cesium3DTile.js 612](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L612) 

 Get the bounding sphere derived from the tile's bounding volume.

#### [](#children) readonly children : Array.<[Cesium3DTile](Cesium3DTile.html)\> 

[engine/Source/Scene/Cesium3DTile.js 218](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L218) 

 Gets the tile's children.

#### [](#computedTransform) readonly computedTransform : [Matrix4](Matrix4.html) 

[engine/Source/Scene/Cesium3DTile.js 110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L110) 

 The final computed transform of this tile.

#### [](#content) readonly content : [Cesium3DTileContent](Cesium3DTileContent.html) 

[engine/Source/Scene/Cesium3DTile.js 566](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L566) 

 The tile's content. This represents the actual tile's payload, not the content's metadata in the tileset JSON file.

#### [](#expireDate) expireDate : [JulianDate](JulianDate.html) 

[engine/Source/Scene/Cesium3DTile.js 402](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L402) 

 The date when the content expires and new content is requested.

#### [](#expireDuration) expireDuration : number 

[engine/Source/Scene/Cesium3DTile.js 395](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L395) 

 The time in seconds after the tile's content is ready when the content expires and new content is requested.

#### [](#extras) readonly extras : object 

[engine/Source/Scene/Cesium3DTile.js 644](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L644) 

 Returns the `extras` property in the tileset JSON for this tile, which contains application specific metadata. Returns `undefined` if `extras` does not exist.

##### See:

* [Extras in the 3D Tiles specification.](https://github.com/CesiumGS/3d-tiles/tree/main/specification#specifying-extensions-and-application-specific-extras)

#### [](#geometricError) readonly geometricError : number 

[engine/Source/Scene/Cesium3DTile.js 167](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L167) 

 The error, in meters, introduced if this tile is rendered and its children are not. This is used to compute screen space error, i.e., the error measured in pixels.

#### [](#i3sNode) i3sNode : string 

[engine/Source/Scene/I3SNode.js 925](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L925) 

 Gets the I3S Node for the tile.

#### [](#parent) readonly parent : [Cesium3DTile](Cesium3DTile.html) 

[engine/Source/Scene/Cesium3DTile.js 231](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L231) 

 This tile's parent or `undefined` if this tile is the root.

When a tile's content points to an external tileset JSON file, the external tileset's root tile's parent is not `undefined`; instead, the parent references the tile (with its content pointing to an external tileset JSON file) as if the two tilesets were merged.

#### [](#tileset) readonly tileset : [Cesium3DTileset](Cesium3DTileset.html) 

[engine/Source/Scene/Cesium3DTile.js 551](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L551) 

 The tileset containing this tile.

#### [](#transform) transform : [Matrix4](Matrix4.html) 

[engine/Source/Scene/Cesium3DTile.js 83](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTile.js#L83) 

 The local transform of this tile.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

