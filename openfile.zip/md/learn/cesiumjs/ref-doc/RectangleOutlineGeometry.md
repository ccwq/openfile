# [![](Images/CesiumLogo.png)](index.html) RectangleOutlineGeometry 

#### [](#RectangleOutlineGeometry) new Cesium.RectangleOutlineGeometry(options) 

[engine/Source/Core/RectangleOutlineGeometry.js 272](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RectangleOutlineGeometry.js#L272) 

 A description of the outline of a a cartographic rectangle on an ellipsoid centered at the origin.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description rectangle [Rectangle](Rectangle.html)  A cartographic rectangle with north, south, east and west properties in radians. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid on which the rectangle lies. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The distance, in radians, between each latitude and longitude. Determines the number of positions in the buffer. height number 0.0 optional The distance in meters between the rectangle and the ellipsoid surface. rotation number 0.0 optional The rotation of the rectangle, in radians. A positive rotation is counter-clockwise. extrudedHeight number optional The distance in meters between the rectangle's extruded face and the ellipsoid surface. |

##### Throws:

* [DeveloperError](DeveloperError.html): `options.rectangle.north` must be in the interval \[`-Pi/2`, `Pi/2`\].
* [DeveloperError](DeveloperError.html): `options.rectangle.south` must be in the interval \[`-Pi/2`, `Pi/2`\].
* [DeveloperError](DeveloperError.html): `options.rectangle.east` must be in the interval \[`-Pi`, `Pi`\].
* [DeveloperError](DeveloperError.html): `options.rectangle.west` must be in the interval \[`-Pi`, `Pi`\].
* [DeveloperError](DeveloperError.html): `options.rectangle.north` must be greater than `rectangle.south`.

##### Example:

```javascript
const rectangle = new Cesium.RectangleOutlineGeometry({
  ellipsoid : Cesium.Ellipsoid.WGS84,
  rectangle : Cesium.Rectangle.fromDegrees(-80.0, 39.0, -74.0, 42.0),
  height : 10000.0
});
const geometry = Cesium.RectangleOutlineGeometry.createGeometry(rectangle);
```

##### See:

* RectangleOutlineGeometry#createGeometry

### Members

#### [](#.packedLength) static Cesium.RectangleOutlineGeometry.packedLength : number 

[engine/Source/Core/RectangleOutlineGeometry.js 312](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RectangleOutlineGeometry.js#L312) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.RectangleOutlineGeometry.createGeometry(rectangleGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/RectangleOutlineGeometry.js 424](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RectangleOutlineGeometry.js#L424) 

 Computes the geometric representation of an outline of a rectangle, including its vertices, indices, and a bounding sphere.

| Name              | Type                                                      | Description                             |
| ----------------- | --------------------------------------------------------- | --------------------------------------- |
| rectangleGeometry | [RectangleOutlineGeometry](RectangleOutlineGeometry.html) | A description of the rectangle outline. |

##### Returns:

 The computed vertices and indices.

##### Throws:

* [DeveloperError](DeveloperError.html): Rotated rectangle is invalid.

#### [](#.pack) static Cesium.RectangleOutlineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/RectangleOutlineGeometry.js 324](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RectangleOutlineGeometry.js#L324) 

 Stores the provided instance into the provided array.

| Name          | Type                                                      | Default | Description                                                               |
| ------------- | --------------------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [RectangleOutlineGeometry](RectangleOutlineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                            |         | The array to pack into.                                                   |
| startingIndex | number                                                    | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.RectangleOutlineGeometry.unpack(array, startingIndex, result) → [RectangleOutlineGeometry](RectangleOutlineGeometry.html) 

[engine/Source/Core/RectangleOutlineGeometry.js 372](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RectangleOutlineGeometry.js#L372) 

 Retrieves an instance from a packed array.

| Name          | Type                                                      | Default | Description                                                |
| ------------- | --------------------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                            |         | The packed array.                                          |
| startingIndex | number                                                    | 0       | optional The starting index of the element to be unpacked. |
| result        | [RectangleOutlineGeometry](RectangleOutlineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new Quaternion instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

