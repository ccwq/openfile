# [![](Images/CesiumLogo.png)](index.html) ScreenSpaceCameraController 

#### [](#ScreenSpaceCameraController) new Cesium.ScreenSpaceCameraController(scene) 

[engine/Source/Scene/ScreenSpaceCameraController.js 36](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L36) 

 Modifies the camera position and orientation based on mouse input to a canvas.

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| scene | [Scene](Scene.html) | The scene.  |

### Members

#### [](#bounceAnimationTime) bounceAnimationTime : number 

[engine/Source/Scene/ScreenSpaceCameraController.js 127](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L127) 

 Sets the duration, in seconds, of the bounce back animations in 2D and Columbus view.

Default Value: `3.0` 

#### [](#enableCollisionDetection) enableCollisionDetection : boolean 

[engine/Source/Scene/ScreenSpaceCameraController.js 273](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L273) 

 When disabled, the values of `maximumZoomDistance` and `minimumZoomDistance` are ignored.

Default Value: `true` 

#### [](#enableInputs) enableInputs : boolean 

[engine/Source/Scene/ScreenSpaceCameraController.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L55) 

 If true, inputs are allowed conditionally with the flags enableTranslate, enableZoom, enableRotate, enableTilt, and enableLook. If false, all inputs are disabled. NOTE: This setting is for temporary use cases, such as camera flights and drag-selection of regions (see Picking demo). It is typically set to false at the start of such events, and set true on completion. To keep inputs disabled past the end of camera flights, you must use the other booleans (enableTranslate, enableZoom, enableRotate, enableTilt, and enableLook).

Default Value: `true` 

#### [](#enableLook) enableLook : boolean 

[engine/Source/Scene/ScreenSpaceCameraController.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L89) 

 If true, allows the user to use free-look. If false, the camera view direction can only be changed through translating or rotating. This flag only applies in 3D and Columbus view modes.

Default Value: `true` 

#### [](#enableRotate) enableRotate : boolean 

[engine/Source/Scene/ScreenSpaceCameraController.js 75](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L75) 

 If true, allows the user to rotate the world which translates the user's position. This flag only applies in 2D and 3D.

Default Value: `true` 

#### [](#enableTilt) enableTilt : boolean 

[engine/Source/Scene/ScreenSpaceCameraController.js 82](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L82) 

 If true, allows the user to tilt the camera. If false, the camera is locked to the current heading. This flag only applies in 3D and Columbus view.

Default Value: `true` 

#### [](#enableTranslate) enableTranslate : boolean 

[engine/Source/Scene/ScreenSpaceCameraController.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L62) 

 If true, allows the user to pan around the map. If false, the camera stays locked at the current position. This flag only applies in 2D and Columbus view modes.

Default Value: `true` 

#### [](#enableZoom) enableZoom : boolean 

[engine/Source/Scene/ScreenSpaceCameraController.js 68](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L68) 

 If true, allows the user to zoom in and out. If false, the camera is locked to the current distance from the ellipsoid.

Default Value: `true` 

#### [](#inertiaSpin) inertiaSpin : number 

[engine/Source/Scene/ScreenSpaceCameraController.js 97](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L97) 

 A parameter in the range `[0, 1)` used to determine how long the camera will continue to spin because of inertia. With value of zero, the camera will have no inertia.

Default Value: `0.9` 

#### [](#inertiaTranslate) inertiaTranslate : number 

[engine/Source/Scene/ScreenSpaceCameraController.js 105](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L105) 

 A parameter in the range `[0, 1)` used to determine how long the camera will continue to translate because of inertia. With value of zero, the camera will have no inertia.

Default Value: `0.9` 

#### [](#inertiaZoom) inertiaZoom : number 

[engine/Source/Scene/ScreenSpaceCameraController.js 113](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L113) 

 A parameter in the range `[0, 1)` used to determine how long the camera will continue to zoom because of inertia. With value of zero, the camera will have no inertia.

Default Value: `0.8` 

#### [](#lookEventTypes) lookEventTypes : [CameraEventType](global.html#CameraEventType)|Array|undefined 

[engine/Source/Scene/ScreenSpaceCameraController.js 223](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L223) 

 The input that allows the user to change the direction the camera is viewing. This only applies in 3D and Columbus view modes.

The type can be a [CameraEventType](global.html#CameraEventType), `undefined`, an object with `eventType`and `modifier` properties with types `CameraEventType` and [KeyboardEventModifier](global.html#KeyboardEventModifier), or an array of any of the preceding.

Default Value: `{ eventType : [CameraEventType.LEFT_DRAG](global.html#CameraEventType#.LEFT%5FDRAG), modifier : [KeyboardEventModifier.SHIFT](global.html#KeyboardEventModifier#.SHIFT) }` 

#### [](#maximumMovementRatio) maximumMovementRatio : number 

[engine/Source/Scene/ScreenSpaceCameraController.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L121) 

 A parameter in the range `[0, 1)` used to limit the range of various user inputs to a percentage of the window width/height per animation frame. This helps keep the camera under control in low-frame-rate situations.

Default Value: `0.1` 

#### [](#maximumTiltAngle) maximumTiltAngle : number|undefined 

[engine/Source/Scene/ScreenSpaceCameraController.js 283](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L283) 

 The angle, relative to the ellipsoid normal, restricting the maximum amount that the user can tilt the camera. If `undefined`, the angle of the camera tilt is unrestricted.

Default Value: `undefined` 

##### Example:

```javascript
// Prevent the camera from tilting below the ellipsoid surface
viewer.scene.screenSpaceCameraController.maximumTiltAngle = Math.PI / 2.0;
```

#### [](#maximumZoomDistance) maximumZoomDistance : number 

[engine/Source/Scene/ScreenSpaceCameraController.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L139) 

 The maximum magnitude, in meters, of the camera position when zooming. Defaults to positive infinity.

Default Value: `` `Number.POSITIVE_INFINITY` `` 

#### [](#minimumCollisionTerrainHeight) minimumCollisionTerrainHeight : number 

[engine/Source/Scene/ScreenSpaceCameraController.js 254](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L254) 

 The minimum height the camera must be before testing for collision with terrain. Default to scene.ellipsoid.minimumRadius \* 0.0025 when another ellipsoid than WGS84 is used.

Default Value: `15000.0 or scene.ellipsoid.minimumRadius * 0.0025.` 

#### [](#minimumPickingTerrainDistanceWithInertia) minimumPickingTerrainDistanceWithInertia : number 

[engine/Source/Scene/ScreenSpaceCameraController.js 244](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L244) 

 The minimum distance the camera must be before testing for collision with terrain when zoom with inertia. Default to scene.ellipsoid.minimumRadius \* 0.00063 when another ellipsoid than WGS84 is used.

Default Value: `4000.0 or scene.ellipsoid.minimumRadius * 0.00063` 

#### [](#minimumPickingTerrainHeight) minimumPickingTerrainHeight : number 

[engine/Source/Scene/ScreenSpaceCameraController.js 235](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L235) 

 The minimum height the camera must be before picking the terrain or scene content instead of the ellipsoid. Defaults to scene.ellipsoid.minimumRadius \* 0.025 when another ellipsoid than WGS84 is used.

Default Value: `150000.0 or scene.ellipsoid.minimumRadius * 0.025` 

#### [](#minimumTrackBallHeight) minimumTrackBallHeight : number 

[engine/Source/Scene/ScreenSpaceCameraController.js 264](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L264) 

 The minimum height the camera must be before switching from rotating a track ball to free look when clicks originate on the sky or in space. Defaults to ellipsoid.minimumRadius \* 1.175 when another ellipsoid than WGS84 is used.

Default Value: `7500000.0 or scene.ellipsoid.minimumRadius * 1.175` 

#### [](#minimumZoomDistance) minimumZoomDistance : number 

[engine/Source/Scene/ScreenSpaceCameraController.js 133](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L133) 

 The minimum magnitude, in meters, of the camera position when zooming. Defaults to 1.0.

Default Value: `1.0` 

#### [](#rotateEventTypes) rotateEventTypes : [CameraEventType](global.html#CameraEventType)|Array|undefined 

[engine/Source/Scene/ScreenSpaceCameraController.js 184](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L184) 

 The input that allows the user to rotate around the globe or another object. This only applies in 3D and Columbus view modes.

The type can be a [CameraEventType](global.html#CameraEventType), `undefined`, an object with `eventType`and `modifier` properties with types `CameraEventType` and [KeyboardEventModifier](global.html#KeyboardEventModifier), or an array of any of the preceding.

Default Value: `[CameraEventType.LEFT_DRAG](global.html#CameraEventType#.LEFT%5FDRAG)` 

#### [](#tiltEventTypes) tiltEventTypes : [CameraEventType](global.html#CameraEventType)|Array|undefined 

[engine/Source/Scene/ScreenSpaceCameraController.js 201](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L201) 

 The input that allows the user to tilt in 3D and Columbus view or twist in 2D.

The type can be a [CameraEventType](global.html#CameraEventType), `undefined`, an object with `eventType`and `modifier` properties with types `CameraEventType` and [KeyboardEventModifier](global.html#KeyboardEventModifier), or an array of any of the preceding.

Default Value: `[[CameraEventType.MIDDLE_DRAG](global.html#CameraEventType#.MIDDLE%5FDRAG), [CameraEventType.PINCH](global.html#CameraEventType#.PINCH), { eventType : [CameraEventType.LEFT_DRAG](global.html#CameraEventType#.LEFT%5FDRAG), modifier : [KeyboardEventModifier.CTRL](global.html#KeyboardEventModifier#.CTRL)}, { eventType : [CameraEventType.RIGHT_DRAG](global.html#CameraEventType#.RIGHT%5FDRAG), modifier : [KeyboardEventModifier.CTRL](global.html#KeyboardEventModifier#.CTRL)}]` 

#### [](#translateEventTypes) translateEventTypes : [CameraEventType](global.html#CameraEventType)|Array|undefined 

[engine/Source/Scene/ScreenSpaceCameraController.js 158](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L158) 

 The input that allows the user to pan around the map. This only applies in 2D and Columbus view modes.

The type can be a [CameraEventType](global.html#CameraEventType), `undefined`, an object with `eventType`and `modifier` properties with types `CameraEventType` and [KeyboardEventModifier](global.html#KeyboardEventModifier), or an array of any of the preceding.

Default Value: `[CameraEventType.LEFT_DRAG](global.html#CameraEventType#.LEFT%5FDRAG)` 

#### [](#zoomEventTypes) zoomEventTypes : [CameraEventType](global.html#CameraEventType)|Array|undefined 

[engine/Source/Scene/ScreenSpaceCameraController.js 169](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L169) 

 The input that allows the user to zoom in/out.

The type can be a [CameraEventType](global.html#CameraEventType), `undefined`, an object with `eventType`and `modifier` properties with types `CameraEventType` and [KeyboardEventModifier](global.html#KeyboardEventModifier), or an array of any of the preceding.

Default Value: `[[CameraEventType.RIGHT_DRAG](global.html#CameraEventType#.RIGHT%5FDRAG), [CameraEventType.WHEEL](global.html#CameraEventType#.WHEEL), [CameraEventType.PINCH](global.html#CameraEventType#.PINCH)]` 

#### [](#zoomFactor) zoomFactor : Number 

[engine/Source/Scene/ScreenSpaceCameraController.js 146](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L146) 

 A multiplier for the speed at which the camera will zoom.

Default Value: `5.0` 

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/ScreenSpaceCameraController.js 3093](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L3093) 

 Removes mouse listeners held by this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
controller = controller && controller.destroy();
```

##### See:

* [ScreenSpaceCameraController#isDestroyed](ScreenSpaceCameraController.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/ScreenSpaceCameraController.js 3074](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ScreenSpaceCameraController.js#L3074) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [ScreenSpaceCameraController#destroy](ScreenSpaceCameraController.html#destroy)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

