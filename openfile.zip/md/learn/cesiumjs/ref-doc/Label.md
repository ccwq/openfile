# [![](Images/CesiumLogo.png)](index.html) Label 

#### [](#Label) internal constructor new Cesium.Label(options, labelCollection) 

[engine/Source/Scene/Label.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L139) 

Create labels by calling [LabelCollection#add](LabelCollection.html#add). Do not call the constructor directly.

| Name            | Type                                                       | Description                              |
| --------------- | ---------------------------------------------------------- | ---------------------------------------- |
| options         | [Label.ConstructorOptions](Label.html#.ConstructorOptions) | Object describing initialization options |
| labelCollection | [LabelCollection](LabelCollection.html)                    | Instance of LabelCollection              |

##### Throws:

* [DeveloperError](DeveloperError.html): translucencyByDistance.far must be greater than translucencyByDistance.near
* [DeveloperError](DeveloperError.html): pixelOffsetScaleByDistance.far must be greater than pixelOffsetScaleByDistance.near
* [DeveloperError](DeveloperError.html): distanceDisplayCondition.far must be greater than distanceDisplayCondition.near

##### Demo:

* [Cesium Sandcastle Labels Demo](https://sandcastle.cesium.com/index.html?src=Labels.html)

##### See:

* [LabelCollection](LabelCollection.html)
* [LabelCollection#add](LabelCollection.html#add)

### Members

#### [](#.enableRightToLeftDetection) static Cesium.Label.enableRightToLeftDetection : boolean 

[engine/Source/Scene/Label.js 1450](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L1450) 

 Determines whether or not run the algorithm, that match the text of the label to right-to-left languages

Default Value: `false` 

##### Examples:

```javascript
// Example 1.
// Set a label's rightToLeft before init
Cesium.Label.enableRightToLeftDetection = true;
const myLabelEntity = viewer.entities.add({
  label: {
    id: 'my label',
    text: 'זה טקסט בעברית \n ועכשיו יורדים שורה',
  }
});
```

```javascript
// Example 2.
const myLabelEntity = viewer.entities.add({
  label: {
    id: 'my label',
    text: 'English text'
  }
});
// Set a label's rightToLeft after init
Cesium.Label.enableRightToLeftDetection = true;
myLabelEntity.text = 'טקסט חדש';
```

#### [](#backgroundColor) backgroundColor : [Color](Color.html) 

[engine/Source/Scene/Label.js 545](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L545) 

 Gets or sets the background color of this label.

Default Value: `new Color(0.165, 0.165, 0.165, 0.8)` 

#### [](#backgroundPadding) backgroundPadding : [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/Label.js 575](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L575) 

 Gets or sets the background padding, in pixels, of this label. The `x` value controls horizontal padding, and the `y` value controls vertical padding.

Default Value: `new Cartesian2(7, 5)` 

#### [](#disableDepthTestDistance) disableDepthTestDistance : number 

[engine/Source/Scene/Label.js 1073](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L1073) 

 Gets or sets the distance from the camera at which to disable the depth test to, for example, prevent clipping against terrain. When set to zero, the depth test is always applied. When set to Number.POSITIVE\_INFINITY, the depth test is never applied.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [DistanceDisplayCondition](DistanceDisplayCondition.html) 

[engine/Source/Scene/Label.js 1034](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L1034) 

 Gets or sets the condition specifying at what distance from the camera that this label will be displayed.

Default Value: `undefined` 

#### [](#eyeOffset) eyeOffset : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Label.js 857](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L857) 

 Gets and sets the 3D Cartesian offset applied to this label in eye coordinates. Eye coordinates is a left-handed coordinate system, where `x` points towards the viewer's right, `y` points up, and`z` points into the screen. Eye coordinates use the same scale as world and model coordinates, which is typically meters.  
  
An eye offset is commonly used to arrange multiple label or objects at the same position, e.g., to arrange a label above its corresponding 3D model.  
  
Below, the label is positioned at the center of the Earth but an eye offset makes it always appear on top of the Earth regardless of the viewer's or Earth's orientation.  
  
| ![](Images/Billboard.setEyeOffset.one.png) | ![](Images/Billboard.setEyeOffset.two.png) |
| ------------------------------------------ | ------------------------------------------ |

`l.eyeOffset = new Cartesian3(0.0, 8000000.0, 0.0);`  
  
Default Value: `Cartesian3.ZERO` 

#### [](#fillColor) fillColor : [Color](Color.html) 

[engine/Source/Scene/Label.js 445](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L445) 

 Gets or sets the fill color of this label.

Default Value: `Color.WHITE` 

##### See:

* [HTML canvas 2D context fill and stroke styles](http://www.whatwg.org/specs/web-apps/current-work/multipage/the-canvas-element.html#fill-and-stroke-styles)

#### [](#font) font : string 

[engine/Source/Scene/Label.js 419](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L419) 

 Gets or sets the font used to draw this label. Fonts are specified using the same syntax as the CSS 'font' property.

Default Value: `'30px sans-serif'` 

##### See:

* [HTML canvas 2D context text styles](http://www.whatwg.org/specs/web-apps/current-work/multipage/the-canvas-element.html#text-styles)

#### [](#heightReference) heightReference : [HeightReference](global.html#HeightReference) 

[engine/Source/Scene/Label.js 351](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L351) 

 Gets or sets the height reference of this billboard.

Default Value: `HeightReference.NONE` 

#### [](#horizontalOrigin) horizontalOrigin : [HorizontalOrigin](global.html#HorizontalOrigin) 

[engine/Source/Scene/Label.js 902](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L902) 

 Gets or sets the horizontal origin of this label, which determines if the label is drawn to the left, center, or right of its anchor position.  
  
![](Images/Billboard.setHorizontalOrigin.png)  

Default Value: `HorizontalOrigin.LEFT` 

##### Example:

```javascript
// Use a top, right origin
l.horizontalOrigin = Cesium.HorizontalOrigin.RIGHT;
l.verticalOrigin = Cesium.VerticalOrigin.TOP;
```

#### [](#id) id : \* 

[engine/Source/Scene/Label.js 1108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L1108) 

 Gets or sets the user-defined value returned when the label is picked.

#### [](#outlineColor) outlineColor : [Color](Color.html) 

[engine/Source/Scene/Label.js 471](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L471) 

 Gets or sets the outline color of this label.

Default Value: `Color.BLACK` 

##### See:

* [HTML canvas 2D context fill and stroke styles](http://www.whatwg.org/specs/web-apps/current-work/multipage/the-canvas-element.html#fill-and-stroke-styles)

#### [](#outlineWidth) outlineWidth : number 

[engine/Source/Scene/Label.js 497](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L497) 

 Gets or sets the outline width of this label.

Default Value: `1.0` 

##### See:

* [HTML canvas 2D context fill and stroke styles](http://www.whatwg.org/specs/web-apps/current-work/multipage/the-canvas-element.html#fill-and-stroke-styles)

#### [](#pixelOffset) pixelOffset : [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/Label.js 635](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L635) 

 Gets or sets the pixel offset in screen space from the origin of this label. This is commonly used to align multiple labels and billboards at the same position, e.g., an image and text. The screen space origin is the top, left corner of the canvas; `x` increases from left to right, and `y` increases from top to bottom.  
  
| default![](Images/Label.setPixelOffset.default.png) | l.pixeloffset = new Cartesian2(25, 75);![](Images/Label.setPixelOffset.x50y-25.png) |
| --------------------------------------------------- | ----------------------------------------------------------------------------------- |

The label's origin is indicated by the yellow point.

Default Value: `Cartesian2.ZERO` 

#### [](#pixelOffsetScaleByDistance) pixelOffsetScaleByDistance : [NearFarScalar](NearFarScalar.html) 

[engine/Source/Scene/Label.js 745](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L745) 

 Gets or sets near and far pixel offset scaling properties of a Label based on the Label's distance from the camera. A label's pixel offset will be scaled between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the label's pixel offset scaling remains clamped to the nearest bound. If undefined, pixelOffsetScaleByDistance will be disabled.

##### Examples:

```javascript
// Example 1.
// Set a label's pixel offset scale to 0.0 when the
// camera is 1500 meters from the label and scale pixel offset to 10.0 pixels
// in the y direction the camera distance approaches 8.0e6 meters.
text.pixelOffset = new Cesium.Cartesian2(0.0, 1.0);
text.pixelOffsetScaleByDistance = new Cesium.NearFarScalar(1.5e2, 0.0, 8.0e6, 10.0);
```

```javascript
// Example 2.
// disable pixel offset by distance
text.pixelOffsetScaleByDistance = undefined;
```

#### [](#position) position : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Label.js 313](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L313) 

 Gets or sets the Cartesian position of this label.

#### [](#scale) scale : number 

[engine/Source/Scene/Label.js 984](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L984) 

 Gets or sets the uniform scale that is multiplied with the label's size in pixels. A scale of `1.0` does not change the size of the label; a scale greater than`1.0` enlarges the label; a positive scale less than `1.0` shrinks the label.  
  
Applying a large scale value may pixelate the label. To make text larger without pixelation, use a larger font size when calling [Label#font](Label.html#font) instead.  
  
![](Images/Label.setScale.png)  
From left to right in the above image, the scales are `0.5`, `1.0`, and `2.0`.

Default Value: `1.0` 

#### [](#scaleByDistance) scaleByDistance : [NearFarScalar](NearFarScalar.html) 

[engine/Source/Scene/Label.js 802](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L802) 

 Gets or sets near and far scaling properties of a Label based on the label's distance from the camera. A label's scale will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the label's scale remains clamped to the nearest bound. If undefined, scaleByDistance will be disabled.

##### Examples:

```javascript
// Example 1.
// Set a label's scaleByDistance to scale by 1.5 when the
// camera is 1500 meters from the label and disappear as
// the camera distance approaches 8.0e6 meters.
label.scaleByDistance = new Cesium.NearFarScalar(1.5e2, 1.5, 8.0e6, 0.0);
```

```javascript
// Example 2.
// disable scaling by distance
label.scaleByDistance = undefined;
```

#### [](#show) show : boolean 

[engine/Source/Scene/Label.js 279](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L279) 

 Determines if this label will be shown. Use this to hide or show a label, instead of removing it and re-adding it to the collection.

Default Value: `true` 

#### [](#showBackground) showBackground : boolean 

[engine/Source/Scene/Label.js 521](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L521) 

 Determines if a background behind this label will be shown.

Default Value: `false` 

#### [](#style) style : [LabelStyle](global.html#LabelStyle) 

[engine/Source/Scene/Label.js 600](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L600) 

 Gets or sets the style of this label.

Default Value: `LabelStyle.FILL` 

#### [](#text) text : string 

[engine/Source/Scene/Label.js 389](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L389) 

 Gets or sets the text of this label.

#### [](#totalScale) totalScale : number 

[engine/Source/Scene/Label.js 1022](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L1022) 

 Gets the total scale of the label, which is the label's scale multiplied by the computed relative size of the desired font compared to the generated glyph size.

Default Value: `1.0` 

#### [](#translucencyByDistance) translucencyByDistance : [NearFarScalar](NearFarScalar.html) 

[engine/Source/Scene/Label.js 687](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L687) 

 Gets or sets near and far translucency properties of a Label based on the Label's distance from the camera. A label's translucency will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the label's translucency remains clamped to the nearest bound. If undefined, translucencyByDistance will be disabled.

##### Examples:

```javascript
// Example 1.
// Set a label's translucencyByDistance to 1.0 when the
// camera is 1500 meters from the label and disappear as
// the camera distance approaches 8.0e6 meters.
text.translucencyByDistance = new Cesium.NearFarScalar(1.5e2, 1.0, 8.0e6, 0.0);
```

```javascript
// Example 2.
// disable translucency by distance
text.translucencyByDistance = undefined;
```

#### [](#verticalOrigin) verticalOrigin : [VerticalOrigin](global.html#VerticalOrigin) 

[engine/Source/Scene/Label.js 935](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L935) 

 Gets or sets the vertical origin of this label, which determines if the label is to the above, below, or at the center of its anchor position.  
  
![](Images/Billboard.setVerticalOrigin.png)  

Default Value: `VerticalOrigin.BASELINE` 

##### Example:

```javascript
// Use a top, right origin
l.horizontalOrigin = Cesium.HorizontalOrigin.RIGHT;
l.verticalOrigin = Cesium.VerticalOrigin.TOP;
```

### Methods

#### [](#computeScreenSpacePosition) computeScreenSpacePosition(scene, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/Label.js 1226](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L1226) 

 Computes the screen-space position of the label's origin, taking into account eye and pixel offsets. The screen space origin is the top, left corner of the canvas; `x` increases from left to right, and `y` increases from top to bottom.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| scene  | [Scene](Scene.html)           | The scene the label is in.                          |
| result | [Cartesian2](Cartesian2.html) | optional The object onto which to store the result. |

##### Returns:

 The screen-space position of the label.

##### Example:

```javascript
console.log(l.computeScreenSpacePosition(scene).toString());
```

##### See:

* [Label#eyeOffset](Label.html#eyeOffset)
* [Label#pixelOffset](Label.html#pixelOffset)

#### [](#equals) equals(other) → boolean 

[engine/Source/Scene/Label.js 1370](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L1370) 

 Determines if this label equals another label. Labels are equal if all their properties are equal. Labels in different collections can be equal.

| Name  | Type                | Description                                 |
| ----- | ------------------- | ------------------------------------------- |
| other | [Label](Label.html) | optional The label to compare for equality. |

##### Returns:

`true` if the labels are equal; otherwise, `false`.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/Label.js 1417](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L1417) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

 True if this object was destroyed; otherwise, false.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.Label.ConstructorOptions

[engine/Source/Scene/Label.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Label.js#L88) 

 Initialization options for the Label constructor

##### Properties:

| Name                       | Type                                                      | Attributes | Default                             | Description                                                                                                                                               |
| -------------------------- | --------------------------------------------------------- | ---------- | ----------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| position                   | [Cartesian3](Cartesian3.html)                             |            |                                     | The cartesian position of the label.                                                                                                                      |
| id                         | \*                                                        | <optional> |                                     | A user-defined object to return when the label is picked with [Scene#pick](Scene.html#pick).                                                              |
| show                       | boolean                                                   | <optional> | true                                | Determines if this label will be shown.                                                                                                                   |
| text                       | string                                                    | <optional> |                                     | A string specifying the text of the label.                                                                                                                |
| font                       | string                                                    | <optional> | '30px sans-serif'                   | A string specifying the font used to draw this label. Fonts are specified using the same syntax as the CSS 'font' property.                               |
| style                      | [LabelStyle](global.html#LabelStyle)                      | <optional> | LabelStyle.FILL                     | A [LabelStyle](global.html#LabelStyle) specifying the style of the label.                                                                                 |
| scale                      | number                                                    | <optional> | 1.0                                 | A number specifying the uniform scale that is multiplied with the label size.                                                                             |
| showBackground             | boolean                                                   | <optional> | false                               | Determines if a background behind this label will be shown.                                                                                               |
| backgroundColor            | [Color](Color.html)                                       | <optional> | new Color(0.165, 0.165, 0.165, 0.8) | A [Color](Color.html) specifying the background color of the label.                                                                                       |
| backgroundPadding          | [Cartesian2](Cartesian2.html)                             | <optional> | new Cartesian2(7, 5)                | A [Cartesian2](Cartesian2.html) Specifying the horizontal and vertical background padding in pixels.                                                      |
| pixelOffset                | [Cartesian2](Cartesian2.html)                             | <optional> | Cartesian2.ZERO                     | A [Cartesian2](Cartesian2.html) specifying the pixel offset in screen space from the origin of this label.                                                |
| eyeOffset                  | [Cartesian3](Cartesian3.html)                             | <optional> | Cartesian3.ZERO                     | A [Cartesian3](Cartesian3.html) specifying the 3D Cartesian offset applied to this label in eye coordinates.                                              |
| horizontalOrigin           | [HorizontalOrigin](global.html#HorizontalOrigin)          | <optional> | HorizontalOrigin.LEFT               | A [HorizontalOrigin](global.html#HorizontalOrigin) specifying the horizontal origin of this label.                                                        |
| verticalOrigin             | [VerticalOrigin](global.html#VerticalOrigin)              | <optional> | VerticalOrigin.BASELINE             | A [VerticalOrigin](global.html#VerticalOrigin) specifying the vertical origin of this label.                                                              |
| heightReference            | [HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE                | A [HeightReference](global.html#HeightReference) specifying the height reference of this label.                                                           |
| fillColor                  | [Color](Color.html)                                       | <optional> | Color.WHITE                         | A [Color](Color.html) specifying the fill color of the label.                                                                                             |
| outlineColor               | [Color](Color.html)                                       | <optional> | Color.BLACK                         | A [Color](Color.html) specifying the outline color of the label.                                                                                          |
| outlineWidth               | number                                                    | <optional> | 1.0                                 | A number specifying the outline width of the label.                                                                                                       |
| translucencyByDistance     | [NearFarScalar](NearFarScalar.html)                       | <optional> |                                     | A [NearFarScalar](NearFarScalar.html) specifying near and far translucency properties of the label based on the label's distance from the camera.         |
| pixelOffsetScaleByDistance | [NearFarScalar](NearFarScalar.html)                       | <optional> |                                     | A [NearFarScalar](NearFarScalar.html) specifying near and far pixel offset scaling properties of the label based on the label's distance from the camera. |
| scaleByDistance            | [NearFarScalar](NearFarScalar.html)                       | <optional> |                                     | A [NearFarScalar](NearFarScalar.html) specifying near and far scaling properties of the label based on the label's distance from the camera.              |
| distanceDisplayCondition   | [DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                                     | A [DistanceDisplayCondition](DistanceDisplayCondition.html) specifying at what distance from the camera that this label will be displayed.                |
| disableDepthTestDistance   | number                                                    | <optional> |                                     | A number specifying the distance from the camera at which to disable the depth test to, for example, prevent clipping against terrain.                    |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

