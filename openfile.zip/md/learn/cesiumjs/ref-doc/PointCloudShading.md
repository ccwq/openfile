# [![](Images/CesiumLogo.png)](index.html) PointCloudShading 

#### [](#PointCloudShading) new Cesium.PointCloudShading(options) 

[engine/Source/Scene/PointCloudShading.js 22](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointCloudShading.js#L22) 

 Options for performing point attenuation based on geometric error when rendering point clouds using 3D Tiles.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description attenuation boolean false optional Perform point attenuation based on geometric error. geometricErrorScale number 1.0 optional Scale to be applied to each tile's geometric error. maximumAttenuation number optional Maximum attenuation in pixels. Defaults to the Cesium3DTileset's maximumScreenSpaceError. baseResolution number optional Average base resolution for the dataset in meters. Substitute for Geometric Error when not available. eyeDomeLighting boolean true optional When true, use eye dome lighting when drawing with point attenuation. eyeDomeLightingStrength number 1.0 optional Increasing this value increases contrast on slopes and edges. eyeDomeLightingRadius number 1.0 optional Increase the thickness of contours from eye dome lighting. backFaceCulling boolean false optional Determines whether back-facing points are hidden. This option works only if data has normals included. normalShading boolean true optional Determines whether a point cloud that contains normals is shaded by the scene's light source. |

### Members

#### [](#attenuation) attenuation : boolean 

[engine/Source/Scene/PointCloudShading.js 30](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointCloudShading.js#L30) 

 Perform point attenuation based on geometric error.

Default Value: `false` 

#### [](#backFaceCulling) backFaceCulling : boolean 

[engine/Source/Scene/PointCloudShading.js 93](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointCloudShading.js#L93) 

 Determines whether back-facing points are hidden. This option works only if data has normals included.

Default Value: `false` 

#### [](#baseResolution) baseResolution : number 

[engine/Source/Scene/PointCloudShading.js 54](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointCloudShading.js#L54) 

 Average base resolution for the dataset in meters. Used in place of geometric error when geometric error is 0\. If undefined, an approximation will be computed for each tile that has geometric error of 0.

#### [](#eyeDomeLighting) eyeDomeLighting : boolean 

[engine/Source/Scene/PointCloudShading.js 64](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointCloudShading.js#L64) 

 Use eye dome lighting when drawing with point attenuation Requires support for EXT\_frag\_depth, OES\_texture\_float, and WEBGL\_draw\_buffers extensions in WebGL 1.0, otherwise eye dome lighting is ignored.

Default Value: `true` 

#### [](#eyeDomeLightingRadius) eyeDomeLightingRadius : number 

[engine/Source/Scene/PointCloudShading.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointCloudShading.js#L81) 

 Thickness of contours from eye dome lighting

Default Value: `1.0` 

#### [](#eyeDomeLightingStrength) eyeDomeLightingStrength : number 

[engine/Source/Scene/PointCloudShading.js 71](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointCloudShading.js#L71) 

 Eye dome lighting strength (apparent contrast)

Default Value: `1.0` 

#### [](#geometricErrorScale) geometricErrorScale : number 

[engine/Source/Scene/PointCloudShading.js 37](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointCloudShading.js#L37) 

 Scale to be applied to the geometric error before computing attenuation.

Default Value: `1.0` 

#### [](#maximumAttenuation) maximumAttenuation : number 

[engine/Source/Scene/PointCloudShading.js 46](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointCloudShading.js#L46) 

 Maximum point attenuation in pixels. If undefined, the Cesium3DTileset's maximumScreenSpaceError will be used.

#### [](#normalShading) normalShading : boolean 

[engine/Source/Scene/PointCloudShading.js 101](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointCloudShading.js#L101) 

 Determines whether a point cloud that contains normals is shaded by the scene's light source.

Default Value: `true` 

### Methods

#### [](#.isSupported) static Cesium.PointCloudShading.isSupported(scene) → boolean 

[engine/Source/Scene/PointCloudShading.js 110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointCloudShading.js#L110) 

 Determines if point cloud shading is supported.

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| scene | [Scene](Scene.html) | The scene.  |

##### Returns:

`true` if point cloud shading is supported; otherwise, returns `false` 

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

