# [![](Images/CesiumLogo.png)](index.html) CallbackPositionProperty 

#### [](#CallbackPositionProperty) new Cesium.CallbackPositionProperty(callback, isConstant, referenceFrame) 

[engine/Source/DataSources/CallbackPositionProperty.js 21](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackPositionProperty.js#L21) 

 A [PositionProperty](PositionProperty.html) whose value is lazily evaluated by a callback function.

| Name           | Type                                                                         | Default              | Description                                                                                        |
| -------------- | ---------------------------------------------------------------------------- | -------------------- | -------------------------------------------------------------------------------------------------- |
| callback       | [CallbackPositionProperty.Callback](CallbackPositionProperty.html#.Callback) |                      | The function to be called when the position property is evaluated.                                 |
| isConstant     | boolean                                                                      |                      | true when the callback function returns the same value every time, false if the value will change. |
| referenceFrame | [ReferenceFrame](global.html#ReferenceFrame)                                 | ReferenceFrame.FIXED | optional The reference frame in which the position is defined.                                     |

##### Demo:

* [Cesium Sandcastle Callback Position Property Demo](https://sandcastle.cesium.com/index.html?src=Callback%2520Position%2520Property.html)

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/CallbackPositionProperty.js 51](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackPositionProperty.js#L51) 

 Gets the event that is raised whenever the definition of this property changes. The definition is considered to have changed if a call to getValue would return a different result for the same time.

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/CallbackPositionProperty.js 37](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackPositionProperty.js#L37) 

 Gets a value indicating if this property is constant.

#### [](#referenceFrame) referenceFrame : [ReferenceFrame](global.html#ReferenceFrame) 

[engine/Source/DataSources/CallbackPositionProperty.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackPositionProperty.js#L62) 

 Gets the reference frame in which the position is defined.

Default Value: `ReferenceFrame.FIXED;` 

### Methods

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/CallbackPositionProperty.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackPositionProperty.js#L155) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getValue) getValue(time, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/DataSources/CallbackPositionProperty.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackPositionProperty.js#L78) 

 Gets the value of the property at the provided time in the fixed frame.

| Name   | Type                          | Default          | Description                                                                                      |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | [Cartesian3](Cartesian3.html) |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

#### [](#getValueInReferenceFrame) getValueInReferenceFrame(time, referenceFrame, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/DataSources/CallbackPositionProperty.js 123](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackPositionProperty.js#L123) 

 Gets the value of the property at the provided time and in the provided reference frame.

| Name           | Type                                         | Description                                                                                      |
| -------------- | -------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| time           | [JulianDate](JulianDate.html)                | The time for which to retrieve the value.                                                        |
| referenceFrame | [ReferenceFrame](global.html#ReferenceFrame) | The desired referenceFrame of the result.                                                        |
| result         | [Cartesian3](Cartesian3.html)                | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

#### [](#setCallback) setCallback(callback, isConstant) 

[engine/Source/DataSources/CallbackPositionProperty.js 91](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackPositionProperty.js#L91) 

 Sets the callback to be used.

| Name       | Type                                                                         | Description                                                                                        |
| ---------- | ---------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| callback   | [CallbackPositionProperty.Callback](CallbackPositionProperty.html#.Callback) | The function to be called when the property is evaluated.                                          |
| isConstant | boolean                                                                      | true when the callback function returns the same value every time, false if the value will change. |

### Type Definitions

#### [](#.Callback) Cesium.CallbackPositionProperty.Callback(time, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/DataSources/CallbackPositionProperty.js 165](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CallbackPositionProperty.js#L165) 

 A function that returns the value of the position property.

| Name   | Type                          | Default          | Description                                                                                                  |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.              |
| result | [Cartesian3](Cartesian3.html) |                  | optional The object to store the value into. If omitted, the function must create and return a new instance. |

##### Returns:

 The modified result parameter, or a new instance if the result parameter was not supplied or is unsupported.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

