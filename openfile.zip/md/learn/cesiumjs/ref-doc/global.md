# [![](Images/CesiumLogo.png)](index.html) Global 

### Members

#### [](#ArcGisBaseMapType) constant ArcGisBaseMapType : number 

[engine/Source/Scene/ArcGisBaseMapType.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisBaseMapType.js#L7) 

 ArcGisBaseMapType enumerates the ArcGIS image tile layers that are supported by default.

##### Properties:

| Name      | Type   | Description |
| --------- | ------ | ----------- |
| SATELLITE | number |             |
| OCEANS    | number |             |
| HILLSHADE | number |             |

##### See:

* [ArcGisMapServerImageryProvider](ArcGisMapServerImageryProvider.html)

#### [](#ArcType) constant ArcType : number 

[engine/Source/Core/ArcType.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ArcType.js#L6) 

 ArcType defines the path that should be taken connecting vertices.

##### Properties:

| Name     | Type   | Description                                                          |
| -------- | ------ | -------------------------------------------------------------------- |
| NONE     | number | Straight line that does not conform to the surface of the ellipsoid. |
| GEODESIC | number | Follow geodesic path.                                                |
| RHUMB    | number | Follow rhumb or loxodrome path.                                      |

#### [](#availableLevels) readonly availableLevels : number|undefined 

[engine/Source/Scene/VoxelProvider.js 201](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelProvider.js#L201) 

 The number of levels of detail containing available tiles in the tileset.

#### [](#Axis) constant Axis : number 

[engine/Source/Scene/Axis.js 10](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Axis.js#L10) 

 An enum describing the x, y, and z axes and helper conversion functions.

##### Properties:

| Name | Type   | Description         |
| ---- | ------ | ------------------- |
| X    | number | Denotes the x-axis. |
| Y    | number | Denotes the y-axis. |
| Z    | number | Denotes the z-axis. |

#### [](#BingMapsStyle) constant BingMapsStyle : number 

[engine/Source/Scene/BingMapsStyle.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsStyle.js#L8) 

 The types of imagery provided by Bing Maps.

##### Properties:

| Name                             | Type   | Description                                                                    |
| -------------------------------- | ------ | ------------------------------------------------------------------------------ |
| AERIAL                           | string | Aerial imagery.                                                                |
| AERIAL\_WITH\_LABELS             | string | Aerial imagery with a road overlay.                                            |
| AERIAL\_WITH\_LABELS\_ON\_DEMAND | string | Aerial imagery with a road overlay.                                            |
| ROAD                             | string | Roads without additional imagery.                                              |
| ROAD\_ON\_DEMAND                 | string | Roads without additional imagery.                                              |
| CANVAS\_DARK                     | string | A dark version of the road maps.                                               |
| CANVAS\_LIGHT                    | string | A lighter version of the road maps.                                            |
| CANVAS\_GRAY                     | string | A grayscale version of the road maps.                                          |
| ORDNANCE\_SURVEY                 | string | Ordnance Survey imagery. This imagery is visible only for the London, UK area. |
| COLLINS\_BART                    | string | Collins Bart imagery.                                                          |

##### See:

* [BingMapsImageryProvider](BingMapsImageryProvider.html)

#### [](#BlendEquation) constant BlendEquation : number 

[engine/Source/Scene/BlendEquation.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BlendEquation.js#L8) 

 Determines how two pixels' values are combined.

##### Properties:

| Name              | Type   | Description                                                                                                                      |
| ----------------- | ------ | -------------------------------------------------------------------------------------------------------------------------------- |
| ADD               | number | Pixel values are added componentwise. This is used in additive blending for translucency.                                        |
| SUBTRACT          | number | Pixel values are subtracted componentwise (source - destination). This is used in alpha blending for translucency.               |
| REVERSE\_SUBTRACT | number | Pixel values are subtracted componentwise (destination - source).                                                                |
| MIN               | number | Pixel values are given to the minimum function (min(source, destination)). This equation operates on each pixel color component. |
| MAX               | number | Pixel values are given to the maximum function (max(source, destination)). This equation operates on each pixel color component. |

#### [](#BlendFunction) constant BlendFunction : number 

[engine/Source/Scene/BlendFunction.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BlendFunction.js#L8) 

 Determines how blending factors are computed.

##### Properties:

| Name                           | Type   | Description                                          |
| ------------------------------ | ------ | ---------------------------------------------------- |
| ZERO                           | number | The blend factor is zero.                            |
| ONE                            | number | The blend factor is one.                             |
| SOURCE\_COLOR                  | number | The blend factor is the source color.                |
| ONE\_MINUS\_SOURCE\_COLOR      | number | The blend factor is one minus the source color.      |
| DESTINATION\_COLOR             | number | The blend factor is the destination color.           |
| ONE\_MINUS\_DESTINATION\_COLOR | number | The blend factor is one minus the destination color. |
| SOURCE\_ALPHA                  | number | The blend factor is the source alpha.                |
| ONE\_MINUS\_SOURCE\_ALPHA      | number | The blend factor is one minus the source alpha.      |
| DESTINATION\_ALPHA             | number | The blend factor is the destination alpha.           |
| ONE\_MINUS\_DESTINATION\_ALPHA | number | The blend factor is one minus the destination alpha. |
| CONSTANT\_COLOR                | number | The blend factor is the constant color.              |
| ONE\_MINUS\_CONSTANT\_COLOR    | number | The blend factor is one minus the constant color.    |
| CONSTANT\_ALPHA                | number | The blend factor is the constant alpha.              |
| ONE\_MINUS\_CONSTANT\_ALPHA    | number | The blend factor is one minus the constant alpha.    |
| SOURCE\_ALPHA\_SATURATE        | number | The blend factor is the saturated source alpha.      |

#### [](#BlendOption) constant BlendOption : number 

[engine/Source/Scene/BlendOption.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BlendOption.js#L6) 

 Determines how opaque and translucent parts of billboards, points, and labels are blended with the scene.

##### Properties:

| Name                     | Type   | Description                                                                          |
| ------------------------ | ------ | ------------------------------------------------------------------------------------ |
| OPAQUE                   | number | The billboards, points, or labels in the collection are completely opaque.           |
| TRANSLUCENT              | number | The billboards, points, or labels in the collection are completely translucent.      |
| OPAQUE\_AND\_TRANSLUCENT | number | The billboards, points, or labels in the collection are both opaque and translucent. |

#### [](#CameraEventType) constant CameraEventType : number 

[engine/Source/Scene/CameraEventType.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CameraEventType.js#L6) 

 Enumerates the available input for interacting with the camera.

##### Properties:

| Name         | Type   | Description                                                                        |
| ------------ | ------ | ---------------------------------------------------------------------------------- |
| LEFT\_DRAG   | number | A left mouse button press followed by moving the mouse and releasing the button.   |
| RIGHT\_DRAG  | number | A right mouse button press followed by moving the mouse and releasing the button.  |
| MIDDLE\_DRAG | number | A middle mouse button press followed by moving the mouse and releasing the button. |
| WHEEL        | number | Scrolling the middle mouse button.                                                 |
| PINCH        | number | A two-finger touch on a touch surface.                                             |

#### [](#Cesium3DTileColorBlendMode) constant Cesium3DTileColorBlendMode : number 

[engine/Source/Scene/Cesium3DTileColorBlendMode.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileColorBlendMode.js#L27) 

 Defines how per-feature colors set from the Cesium API or declarative styling blend with the source colors from the original feature, e.g. glTF material or per-point color in the tile.

When `REPLACE` or `MIX` are used and the source color is a glTF material, the technique must assign the`_3DTILESDIFFUSE` semantic to the diffuse color parameter. Otherwise only `HIGHLIGHT` is supported.

A feature whose color evaluates to white (1.0, 1.0, 1.0) is always rendered without color blending, regardless of the tileset's color blend mode.

```

"techniques": {
  "technique0": {
    "parameters": {
      "diffuse": {
        "semantic": "_3DTILESDIFFUSE",
        "type": 35666
      }
    }
  }
}

```

##### Properties:

| Name      | Type   | Description                                         |
| --------- | ------ | --------------------------------------------------- |
| HIGHLIGHT | number | Multiplies the source color by the feature color.   |
| REPLACE   | number | Replaces the source color with the feature color.   |
| MIX       | number | Blends the source color and feature color together. |

#### [](#Check) constant Check 

[engine/Source/Core/Check.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Check.js#L8) 

 Contains functions for checking that supplied arguments are of a specified type or meet specified conditions

#### [](#ClassificationType) constant ClassificationType : number 

[engine/Source/Scene/ClassificationType.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationType.js#L6) 

 Whether a classification affects terrain, 3D Tiles or both.

##### Properties:

| Name             | Type   | Description                                   |
| ---------------- | ------ | --------------------------------------------- |
| TERRAIN          | number | Only terrain will be classified.              |
| CESIUM\_3D\_TILE | number | Only 3D Tiles will be classified.             |
| BOTH             | number | Both terrain and 3D Tiles will be classified. |

#### [](#className) className : string 

[engine/Source/Scene/PickedMetadataInfo.js 31](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PickedMetadataInfo.js#L31) 

 The name of the metadata class

#### [](#classProperty) classProperty : [MetadataClassProperty](MetadataClassProperty.html) 

[engine/Source/Scene/PickedMetadataInfo.js 45](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PickedMetadataInfo.js#L45) 

 The the \`MetadataClassProperty\` that is described by this structure, as obtained from the \`MetadataSchema\`

#### [](#ClockRange) constant ClockRange : number 

[engine/Source/Core/ClockRange.js 10](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ClockRange.js#L10) 

 Constants used by [Clock#tick](Clock.html#tick) to determine behavior when [Clock#startTime](Clock.html#startTime) or [Clock#stopTime](Clock.html#stopTime) is reached.

##### Properties:

| Name       | Type   | Description                                                                                                                                                                                                                                                                                                 |
| ---------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| UNBOUNDED  | number | [Clock#tick](Clock.html#tick) will always advances the clock in its current direction.                                                                                                                                                                                                                      |
| CLAMPED    | number | When [Clock#startTime](Clock.html#startTime) or [Clock#stopTime](Clock.html#stopTime) is reached,[Clock#tick](Clock.html#tick) will not advance [Clock#currentTime](Clock.html#currentTime) any further.                                                                                                    |
| LOOP\_STOP | number | When [Clock#stopTime](Clock.html#stopTime) is reached, [Clock#tick](Clock.html#tick) will advance[Clock#currentTime](Clock.html#currentTime) to the opposite end of the interval. When time is moving backwards, [Clock#tick](Clock.html#tick) will not advance past[Clock#startTime](Clock.html#startTime) |

##### See:

* [Clock](Clock.html)
* [ClockStep](global.html#ClockStep)

#### [](#ClockStep) constant ClockStep : number 

[engine/Source/Core/ClockStep.js 10](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ClockStep.js#L10) 

 Constants to determine how much time advances with each call to [Clock#tick](Clock.html#tick).

##### Properties:

| Name                      | Type   | Description                                                                                                                                                                   |
| ------------------------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| TICK\_DEPENDENT           | number | [Clock#tick](Clock.html#tick) advances the current time by a fixed step, which is the number of seconds specified by [Clock#multiplier](Clock.html#multiplier).               |
| SYSTEM\_CLOCK\_MULTIPLIER | number | [Clock#tick](Clock.html#tick) advances the current time by the amount of system time elapsed since the previous call multiplied by [Clock#multiplier](Clock.html#multiplier). |
| SYSTEM\_CLOCK             | number | [Clock#tick](Clock.html#tick) sets the clock to the current system time; ignoring all other settings.                                                                         |

##### See:

* [Clock](Clock.html)
* [ClockRange](global.html#ClockRange)

#### [](#CloudType) constant CloudType : number 

[engine/Source/Scene/CloudType.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudType.js#L7) 

 Specifies the type of the cloud that is added to a [CloudCollection](CloudCollection.html) in [CloudCollection#add](CloudCollection.html#add).

##### Properties:

| Name    | Type   | Description    |
| ------- | ------ | -------------- |
| CUMULUS | number | Cumulus cloud. |

#### [](#ColorBlendMode) constant ColorBlendMode : number 

[engine/Source/Scene/ColorBlendMode.js 14](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ColorBlendMode.js#L14) 

 Defines different modes for blending between a target color and a primitive's source color. HIGHLIGHT multiplies the source color by the target color REPLACE replaces the source color with the target color MIX blends the source color and target color together

##### Properties:

| Name      | Type   | Description |
| --------- | ------ | ----------- |
| HIGHLIGHT | number |             |
| REPLACE   | number |             |
| MIX       | number |             |

##### See:

* Model.colorBlendMode

#### [](#ComponentDatatype) constant ComponentDatatype : number 

[engine/Source/Core/ComponentDatatype.js 12](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ComponentDatatype.js#L12) 

 WebGL component datatypes. Components are intrinsics, which form attributes, which form vertices.

##### Properties:

| Name            | Type   | Description                                                                                                                                                                                                                                                |
| --------------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| BYTE            | number | 8-bit signed byte corresponding to gl.BYTE and the type of an element in Int8Array.                                                                                                                                                                        |
| UNSIGNED\_BYTE  | number | 8-bit unsigned byte corresponding to UNSIGNED\_BYTE and the type of an element in Uint8Array.                                                                                                                                                              |
| SHORT           | number | 16-bit signed short corresponding to SHORT and the type of an element in Int16Array.                                                                                                                                                                       |
| UNSIGNED\_SHORT | number | 16-bit unsigned short corresponding to UNSIGNED\_SHORT and the type of an element in Uint16Array.                                                                                                                                                          |
| INT             | number | 32-bit signed int corresponding to INT and the type of an element in Int32Array.                                                                                                                                                                           |
| UNSIGNED\_INT   | number | 32-bit unsigned int corresponding to UNSIGNED\_INT and the type of an element in Uint32Array.                                                                                                                                                              |
| FLOAT           | number | 32-bit floating-point corresponding to FLOAT and the type of an element in Float32Array.                                                                                                                                                                   |
| DOUBLE          | number | 64-bit floating-point corresponding to gl.DOUBLE (in Desktop OpenGL; this is not supported in WebGL, and is emulated in Cesium via [GeometryPipeline.encodeAttribute](GeometryPipeline.html#.encodeAttribute)) and the type of an element in Float64Array. |

#### [](#CornerType) constant CornerType : number 

[engine/Source/Core/CornerType.js 9](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CornerType.js#L9) 

 Style options for corners.

##### Properties:

| Name    | Type   | Description                                                                          |
| ------- | ------ | ------------------------------------------------------------------------------------ |
| ROUNDED | number | ![](Images/CornerTypeRounded.png)Corner has a smooth edge.                           |
| MITERED | number | ![](Images/CornerTypeMitered.png)Corner point is the intersection of adjacent edges. |
| BEVELED | number | ![](Images/CornerTypeBeveled.png)Corner is clipped.                                  |

##### Demo:

* The [Corridor Demo](https://sandcastle.cesium.com/index.html?src=Corridor.html&label=Geometries)demonstrates the three corner types, as used by [CorridorGraphics](CorridorGraphics.html).

#### [](#CullFace) constant CullFace : number 

[engine/Source/Scene/CullFace.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CullFace.js#L8) 

 Determines which triangles, if any, are culled.

##### Properties:

| Name             | Type   | Description                                             |
| ---------------- | ------ | ------------------------------------------------------- |
| FRONT            | number | Front-facing triangles are culled.                      |
| BACK             | number | Back-facing triangles are culled.                       |
| FRONT\_AND\_BACK | number | Both front-facing and back-facing triangles are culled. |

#### [](#CustomShaderMode) constant CustomShaderMode : string 

[engine/Source/Scene/Model/CustomShaderMode.js 9](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShaderMode.js#L9) 

 An enum describing how the [CustomShader](CustomShader.html) will be added to the fragment shader. This determines how the shader interacts with the material.

##### Properties:

| Name              | Type   | Description                                                                                                                |
| ----------------- | ------ | -------------------------------------------------------------------------------------------------------------------------- |
| MODIFY\_MATERIAL  | string | The custom shader will be used to modify the results of the material stage before lighting is applied.                     |
| REPLACE\_MATERIAL | string | The custom shader will be used instead of the material stage. This is a hint to optimize out the material processing code. |

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#CustomShaderTranslucencyMode) constant CustomShaderTranslucencyMode : number 

[engine/Source/Scene/Model/CustomShaderTranslucencyMode.js 9](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShaderTranslucencyMode.js#L9) 

 An enum for controling how [CustomShader](CustomShader.html) handles translucency compared with the original primitive.

##### Properties:

| Name        | Type   | Description                                                                                                                                                                                                                                              |
| ----------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| INHERIT     | number | Inherit translucency settings from the primitive's material. If the primitive used a translucent material, the custom shader will also be considered translucent. If the primitive used an opaque material, the custom shader will be considered opaque. |
| OPAQUE      | number | Force the primitive to render the primitive as opaque, ignoring any material settings.                                                                                                                                                                   |
| TRANSLUCENT | number | Force the primitive to render the primitive as translucent, ignoring any material settings.                                                                                                                                                              |

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#DepthFunction) constant DepthFunction : number 

[engine/Source/Scene/DepthFunction.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DepthFunction.js#L8) 

 Determines the function used to compare two depths for the depth test.

##### Properties:

| Name               | Type   | Description                                                                               |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| NEVER              | number | The depth test never passes.                                                              |
| LESS               | number | The depth test passes if the incoming depth is less than the stored depth.                |
| EQUAL              | number | The depth test passes if the incoming depth is equal to the stored depth.                 |
| LESS\_OR\_EQUAL    | number | The depth test passes if the incoming depth is less than or equal to the stored depth.    |
| GREATER            | number | The depth test passes if the incoming depth is greater than the stored depth.             |
| NOT\_EQUAL         | number | The depth test passes if the incoming depth is not equal to the stored depth.             |
| GREATER\_OR\_EQUAL | number | The depth test passes if the incoming depth is greater than or equal to the stored depth. |
| ALWAYS             | number | The depth test always passes.                                                             |

#### [](#DONE) constant DONE : BoundingSphereState 

[engine/Source/DataSources/BoundingSphereState.js 12](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoundingSphereState.js#L12) 

 The BoundingSphere has been computed.

#### [](#DynamicAtmosphereLightingType) constant DynamicAtmosphereLightingType : number 

[engine/Source/Scene/DynamicAtmosphereLightingType.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DynamicAtmosphereLightingType.js#L8) 

 Atmosphere lighting effects (sky atmosphere, ground atmosphere, fog) can be further modified with dynamic lighting from the sun or other light source that changes over time. This enum determines which light source to use.

##### Properties:

| Name         | Type   | Description                                                                                                                                     |
| ------------ | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| NONE         | number | Do not use dynamic atmosphere lighting. Atmosphere lighting effects will be lit from directly above rather than using the scene's light source. |
| SCENE\_LIGHT | number | Use the scene's current light source for dynamic atmosphere lighting.                                                                           |
| SUNLIGHT     | number | Force the dynamic atmosphere lighting to always use the sunlight direction, even if the scene uses a different light source.                    |

#### [](#excludesReverseAxis) constant excludesReverseAxis : Array.<number> 

[engine/Source/Scene/WebMapServiceImageryProvider.js 29](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L29) 

 EPSG codes known to not include reverse axis orders, and are within 4000-5000.

#### [](#ExtrapolationType) constant ExtrapolationType : number 

[engine/Source/Core/ExtrapolationType.js 9](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ExtrapolationType.js#L9) 

 Constants to determine how an interpolated value is extrapolated when querying outside the bounds of available data.

##### Properties:

| Name        | Type   | Description                                                            |
| ----------- | ------ | ---------------------------------------------------------------------- |
| NONE        | number | No extrapolation occurs.                                               |
| HOLD        | number | The first or last value is used when outside the range of sample data. |
| EXTRAPOLATE | number | The value is extrapolated.                                             |

##### See:

* [SampledProperty](SampledProperty.html)

#### [](#FAILED) constant FAILED : BoundingSphereState 

[engine/Source/DataSources/BoundingSphereState.js 24](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoundingSphereState.js#L24) 

 The BoundingSphere does not exist.

#### [](#GeocodeType) constant GeocodeType : number 

[engine/Source/Core/GeocodeType.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeocodeType.js#L6) 

 The type of geocoding to be performed by a [GeocoderService](GeocoderService.html).

##### Properties:

| Name         | Type   | Description                                                                                                          |
| ------------ | ------ | -------------------------------------------------------------------------------------------------------------------- |
| SEARCH       | number | Perform a search where the input is considered complete.                                                             |
| AUTOCOMPLETE | number | Perform an auto-complete using partial input, typically reserved for providing possible results as a user is typing. |

##### See:

* [Geocoder](Geocoder.html)

#### [](#geometryUpdaters) constant geometryUpdaters : Array.<[GeometryUpdater](GeometryUpdater.html)\> 

[engine/Source/DataSources/GeometryUpdaterSet.js 16](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeometryUpdaterSet.js#L16) 

#### [](#HeightmapEncoding) constant HeightmapEncoding : number 

[engine/Source/Core/HeightmapEncoding.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeightmapEncoding.js#L6) 

 The encoding that is used for a heightmap

##### Properties:

| Name | Type   | Description   |
| ---- | ------ | ------------- |
| NONE | number | No encoding   |
| LERC | number | LERC encoding |

#### [](#HeightReference) constant HeightReference : number 

[engine/Source/Scene/HeightReference.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/HeightReference.js#L6) 

 Represents the position relative to the terrain.

##### Properties:

| Name                   | Type   | Description                                                       |
| ---------------------- | ------ | ----------------------------------------------------------------- |
| NONE                   | number | The position is absolute.                                         |
| CLAMP\_TO\_GROUND      | number | The position is clamped to the terrain and 3D Tiles.              |
| RELATIVE\_TO\_GROUND   | number | The position height is the height above the terrain and 3D Tiles. |
| CLAMP\_TO\_TERRAIN     | number | The position is clamped to terain.                                |
| RELATIVE\_TO\_TERRAIN  | number | The position height is the height above terrain.                  |
| CLAMP\_TO\_3D\_TILE    | number | The position is clamped to 3D Tiles.                              |
| RELATIVE\_TO\_3D\_TILE | number | The position height is the height above 3D Tiles.                 |

#### [](#HorizontalOrigin) constant HorizontalOrigin : number 

[engine/Source/Scene/HorizontalOrigin.js 16](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/HorizontalOrigin.js#L16) 

 The horizontal location of an origin relative to an object, e.g., a [Billboard](Billboard.html)or [Label](Label.html). For example, setting the horizontal origin to `LEFT`or `RIGHT` will display a billboard to the left or right (in screen space) of the anchor position.  
  
![](Images/Billboard.setHorizontalOrigin.png)  

##### Properties:

| Name   | Type   | Description                                           |
| ------ | ------ | ----------------------------------------------------- |
| CENTER | number | The origin is at the horizontal center of the object. |
| LEFT   | number | The origin is on the left side of the object.         |
| RIGHT  | number | The origin is on the right side of the object.        |

##### See:

* [Billboard#horizontalOrigin](Billboard.html#horizontalOrigin)
* [Label#horizontalOrigin](Label.html#horizontalOrigin)

#### [](#includesReverseAxis) constant includesReverseAxis : Array.<number> 

[engine/Source/Scene/WebMapServiceImageryProvider.js 16](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L16) 

 EPSG codes known to include reverse axis orders, but are not within 4000-5000.

#### [](#IndexDatatype) constant IndexDatatype : number 

[engine/Source/Core/IndexDatatype.js 12](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IndexDatatype.js#L12) 

 Constants for WebGL index datatypes. These corresponds to the`type` parameter of [drawElements](http://www.khronos.org/opengles/sdk/docs/man/xhtml/glDrawElements.xml).

##### Properties:

| Name            | Type   | Description                                                                                       |
| --------------- | ------ | ------------------------------------------------------------------------------------------------- |
| UNSIGNED\_BYTE  | number | 8-bit unsigned byte corresponding to UNSIGNED\_BYTE and the type of an element in Uint8Array.     |
| UNSIGNED\_SHORT | number | 16-bit unsigned short corresponding to UNSIGNED\_SHORT and the type of an element in Uint16Array. |
| UNSIGNED\_INT   | number | 32-bit unsigned int corresponding to UNSIGNED\_INT and the type of an element in Uint32Array.     |

#### [](#Intersect) constant Intersect : number 

[engine/Source/Core/Intersect.js 9](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Intersect.js#L9) 

 This enumerated type is used in determining where, relative to the frustum, an object is located. The object can either be fully contained within the frustum (INSIDE), partially inside the frustum and partially outside (INTERSECTING), or somewhere entirely outside of the frustum's 6 planes (OUTSIDE).

##### Properties:

| Name         | Type   | Description                                                       |
| ------------ | ------ | ----------------------------------------------------------------- |
| OUTSIDE      | number | Represents that an object is not contained within the frustum.    |
| INTERSECTING | number | Represents that an object intersects one of the frustum's planes. |
| INSIDE       | number | Represents that an object is fully within the frustum.            |

#### [](#IonGeocodeProviderType) constant IonGeocodeProviderType : string 

[engine/Source/Core/IonGeocodeProviderType.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/IonGeocodeProviderType.js#L6) 

 Underlying geocoding services that can be used via Cesium ion.

##### Properties:

| Name    | Type   | Description                                                                                   |
| ------- | ------ | --------------------------------------------------------------------------------------------- |
| GOOGLE  | string | Google geocoder, for use with Google data.                                                    |
| BING    | string | Bing geocoder, for use with Bing data.                                                        |
| DEFAULT | string | Use the default geocoder as set on the server. Used when neither Bing or Google data is used. |

#### [](#IonWorldImageryStyle) constant IonWorldImageryStyle : number 

[engine/Source/Scene/IonWorldImageryStyle.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/IonWorldImageryStyle.js#L8) 

 The types of imagery provided by `createWorldImagery`.

##### Properties:

| Name                 | Type   | Description                         |
| -------------------- | ------ | ----------------------------------- |
| AERIAL               | number | Aerial imagery.                     |
| AERIAL\_WITH\_LABELS | number | Aerial imagery with a road overlay. |
| ROAD                 | number | Roads without additional imagery.   |

#### [](#KeyboardEventModifier) constant KeyboardEventModifier : number 

[engine/Source/Core/KeyboardEventModifier.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/KeyboardEventModifier.js#L7) 

 This enumerated type is for representing keyboard modifiers. These are keys that are held down in addition to other event types.

##### Properties:

| Name  | Type   | Description                                 |
| ----- | ------ | ------------------------------------------- |
| SHIFT | number | Represents the shift key being held down.   |
| CTRL  | number | Represents the control key being held down. |
| ALT   | number | Represents the alt key being held down.     |

#### [](#LabelStyle) constant LabelStyle : number 

[engine/Source/Scene/LabelStyle.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/LabelStyle.js#L8) 

 Describes how to draw a label.

##### Properties:

| Name               | Type   | Description                                     |
| ------------------ | ------ | ----------------------------------------------- |
| FILL               | number | Fill the text of the label, but do not outline. |
| OUTLINE            | number | Outline the text of the label, but do not fill. |
| FILL\_AND\_OUTLINE | number | Fill and outline the text of the label.         |

##### See:

* [Label#style](Label.html#style)

#### [](#LightingModel) constant LightingModel : number 

[engine/Source/Scene/Model/LightingModel.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/LightingModel.js#L8) 

 The lighting model to use for lighting a [Model](Model.html).

##### Properties:

| Name  | Type   | Description                                                                                                                                                                                         |
| ----- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| UNLIT | number | Use unlit shading, i.e. skip lighting calculations. The model's diffuse color (assumed to be linear RGB, not sRGB) is used directly when computing out\_FragColor. The alpha mode is still applied. |
| PBR   | number | Use physically-based rendering lighting calculations. This includes both PBR metallic roughness and PBR specular glossiness. Image-based lighting is also applied when possible.                    |

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#MapMode2D) constant MapMode2D : number 

[engine/Source/Scene/MapMode2D.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapMode2D.js#L6) 

 Describes how the map will operate in 2D.

##### Properties:

| Name             | Type   | Description                                                        |
| ---------------- | ------ | ------------------------------------------------------------------ |
| ROTATE           | number | The 2D map can be rotated about the z axis.                        |
| INFINITE\_SCROLL | number | The 2D map can be scrolled infinitely in the horizontal direction. |

#### [](#metadata) readonly metadata : Array.<Int8Array>|Array.<Uint8Array>|Array.<Int16Array>|Array.<Uint16Array>|Array.<Int32Array>|Array.<Uint32Array>|Array.<Float32Array>|Array.<Float64Array> 

[engine/Source/Scene/VoxelContent.js 72](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelContent.js#L72) 

 The metadata for this voxel content. The metadata is an array of typed arrays, one for each field. The data for one field is a flattened 3D array ordered by X, then Y, then Z.

#### [](#MetadataComponentType) constant MetadataComponentType : string 

[engine/Source/Scene/MetadataComponentType.js 13](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataComponentType.js#L13) 

 An enum of metadata component types.

##### Properties:

| Name    | Type   | Description                                                 |
| ------- | ------ | ----------------------------------------------------------- |
| INT8    | string | An 8-bit signed integer                                     |
| UINT8   | string | An 8-bit unsigned integer                                   |
| INT16   | string | A 16-bit signed integer                                     |
| UINT16  | string | A 16-bit unsigned integer                                   |
| INT32   | string | A 32-bit signed integer                                     |
| UINT32  | string | A 32-bit unsigned integer                                   |
| INT64   | string | A 64-bit signed integer. This type requires BigInt support. |
| UINT64  | string | A 64-bit signed integer. This type requires BigInt support  |
| FLOAT32 | string | A 32-bit (single precision) floating point number           |
| FLOAT64 | string | A 64-bit (double precision) floating point number           |

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#metadataProperty) metadataProperty : object 

[engine/Source/Scene/PickedMetadataInfo.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PickedMetadataInfo.js#L55) 

 The \`PropertyTextureProperty\` or \`PropertyAttributeProperty\` that is described by this structure, as obtained from the property texture or property attribute of the \`StructuralMetadata\` that matches the class name and property name.

#### [](#MetadataType) constant MetadataType : string 

[engine/Source/Scene/MetadataType.js 37](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataType.js#L37) 

 An enum of metadata types. These metadata types are containers containing one or more components of type [MetadataComponentType](global.html#MetadataComponentType) 

##### Properties:

| Name    | Type   | Description                                                                                                                  |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------- |
| SCALAR  | string | A single component                                                                                                           |
| VEC2    | string | A vector with two components                                                                                                 |
| VEC3    | string | A vector with three components                                                                                               |
| VEC4    | string | A vector with four components                                                                                                |
| MAT2    | string | A 2x2 matrix, stored in column-major format.                                                                                 |
| MAT3    | string | A 3x3 matrix, stored in column-major format.                                                                                 |
| MAT4    | string | A 4x4 matrix, stored in column-major format.                                                                                 |
| BOOLEAN | string | A boolean (true/false) value                                                                                                 |
| STRING  | string | A UTF-8 encoded string value                                                                                                 |
| ENUM    | string | An enumerated value. This type is used in conjunction with a [MetadataEnum](MetadataEnum.html) to describe the valid values. |

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#ModelAnimationLoop) constant ModelAnimationLoop : number 

[engine/Source/Scene/ModelAnimationLoop.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ModelAnimationLoop.js#L8) 

 Determines if and how a glTF animation is looped.

##### Properties:

| Name             | Type   | Description                                                                              |
| ---------------- | ------ | ---------------------------------------------------------------------------------------- |
| NONE             | number | Play the animation once; do not loop it.                                                 |
| REPEAT           | number | Loop the animation playing it from the start immediately after it stops.                 |
| MIRRORED\_REPEAT | number | Loop the animation. First, playing it forward, then in reverse, then forward, and so on. |

##### See:

* [ModelAnimationCollection#add](ModelAnimationCollection.html#add)

#### [](#PENDING) constant PENDING : BoundingSphereState 

[engine/Source/DataSources/BoundingSphereState.js 18](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoundingSphereState.js#L18) 

 The BoundingSphere is still being computed.

#### [](#PixelDatatype) constant PixelDatatype : number 

[engine/Source/Renderer/PixelDatatype.js 9](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Renderer/PixelDatatype.js#L9) 

 The data type of a pixel.

##### Properties:

| Name                        | Type   | Description |
| --------------------------- | ------ | ----------- |
| UNSIGNED\_BYTE              | number |             |
| UNSIGNED\_SHORT             | number |             |
| UNSIGNED\_INT               | number |             |
| FLOAT                       | number |             |
| HALF\_FLOAT                 | number |             |
| UNSIGNED\_INT\_24\_8        | number |             |
| UNSIGNED\_SHORT\_4\_4\_4\_4 | number |             |
| UNSIGNED\_SHORT\_5\_5\_5\_1 | number |             |
| UNSIGNED\_SHORT\_5\_6\_5    | number |             |

##### See:

* [PostProcessStage](PostProcessStage.html)

#### [](#PixelFormat) constant PixelFormat : number 

[engine/Source/Core/PixelFormat.js 9](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PixelFormat.js#L9) 

 The format of a pixel, i.e., the number of components it has and what they represent.

##### Properties:

| Name                | Type   | Description                                                                                                                                                         |
| ------------------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| DEPTH\_COMPONENT    | number | A pixel format containing a depth value.                                                                                                                            |
| DEPTH\_STENCIL      | number | A pixel format containing a depth and stencil value, most often used with [PixelDatatype.UNSIGNED\_INT\_24\_8](global.html#PixelDatatype#.UNSIGNED%5FINT%5F24%5F8). |
| ALPHA               | number | A pixel format containing an alpha channel.                                                                                                                         |
| RED                 | number | A pixel format containing a red channel                                                                                                                             |
| RG                  | number | A pixel format containing red and green channels.                                                                                                                   |
| RGB                 | number | A pixel format containing red, green, and blue channels.                                                                                                            |
| RGBA                | number | A pixel format containing red, green, blue, and alpha channels.                                                                                                     |
| LUMINANCE           | number | A pixel format containing a luminance (intensity) channel.                                                                                                          |
| LUMINANCE\_ALPHA    | number | A pixel format containing luminance (intensity) and alpha channels.                                                                                                 |
| RGB\_DXT1           | number | A pixel format containing red, green, and blue channels that is DXT1 compressed.                                                                                    |
| RGBA\_DXT1          | number | A pixel format containing red, green, blue, and alpha channels that is DXT1 compressed.                                                                             |
| RGBA\_DXT3          | number | A pixel format containing red, green, blue, and alpha channels that is DXT3 compressed.                                                                             |
| RGBA\_DXT5          | number | A pixel format containing red, green, blue, and alpha channels that is DXT5 compressed.                                                                             |
| RGB\_PVRTC\_4BPPV1  | number | A pixel format containing red, green, and blue channels that is PVR 4bpp compressed.                                                                                |
| RGB\_PVRTC\_2BPPV1  | number | A pixel format containing red, green, and blue channels that is PVR 2bpp compressed.                                                                                |
| RGBA\_PVRTC\_4BPPV1 | number | A pixel format containing red, green, blue, and alpha channels that is PVR 4bpp compressed.                                                                         |
| RGBA\_PVRTC\_2BPPV1 | number | A pixel format containing red, green, blue, and alpha channels that is PVR 2bpp compressed.                                                                         |
| RGBA\_ASTC          | number | A pixel format containing red, green, blue, and alpha channels that is ASTC compressed.                                                                             |
| RGB\_ETC1           | number | A pixel format containing red, green, and blue channels that is ETC1 compressed.                                                                                    |
| RGB8\_ETC2          | number | A pixel format containing red, green, and blue channels that is ETC2 compressed.                                                                                    |
| RGBA8\_ETC2\_EAC    | number | A pixel format containing red, green, blue, and alpha channels that is ETC2 compressed.                                                                             |
| RGBA\_BC7           | number | A pixel format containing red, green, blue, and alpha channels that is BC7 compressed.                                                                              |

#### [](#PostProcessStageSampleMode) constant PostProcessStageSampleMode : number 

[engine/Source/Scene/PostProcessStageSampleMode.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageSampleMode.js#L6) 

 Determines how input texture to a [PostProcessStage](PostProcessStage.html) is sampled.

##### Properties:

| Name    | Type   | Description                                                                     |
| ------- | ------ | ------------------------------------------------------------------------------- |
| NEAREST | number | Samples the texture by returning the closest texel.                             |
| LINEAR  | number | Samples the texture through bi-linear interpolation of the four nearest texels. |

#### [](#PrimitiveType) constant PrimitiveType : number 

[engine/Source/Core/PrimitiveType.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PrimitiveType.js#L8) 

 The type of a geometric primitive, i.e., points, lines, and triangles.

##### Properties:

| Name            | Type   | Description                                                                                                                                                                                              |
| --------------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| POINTS          | number | Points primitive where each vertex (or index) is a separate point.                                                                                                                                       |
| LINES           | number | Lines primitive where each two vertices (or indices) is a line segment. Line segments are not necessarily connected.                                                                                     |
| LINE\_LOOP      | number | Line loop primitive where each vertex (or index) after the first connects a line to the previous vertex, and the last vertex implicitly connects to the first.                                           |
| LINE\_STRIP     | number | Line strip primitive where each vertex (or index) after the first connects a line to the previous vertex.                                                                                                |
| TRIANGLES       | number | Triangles primitive where each three vertices (or indices) is a triangle. Triangles do not necessarily share edges.                                                                                      |
| TRIANGLE\_STRIP | number | Triangle strip primitive where each vertex (or index) after the first two connect to the previous two vertices forming a triangle. For example, this can be used to model a wall.                        |
| TRIANGLE\_FAN   | number | Triangle fan primitive where each vertex (or index) after the first two connect to the previous vertex and the first vertex forming a triangle. For example, this can be used to model a cone or circle. |

#### [](#propertyName) propertyName : string 

[engine/Source/Scene/PickedMetadataInfo.js 37](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PickedMetadataInfo.js#L37) 

 The name of the metadata property

#### [](#ReferenceFrame) constant ReferenceFrame : number 

[engine/Source/Core/ReferenceFrame.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ReferenceFrame.js#L6) 

 Constants for identifying well-known reference frames.

##### Properties:

| Name     | Type   | Description         |
| -------- | ------ | ------------------- |
| FIXED    | number | The fixed frame.    |
| INERTIAL | number | The inertial frame. |

#### [](#RequestState) constant RequestState : number 

[engine/Source/Core/RequestState.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RequestState.js#L6) 

 State of the request.

##### Properties:

| Name      | Type   | Description                                                                        |
| --------- | ------ | ---------------------------------------------------------------------------------- |
| UNISSUED  | number | Initial unissued state.                                                            |
| ISSUED    | number | Issued but not yet active. Will become active when open slots are available.       |
| ACTIVE    | number | Actual http request has been sent.                                                 |
| RECEIVED  | number | Request completed successfully.                                                    |
| CANCELLED | number | Request was cancelled, either explicitly or automatically because of low priority. |
| FAILED    | number | Request failed.                                                                    |

#### [](#RequestType) constant RequestType : number 

[engine/Source/Core/RequestType.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/RequestType.js#L6) 

 An enum identifying the type of request. Used for finer grained logging and priority sorting.

##### Properties:

| Name    | Type   | Description       |
| ------- | ------ | ----------------- |
| TERRAIN | number | Terrain request.  |
| IMAGERY | number | Imagery request.  |
| TILES3D | number | 3D Tiles request. |
| OTHER   | number | Other request.    |

#### [](#SceneMode) constant SceneMode : number 

[engine/Source/Scene/SceneMode.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SceneMode.js#L7) 

 Indicates if the scene is viewed in 3D, 2D, or 2.5D Columbus view.

##### Properties:

| Name           | Type   | Description                                                                                                                     |
| -------------- | ------ | ------------------------------------------------------------------------------------------------------------------------------- |
| MORPHING       | number | Morphing between mode, e.g., 3D to 2D.                                                                                          |
| COLUMBUS\_VIEW | number | Columbus View mode. A 2.5D perspective view where the map is laid out flat and objects with non-zero height are drawn above it. |
| SCENE2D        | number | 2D mode. The map is viewed top-down with an orthographic projection.                                                            |
| SCENE3D        | number | 3D mode. A traditional 3D perspective view of the globe.                                                                        |

##### See:

* [Scene#mode](Scene.html#mode)

#### [](#schemaId) schemaId : string|undefined 

[engine/Source/Scene/PickedMetadataInfo.js 25](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PickedMetadataInfo.js#L25) 

 The optional ID of the metadata schema

#### [](#ScreenSpaceEventType) constant ScreenSpaceEventType : number 

[engine/Source/Core/ScreenSpaceEventType.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventType.js#L6) 

 This enumerated type is for classifying mouse events: down, up, click, double click, move and move while a button is held down.

##### Properties:

| Name                | Type   | Description                                                    |
| ------------------- | ------ | -------------------------------------------------------------- |
| LEFT\_DOWN          | number | Represents a mouse left button down event.                     |
| LEFT\_UP            | number | Represents a mouse left button up event.                       |
| LEFT\_CLICK         | number | Represents a mouse left click event.                           |
| LEFT\_DOUBLE\_CLICK | number | Represents a mouse left double click event.                    |
| RIGHT\_DOWN         | number | Represents a mouse left button down event.                     |
| RIGHT\_UP           | number | Represents a mouse right button up event.                      |
| RIGHT\_CLICK        | number | Represents a mouse right click event.                          |
| MIDDLE\_DOWN        | number | Represents a mouse middle button down event.                   |
| MIDDLE\_UP          | number | Represents a mouse middle button up event.                     |
| MIDDLE\_CLICK       | number | Represents a mouse middle click event.                         |
| MOUSE\_MOVE         | number | Represents a mouse move event.                                 |
| WHEEL               | number | Represents a mouse wheel event.                                |
| PINCH\_START        | number | Represents the start of a two-finger event on a touch surface. |
| PINCH\_END          | number | Represents the end of a two-finger event on a touch surface.   |
| PINCH\_MOVE         | number | Represents a change of a two-finger event on a touch surface.  |

#### [](#SensorVolumePortionToDisplay) constant SensorVolumePortionToDisplay : Number 

[engine/Source/Scene/SensorVolumePortionToDisplay.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SensorVolumePortionToDisplay.js#L8) 

 Constants used to indicated what part of the sensor volume to display.

##### Properties:

| Name                      | Type   | Description                                                                                          |
| ------------------------- | ------ | ---------------------------------------------------------------------------------------------------- |
| COMPLETE                  | Number | 0x0000\. Display the complete sensor volume.                                                         |
| BELOW\_ELLIPSOID\_HORIZON | Number | 0x0001\. Display the portion of the sensor volume that lies below the true horizon of the ellipsoid. |
| ABOVE\_ELLIPSOID\_HORIZON | Number | 0x0002\. Display the portion of the sensor volume that lies above the true horizon of the ellipsoid. |

#### [](#ShadowMode) constant ShadowMode : number 

[engine/Source/Scene/ShadowMode.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ShadowMode.js#L7) 

 Specifies whether the object casts or receives shadows from light sources when shadows are enabled.

##### Properties:

| Name          | Type   | Description                                  |
| ------------- | ------ | -------------------------------------------- |
| DISABLED      | number | The object does not cast or receive shadows. |
| ENABLED       | number | The object casts and receives shadows.       |
| CAST\_ONLY    | number | The object casts shadows only.               |
| RECEIVE\_ONLY | number | The object receives shadows only.            |

#### [](#SplitDirection) constant SplitDirection : number 

[engine/Source/Scene/SplitDirection.js 9](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SplitDirection.js#L9) 

 The direction to display a primitive or ImageryLayer relative to the [Scene#splitPosition](Scene.html#splitPosition).

##### Properties:

| Name  | Type   | Description                                                                                                |
| ----- | ------ | ---------------------------------------------------------------------------------------------------------- |
| LEFT  | number | Display the primitive or ImageryLayer to the left of the [Scene#splitPosition](Scene.html#splitPosition).  |
| NONE  | number | Always display the primitive or ImageryLayer.                                                              |
| RIGHT | number | Display the primitive or ImageryLayer to the right of the [Scene#splitPosition](Scene.html#splitPosition). |

##### See:

* [ImageryLayer#splitDirection](ImageryLayer.html#splitDirection)
* [Cesium3DTileset#splitDirection](Cesium3DTileset.html#splitDirection)

#### [](#StencilFunction) constant StencilFunction : number 

[engine/Source/Scene/StencilFunction.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/StencilFunction.js#L8) 

 Determines the function used to compare stencil values for the stencil test.

##### Properties:

| Name               | Type   | Description                                                                                                   |
| ------------------ | ------ | ------------------------------------------------------------------------------------------------------------- |
| NEVER              | number | The stencil test never passes.                                                                                |
| LESS               | number | The stencil test passes when the masked reference value is less than the masked stencil value.                |
| EQUAL              | number | The stencil test passes when the masked reference value is equal to the masked stencil value.                 |
| LESS\_OR\_EQUAL    | number | The stencil test passes when the masked reference value is less than or equal to the masked stencil value.    |
| GREATER            | number | The stencil test passes when the masked reference value is greater than the masked stencil value.             |
| NOT\_EQUAL         | number | The stencil test passes when the masked reference value is not equal to the masked stencil value.             |
| GREATER\_OR\_EQUAL | number | The stencil test passes when the masked reference value is greater than or equal to the masked stencil value. |
| ALWAYS             | number | The stencil test always passes.                                                                               |

#### [](#StencilOperation) constant StencilOperation : number 

[engine/Source/Scene/StencilOperation.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/StencilOperation.js#L8) 

 Determines the action taken based on the result of the stencil test.

##### Properties:

| Name            | Type   | Description                                                                                             |
| --------------- | ------ | ------------------------------------------------------------------------------------------------------- |
| ZERO            | number | Sets the stencil buffer value to zero.                                                                  |
| KEEP            | number | Does not change the stencil buffer.                                                                     |
| REPLACE         | number | Replaces the stencil buffer value with the reference value.                                             |
| INCREMENT       | number | Increments the stencil buffer value, clamping to unsigned byte.                                         |
| DECREMENT       | number | Decrements the stencil buffer value, clamping to zero.                                                  |
| INVERT          | number | Bitwise inverts the existing stencil buffer value.                                                      |
| INCREMENT\_WRAP | number | Increments the stencil buffer value, wrapping to zero when exceeding the unsigned byte range.           |
| DECREMENT\_WRAP | number | Decrements the stencil buffer value, wrapping to the maximum unsigned byte instead of going below zero. |

#### [](#StorageType) constant StorageType : string 

[engine/Source/Scene/Model/Extensions/Gpm/StorageType.js 10](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/StorageType.js#L10) 

 An enum of storage types for covariance information. This reflects the \`gltfGpmLocal.storageType\` definition of the[NGA\_gpm\_local](https://nsgreg.nga.mil/csmwg.jsp) glTF extension.

##### Properties:

| Name     | Type   | Description                                                                                                                                                                                                                                           |
| -------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Direct   | string | Store the full error covariance of the anchor points, to include the cross-covariance terms                                                                                                                                                           |
| Indirect | string | A full covariance matrix is stored for each of the anchor points. However, in this case the cross-covariance terms are not directly stored, but can be computed by a set of spatial correlation function parameters which are stored in the metadata. |

##### Experimental

This feature is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#StripeOrientation) constant StripeOrientation : number 

[engine/Source/DataSources/StripeOrientation.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/StripeOrientation.js#L6) 

 Defined the orientation of stripes in [StripeMaterialProperty](StripeMaterialProperty.html).

##### Properties:

| Name       | Type   | Description             |
| ---------- | ------ | ----------------------- |
| HORIZONTAL | number | Horizontal orientation. |
| VERTICAL   | number | Vertical orientation.   |

#### [](#TextureMagnificationFilter) constant TextureMagnificationFilter : number 

[engine/Source/Renderer/TextureMagnificationFilter.js 10](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Renderer/TextureMagnificationFilter.js#L10) 

 Enumerates all possible filters used when magnifying WebGL textures.

##### Properties:

| Name    | Type   | Description                                                                                                                            |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------- |
| NEAREST | number | Samples the texture by returning the closest pixel.                                                                                    |
| LINEAR  | number | Samples the texture through bi-linear interpolation of the four nearest pixels. This produces smoother results than NEAREST filtering. |

##### See:

* [TextureMinificationFilter](global.html#TextureMinificationFilter)

#### [](#TextureMinificationFilter) constant TextureMinificationFilter : number 

[engine/Source/Renderer/TextureMinificationFilter.js 10](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Renderer/TextureMinificationFilter.js#L10) 

 Enumerates all possible filters used when minifying WebGL textures.

##### Properties:

| Name                     | Type   | Description                                                                                                                                                                                                                                                                                                                                 |
| ------------------------ | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| NEAREST                  | number | Samples the texture by returning the closest pixel.                                                                                                                                                                                                                                                                                         |
| LINEAR                   | number | Samples the texture through bi-linear interpolation of the four nearest pixels. This produces smoother results than NEAREST filtering.                                                                                                                                                                                                      |
| NEAREST\_MIPMAP\_NEAREST | number | Selects the nearest mip level and applies nearest sampling within that level.Requires that the texture has a mipmap. The mip level is chosen by the view angle and screen-space size of the texture.                                                                                                                                        |
| LINEAR\_MIPMAP\_NEAREST  | number | Selects the nearest mip level and applies linear sampling within that level.Requires that the texture has a mipmap. The mip level is chosen by the view angle and screen-space size of the texture.                                                                                                                                         |
| NEAREST\_MIPMAP\_LINEAR  | number | Read texture values with nearest sampling from two adjacent mip levels and linearly interpolate the results.This option provides a good balance of visual quality and speed when sampling from a mipmapped texture. Requires that the texture has a mipmap. The mip level is chosen by the view angle and screen-space size of the texture. |
| LINEAR\_MIPMAP\_LINEAR   | number | Read texture values with linear sampling from two adjacent mip levels and linearly interpolate the results.This option provides a good balance of visual quality and speed when sampling from a mipmapped texture. Requires that the texture has a mipmap. The mip level is chosen by the view angle and screen-space size of the texture.  |

##### See:

* [TextureMagnificationFilter](global.html#TextureMagnificationFilter)

#### [](#TimeStandard) constant TimeStandard : number 

[engine/Source/Core/TimeStandard.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeStandard.js#L8) 

 Provides the type of time standards which JulianDate can take as input.

##### Properties:

| Name | Type   | Description                                                                                                                                                                                                                       |
| ---- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| UTC  | number | Represents the coordinated Universal Time (UTC) time standard. UTC is related to TAI according to the relationshipUTC = TAI - deltaT where deltaT is the number of leap seconds which have been introduced as of the time in TAI. |
| TAI  | number | Represents the International Atomic Time (TAI) time standard. TAI is the principal time standard to which the other time standards are related.                                                                                   |

##### See:

* [JulianDate](JulianDate.html)

#### [](#Tonemapper) constant Tonemapper : string 

[engine/Source/Scene/Tonemapper.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Tonemapper.js#L6) 

 A tonemapping algorithm when rendering with high dynamic range.

##### Properties:

| Name               | Type   | Description                                                                                                          |
| ------------------ | ------ | -------------------------------------------------------------------------------------------------------------------- |
| REINHARD           | string | Use the Reinhard tonemapping.                                                                                        |
| MODIFIED\_REINHARD | string | Use the modified Reinhard tonemapping.                                                                               |
| FILMIC             | string | Use the Filmic tonemapping.                                                                                          |
| ACES               | string | Use the ACES tonemapping.                                                                                            |
| PBR\_NEUTRAL       | string | Use the PBR Neutral tonemapping [from Khronos](https://github.com/KhronosGroup/ToneMapping/tree/main/PBR%5FNeutral). |

#### [](#TrackingReferenceFrame) constant TrackingReferenceFrame : number 

[engine/Source/Core/TrackingReferenceFrame.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TrackingReferenceFrame.js#L6) 

 Constants for identifying well-known tracking reference frames.

##### Properties:

| Name       | Type   | Description                                                                                                                                                                                                                                                                                                                |
| ---------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| AUTODETECT | number | Auto-detect algorithm. The reference frame used to track the Entity will be automatically selected based on its trajectory: near-surface slow moving objects will be tracked in the entity's local east-north-up reference frame, while faster objects like satellites will use VVLH (Vehicle Velocity, Local Horizontal). |
| ENU        | number | The entity's local East-North-Up reference frame.                                                                                                                                                                                                                                                                          |
| INERTIAL   | number | The entity's inertial reference frame. If entity has no defined orientation property, it falls back to auto-detect algorithm.                                                                                                                                                                                              |
| VELOCITY   | number | The entity's inertial reference frame with orientation fixed to its[VelocityOrientationProperty](VelocityOrientationProperty.html), ignoring its own orientation.                                                                                                                                                          |

#### [](#UniformType) constant UniformType : string 

[engine/Source/Scene/Model/UniformType.js 9](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/UniformType.js#L9) 

 An enum of the basic GLSL uniform types. These can be used with[CustomShader](CustomShader.html) to declare user-defined uniforms.

##### Properties:

| Name          | Type   | Description                            |
| ------------- | ------ | -------------------------------------- |
| FLOAT         | string | A single floating point value.         |
| VEC2          | string | A vector of 2 floating point values.   |
| VEC3          | string | A vector of 3 floating point values.   |
| VEC4          | string | A vector of 4 floating point values.   |
| INT           | string | A single integer value                 |
| INT\_VEC2     | string | A vector of 2 integer values.          |
| INT\_VEC3     | string | A vector of 3 integer values.          |
| INT\_VEC4     | string | A vector of 4 integer values.          |
| BOOL          | string | A single boolean value.                |
| BOOL\_VEC2    | string | A vector of 2 boolean values.          |
| BOOL\_VEC3    | string | A vector of 3 boolean values.          |
| BOOL\_VEC4    | string | A vector of 4 boolean values.          |
| MAT2          | string | A 2x2 matrix of floating point values. |
| MAT3          | string | A 3x3 matrix of floating point values. |
| MAT4          | string | A 3x3 matrix of floating point values. |
| SAMPLER\_2D   | string | A 2D sampled texture.                  |
| SAMPLER\_CUBE | string |                                        |

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#VaryingType) constant VaryingType : string 

[engine/Source/Scene/Model/VaryingType.js 9](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/VaryingType.js#L9) 

 An enum for the GLSL varying types. These can be used for declaring varyings in [CustomShader](CustomShader.html) 

##### Properties:

| Name  | Type   | Description                            |
| ----- | ------ | -------------------------------------- |
| FLOAT | string | A single floating point value.         |
| VEC2  | string | A vector of 2 floating point values.   |
| VEC3  | string | A vector of 3 floating point values.   |
| VEC4  | string | A vector of 4 floating point values.   |
| MAT2  | string | A 2x2 matrix of floating point values. |
| MAT3  | string | A 3x3 matrix of floating point values. |
| MAT4  | string | A 3x3 matrix of floating point values. |

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#VerticalOrigin) constant VerticalOrigin : number 

[engine/Source/Scene/VerticalOrigin.js 16](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VerticalOrigin.js#L16) 

 The vertical location of an origin relative to an object, e.g., a [Billboard](Billboard.html)or [Label](Label.html). For example, setting the vertical origin to `TOP`or `BOTTOM` will display a billboard above or below (in screen space) the anchor position.  
  
![](Images/Billboard.setVerticalOrigin.png)  

##### Properties:

| Name     | Type   | Description                                                                                                             |
| -------- | ------ | ----------------------------------------------------------------------------------------------------------------------- |
| CENTER   | number | The origin is at the vertical center between BASELINE and TOP.                                                          |
| BOTTOM   | number | The origin is at the bottom of the object.                                                                              |
| BASELINE | number | If the object contains text, the origin is at the baseline of the text, else the origin is at the bottom of the object. |
| TOP      | number | The origin is at the top of the object.                                                                                 |

##### See:

* [Billboard#verticalOrigin](Billboard.html#verticalOrigin)
* [Label#verticalOrigin](Label.html#verticalOrigin)

#### [](#Visibility) constant Visibility : number 

[engine/Source/Core/Visibility.js 9](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Visibility.js#L9) 

 This enumerated type is used in determining to what extent an object, the occludee, is visible during horizon culling. An occluder may fully block an occludee, in which case it has no visibility, may partially block an occludee from view, or may not block it at all, leading to full visibility.

##### Properties:

| Name    | Type   | Description                                                |
| ------- | ------ | ---------------------------------------------------------- |
| NONE    | number | Represents that no part of an object is visible.           |
| PARTIAL | number | Represents that part, but not all, of an object is visible |
| FULL    | number | Represents that an object is visible in its entirety.      |

#### [](#VoxelMetadataOrder) constant VoxelMetadataOrder : number 

[engine/Source/Scene/VoxelMetadataOrder.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelMetadataOrder.js#L8) 

 Metadata ordering for voxel content. In all cases, x data is contiguous in strides along the y axis, and each group of y strides represents a z slice. However, the orientation of the axes follows different conventions.

##### Properties:

| Name | Type   | Description |
| ---- | ------ | ----------- |
| XYZ  | number |             |
| GLTF | number |             |

#### [](#VoxelShapeType) constant VoxelShapeType : string 

[engine/Source/Scene/VoxelShapeType.js 13](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelShapeType.js#L13) 

 An enum of voxel shapes. The shape controls how the voxel grid is mapped to 3D space.

##### Properties:

| Name      | Type   | Description         |
| --------- | ------ | ------------------- |
| BOX       | string | A box shape.        |
| ELLIPSOID | string | An ellipsoid shape. |
| CYLINDER  | string | A cylinder shape.   |

##### Experimental

This feature is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#WebGLConstants) constant WebGLConstants : number 

[engine/Source/Core/WebGLConstants.js 12](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebGLConstants.js#L12) 

 Enum containing WebGL Constant values by name. for use without an active WebGL context, or in cases where certain constants are unavailable using the WebGL context (For example, in [Safari 9](https://github.com/CesiumGS/cesium/issues/2989)). These match the constants from the [WebGL 1.0](https://www.khronos.org/registry/webgl/specs/latest/1.0/)and [WebGL 2.0](https://www.khronos.org/registry/webgl/specs/latest/2.0/)specifications.

##### Properties:

| Name                                              | Type   | Description |
| ------------------------------------------------- | ------ | ----------- |
| DEPTH\_BUFFER\_BIT                                | number |             |
| STENCIL\_BUFFER\_BIT                              | number |             |
| COLOR\_BUFFER\_BIT                                | number |             |
| POINTS                                            | number |             |
| LINES                                             | number |             |
| LINE\_LOOP                                        | number |             |
| LINE\_STRIP                                       | number |             |
| TRIANGLES                                         | number |             |
| TRIANGLE\_STRIP                                   | number |             |
| TRIANGLE\_FAN                                     | number |             |
| ZERO                                              | number |             |
| ONE                                               | number |             |
| SRC\_COLOR                                        | number |             |
| ONE\_MINUS\_SRC\_COLOR                            | number |             |
| SRC\_ALPHA                                        | number |             |
| ONE\_MINUS\_SRC\_ALPHA                            | number |             |
| DST\_ALPHA                                        | number |             |
| ONE\_MINUS\_DST\_ALPHA                            | number |             |
| DST\_COLOR                                        | number |             |
| ONE\_MINUS\_DST\_COLOR                            | number |             |
| SRC\_ALPHA\_SATURATE                              | number |             |
| FUNC\_ADD                                         | number |             |
| BLEND\_EQUATION                                   | number |             |
| BLEND\_EQUATION\_RGB                              | number |             |
| BLEND\_EQUATION\_ALPHA                            | number |             |
| FUNC\_SUBTRACT                                    | number |             |
| FUNC\_REVERSE\_SUBTRACT                           | number |             |
| BLEND\_DST\_RGB                                   | number |             |
| BLEND\_SRC\_RGB                                   | number |             |
| BLEND\_DST\_ALPHA                                 | number |             |
| BLEND\_SRC\_ALPHA                                 | number |             |
| CONSTANT\_COLOR                                   | number |             |
| ONE\_MINUS\_CONSTANT\_COLOR                       | number |             |
| CONSTANT\_ALPHA                                   | number |             |
| ONE\_MINUS\_CONSTANT\_ALPHA                       | number |             |
| BLEND\_COLOR                                      | number |             |
| ARRAY\_BUFFER                                     | number |             |
| ELEMENT\_ARRAY\_BUFFER                            | number |             |
| ARRAY\_BUFFER\_BINDING                            | number |             |
| ELEMENT\_ARRAY\_BUFFER\_BINDING                   | number |             |
| STREAM\_DRAW                                      | number |             |
| STATIC\_DRAW                                      | number |             |
| DYNAMIC\_DRAW                                     | number |             |
| BUFFER\_SIZE                                      | number |             |
| BUFFER\_USAGE                                     | number |             |
| CURRENT\_VERTEX\_ATTRIB                           | number |             |
| FRONT                                             | number |             |
| BACK                                              | number |             |
| FRONT\_AND\_BACK                                  | number |             |
| CULL\_FACE                                        | number |             |
| BLEND                                             | number |             |
| DITHER                                            | number |             |
| STENCIL\_TEST                                     | number |             |
| DEPTH\_TEST                                       | number |             |
| SCISSOR\_TEST                                     | number |             |
| POLYGON\_OFFSET\_FILL                             | number |             |
| SAMPLE\_ALPHA\_TO\_COVERAGE                       | number |             |
| SAMPLE\_COVERAGE                                  | number |             |
| NO\_ERROR                                         | number |             |
| INVALID\_ENUM                                     | number |             |
| INVALID\_VALUE                                    | number |             |
| INVALID\_OPERATION                                | number |             |
| OUT\_OF\_MEMORY                                   | number |             |
| CW                                                | number |             |
| CCW                                               | number |             |
| LINE\_WIDTH                                       | number |             |
| ALIASED\_POINT\_SIZE\_RANGE                       | number |             |
| ALIASED\_LINE\_WIDTH\_RANGE                       | number |             |
| CULL\_FACE\_MODE                                  | number |             |
| FRONT\_FACE                                       | number |             |
| DEPTH\_RANGE                                      | number |             |
| DEPTH\_WRITEMASK                                  | number |             |
| DEPTH\_CLEAR\_VALUE                               | number |             |
| DEPTH\_FUNC                                       | number |             |
| STENCIL\_CLEAR\_VALUE                             | number |             |
| STENCIL\_FUNC                                     | number |             |
| STENCIL\_FAIL                                     | number |             |
| STENCIL\_PASS\_DEPTH\_FAIL                        | number |             |
| STENCIL\_PASS\_DEPTH\_PASS                        | number |             |
| STENCIL\_REF                                      | number |             |
| STENCIL\_VALUE\_MASK                              | number |             |
| STENCIL\_WRITEMASK                                | number |             |
| STENCIL\_BACK\_FUNC                               | number |             |
| STENCIL\_BACK\_FAIL                               | number |             |
| STENCIL\_BACK\_PASS\_DEPTH\_FAIL                  | number |             |
| STENCIL\_BACK\_PASS\_DEPTH\_PASS                  | number |             |
| STENCIL\_BACK\_REF                                | number |             |
| STENCIL\_BACK\_VALUE\_MASK                        | number |             |
| STENCIL\_BACK\_WRITEMASK                          | number |             |
| VIEWPORT                                          | number |             |
| SCISSOR\_BOX                                      | number |             |
| COLOR\_CLEAR\_VALUE                               | number |             |
| COLOR\_WRITEMASK                                  | number |             |
| UNPACK\_ALIGNMENT                                 | number |             |
| PACK\_ALIGNMENT                                   | number |             |
| MAX\_TEXTURE\_SIZE                                | number |             |
| MAX\_VIEWPORT\_DIMS                               | number |             |
| SUBPIXEL\_BITS                                    | number |             |
| RED\_BITS                                         | number |             |
| GREEN\_BITS                                       | number |             |
| BLUE\_BITS                                        | number |             |
| ALPHA\_BITS                                       | number |             |
| DEPTH\_BITS                                       | number |             |
| STENCIL\_BITS                                     | number |             |
| POLYGON\_OFFSET\_UNITS                            | number |             |
| POLYGON\_OFFSET\_FACTOR                           | number |             |
| TEXTURE\_BINDING\_2D                              | number |             |
| SAMPLE\_BUFFERS                                   | number |             |
| SAMPLES                                           | number |             |
| SAMPLE\_COVERAGE\_VALUE                           | number |             |
| SAMPLE\_COVERAGE\_INVERT                          | number |             |
| COMPRESSED\_TEXTURE\_FORMATS                      | number |             |
| DONT\_CARE                                        | number |             |
| FASTEST                                           | number |             |
| NICEST                                            | number |             |
| GENERATE\_MIPMAP\_HINT                            | number |             |
| BYTE                                              | number |             |
| UNSIGNED\_BYTE                                    | number |             |
| SHORT                                             | number |             |
| UNSIGNED\_SHORT                                   | number |             |
| INT                                               | number |             |
| UNSIGNED\_INT                                     | number |             |
| FLOAT                                             | number |             |
| DEPTH\_COMPONENT                                  | number |             |
| ALPHA                                             | number |             |
| RGB                                               | number |             |
| RGBA                                              | number |             |
| LUMINANCE                                         | number |             |
| LUMINANCE\_ALPHA                                  | number |             |
| UNSIGNED\_SHORT\_4\_4\_4\_4                       | number |             |
| UNSIGNED\_SHORT\_5\_5\_5\_1                       | number |             |
| UNSIGNED\_SHORT\_5\_6\_5                          | number |             |
| FRAGMENT\_SHADER                                  | number |             |
| VERTEX\_SHADER                                    | number |             |
| MAX\_VERTEX\_ATTRIBS                              | number |             |
| MAX\_VERTEX\_UNIFORM\_VECTORS                     | number |             |
| MAX\_VARYING\_VECTORS                             | number |             |
| MAX\_COMBINED\_TEXTURE\_IMAGE\_UNITS              | number |             |
| MAX\_VERTEX\_TEXTURE\_IMAGE\_UNITS                | number |             |
| MAX\_TEXTURE\_IMAGE\_UNITS                        | number |             |
| MAX\_FRAGMENT\_UNIFORM\_VECTORS                   | number |             |
| SHADER\_TYPE                                      | number |             |
| DELETE\_STATUS                                    | number |             |
| LINK\_STATUS                                      | number |             |
| VALIDATE\_STATUS                                  | number |             |
| ATTACHED\_SHADERS                                 | number |             |
| ACTIVE\_UNIFORMS                                  | number |             |
| ACTIVE\_ATTRIBUTES                                | number |             |
| SHADING\_LANGUAGE\_VERSION                        | number |             |
| CURRENT\_PROGRAM                                  | number |             |
| NEVER                                             | number |             |
| LESS                                              | number |             |
| EQUAL                                             | number |             |
| LEQUAL                                            | number |             |
| GREATER                                           | number |             |
| NOTEQUAL                                          | number |             |
| GEQUAL                                            | number |             |
| ALWAYS                                            | number |             |
| KEEP                                              | number |             |
| REPLACE                                           | number |             |
| INCR                                              | number |             |
| DECR                                              | number |             |
| INVERT                                            | number |             |
| INCR\_WRAP                                        | number |             |
| DECR\_WRAP                                        | number |             |
| VENDOR                                            | number |             |
| RENDERER                                          | number |             |
| VERSION                                           | number |             |
| NEAREST                                           | number |             |
| LINEAR                                            | number |             |
| NEAREST\_MIPMAP\_NEAREST                          | number |             |
| LINEAR\_MIPMAP\_NEAREST                           | number |             |
| NEAREST\_MIPMAP\_LINEAR                           | number |             |
| LINEAR\_MIPMAP\_LINEAR                            | number |             |
| TEXTURE\_MAG\_FILTER                              | number |             |
| TEXTURE\_MIN\_FILTER                              | number |             |
| TEXTURE\_WRAP\_S                                  | number |             |
| TEXTURE\_WRAP\_T                                  | number |             |
| TEXTURE\_2D                                       | number |             |
| TEXTURE                                           | number |             |
| TEXTURE\_CUBE\_MAP                                | number |             |
| TEXTURE\_BINDING\_CUBE\_MAP                       | number |             |
| TEXTURE\_CUBE\_MAP\_POSITIVE\_X                   | number |             |
| TEXTURE\_CUBE\_MAP\_NEGATIVE\_X                   | number |             |
| TEXTURE\_CUBE\_MAP\_POSITIVE\_Y                   | number |             |
| TEXTURE\_CUBE\_MAP\_NEGATIVE\_Y                   | number |             |
| TEXTURE\_CUBE\_MAP\_POSITIVE\_Z                   | number |             |
| TEXTURE\_CUBE\_MAP\_NEGATIVE\_Z                   | number |             |
| MAX\_CUBE\_MAP\_TEXTURE\_SIZE                     | number |             |
| TEXTURE0                                          | number |             |
| TEXTURE1                                          | number |             |
| TEXTURE2                                          | number |             |
| TEXTURE3                                          | number |             |
| TEXTURE4                                          | number |             |
| TEXTURE5                                          | number |             |
| TEXTURE6                                          | number |             |
| TEXTURE7                                          | number |             |
| TEXTURE8                                          | number |             |
| TEXTURE9                                          | number |             |
| TEXTURE10                                         | number |             |
| TEXTURE11                                         | number |             |
| TEXTURE12                                         | number |             |
| TEXTURE13                                         | number |             |
| TEXTURE14                                         | number |             |
| TEXTURE15                                         | number |             |
| TEXTURE16                                         | number |             |
| TEXTURE17                                         | number |             |
| TEXTURE18                                         | number |             |
| TEXTURE19                                         | number |             |
| TEXTURE20                                         | number |             |
| TEXTURE21                                         | number |             |
| TEXTURE22                                         | number |             |
| TEXTURE23                                         | number |             |
| TEXTURE24                                         | number |             |
| TEXTURE25                                         | number |             |
| TEXTURE26                                         | number |             |
| TEXTURE27                                         | number |             |
| TEXTURE28                                         | number |             |
| TEXTURE29                                         | number |             |
| TEXTURE30                                         | number |             |
| TEXTURE31                                         | number |             |
| ACTIVE\_TEXTURE                                   | number |             |
| REPEAT                                            | number |             |
| CLAMP\_TO\_EDGE                                   | number |             |
| MIRRORED\_REPEAT                                  | number |             |
| FLOAT\_VEC2                                       | number |             |
| FLOAT\_VEC3                                       | number |             |
| FLOAT\_VEC4                                       | number |             |
| INT\_VEC2                                         | number |             |
| INT\_VEC3                                         | number |             |
| INT\_VEC4                                         | number |             |
| BOOL                                              | number |             |
| BOOL\_VEC2                                        | number |             |
| BOOL\_VEC3                                        | number |             |
| BOOL\_VEC4                                        | number |             |
| FLOAT\_MAT2                                       | number |             |
| FLOAT\_MAT3                                       | number |             |
| FLOAT\_MAT4                                       | number |             |
| SAMPLER\_2D                                       | number |             |
| SAMPLER\_CUBE                                     | number |             |
| VERTEX\_ATTRIB\_ARRAY\_ENABLED                    | number |             |
| VERTEX\_ATTRIB\_ARRAY\_SIZE                       | number |             |
| VERTEX\_ATTRIB\_ARRAY\_STRIDE                     | number |             |
| VERTEX\_ATTRIB\_ARRAY\_TYPE                       | number |             |
| VERTEX\_ATTRIB\_ARRAY\_NORMALIZED                 | number |             |
| VERTEX\_ATTRIB\_ARRAY\_POINTER                    | number |             |
| VERTEX\_ATTRIB\_ARRAY\_BUFFER\_BINDING            | number |             |
| IMPLEMENTATION\_COLOR\_READ\_TYPE                 | number |             |
| IMPLEMENTATION\_COLOR\_READ\_FORMAT               | number |             |
| COMPILE\_STATUS                                   | number |             |
| LOW\_FLOAT                                        | number |             |
| MEDIUM\_FLOAT                                     | number |             |
| HIGH\_FLOAT                                       | number |             |
| LOW\_INT                                          | number |             |
| MEDIUM\_INT                                       | number |             |
| HIGH\_INT                                         | number |             |
| FRAMEBUFFER                                       | number |             |
| RENDERBUFFER                                      | number |             |
| RGBA4                                             | number |             |
| RGB5\_A1                                          | number |             |
| RGB565                                            | number |             |
| DEPTH\_COMPONENT16                                | number |             |
| STENCIL\_INDEX                                    | number |             |
| STENCIL\_INDEX8                                   | number |             |
| DEPTH\_STENCIL                                    | number |             |
| RENDERBUFFER\_WIDTH                               | number |             |
| RENDERBUFFER\_HEIGHT                              | number |             |
| RENDERBUFFER\_INTERNAL\_FORMAT                    | number |             |
| RENDERBUFFER\_RED\_SIZE                           | number |             |
| RENDERBUFFER\_GREEN\_SIZE                         | number |             |
| RENDERBUFFER\_BLUE\_SIZE                          | number |             |
| RENDERBUFFER\_ALPHA\_SIZE                         | number |             |
| RENDERBUFFER\_DEPTH\_SIZE                         | number |             |
| RENDERBUFFER\_STENCIL\_SIZE                       | number |             |
| FRAMEBUFFER\_ATTACHMENT\_OBJECT\_TYPE             | number |             |
| FRAMEBUFFER\_ATTACHMENT\_OBJECT\_NAME             | number |             |
| FRAMEBUFFER\_ATTACHMENT\_TEXTURE\_LEVEL           | number |             |
| FRAMEBUFFER\_ATTACHMENT\_TEXTURE\_CUBE\_MAP\_FACE | number |             |
| COLOR\_ATTACHMENT0                                | number |             |
| DEPTH\_ATTACHMENT                                 | number |             |
| STENCIL\_ATTACHMENT                               | number |             |
| DEPTH\_STENCIL\_ATTACHMENT                        | number |             |
| NONE                                              | number |             |
| FRAMEBUFFER\_COMPLETE                             | number |             |
| FRAMEBUFFER\_INCOMPLETE\_ATTACHMENT               | number |             |
| FRAMEBUFFER\_INCOMPLETE\_MISSING\_ATTACHMENT      | number |             |
| FRAMEBUFFER\_INCOMPLETE\_DIMENSIONS               | number |             |
| FRAMEBUFFER\_UNSUPPORTED                          | number |             |
| FRAMEBUFFER\_BINDING                              | number |             |
| RENDERBUFFER\_BINDING                             | number |             |
| MAX\_RENDERBUFFER\_SIZE                           | number |             |
| INVALID\_FRAMEBUFFER\_OPERATION                   | number |             |
| UNPACK\_FLIP\_Y\_WEBGL                            | number |             |
| UNPACK\_PREMULTIPLY\_ALPHA\_WEBGL                 | number |             |
| CONTEXT\_LOST\_WEBGL                              | number |             |
| UNPACK\_COLORSPACE\_CONVERSION\_WEBGL             | number |             |
| BROWSER\_DEFAULT\_WEBGL                           | number |             |
| COMPRESSED\_RGB\_S3TC\_DXT1\_EXT                  | number |             |
| COMPRESSED\_RGBA\_S3TC\_DXT1\_EXT                 | number |             |
| COMPRESSED\_RGBA\_S3TC\_DXT3\_EXT                 | number |             |
| COMPRESSED\_RGBA\_S3TC\_DXT5\_EXT                 | number |             |
| COMPRESSED\_RGB\_PVRTC\_4BPPV1\_IMG               | number |             |
| COMPRESSED\_RGB\_PVRTC\_2BPPV1\_IMG               | number |             |
| COMPRESSED\_RGBA\_PVRTC\_4BPPV1\_IMG              | number |             |
| COMPRESSED\_RGBA\_PVRTC\_2BPPV1\_IMG              | number |             |
| COMPRESSED\_RGBA\_ASTC\_4x4\_WEBGL                | number |             |
| COMPRESSED\_RGB\_ETC1\_WEBGL                      | number |             |
| COMPRESSED\_RGBA\_BPTC\_UNORM                     | number |             |
| HALF\_FLOAT\_OES                                  | number |             |
| DOUBLE                                            | number |             |
| READ\_BUFFER                                      | number |             |
| UNPACK\_ROW\_LENGTH                               | number |             |
| UNPACK\_SKIP\_ROWS                                | number |             |
| UNPACK\_SKIP\_PIXELS                              | number |             |
| PACK\_ROW\_LENGTH                                 | number |             |
| PACK\_SKIP\_ROWS                                  | number |             |
| PACK\_SKIP\_PIXELS                                | number |             |
| COLOR                                             | number |             |
| DEPTH                                             | number |             |
| STENCIL                                           | number |             |
| RED                                               | number |             |
| RGB8                                              | number |             |
| RGBA8                                             | number |             |
| RGB10\_A2                                         | number |             |
| TEXTURE\_BINDING\_3D                              | number |             |
| UNPACK\_SKIP\_IMAGES                              | number |             |
| UNPACK\_IMAGE\_HEIGHT                             | number |             |
| TEXTURE\_3D                                       | number |             |
| TEXTURE\_WRAP\_R                                  | number |             |
| MAX\_3D\_TEXTURE\_SIZE                            | number |             |
| UNSIGNED\_INT\_2\_10\_10\_10\_REV                 | number |             |
| MAX\_ELEMENTS\_VERTICES                           | number |             |
| MAX\_ELEMENTS\_INDICES                            | number |             |
| TEXTURE\_MIN\_LOD                                 | number |             |
| TEXTURE\_MAX\_LOD                                 | number |             |
| TEXTURE\_BASE\_LEVEL                              | number |             |
| TEXTURE\_MAX\_LEVEL                               | number |             |
| MIN                                               | number |             |
| MAX                                               | number |             |
| DEPTH\_COMPONENT24                                | number |             |
| MAX\_TEXTURE\_LOD\_BIAS                           | number |             |
| TEXTURE\_COMPARE\_MODE                            | number |             |
| TEXTURE\_COMPARE\_FUNC                            | number |             |
| CURRENT\_QUERY                                    | number |             |
| QUERY\_RESULT                                     | number |             |
| QUERY\_RESULT\_AVAILABLE                          | number |             |
| STREAM\_READ                                      | number |             |
| STREAM\_COPY                                      | number |             |
| STATIC\_READ                                      | number |             |
| STATIC\_COPY                                      | number |             |
| DYNAMIC\_READ                                     | number |             |
| DYNAMIC\_COPY                                     | number |             |
| MAX\_DRAW\_BUFFERS                                | number |             |
| DRAW\_BUFFER0                                     | number |             |
| DRAW\_BUFFER1                                     | number |             |
| DRAW\_BUFFER2                                     | number |             |
| DRAW\_BUFFER3                                     | number |             |
| DRAW\_BUFFER4                                     | number |             |
| DRAW\_BUFFER5                                     | number |             |
| DRAW\_BUFFER6                                     | number |             |
| DRAW\_BUFFER7                                     | number |             |
| DRAW\_BUFFER8                                     | number |             |
| DRAW\_BUFFER9                                     | number |             |
| DRAW\_BUFFER10                                    | number |             |
| DRAW\_BUFFER11                                    | number |             |
| DRAW\_BUFFER12                                    | number |             |
| DRAW\_BUFFER13                                    | number |             |
| DRAW\_BUFFER14                                    | number |             |
| DRAW\_BUFFER15                                    | number |             |
| MAX\_FRAGMENT\_UNIFORM\_COMPONENTS                | number |             |
| MAX\_VERTEX\_UNIFORM\_COMPONENTS                  | number |             |
| SAMPLER\_3D                                       | number |             |
| SAMPLER\_2D\_SHADOW                               | number |             |
| FRAGMENT\_SHADER\_DERIVATIVE\_HINT                | number |             |
| PIXEL\_PACK\_BUFFER                               | number |             |
| PIXEL\_UNPACK\_BUFFER                             | number |             |
| PIXEL\_PACK\_BUFFER\_BINDING                      | number |             |
| PIXEL\_UNPACK\_BUFFER\_BINDING                    | number |             |
| FLOAT\_MAT2x3                                     | number |             |
| FLOAT\_MAT2x4                                     | number |             |
| FLOAT\_MAT3x2                                     | number |             |
| FLOAT\_MAT3x4                                     | number |             |
| FLOAT\_MAT4x2                                     | number |             |
| FLOAT\_MAT4x3                                     | number |             |
| SRGB                                              | number |             |
| SRGB8                                             | number |             |
| SRGB8\_ALPHA8                                     | number |             |
| COMPARE\_REF\_TO\_TEXTURE                         | number |             |
| RGBA32F                                           | number |             |
| RGB32F                                            | number |             |
| RGBA16F                                           | number |             |
| RGB16F                                            | number |             |
| VERTEX\_ATTRIB\_ARRAY\_INTEGER                    | number |             |
| MAX\_ARRAY\_TEXTURE\_LAYERS                       | number |             |
| MIN\_PROGRAM\_TEXEL\_OFFSET                       | number |             |
| MAX\_PROGRAM\_TEXEL\_OFFSET                       | number |             |
| MAX\_VARYING\_COMPONENTS                          | number |             |
| TEXTURE\_2D\_ARRAY                                | number |             |
| TEXTURE\_BINDING\_2D\_ARRAY                       | number |             |
| R11F\_G11F\_B10F                                  | number |             |
| UNSIGNED\_INT\_10F\_11F\_11F\_REV                 | number |             |
| RGB9\_E5                                          | number |             |
| UNSIGNED\_INT\_5\_9\_9\_9\_REV                    | number |             |
| TRANSFORM\_FEEDBACK\_BUFFER\_MODE                 | number |             |
| MAX\_TRANSFORM\_FEEDBACK\_SEPARATE\_COMPONENTS    | number |             |
| TRANSFORM\_FEEDBACK\_VARYINGS                     | number |             |
| TRANSFORM\_FEEDBACK\_BUFFER\_START                | number |             |
| TRANSFORM\_FEEDBACK\_BUFFER\_SIZE                 | number |             |
| TRANSFORM\_FEEDBACK\_PRIMITIVES\_WRITTEN          | number |             |
| RASTERIZER\_DISCARD                               | number |             |
| MAX\_TRANSFORM\_FEEDBACK\_INTERLEAVED\_COMPONENTS | number |             |
| MAX\_TRANSFORM\_FEEDBACK\_SEPARATE\_ATTRIBS       | number |             |
| INTERLEAVED\_ATTRIBS                              | number |             |
| SEPARATE\_ATTRIBS                                 | number |             |
| TRANSFORM\_FEEDBACK\_BUFFER                       | number |             |
| TRANSFORM\_FEEDBACK\_BUFFER\_BINDING              | number |             |
| RGBA32UI                                          | number |             |
| RGB32UI                                           | number |             |
| RGBA16UI                                          | number |             |
| RGB16UI                                           | number |             |
| RGBA8UI                                           | number |             |
| RGB8UI                                            | number |             |
| RGBA32I                                           | number |             |
| RGB32I                                            | number |             |
| RGBA16I                                           | number |             |
| RGB16I                                            | number |             |
| RGBA8I                                            | number |             |
| RGB8I                                             | number |             |
| RED\_INTEGER                                      | number |             |
| RGB\_INTEGER                                      | number |             |
| RGBA\_INTEGER                                     | number |             |
| SAMPLER\_2D\_ARRAY                                | number |             |
| SAMPLER\_2D\_ARRAY\_SHADOW                        | number |             |
| SAMPLER\_CUBE\_SHADOW                             | number |             |
| UNSIGNED\_INT\_VEC2                               | number |             |
| UNSIGNED\_INT\_VEC3                               | number |             |
| UNSIGNED\_INT\_VEC4                               | number |             |
| INT\_SAMPLER\_2D                                  | number |             |
| INT\_SAMPLER\_3D                                  | number |             |
| INT\_SAMPLER\_CUBE                                | number |             |
| INT\_SAMPLER\_2D\_ARRAY                           | number |             |
| UNSIGNED\_INT\_SAMPLER\_2D                        | number |             |
| UNSIGNED\_INT\_SAMPLER\_3D                        | number |             |
| UNSIGNED\_INT\_SAMPLER\_CUBE                      | number |             |
| UNSIGNED\_INT\_SAMPLER\_2D\_ARRAY                 | number |             |
| DEPTH\_COMPONENT32F                               | number |             |
| DEPTH32F\_STENCIL8                                | number |             |
| FLOAT\_32\_UNSIGNED\_INT\_24\_8\_REV              | number |             |
| FRAMEBUFFER\_ATTACHMENT\_COLOR\_ENCODING          | number |             |
| FRAMEBUFFER\_ATTACHMENT\_COMPONENT\_TYPE          | number |             |
| FRAMEBUFFER\_ATTACHMENT\_RED\_SIZE                | number |             |
| FRAMEBUFFER\_ATTACHMENT\_GREEN\_SIZE              | number |             |
| FRAMEBUFFER\_ATTACHMENT\_BLUE\_SIZE               | number |             |
| FRAMEBUFFER\_ATTACHMENT\_ALPHA\_SIZE              | number |             |
| FRAMEBUFFER\_ATTACHMENT\_DEPTH\_SIZE              | number |             |
| FRAMEBUFFER\_ATTACHMENT\_STENCIL\_SIZE            | number |             |
| FRAMEBUFFER\_DEFAULT                              | number |             |
| UNSIGNED\_INT\_24\_8                              | number |             |
| DEPTH24\_STENCIL8                                 | number |             |
| UNSIGNED\_NORMALIZED                              | number |             |
| DRAW\_FRAMEBUFFER\_BINDING                        | number |             |
| READ\_FRAMEBUFFER                                 | number |             |
| DRAW\_FRAMEBUFFER                                 | number |             |
| READ\_FRAMEBUFFER\_BINDING                        | number |             |
| RENDERBUFFER\_SAMPLES                             | number |             |
| FRAMEBUFFER\_ATTACHMENT\_TEXTURE\_LAYER           | number |             |
| MAX\_COLOR\_ATTACHMENTS                           | number |             |
| COLOR\_ATTACHMENT1                                | number |             |
| COLOR\_ATTACHMENT2                                | number |             |
| COLOR\_ATTACHMENT3                                | number |             |
| COLOR\_ATTACHMENT4                                | number |             |
| COLOR\_ATTACHMENT5                                | number |             |
| COLOR\_ATTACHMENT6                                | number |             |
| COLOR\_ATTACHMENT7                                | number |             |
| COLOR\_ATTACHMENT8                                | number |             |
| COLOR\_ATTACHMENT9                                | number |             |
| COLOR\_ATTACHMENT10                               | number |             |
| COLOR\_ATTACHMENT11                               | number |             |
| COLOR\_ATTACHMENT12                               | number |             |
| COLOR\_ATTACHMENT13                               | number |             |
| COLOR\_ATTACHMENT14                               | number |             |
| COLOR\_ATTACHMENT15                               | number |             |
| FRAMEBUFFER\_INCOMPLETE\_MULTISAMPLE              | number |             |
| MAX\_SAMPLES                                      | number |             |
| HALF\_FLOAT                                       | number |             |
| RG                                                | number |             |
| RG\_INTEGER                                       | number |             |
| R8                                                | number |             |
| RG8                                               | number |             |
| R16F                                              | number |             |
| R32F                                              | number |             |
| RG16F                                             | number |             |
| RG32F                                             | number |             |
| R8I                                               | number |             |
| R8UI                                              | number |             |
| R16I                                              | number |             |
| R16UI                                             | number |             |
| R32I                                              | number |             |
| R32UI                                             | number |             |
| RG8I                                              | number |             |
| RG8UI                                             | number |             |
| RG16I                                             | number |             |
| RG16UI                                            | number |             |
| RG32I                                             | number |             |
| RG32UI                                            | number |             |
| VERTEX\_ARRAY\_BINDING                            | number |             |
| R8\_SNORM                                         | number |             |
| RG8\_SNORM                                        | number |             |
| RGB8\_SNORM                                       | number |             |
| RGBA8\_SNORM                                      | number |             |
| SIGNED\_NORMALIZED                                | number |             |
| COPY\_READ\_BUFFER                                | number |             |
| COPY\_WRITE\_BUFFER                               | number |             |
| COPY\_READ\_BUFFER\_BINDING                       | number |             |
| COPY\_WRITE\_BUFFER\_BINDING                      | number |             |
| UNIFORM\_BUFFER                                   | number |             |
| UNIFORM\_BUFFER\_BINDING                          | number |             |
| UNIFORM\_BUFFER\_START                            | number |             |
| UNIFORM\_BUFFER\_SIZE                             | number |             |
| MAX\_VERTEX\_UNIFORM\_BLOCKS                      | number |             |
| MAX\_FRAGMENT\_UNIFORM\_BLOCKS                    | number |             |
| MAX\_COMBINED\_UNIFORM\_BLOCKS                    | number |             |
| MAX\_UNIFORM\_BUFFER\_BINDINGS                    | number |             |
| MAX\_UNIFORM\_BLOCK\_SIZE                         | number |             |
| MAX\_COMBINED\_VERTEX\_UNIFORM\_COMPONENTS        | number |             |
| MAX\_COMBINED\_FRAGMENT\_UNIFORM\_COMPONENTS      | number |             |
| UNIFORM\_BUFFER\_OFFSET\_ALIGNMENT                | number |             |
| ACTIVE\_UNIFORM\_BLOCKS                           | number |             |
| UNIFORM\_TYPE                                     | number |             |
| UNIFORM\_SIZE                                     | number |             |
| UNIFORM\_BLOCK\_INDEX                             | number |             |
| UNIFORM\_OFFSET                                   | number |             |
| UNIFORM\_ARRAY\_STRIDE                            | number |             |
| UNIFORM\_MATRIX\_STRIDE                           | number |             |
| UNIFORM\_IS\_ROW\_MAJOR                           | number |             |
| UNIFORM\_BLOCK\_BINDING                           | number |             |
| UNIFORM\_BLOCK\_DATA\_SIZE                        | number |             |
| UNIFORM\_BLOCK\_ACTIVE\_UNIFORMS                  | number |             |
| UNIFORM\_BLOCK\_ACTIVE\_UNIFORM\_INDICES          | number |             |
| UNIFORM\_BLOCK\_REFERENCED\_BY\_VERTEX\_SHADER    | number |             |
| UNIFORM\_BLOCK\_REFERENCED\_BY\_FRAGMENT\_SHADER  | number |             |
| INVALID\_INDEX                                    | number |             |
| MAX\_VERTEX\_OUTPUT\_COMPONENTS                   | number |             |
| MAX\_FRAGMENT\_INPUT\_COMPONENTS                  | number |             |
| MAX\_SERVER\_WAIT\_TIMEOUT                        | number |             |
| OBJECT\_TYPE                                      | number |             |
| SYNC\_CONDITION                                   | number |             |
| SYNC\_STATUS                                      | number |             |
| SYNC\_FLAGS                                       | number |             |
| SYNC\_FENCE                                       | number |             |
| SYNC\_GPU\_COMMANDS\_COMPLETE                     | number |             |
| UNSIGNALED                                        | number |             |
| SIGNALED                                          | number |             |
| ALREADY\_SIGNALED                                 | number |             |
| TIMEOUT\_EXPIRED                                  | number |             |
| CONDITION\_SATISFIED                              | number |             |
| WAIT\_FAILED                                      | number |             |
| SYNC\_FLUSH\_COMMANDS\_BIT                        | number |             |
| VERTEX\_ATTRIB\_ARRAY\_DIVISOR                    | number |             |
| ANY\_SAMPLES\_PASSED                              | number |             |
| ANY\_SAMPLES\_PASSED\_CONSERVATIVE                | number |             |
| SAMPLER\_BINDING                                  | number |             |
| RGB10\_A2UI                                       | number |             |
| INT\_2\_10\_10\_10\_REV                           | number |             |
| TRANSFORM\_FEEDBACK                               | number |             |
| TRANSFORM\_FEEDBACK\_PAUSED                       | number |             |
| TRANSFORM\_FEEDBACK\_ACTIVE                       | number |             |
| TRANSFORM\_FEEDBACK\_BINDING                      | number |             |
| COMPRESSED\_R11\_EAC                              | number |             |
| COMPRESSED\_SIGNED\_R11\_EAC                      | number |             |
| COMPRESSED\_RG11\_EAC                             | number |             |
| COMPRESSED\_SIGNED\_RG11\_EAC                     | number |             |
| COMPRESSED\_RGB8\_ETC2                            | number |             |
| COMPRESSED\_SRGB8\_ETC2                           | number |             |
| COMPRESSED\_RGB8\_PUNCHTHROUGH\_ALPHA1\_ETC2      | number |             |
| COMPRESSED\_SRGB8\_PUNCHTHROUGH\_ALPHA1\_ETC2     | number |             |
| COMPRESSED\_RGBA8\_ETC2\_EAC                      | number |             |
| COMPRESSED\_SRGB8\_ALPHA8\_ETC2\_EAC              | number |             |
| TEXTURE\_IMMUTABLE\_FORMAT                        | number |             |
| MAX\_ELEMENT\_INDEX                               | number |             |
| TEXTURE\_IMMUTABLE\_LEVELS                        | number |             |
| MAX\_TEXTURE\_MAX\_ANISOTROPY\_EXT                | number |             |

#### [](#WindingOrder) constant WindingOrder : number 

[engine/Source/Core/WindingOrder.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WindingOrder.js#L8) 

 Winding order defines the order of vertices for a triangle to be considered front-facing.

##### Properties:

| Name               | Type   | Description                              |
| ------------------ | ------ | ---------------------------------------- |
| CLOCKWISE          | number | Vertices are in clockwise order.         |
| COUNTER\_CLOCKWISE | number | Vertices are in counter-clockwise order. |

### Methods

#### [](#barycentricCoordinates) barycentricCoordinates(point, p0, p1, p2, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/Core/barycentricCoordinates.js 31](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/barycentricCoordinates.js#L31) 

 Computes the barycentric coordinates for a point with respect to a triangle.

| Name   | Type                                                         | Description                                                                |
| ------ | ------------------------------------------------------------ | -------------------------------------------------------------------------- |
| point  | [Cartesian2](Cartesian2.html)\|[Cartesian3](Cartesian3.html) | The point to test.                                                         |
| p0     | [Cartesian2](Cartesian2.html)\|[Cartesian3](Cartesian3.html) | The first point of the triangle, corresponding to the barycentric x-axis.  |
| p1     | [Cartesian2](Cartesian2.html)\|[Cartesian3](Cartesian3.html) | The second point of the triangle, corresponding to the barycentric y-axis. |
| p2     | [Cartesian2](Cartesian2.html)\|[Cartesian3](Cartesian3.html) | The third point of the triangle, corresponding to the barycentric z-axis.  |
| result | [Cartesian3](Cartesian3.html)                                | optional The object onto which to store the result.                        |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if one was not provided. If the triangle is degenerate the function will return undefined.

##### Example:

```javascript
// Returns Cartesian3.UNIT_X
const p = new Cesium.Cartesian3(-1.0, 0.0, 0.0);
const b = Cesium.barycentricCoordinates(p,
  new Cesium.Cartesian3(-1.0, 0.0, 0.0),
  new Cesium.Cartesian3( 1.0, 0.0, 0.0),
  new Cesium.Cartesian3( 0.0, 1.0, 1.0));
```

#### [](#binarySearch) binarySearch(array, itemToFind, comparator) → number 

[engine/Source/Core/binarySearch.js 24](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/binarySearch.js#L24) 

 Finds an item in a sorted array.

| Name       | Type                                                         | Description                                                       |
| ---------- | ------------------------------------------------------------ | ----------------------------------------------------------------- |
| array      | Array                                                        | The sorted array to search.                                       |
| itemToFind | \*                                                           | The item to find in the array.                                    |
| comparator | [binarySearchComparator](global.html#binarySearchComparator) | The function to use to compare the item to elements in the array. |

##### Returns:

 The index of `itemToFind` in the array, if it exists. If `itemToFind` does not exist, the return value is a negative number which is the bitwise complement (\~) of the index before which the itemToFind should be inserted in order to maintain the sorted order of the array.

##### Example:

```javascript
// Create a comparator function to search through an array of numbers.
function comparator(a, b) {
    return a - b;
};
const numbers = [0, 2, 4, 6, 8];
const index = Cesium.binarySearch(numbers, 6, comparator); // 3
```

#### [](#buildModuleUrl) buildModuleUrl(relativeUrl) → string 

[engine/Source/Core/buildModuleUrl.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/buildModuleUrl.js#L109) 

 Given a relative URL under the Cesium base URL, returns an absolute URL.

| Name        | Type   | Description        |
| ----------- | ------ | ------------------ |
| relativeUrl | string | The relative path. |

##### Returns:

 The absolutely URL representation of the provided path.

##### Example:

```javascript
const viewer = new Cesium.Viewer("cesiumContainer", {
  baseLayer: Cesium.ImageryLayer.fromProviderAsync(
    Cesium.TileMapServiceImageryProvider.fromUrl(
      Cesium.buildModuleUrl("Assets/Textures/NaturalEarthII"),
    )),
  baseLayerPicker: false,
});
```

#### [](#clone) clone(object, deep) → object 

[engine/Source/Core/clone.js 12](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/clone.js#L12) 

 Clones an object, returning a new object containing the same properties.

| Name   | Type    | Default | Description                                                       |
| ------ | ------- | ------- | ----------------------------------------------------------------- |
| object | object  |         | The object to clone.                                              |
| deep   | boolean | false   | optional If true, all properties will be deep cloned recursively. |

##### Returns:

 The cloned object.

#### [](#combine) combine(object1, object2, deep) → object 

[engine/Source/Core/combine.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/combine.js#L35) 

 Merges two objects, copying their properties onto a new combined object. When two objects have the same property, the value of the property on the first object is used. If either object is undefined, it will be treated as an empty object.

| Name    | Type    | Default | Description                          |
| ------- | ------- | ------- | ------------------------------------ |
| object1 | object  |         | optional The first object to merge.  |
| object2 | object  |         | optional The second object to merge. |
| deep    | boolean | false   | optional Perform a recursive merge.  |

##### Returns:

 The combined object containing all properties from both objects.

##### Example:

```javascript
const object1 = {
    propOne : 1,
    propTwo : {
        value1 : 10
    }
}
const object2 = {
    propTwo : 2
}
const final = Cesium.combine(object1, object2);

// final === {
//     propOne : 1,
//     propTwo : {
//         value1 : 10
//     }
// }
```

#### [](#computePickingDrawingBufferRectangle) computePickingDrawingBufferRectangle(drawingBufferHeight, position, width, height, result) → [BoundingRectangle](BoundingRectangle.html) 

[engine/Source/Scene/Picking.js 251](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Picking.js#L251) 

 Compute the rectangle that describes the part of the drawing buffer that is relevant for picking.

| Name                | Type                                        | Description                                                                            |
| ------------------- | ------------------------------------------- | -------------------------------------------------------------------------------------- |
| drawingBufferHeight | number                                      | The height of the drawing buffer                                                       |
| position            | [Cartesian2](Cartesian2.html)               | The position inside the drawing buffer                                                 |
| width               | number\|undefined                           | The width of the rectangle, assumed to be an odd integer number, default : 3.0         |
| height              | number\|undefined                           | The height of the rectangle. If unspecified, height will default to the value of width |
| result              | [BoundingRectangle](BoundingRectangle.html) | The result rectangle                                                                   |

##### Returns:

 The result rectangle

#### [](#createAnchorPointDirect) createAnchorPointDirect(anchorPointDirectJson) → [AnchorPointDirect](AnchorPointDirect.html) 

[engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLoader.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLoader.js#L55) 

 Creates an \`AnchorPointDirect\` from the given JSON representation

| Name                  | Type   | Description    |
| --------------------- | ------ | -------------- |
| anchorPointDirectJson | object | The input JSON |

##### Returns:

 The direct anchor point

#### [](#createAnchorPointIndirect) createAnchorPointIndirect(anchorPointIndirectJson) → [AnchorPointIndirect](AnchorPointIndirect.html) 

[engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLoader.js 79](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLoader.js#L79) 

 Creates an \`AnchorPointIndirect\` from the given JSON representation

| Name                    | Type   | Description    |
| ----------------------- | ------ | -------------- |
| anchorPointIndirectJson | object | The input JSON |

##### Returns:

 The indirect anchor point

#### [](#createCommand) createCommand(func, canExecute) 

[widgets/Source/createCommand.js 17](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/createCommand.js#L17) 

 Create a Command from a given function, for use with ViewModels. A Command is a function with an extra `canExecute` observable property to determine whether the command can be executed. When executed, a Command function will check the value of `canExecute` and throw if false. It also provides events for when a command has been or is about to be executed.

| Name       | Type     | Default | Description                                                                   |
| ---------- | -------- | ------- | ----------------------------------------------------------------------------- |
| func       | function |         | The function to execute.                                                      |
| canExecute | boolean  | true    | optional A boolean indicating whether the function can currently be executed. |

#### [](#createCorrelationGroup) createCorrelationGroup(correlationGroupJson) → [CorrelationGroup](CorrelationGroup.html) 

[engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLoader.js 107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLoader.js#L107) 

 Creates a \`CorrelationGroup\` from the given JSON representation

| Name                 | Type   | Description    |
| -------------------- | ------ | -------------- |
| correlationGroupJson | object | The input JSON |

##### Returns:

 The correlation group

#### [](#createCovarianceMatrixFromUpperTriangle) createCovarianceMatrixFromUpperTriangle(array) → [Matrix3](Matrix3.html) 

[engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLoader.js 34](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLoader.js#L34) 

 Creates a Matrix3 that describes a covariance matrix (which is symmetric) from the array containing the upper triangle, in column-major order.

| Name  | Type           | Description     |
| ----- | -------------- | --------------- |
| array | Array.<number> | The input array |

##### Returns:

 The Matrix3

#### [](#createElevationBandMaterial) createElevationBandMaterial(options) → [Material](Material.html) 

[engine/Source/Scene/createElevationBandMaterial.js 425](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/createElevationBandMaterial.js#L425) 

 Creates a [Material](Material.html) that combines multiple layers of color/gradient bands and maps them to terrain heights. The shader does a binary search over all the heights to find out which colors are above and below a given height, and interpolates between them for the final color. This material supports hundreds of entries relatively cheaply.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                          |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description scene [Scene](Scene.html)  The scene where the visualization is taking place. layers Array.<[createElevationBandMaterialBand](global.html#createElevationBandMaterialBand)\>  A list of bands ordered from lowest to highest precedence. |

##### Returns:

 A new [Material](Material.html) instance.

##### Example:

```javascript
scene.globe.material = Cesium.createElevationBandMaterial({
    scene : scene,
    layers : [{
        entries : [{
            height : 4200.0,
            color : new Cesium.Color(0.0, 0.0, 0.0, 1.0)
        }, {
            height : 8848.0,
            color : new Cesium.Color(1.0, 1.0, 1.0, 1.0)
        }],
        extendDownwards : true,
        extendUpwards : true,
    }, {
        entries : [{
            height : 7000.0,
            color : new Cesium.Color(1.0, 0.0, 0.0, 0.5)
        }, {
            height : 7100.0,
            color : new Cesium.Color(1.0, 0.0, 0.0, 0.5)
        }]
    }]
});
```

##### Demo:

* [Cesium Sandcastle Elevation Band Demo](https://sandcastle.cesium.com/index.html?src=Elevation%2520Band%2520Material.html)

#### [](#createGooglePhotorealistic3DTileset) async createGooglePhotorealistic3DTileset(apiOptions, tilesetOptions) → Promise.<[Cesium3DTileset](Cesium3DTileset.html)\> 

[engine/Source/Scene/createGooglePhotorealistic3DTileset.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/createGooglePhotorealistic3DTileset.js#L60) 

 Creates a [Cesium3DTileset](Cesium3DTileset.html) instance for the Google Photorealistic 3D Tiles tileset. Google Photorealistic 3D Tiles can only be used with the Google geocoder. To confirm that you are aware of this restriction pass \`usingOnlyWithGoogleGeocoder: true\` to the apiOptions. Otherwise a one time warning will be displayed when this function is called.

| Name           | Type                                                                           | Description                                                                                                                                                                                                                                                                                                                                                                                   |
| -------------- | ------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| apiOptions     | object                                                                         | optional Name Type Default Description key string GoogleMaps.defaultApiKey optional Your API key to access Google Photorealistic 3D Tiles. See <https://developers.google.com/maps/documentation/javascript/get-api-key> for instructions on how to create your own key. onlyUsingWithGoogleGeocoder true optional Confirmation that this tileset will only be used with the Google geocoder. |
| tilesetOptions | [Cesium3DTileset.ConstructorOptions](Cesium3DTileset.html#.ConstructorOptions) | optional An object describing initialization options.                                                                                                                                                                                                                                                                                                                                         |

##### Returns:

##### Examples:

```javascript
const viewer = new Cesium.Viewer("cesiumContainer", {
  geocoder: Cesium.IonGeocodeProviderType.GOOGLE
});

try {
  const tileset = await Cesium.createGooglePhotorealistic3DTileset({
     onlyUsingWithGoogleGeocoder: true,
  });
  viewer.scene.primitives.add(tileset));
} catch (error) {
  console.log(`Error creating tileset: ${error}`);
}
```

```javascript
// Use your own Google Maps API key
Cesium.GoogleMaps.defaultApiKey = "your-api-key";

const viewer = new Cesium.Viewer("cesiumContainer". {
  geocoder: Cesium.IonGeocodeProviderType.GOOGLE
});

try {
  const tileset = await Cesium.createGooglePhotorealistic3DTileset({
     onlyUsingWithGoogleGeocoder: true,
  });
  viewer.scene.primitives.add(tileset));
} catch (error) {
  console.log(`Error creating tileset: ${error}`);
}
```

##### See:

* [GoogleMaps](GoogleMaps.html)

#### [](#createGuid) createGuid() → string 

[engine/Source/Core/createGuid.js 14](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/createGuid.js#L14) 

 Creates a Globally unique identifier (GUID) string. A GUID is 128 bits long, and can guarantee uniqueness across space and time.

##### Returns:

##### Example:

```javascript
this.guid = Cesium.createGuid();
```

##### See:

* [RFC 4122 A Universally Unique IDentifier (UUID) URN Namespace](http://www.ietf.org/rfc/rfc4122.txt)

#### [](#createOsmBuildingsAsync) async createOsmBuildingsAsync(options) → Promise.<[Cesium3DTileset](Cesium3DTileset.html)\> 

[engine/Source/Scene/createOsmBuildingsAsync.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/createOsmBuildingsAsync.js#L60) 

 Creates a [Cesium3DTileset](Cesium3DTileset.html) instance for the[Cesium OSM Buildings](https://cesium.com/content/cesium-osm-buildings/)tileset.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Construction options. Any options allowed by the [Cesium3DTileset](Cesium3DTileset.html) constructor may be specified here. In addition to those, the following properties are supported: Name Type Default Description defaultColor [Color](Color.html) Color.WHITE optional The default color to use for buildings that do not have a color. This parameter is ignored if options.style is specified. style [Cesium3DTileStyle](Cesium3DTileStyle.html) optional The style to use with the tileset. If not specified, a default style is used which gives each building or building part a color inferred from its OpenStreetMap tags. If no color can be inferred,options.defaultColor is used. enableShowOutline boolean true optional If true, enable rendering outlines. This can be set to false to avoid the additional processing of geometry at load time. showOutline boolean true optional Whether to show outlines around buildings. When true, outlines are displayed. When false, outlines are not displayed. |

##### Returns:

##### Examples:

```javascript
// Create Cesium OSM Buildings with default styling
const viewer = new Cesium.Viewer("cesiumContainer");
try {
  const tileset = await Cesium.createOsmBuildingsAsync();
  viewer.scene.primitives.add(tileset));
} catch (error) {
  console.log(`Error creating tileset: ${error}`);
}
```

```javascript
// Create Cesium OSM Buildings with a custom style highlighting
// schools and hospitals.
const viewer = new Cesium.Viewer("cesiumContainer");
try {
  const tileset = await Cesium.createOsmBuildingsAsync({
    style: new Cesium.Cesium3DTileStyle({
      color: {
        conditions: [
          ["${feature['building']} === 'hospital'", "color('#0000FF')"],
          ["${feature['building']} === 'school'", "color('#00FF00')"],
          [true, "color('#ffffff')"]
        ]
      }
    })
  });
  viewer.scene.primitives.add(tileset));
} catch (error) {
  console.log(`Error creating tileset: ${error}`);
}
```

##### See:

* [Ion](Ion.html)

#### [](#createTangentSpaceDebugPrimitive) createTangentSpaceDebugPrimitive(options) → [Primitive](Primitive.html) 

[engine/Source/Scene/createTangentSpaceDebugPrimitive.js 32](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/createTangentSpaceDebugPrimitive.js#L32) 

 Creates a [Primitive](Primitive.html) to visualize well-known vector vertex attributes:`normal`, `tangent`, and `bitangent`. Normal is red; tangent is green; and bitangent is blue. If an attribute is not present, it is not drawn.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description geometry [Geometry](Geometry.html)  The Geometry instance with the attribute. length number 10000.0 optional The length of each line segment in meters. This can be negative to point the vector in the opposite direction. modelMatrix [Matrix4](Matrix4.html) Matrix4.IDENTITY optional The model matrix that transforms to transform the geometry from model to world coordinates. |

##### Returns:

 A new `Primitive` instance with geometry for the vectors.

##### Example:

```javascript
scene.primitives.add(Cesium.createTangentSpaceDebugPrimitive({
   geometry : instance.geometry,
   length : 100000.0,
   modelMatrix : instance.modelMatrix
}));
```

#### [](#createWorldBathymetryAsync) createWorldBathymetryAsync(options) → Promise.<[CesiumTerrainProvider](CesiumTerrainProvider.html)\> 

[engine/Source/Core/createWorldBathymetryAsync.js 38](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/createWorldBathymetryAsync.js#L38) 

 Creates a [CesiumTerrainProvider](CesiumTerrainProvider.html) instance for the [Cesium World Bathymetry](https://cesium.com/content/#cesium-world-bathymetry).

| Name    | Type   | Description                                                                                                                                                                                                                             |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | Object | optional Object with the following properties: Name Type Default Description requestVertexNormals Boolean false optional Flag that indicates if the client should request additional lighting information from the server if available. |

##### Returns:

 A promise that resolves to the created CesiumTerrainProvider

##### Examples:

```javascript
// Create Cesium World Bathymetry with default settings
try {
  const viewer = new Cesium.Viewer("cesiumContainer", {
    terrainProvider: await Cesium.createWorldBathymetryAsync();
  });
} catch (error) {
  console.log(error);
}
```

```javascript
// Create Cesium World Bathymetry with normals.
try {
  const viewer1 = new Cesium.Viewer("cesiumContainer", {
    terrainProvider: await Cesium.createWorldBathymetryAsync({
      requestVertexNormals: true
    });
  });
} catch (error) {
  console.log(error);
}
```

##### See:

* [Ion](Ion.html)

#### [](#createWorldImageryAsync) createWorldImageryAsync(options) → Promise.<[IonImageryProvider](IonImageryProvider.html)\> 

[engine/Source/Scene/createWorldImageryAsync.js 34](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/createWorldImageryAsync.js#L34) 

 Creates an [IonImageryProvider](IonImageryProvider.html) instance for ion's default global base imagery layer, currently Bing Maps.

| Name    | Type   | Description                                                                                                                                                                                                                                                               |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | Object | optional Object with the following properties: Name Type Default Description style [IonWorldImageryStyle](global.html#IonWorldImageryStyle) IonWorldImageryStyle optional The style of base imagery, only AERIAL, AERIAL\_WITH\_LABELS, and ROAD are currently supported. |

##### Returns:

##### Examples:

```javascript
// Create a Cesium World Imagery base layer with default settings
try {
  const imageryProvider = await Cesium.createWorldImageryAsync();
} catch (error) {
  console.log(`There was an error creating world imagery: ${error}`);
}
```

```javascript
// Create Cesium World Imagery with different style
try {
  const imageryProvider = await Cesium.createWorldImageryAsync({
        style: Cesium.IonWorldImageryStyle.AERIAL_WITH_LABELS
  });
} catch (error) {
  console.log(`There was an error creating world imagery: ${error}`);
}
```

##### See:

* [Ion](Ion.html)

#### [](#createWorldTerrainAsync) createWorldTerrainAsync(options) → Promise.<[CesiumTerrainProvider](CesiumTerrainProvider.html)\> 

[engine/Source/Core/createWorldTerrainAsync.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/createWorldTerrainAsync.js#L41) 

 Creates a [CesiumTerrainProvider](CesiumTerrainProvider.html) instance for the [Cesium World Terrain](https://cesium.com/content/#cesium-world-terrain).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                         |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | Object | optional Object with the following properties: Name Type Default Description requestVertexNormals Boolean false optional Flag that indicates if the client should request additional lighting information from the server if available. requestWaterMask Boolean false optional Flag that indicates if the client should request per tile water masks from the server if available. |

##### Returns:

 A promise that resolves to the created CesiumTerrainProvider

##### Examples:

```javascript
// Create Cesium World Terrain with default settings
try {
  const viewer = new Cesium.Viewer("cesiumContainer", {
    terrainProvider: await Cesium.createWorldTerrainAsync();
  });
} catch (error) {
  console.log(error);
}
```

```javascript
// Create Cesium World Terrain with water and normals.
try {
  const viewer1 = new Cesium.Viewer("cesiumContainer", {
    terrainProvider: await Cesium.createWorldTerrainAsync({
      requestWaterMask: true,
      requestVertexNormals: true
    });
  });
} catch (error) {
  console.log(error);
}
```

##### See:

* [Ion](Ion.html)

#### [](#defaultValue) defaultValue(a, b) → \* 

[engine/Source/Core/defaultValue.js 14](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/defaultValue.js#L14) 

 Returns the first parameter if not undefined, otherwise the second parameter. Useful for setting a default value for a parameter.

| Name | Type | Description |
| ---- | ---- | ----------- |
| a    | \*   |             |
| b    | \*   |             |

##### Returns:

 Returns the first parameter if not undefined, otherwise the second parameter.

##### Example:

```javascript
param = Cesium.defaultValue(param, 'default');
```

#### [](#defined) defined(value) → boolean 

[engine/Source/Core/defined.js 14](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/defined.js#L14) 

| Name  | Type | Description |
| ----- | ---- | ----------- |
| value | \*   | The object. |

##### Returns:

 Returns true if the object is defined, returns false otherwise.

##### Example:

```javascript
if (Cesium.defined(positions)) {
     doSomething();
} else {
     doSomethingElse();
}
```

#### [](#destroyObject) destroyObject(object, message) 

[engine/Source/Core/destroyObject.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/destroyObject.js#L35) 

 Destroys an object. Each of the object's functions, including functions in its prototype, is replaced with a function that throws a [DeveloperError](DeveloperError.html), except for the object's`isDestroyed` function, which is set to a function that returns `true`. The object's properties are removed with `delete`.  
  
This function is used by objects that hold native resources, e.g., WebGL resources, which need to be explicitly released. Client code calls an object's `destroy` function, which then releases the native resource and calls `destroyObject` to put itself in a destroyed state.

| Name    | Type   | Description                                                                                                 |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------- |
| object  | object | The object to destroy.                                                                                      |
| message | string | optional The message to include in the exception that is thrown if a destroyed object's function is called. |

##### Example:

```javascript
// How a texture would destroy itself.
this.destroy = function () {
    _gl.deleteTexture(_texture);
    return Cesium.destroyObject(this);
};
```

##### See:

* [DeveloperError](DeveloperError.html)

#### [](#exportKml) exportKml(options) → Promise.<([exportKmlResultKml](global.html#exportKmlResultKml)|[exportKmlResultKmz](global.html#exportKmlResultKmz))> 

[engine/Source/DataSources/exportKml.js 238](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/exportKml.js#L238) 

 Exports an EntityCollection as a KML document. Only Point, Billboard, Model, Path, Polygon, Polyline geometries will be exported. Note that there is not a 1 to 1 mapping of Entity properties to KML Feature properties. For example, entity properties that are time dynamic but cannot be dynamic in KML are exported with their values at options.time or the beginning of the EntityCollection's time interval if not specified. For time-dynamic properties that are supported in KML, we use the samples if it is a [SampledProperty](SampledProperty.html) otherwise we sample the value using the options.sampleDuration. Point, Billboard, Model and Path geometries with time-dynamic positions will be exported as gx:Track Features. Not all Materials are representable in KML, so for more advanced Materials just the primary color is used. Canvas objects are exported as PNG images.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | An object with the following properties: Name Type Default Description entities [EntityCollection](EntityCollection.html)  The EntityCollection to export as KML. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid for the output file. modelCallback [exportKmlModelCallback](global.html#exportKmlModelCallback) optional A callback that will be called with a [ModelGraphics](ModelGraphics.html) instance and should return the URI to use in the KML. Required if a model exists in the entity collection. time [JulianDate](JulianDate.html) entities.computeAvailability().start optional The time value to use to get properties that are not time varying in KML. defaultAvailability [TimeInterval](TimeInterval.html) entities.computeAvailability() optional The interval that will be sampled if an entity doesn't have an availability. sampleDuration number 60 optional The number of seconds to sample properties that are varying in KML. kmz boolean false optional If true KML and external files will be compressed into a kmz file. |

##### Returns:

 A promise that resolved to an object containing the KML string and a dictionary of external file blobs, or a kmz file as a blob if options.kmz is true.

##### Example:

```javascript
Cesium.exportKml({
     entities: entityCollection
 })
  .then(function(result) {
    // The XML string is in result.kml

    const externalFiles = result.externalFiles
    for(const file in externalFiles) {
      // file is the name of the file used in the KML document as the href
      // externalFiles[file] is a blob with the contents of the file
    }
  });
```

##### Demo:

* [Cesium Sandcastle KML Export Demo](https://sandcastle.cesium.com/index.html?src=Export%2520KML.html)

#### [](#formatError) formatError(object) → string 

[engine/Source/Core/formatError.js 12](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/formatError.js#L12) 

 Formats an error object into a String. If available, uses name, message, and stack properties, otherwise, falls back on toString().

| Name   | Type | Description                    |
| ------ | ---- | ------------------------------ |
| object | \*   | The item to find in the array. |

##### Returns:

 A string containing the formatted error.

#### [](#getAbsoluteUri) getAbsoluteUri(relative, base) → string 

[engine/Source/Core/getAbsoluteUri.js 18](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/getAbsoluteUri.js#L18) 

 Given a relative Uri and a base Uri, returns the absolute Uri of the relative Uri.

| Name     | Type   | Description            |
| -------- | ------ | ---------------------- |
| relative | string | The relative Uri.      |
| base     | string | optional The base Uri. |

##### Returns:

 The absolute Uri of the given relative Uri.

##### Example:

```javascript
//absolute Uri will be "https://test.com/awesome.png";
const absoluteUri = Cesium.getAbsoluteUri('awesome.png', 'https://test.com');
```

#### [](#getBaseUri) getBaseUri(uri, includeQuery) → string 

[engine/Source/Core/getBaseUri.js 20](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/getBaseUri.js#L20) 

 Given a URI, returns the base path of the URI.

| Name         | Type    | Default | Description                                                                   |
| ------------ | ------- | ------- | ----------------------------------------------------------------------------- |
| uri          | string  |         | The Uri.                                                                      |
| includeQuery | boolean | false   | optional Whether or not to include the query string and fragment form the uri |

##### Returns:

 The base path of the Uri.

##### Example:

```javascript
// basePath will be "/Gallery/";
const basePath = Cesium.getBaseUri('/Gallery/simple.czml?value=true&example=false');

// basePath will be "/Gallery/?value=true&example=false";
const basePath = Cesium.getBaseUri('/Gallery/simple.czml?value=true&example=false', true);
```

#### [](#getExtensionFromUri) getExtensionFromUri(uri) → string 

[engine/Source/Core/getExtensionFromUri.js 5](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/getExtensionFromUri.js#L5) 

 Given a URI, returns the extension of the URI.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| uri  | string | The Uri.    |

##### Returns:

 The extension of the Uri.

##### Example:

```javascript
//extension will be "czml";
const extension = Cesium.getExtensionFromUri('/Gallery/simple.czml?value=true&example=false');
```

#### [](#getFilenameFromUri) getFilenameFromUri(uri) → string 

[engine/Source/Core/getFilenameFromUri.js 5](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/getFilenameFromUri.js#L5) 

 Given a URI, returns the last segment of the URI, removing any path or query information.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| uri  | string | The Uri.    |

##### Returns:

 The last segment of the Uri.

##### Example:

```javascript
//fileName will be"simple.czml";
const fileName = Cesium.getFilenameFromUri('/Gallery/simple.czml?value=true&example=false');
```

#### [](#getGlslType) getGlslType(classProperty) → string 

[engine/Source/Scene/DerivedCommand.js 406](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DerivedCommand.js#L406) 

 Returns the type that the given class property has in a GLSL shader. It returns the same string as \`PropertyTextureProperty.prototype.getGlslType\` for a property texture property with the given class property

| Name          | Type                                                | Description        |
| ------------- | --------------------------------------------------- | ------------------ |
| classProperty | [MetadataClassProperty](MetadataClassProperty.html) | The class property |

##### Returns:

 The GLSL shader type string for the property

#### [](#getImagePixels) getImagePixels(image, width, height) → ImageData 

[engine/Source/Core/getImagePixels.js 5](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/getImagePixels.js#L5) 

 Extract a pixel array from a loaded image. Draws the image into a canvas so it can read the pixels back.

| Name   | Type                          | Description                                                             |
| ------ | ----------------------------- | ----------------------------------------------------------------------- |
| image  | HTMLImageElement\|ImageBitmap | The image to extract pixels from.                                       |
| width  | number                        | The width of the image. If not defined, then image.width is assigned.   |
| height | number                        | The height of the image. If not defined, then image.height is assigned. |

##### Returns:

 The pixels of the image.

#### [](#getSourceValueStringComponent) getSourceValueStringComponent(classProperty, metadataProperty, componentName) → string 

[engine/Source/Scene/DerivedCommand.js 484](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DerivedCommand.js#L484) 

 Creates a shader statement that returns the value of the specified component of the given property, normalized to the range \[0, 1\].

| Name             | Type                                                | Description                                                                                    |
| ---------------- | --------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| classProperty    | [MetadataClassProperty](MetadataClassProperty.html) | The class property                                                                             |
| metadataProperty | object                                              | The metadata property, either a \`PropertyTextureProperty\` or a \`PropertyAttributeProperty\` |
| componentName    | string                                              | The name, in \["x", "y", "z", "w"\]                                                            |

##### Returns:

 The string

#### [](#getSourceValueStringScalar) getSourceValueStringScalar(classProperty, metadataProperty) → string 

[engine/Source/Scene/DerivedCommand.js 456](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DerivedCommand.js#L456) 

 Creates a shader statement that returns the value of the specified property, normalized to the range \[0, 1\].

| Name             | Type                                                | Description                                                                                    |
| ---------------- | --------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| classProperty    | [MetadataClassProperty](MetadataClassProperty.html) | The class property                                                                             |
| metadataProperty | object                                              | The metadata property, either a \`PropertyTextureProperty\` or a \`PropertyAttributeProperty\` |

##### Returns:

 The string

#### [](#getTimestamp) getTimestamp() → number 

[engine/Source/Core/getTimestamp.js 1](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/getTimestamp.js#L1) 

 Gets a timestamp that can be used in measuring the time between events. Timestamps are expressed in milliseconds, but it is not specified what the milliseconds are measured from. This function uses performance.now() if it is available, or Date.now() otherwise.

##### Returns:

 The timestamp in milliseconds since some unspecified reference time.

#### [](#isLeapYear) isLeapYear(year) → boolean 

[engine/Source/Core/isLeapYear.js 3](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/isLeapYear.js#L3) 

 Determines if a given date is a leap year.

| Name | Type   | Description            |
| ---- | ------ | ---------------------- |
| year | number | The year to be tested. |

##### Returns:

 True if `year` is a leap year.

##### Example:

```javascript
const leapYear = Cesium.isLeapYear(2000); // true
```

#### [](#loadGltfJson) async loadGltfJson() 

[engine/Source/Scene/GltfLoader.js 366](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GltfLoader.js#L366) 

 Loads the gltf object

#### [](#mergeSort) mergeSort(array, comparator, userDefinedObject) 

[engine/Source/Core/mergeSort.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/mergeSort.js#L55) 

 A stable merge sort.

| Name              | Type                                                   | Description                                                     |
| ----------------- | ------------------------------------------------------ | --------------------------------------------------------------- |
| array             | Array                                                  | The array to sort.                                              |
| comparator        | [mergeSortComparator](global.html#mergeSortComparator) | The function to use to compare elements in the array.           |
| userDefinedObject | \*                                                     | optional Any item to pass as the third parameter to comparator. |

##### Example:

```javascript
// Assume array contains BoundingSpheres in world coordinates.
// Sort them in ascending order of distance from the camera.
const position = camera.positionWC;
Cesium.mergeSort(array, function(a, b, position) {
    return Cesium.BoundingSphere.distanceSquaredTo(b, position) - Cesium.BoundingSphere.distanceSquaredTo(a, position);
}, position);
```

#### [](#objectToQuery) objectToQuery(obj) → string 

[engine/Source/Core/objectToQuery.js 4](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/objectToQuery.js#L4) 

 Converts an object representing a set of name/value pairs into a query string, with names and values encoded properly for use in a URL. Values that are arrays will produce multiple values with the same name.

| Name | Type   | Description                           |
| ---- | ------ | ------------------------------------- |
| obj  | object | The object containing data to encode. |

##### Returns:

 An encoded query string.

##### Example:

```javascript
const str = Cesium.objectToQuery({
    key1 : 'some value',
    key2 : 'a/b',
    key3 : ['x', 'y']
});
```

##### See:

* queryToObject // str will be: // 'key1=some%20value&key2=a%2Fb&key3=x&key3=y'

#### [](#obtainTranslucentCommandExecutionFunction) obtainTranslucentCommandExecutionFunction(scene) → function 

[engine/Source/Scene/Scene.js 2428](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Scene.js#L2428) 

 Determine how translucent surfaces will be handled. When OIT is enabled, then this will delegate to OIT.executeCommands. Otherwise, it will just be executeTranslucentCommandsBackToFront for render passes, or executeTranslucentCommandsFrontToBack for other passes.

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| scene | [Scene](Scene.html) | The scene.  |

##### Returns:

 A function to execute translucent commands.

#### [](#pointInsideTriangle) pointInsideTriangle(point, p0, p1, p2) → boolean 

[engine/Source/Core/pointInsideTriangle.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/pointInsideTriangle.js#L7) 

 Determines if a point is inside a triangle.

| Name  | Type                                                         | Description                       |
| ----- | ------------------------------------------------------------ | --------------------------------- |
| point | [Cartesian2](Cartesian2.html)\|[Cartesian3](Cartesian3.html) | The point to test.                |
| p0    | [Cartesian2](Cartesian2.html)\|[Cartesian3](Cartesian3.html) | The first point of the triangle.  |
| p1    | [Cartesian2](Cartesian2.html)\|[Cartesian3](Cartesian3.html) | The second point of the triangle. |
| p2    | [Cartesian2](Cartesian2.html)\|[Cartesian3](Cartesian3.html) | The third point of the triangle.  |

##### Returns:

`true` if the point is inside the triangle; otherwise, `false`.

##### Example:

```javascript
// Returns true
const p = new Cesium.Cartesian2(0.25, 0.25);
const b = Cesium.pointInsideTriangle(p,
  new Cesium.Cartesian2(0.0, 0.0),
  new Cesium.Cartesian2(1.0, 0.0),
  new Cesium.Cartesian2(0.0, 1.0));
```

#### [](#queryToObject) queryToObject(queryString) → object 

[engine/Source/Core/queryToObject.js 4](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/queryToObject.js#L4) 

 Parses a query string into an object, where the keys and values of the object are the name/value pairs from the query string, decoded. If a name appears multiple times, the value in the object will be an array of values.

| Name        | Type   | Description       |
| ----------- | ------ | ----------------- |
| queryString | string | The query string. |

##### Returns:

 An object containing the parameters parsed from the query string.

##### Example:

```javascript
const obj = Cesium.queryToObject('key1=some%20value&key2=a%2Fb&key3=x&key3=y');
// obj will be:
// {
//   key1 : 'some value',
//   key2 : 'a/b',
//   key3 : ['x', 'y']
// }
```

##### See:

* [objectToQuery](global.html#objectToQuery)

#### [](#removeExtension) removeExtension(gltf, extension) → \* 

[engine/Source/Scene/GltfPipeline/removeExtension.js 13](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GltfPipeline/removeExtension.js#L13) 

 Removes an extension from gltf.extensions, gltf.extensionsUsed, gltf.extensionsRequired, and any other objects in the glTF if it is present.

| Name      | Type   | Description                                  |
| --------- | ------ | -------------------------------------------- |
| gltf      | object | A javascript object containing a glTF asset. |
| extension | string | The extension to remove.                     |

##### Returns:

 The extension data removed from gltf.extensions.

#### [](#sampleTerrain) sampleTerrain(terrainProvider, level, positions, rejectOnTileFail) → Promise.<Array.<[Cartographic](Cartographic.html)\>> 

[engine/Source/Core/sampleTerrain.js 4](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/sampleTerrain.js#L4) 

 Initiates a terrain height query for an array of [Cartographic](Cartographic.html) positions by requesting tiles from a terrain provider, sampling, and interpolating. The interpolation matches the triangles used to render the terrain at the specified level. The query happens asynchronously, so this function returns a promise that is resolved when the query completes. Each point height is modified in place. If a height can not be determined because no terrain data is available for the specified level at that location, or another error occurs, the height is set to undefined. As is typical of the[Cartographic](Cartographic.html) type, the supplied height is a height above the reference ellipsoid (such as [Ellipsoid.WGS84](Ellipsoid.html#.WGS84)) rather than an altitude above mean sea level. In other words, it will not necessarily be 0.0 if sampled in the ocean. This function needs the terrain level of detail as input, if you need to get the altitude of the terrain as precisely as possible (i.e. with maximum level of detail) use [sampleTerrainMostDetailed](global.html#sampleTerrainMostDetailed).

| Name             | Type                                       | Default | Description                                                                                                                         |
| ---------------- | ------------------------------------------ | ------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| terrainProvider  | [TerrainProvider](TerrainProvider.html)    |         | The terrain provider from which to query heights.                                                                                   |
| level            | number                                     |         | The terrain level-of-detail from which to query terrain heights.                                                                    |
| positions        | Array.<[Cartographic](Cartographic.html)\> |         | The positions to update with terrain heights.                                                                                       |
| rejectOnTileFail | boolean                                    | false   | optional If true, for any failed terrain tile requests, the promise will be rejected. If false, returned heights will be undefined. |

##### Returns:

 A promise that resolves to the provided list of positions when terrain the query has completed.

##### Example:

```javascript
// Query the terrain height of two Cartographic positions
const terrainProvider = await Cesium.createWorldTerrainAsync();
const positions = [
    Cesium.Cartographic.fromDegrees(86.925145, 27.988257),
    Cesium.Cartographic.fromDegrees(87.0, 28.0)
];
const updatedPositions = await Cesium.sampleTerrain(terrainProvider, 11, positions);
// positions[0].height and positions[1].height have been updated.
// updatedPositions is just a reference to positions.

// To handle tile errors, pass true for the rejectOnTileFail parameter.
try {
   const updatedPositions = await Cesium.sampleTerrain(terrainProvider, 11, positions, true);
} catch (error) {
  // A tile request error occurred.
}
```

##### See:

* [sampleTerrainMostDetailed](global.html#sampleTerrainMostDetailed)

#### [](#sampleTerrainMostDetailed) sampleTerrainMostDetailed(terrainProvider, positions, rejectOnTileFail) → Promise.<Array.<[Cartographic](Cartographic.html)\>> 

[engine/Source/Core/sampleTerrainMostDetailed.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/sampleTerrainMostDetailed.js#L8) 

 Initiates a sampleTerrain() request at the maximum available tile level for a terrain dataset.

| Name             | Type                                       | Default | Description                                                                                                                     |
| ---------------- | ------------------------------------------ | ------- | ------------------------------------------------------------------------------------------------------------------------------- |
| terrainProvider  | [TerrainProvider](TerrainProvider.html)    |         | The terrain provider from which to query heights.                                                                               |
| positions        | Array.<[Cartographic](Cartographic.html)\> |         | The positions to update with terrain heights.                                                                                   |
| rejectOnTileFail | boolean                                    | false   | optional If true, for a failed terrain tile request the promise will be rejected. If false, returned heights will be undefined. |

##### Returns:

 A promise that resolves to the provided list of positions when terrain the query has completed. This promise will reject if the terrain provider's \`availability\` property is undefined.

##### Example:

```javascript
// Query the terrain height of two Cartographic positions
const terrainProvider = await Cesium.createWorldTerrainAsync();
const positions = [
    Cesium.Cartographic.fromDegrees(86.925145, 27.988257),
    Cesium.Cartographic.fromDegrees(87.0, 28.0)
];
const updatedPositions = await Cesium.sampleTerrainMostDetailed(terrainProvider, positions);
// positions[0].height and positions[1].height have been updated.
// updatedPositions is just a reference to positions.

// To handle tile errors, pass true for the rejectOnTileFail parameter.
try {
   const updatedPositions = await Cesium.sampleTerrainMostDetailed(terrainProvider, positions, true);
} catch (error) {
  // A tile request error occurred.
}
```

#### [](#srgbToLinear) srgbToLinear(value) → number 

[engine/Source/Core/srgbToLinear.js 17](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/srgbToLinear.js#L17) 

 Converts the value from sRGB color space to linear color space.

| Name  | Type   | Description                          |
| ----- | ------ | ------------------------------------ |
| value | number | The color value in sRGB color space. |

##### Returns:

 Returns the color value in linear color space.

##### Example:

```javascript
const srgbColor = [0.5, 0.5, 0.5];
const linearColor = srgbColor.map(function (c) {
    return Cesium.srgbToLinear(c);
});
```

#### [](#Stereographic) Stereographic(position, tangentPlane) 

[engine/Source/Core/Stereographic.js 19](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Stereographic.js#L19) 

 Represents a point in stereographic coordinates, which can be obtained by projecting a cartesian coordinate from one pole onto a tangent plane at the other pole. The stereographic projection faithfully represents the relative directions of all great circles passing through its center point. To faithfully represents angles everywhere, this is a conformal projection, which means points are projected onto an arbrary sphere.

| Name         | Type                                    | Description                                                    |
| ------------ | --------------------------------------- | -------------------------------------------------------------- |
| position     | [Cartesian2](Cartesian2.html)           | optional The steroegraphic coordinates.                        |
| tangentPlane | [EllipseGeometry](EllipseGeometry.html) | optional The tangent plane onto which the point was projected. |

#### [](#subdivideArray) subdivideArray(array, numberOfArrays) 

[engine/Source/Core/subdivideArray.js 4](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/subdivideArray.js#L4) 

 Subdivides an array into a number of smaller, equal sized arrays.

| Name           | Type   | Description                                             |
| -------------- | ------ | ------------------------------------------------------- |
| array          | Array  | The array to divide.                                    |
| numberOfArrays | number | The number of arrays to divide the provided array into. |

##### Throws:

* [DeveloperError](DeveloperError.html): numberOfArrays must be greater than 0.

#### [](#unapplyValueTransform) unapplyValueTransform(input, offset, scale) → string 

[engine/Source/Scene/DerivedCommand.js 430](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DerivedCommand.js#L430) 

 Returns a shader statement that applies the inverse of the value transform to the given value, based on the given offset and scale.

| Name   | Type   | Description     |
| ------ | ------ | --------------- |
| input  | string | The input value |
| offset | string | The offset      |
| scale  | string | The scale       |

##### Returns:

 The statement

#### [](#unnormalize) unnormalize(input, componentType) → string 

[engine/Source/Scene/DerivedCommand.js 442](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DerivedCommand.js#L442) 

 Returns a shader statement that applies the inverse of the normalization, based on the given component type

| Name          | Type   | Description        |
| ------------- | ------ | ------------------ |
| input         | string | The input value    |
| componentType | string | The component type |

##### Returns:

 The statement

#### [](#viewerCesium3DTilesInspectorMixin) viewerCesium3DTilesInspectorMixin(viewer) 

[widgets/Source/Viewer/viewerCesium3DTilesInspectorMixin.js 16](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/viewerCesium3DTilesInspectorMixin.js#L16) 

 A mixin which adds the [Cesium3DTilesInspector](Cesium3DTilesInspector.html) widget to the [Viewer](Viewer.html) widget. Rather than being called directly, this function is normally passed as a parameter to [Viewer#extend](Viewer.html#extend), as shown in the example below.

| Name   | Type                  | Description          |
| ------ | --------------------- | -------------------- |
| viewer | [Viewer](Viewer.html) | The viewer instance. |

##### Example:

```javascript
const viewer = new Cesium.Viewer('cesiumContainer');
viewer.extend(Cesium.viewerCesium3DTilesInspectorMixin);
```

#### [](#viewerCesiumInspectorMixin) viewerCesiumInspectorMixin(viewer) 

[widgets/Source/Viewer/viewerCesiumInspectorMixin.js 20](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/viewerCesiumInspectorMixin.js#L20) 

 A mixin which adds the CesiumInspector widget to the Viewer widget. Rather than being called directly, this function is normally passed as a parameter to [Viewer#extend](Viewer.html#extend), as shown in the example below.

| Name   | Type                  | Description          |
| ------ | --------------------- | -------------------- |
| viewer | [Viewer](Viewer.html) | The viewer instance. |

##### Throws:

* [DeveloperError](DeveloperError.html): viewer is required.

##### Example:

```javascript
const viewer = new Cesium.Viewer('cesiumContainer');
viewer.extend(Cesium.viewerCesiumInspectorMixin);
```

##### Demo:

* [Cesium Sandcastle Cesium Inspector Demo](https://sandcastle.cesium.com/index.html?src=Cesium%2520Inspector.html)

#### [](#viewerDragDropMixin) viewerDragDropMixin(viewer, options) 

[widgets/Source/Viewer/viewerDragDropMixin.js 13](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/viewerDragDropMixin.js#L13) 

 A mixin which adds default drag and drop support for CZML files to the Viewer widget. Rather than being called directly, this function is normally passed as a parameter to [Viewer#extend](Viewer.html#extend), as shown in the example below.

| Name    | Type                  | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ------- | --------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| viewer  | [Viewer](Viewer.html) | The viewer instance.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| options | object                | optional Object with the following properties: Name Type Default Description dropTarget Element\|string viewer.container optional The DOM element which will serve as the drop target. clearOnDrop boolean true optional When true, dropping files will clear all existing data sources first, when false, new data sources will be loaded after the existing ones. flyToOnDrop boolean true optional When true, dropping files will fly to the data source once it is loaded. clampToGround boolean true optional When true, datasources are clamped to the ground. proxy [Proxy](Proxy.html) optional The proxy to be used for KML network links. |

##### Throws:

[DeveloperError](DeveloperError.html): Element with id  does not exist in the document. 
* [DeveloperError](DeveloperError.html): dropTarget is already defined by another mixin.
* [DeveloperError](DeveloperError.html): dropEnabled is already defined by another mixin.
* [DeveloperError](DeveloperError.html): dropError is already defined by another mixin.
* [DeveloperError](DeveloperError.html): clearOnDrop is already defined by another mixin.

##### Example:

```javascript
// Add basic drag and drop support and pop up an alert window on error.
const viewer = new Cesium.Viewer('cesiumContainer');
viewer.extend(Cesium.viewerDragDropMixin);
viewer.dropError.addEventListener(function(viewerArg, source, error) {
    window.alert('Error processing ' + source + ':' + error);
});
```

#### [](#viewerPerformanceWatchdogMixin) viewerPerformanceWatchdogMixin(viewer, options) 

[widgets/Source/Viewer/viewerPerformanceWatchdogMixin.js 24](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/viewerPerformanceWatchdogMixin.js#L24) 

 A mixin which adds the [PerformanceWatchdog](PerformanceWatchdog.html) widget to the [Viewer](Viewer.html) widget. Rather than being called directly, this function is normally passed as a parameter to [Viewer#extend](Viewer.html#extend), as shown in the example below.

| Name    | Type                  | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | --------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| viewer  | [Viewer](Viewer.html) | The viewer instance.                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| options | object                | optional An object with properties. Name Type Default Description lowFrameRateMessage string 'This application appears to be performing poorly on your system. Please try using a different web browser or updating your video drivers.' optional The message to display when a low frame rate is detected. The message is interpeted as HTML, so make sure it comes from a trusted source so that your application is not vulnerable to cross-site scripting attacks. |

##### Throws:

* [DeveloperError](DeveloperError.html): viewer is required.

##### Example:

```javascript
const viewer = new Cesium.Viewer('cesiumContainer');
viewer.extend(Cesium.viewerPerformanceWatchdogMixin, {
    lowFrameRateMessage : 'Why is this going so <em>slowly</em>?'
});
```

#### [](#viewerVoxelInspectorMixin) viewerVoxelInspectorMixin(viewer) 

[widgets/Source/Viewer/viewerVoxelInspectorMixin.js 16](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Viewer/viewerVoxelInspectorMixin.js#L16) 

 A mixin which adds the [VoxelInspector](VoxelInspector.html) widget to the [Viewer](Viewer.html) widget. Rather than being called directly, this function is normally passed as a parameter to [Viewer#extend](Viewer.html#extend), as shown in the example below.

| Name   | Type                  | Description          |
| ------ | --------------------- | -------------------- |
| viewer | [Viewer](Viewer.html) | The viewer instance. |

##### Example:

```javascript
var viewer = new Cesium.Viewer('cesiumContainer');
viewer.extend(Cesium.viewerVoxelInspectorMixin);
```

#### [](#writeTextToCanvas) writeTextToCanvas(text, options) → HTMLCanvasElement|undefined 

[engine/Source/Core/writeTextToCanvas.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/writeTextToCanvas.js#L100) 

 Writes the given text into a new canvas. The canvas will be sized to fit the text. If text is blank, returns undefined.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| text    | string | The text to write.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| options | object | optional Object with the following properties: Name Type Default Description font string '10px sans-serif' optional The CSS font to use. fill boolean true optional Whether to fill the text. stroke boolean false optional Whether to stroke the text. fillColor [Color](Color.html) Color.WHITE optional The fill color. strokeColor [Color](Color.html) Color.BLACK optional The stroke color. strokeWidth number 1 optional The stroke width. backgroundColor [Color](Color.html) Color.TRANSPARENT optional The background color of the canvas. padding number 0 optional The pixel size of the padding to add around the text. |

##### Returns:

 A new canvas with the given text drawn into it. The dimensions object from measureText will also be added to the returned canvas. If text is blank, returns undefined.

### Type Definitions

#### [](#binarySearchComparator) binarySearchComparator(a, b) → number 

[engine/Source/Core/binarySearch.js 52](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/binarySearch.js#L52) 

 A function used to compare two items while performing a binary search.

| Name | Type | Description                  |
| ---- | ---- | ---------------------------- |
| a    | \*   | An item in the array.        |
| b    | \*   | The item being searched for. |

##### Returns:

 Returns a negative value if `a` is less than `b`, a positive value if `a` is greater than `b`, or 0 if `a` is equal to `b`.

##### Example:

```javascript
function compareNumbers(a, b) {
    return a - b;
}
```

#### [](#ContextOptions) ContextOptions

[engine/Source/Renderer/Context.js 390](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Renderer/Context.js#L390) 

 Options to control the setting up of a WebGL Context.

`allowTextureFilterAnisotropic` defaults to true, which enables anisotropic texture filtering when the WebGL extension is supported. Setting this to false will improve performance, but hurt visual quality, especially for horizon views.

##### Properties:

| Name                          | Type                                     | Attributes | Default | Description                                                          |
| ----------------------------- | ---------------------------------------- | ---------- | ------- | -------------------------------------------------------------------- |
| requestWebgl1                 | boolean                                  | <optional> | false   | If true and the browser supports it, use a WebGL 1 rendering context |
| allowTextureFilterAnisotropic | boolean                                  | <optional> | true    | If true, use anisotropic filtering during texture sampling           |
| webgl                         | [WebGLOptions](global.html#WebGLOptions) | <optional> |         | WebGL options to be passed on to canvas.getContext                   |
| getWebGLStub                  | function                                 | <optional> |         | A function to create a WebGL stub for testing                        |

#### [](#createElevationBandMaterialBand) createElevationBandMaterialBand

[engine/Source/Scene/createElevationBandMaterial.js 417](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/createElevationBandMaterial.js#L417) 

##### Properties:

| Name            | Type                                                                                      | Attributes | Default | Description                                                                                                                                                                                            |
| --------------- | ----------------------------------------------------------------------------------------- | ---------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| entries         | Array.<[createElevationBandMaterialEntry](global.html#createElevationBandMaterialEntry)\> |            |         | A list of elevation entries. They will automatically be sorted from lowest to highest. If there is only one entry and extendsDownards and extendUpwards are both false, they will both be set to true. |
| extendDownwards | boolean                                                                                   | <optional> | false   | If true, the band's minimum elevation color will extend infinitely downwards.                                                                                                                          |
| extendUpwards   | boolean                                                                                   | <optional> | false   | If true, the band's maximum elevation color will extend infinitely upwards.                                                                                                                            |

#### [](#createElevationBandMaterialEntry) createElevationBandMaterialEntry

[engine/Source/Scene/createElevationBandMaterial.js 411](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/createElevationBandMaterial.js#L411) 

##### Properties:

| Name   | Type                | Description               |
| ------ | ------------------- | ------------------------- |
| height | number              | The height.               |
| color  | [Color](Color.html) | The color at this height. |

#### [](#DirectionUp) DirectionUp

[engine/Source/Scene/Camera.js 32](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L32) 

 An orientation given by a pair of unit vectors

##### Properties:

| Name      | Type                          | Description                 |
| --------- | ----------------------------- | --------------------------- |
| direction | [Cartesian3](Cartesian3.html) | The unit "direction" vector |
| up        | [Cartesian3](Cartesian3.html) | The unit "up" vector        |

#### [](#exportKmlModelCallback) exportKmlModelCallback(model, time, externalFiles) → string 

[engine/Source/DataSources/exportKml.js 1511](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/exportKml.js#L1511) 

 Since KML does not support glTF models, this callback is required to specify what URL to use for the model in the KML document. It can also be used to add additional files to the `externalFiles` object, which is the list of files embedded in the exported KMZ, or otherwise returned with the KML string when exporting.

| Name          | Type                                | Description                                                                    |
| ------------- | ----------------------------------- | ------------------------------------------------------------------------------ |
| model         | [ModelGraphics](ModelGraphics.html) | The ModelGraphics instance for an Entity.                                      |
| time          | [JulianDate](JulianDate.html)       | The time that any properties should use to get the value.                      |
| externalFiles | object                              | An object that maps a filename to a Blob or a Promise that resolves to a Blob. |

##### Returns:

 The URL to use for the href in the KML document.

#### [](#exportKmlResultKml) exportKmlResultKml

[engine/Source/DataSources/exportKml.js 225](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/exportKml.js#L225) 

##### Properties:

| Name          | Type                  | Description                            |
| ------------- | --------------------- | -------------------------------------- |
| kml           | string                | The generated KML.                     |
| externalFiles | Object.<string, Blob> | An object dictionary of external files |

#### [](#exportKmlResultKmz) exportKmlResultKmz

[engine/Source/DataSources/exportKml.js 232](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/exportKml.js#L232) 

##### Properties:

| Name | Type | Description             |
| ---- | ---- | ----------------------- |
| kmz  | Blob | The generated kmz file. |

#### [](#HeadingPitchRollValues) HeadingPitchRollValues

[engine/Source/Scene/Camera.js 40](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Camera.js#L40) 

 An orientation given by numeric heading, pitch, and roll

##### Properties:

| Name    | Type   | Attributes | Default                    | Description            |
| ------- | ------ | ---------- | -------------------------- | ---------------------- |
| heading | number | <optional> | 0.0                        | The heading in radians |
| pitch   | number | <optional> | \-CesiumMath.PI\_OVER\_TWO | The pitch in radians   |
| roll    | number | <optional> | 0.0                        | The roll in radians    |

#### [](#ImageryTypes) ImageryTypes

[engine/Source/Scene/ImageryProvider.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryProvider.js#L7) 

 The format in which [ImageryProvider](ImageryProvider.html) methods return an image may vary by provider, configuration, or server settings. Most common are`HTMLImageElement`, `HTMLCanvasElement`, or on supported browsers, `ImageBitmap`. See the documentation for each ImageryProvider class for more information about how they return images.

#### [](#mergeSortComparator) mergeSortComparator(a, b, userDefinedObject) → number 

[engine/Source/Core/mergeSort.js 95](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/mergeSort.js#L95) 

 A function used to compare two items while performing a merge sort.

| Name              | Type | Description                                                               |
| ----------------- | ---- | ------------------------------------------------------------------------- |
| a                 | \*   | An item in the array.                                                     |
| b                 | \*   | An item in the array.                                                     |
| userDefinedObject | \*   | optional An object that was passed to [mergeSort](global.html#mergeSort). |

##### Returns:

 Returns a negative value if `a` is less than `b`, a positive value if `a` is greater than `b`, or 0 if `a` is equal to `b`.

##### Example:

```javascript
function compareNumbers(a, b, userDefinedObject) {
    return a - b;
}
```

#### [](#MetadataValue) MetadataValue

[engine/Source/Scene/MetadataType.js 10](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataType.js#L10) 

 An instance of a metadata value.  
  
This can be one of the following types:
* `number` for type `SCALAR` and numeric component types except for `INT64` or `UINT64`
* `bigint` for type `SCALAR` and component type `INT64` or `UINT64`
* `string` for type `STRING` or `ENUM`
* `boolean` for type `BOOLEAN`
* `Cartesian2` for type `VEC2`
* `Cartesian3` for type `VEC3`
* `Cartesian4` for type `VEC4`
* `Matrix2` for type `MAT2`
* `Matrix3` for type `MAT3`
* `Matrix4` for type `MAT4`
* Arrays of these types when the metadata value is an array

#### [](#PickedMetadataInfo) PickedMetadataInfo

[engine/Source/Scene/Picking.js 532](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Picking.js#L532) 

 Information about metadata that is supposed to be picked

##### Properties:

| Name          | Type                                                | Description                            |
| ------------- | --------------------------------------------------- | -------------------------------------- |
| schemaId      | string\|undefined                                   | The optional ID of the metadata schema |
| className     | string                                              | The name of the metadata class         |
| propertyName  | string                                              | The name of the metadata property      |
| classProperty | [MetadataClassProperty](MetadataClassProperty.html) | The metadata class property            |

#### [](#UniformSpecifier) UniformSpecifier

[engine/Source/Scene/Model/CustomShader.js 11](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L11) 

 An object describing a uniform, its type, and an initial value

##### Properties:

| Name  | Type                                                                                                                                                                                                                    | Description                      |
| ----- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------- |
| type  | [UniformType](global.html#UniformType)                                                                                                                                                                                  | The Glsl type of the uniform.    |
| value | boolean\|number|[Cartesian2](Cartesian2.html)|[Cartesian3](Cartesian3.html)|[Cartesian4](Cartesian4.html)|[Matrix2](Matrix2.html)|[Matrix3](Matrix3.html)|[Matrix4](Matrix4.html)|[TextureUniform](TextureUniform.html) | The initial value of the uniform |

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#WebGLOptions) WebGLOptions

[engine/Source/Renderer/Context.js 439](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Renderer/Context.js#L439) 

 WebGL options to be passed on to HTMLCanvasElement.getContext(). See [WebGLContextAttributes](https://registry.khronos.org/webgl/specs/latest/1.0/#5.2)but note the modified defaults for 'alpha', 'stencil', and 'powerPreference'

`alpha` defaults to false, which can improve performance compared to the standard WebGL default of true. If an application needs to composite Cesium above other HTML elements using alpha-blending, set`alpha` to true.

##### Properties:

| Name                         | Type                                      | Attributes | Default            | Description |
| ---------------------------- | ----------------------------------------- | ---------- | ------------------ | ----------- |
| alpha                        | boolean                                   | <optional> | false              |             |
| depth                        | boolean                                   | <optional> | true               |             |
| stencil                      | boolean                                   | <optional> | false              |             |
| antialias                    | boolean                                   | <optional> | true               |             |
| premultipliedAlpha           | boolean                                   | <optional> | true               |             |
| preserveDrawingBuffer        | boolean                                   | <optional> | false              |             |
| powerPreference              | "default"\|"low-power"|"high-performance" | <optional> | "high-performance" |             |
| failIfMajorPerformanceCaveat | boolean                                   | <optional> | false              |             |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

