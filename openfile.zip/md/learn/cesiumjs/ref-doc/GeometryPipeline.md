# [![](Images/CesiumLogo.png)](index.html) GeometryPipeline 

[engine/Source/Core/GeometryPipeline.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L27) 

Content pipeline functions for geometries.

##### See:

* [Geometry](Geometry.html)

### Methods

#### [](#.compressVertices) static Cesium.GeometryPipeline.compressVertices(geometry) → [Geometry](Geometry.html) 

[engine/Source/Core/GeometryPipeline.js 1481](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L1481) 

 Compresses and packs geometry normal attribute values to save memory.

| Name     | Type                      | Description             |
| -------- | ------------------------- | ----------------------- |
| geometry | [Geometry](Geometry.html) | The geometry to modify. |

##### Returns:

 The modified `geometry` argument, with its normals compressed and packed.

##### Example:

```javascript
geometry = Cesium.GeometryPipeline.compressVertices(geometry);
```

#### [](#.computeNormal) static Cesium.GeometryPipeline.computeNormal(geometry) → [Geometry](Geometry.html) 

[engine/Source/Core/GeometryPipeline.js 1163](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L1163) 

 Computes per-vertex normals for a geometry containing `TRIANGLES` by averaging the normals of all triangles incident to the vertex. The result is a new `normal` attribute added to the geometry. This assumes a counter-clockwise winding order.

| Name     | Type                      | Description             |
| -------- | ------------------------- | ----------------------- |
| geometry | [Geometry](Geometry.html) | The geometry to modify. |

##### Returns:

 The modified `geometry` argument with the computed `normal` attribute.

##### Throws:

* [DeveloperError](DeveloperError.html): geometry.indices length must be greater than 0 and be a multiple of 3.
* [DeveloperError](DeveloperError.html): geometry.primitiveType must be [PrimitiveType.TRIANGLES](global.html#PrimitiveType#.TRIANGLES).

##### Example:

```javascript
Cesium.GeometryPipeline.computeNormal(geometry);
```

#### [](#.computeTangentAndBitangent) static Cesium.GeometryPipeline.computeTangentAndBitangent(geometry) → [Geometry](Geometry.html) 

[engine/Source/Core/GeometryPipeline.js 1334](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L1334) 

 Computes per-vertex tangents and bitangents for a geometry containing `TRIANGLES`. The result is new `tangent` and `bitangent` attributes added to the geometry. This assumes a counter-clockwise winding order.

Based on [Computing Tangent Space Basis Vectors for an Arbitrary Mesh](http://www.terathon.com/code/tangent.html) by Eric Lengyel.

| Name     | Type                      | Description             |
| -------- | ------------------------- | ----------------------- |
| geometry | [Geometry](Geometry.html) | The geometry to modify. |

##### Returns:

 The modified `geometry` argument with the computed `tangent` and `bitangent` attributes.

##### Throws:

* [DeveloperError](DeveloperError.html): geometry.indices length must be greater than 0 and be a multiple of 3.
* [DeveloperError](DeveloperError.html): geometry.primitiveType must be [PrimitiveType.TRIANGLES](global.html#PrimitiveType#.TRIANGLES).

##### Example:

```javascript
Cesium.GeometryPipeline.computeTangentAndBiTangent(geometry);
```

#### [](#.createAttributeLocations) static Cesium.GeometryPipeline.createAttributeLocations(geometry) → object 

[engine/Source/Core/GeometryPipeline.js 241](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L241) 

 Creates an object that maps attribute names to unique locations (indices) for matching vertex attributes and shader programs.

| Name     | Type                      | Description                                                    |
| -------- | ------------------------- | -------------------------------------------------------------- |
| geometry | [Geometry](Geometry.html) | The geometry, which is not modified, to create the object for. |

##### Returns:

 An object with attribute name / index pairs.

##### Example:

```javascript
const attributeLocations = Cesium.GeometryPipeline.createAttributeLocations(geometry);
// Example output
// {
//   'position' : 0,
//   'normal' : 1
// }
```

#### [](#.createLineSegmentsForVectors) static Cesium.GeometryPipeline.createLineSegmentsForVectors(geometry, attributeName, length) → [Geometry](Geometry.html) 

[engine/Source/Core/GeometryPipeline.js 167](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L167) 

 Creates a new [Geometry](Geometry.html) with `LINES` representing the provided attribute (`attributeName`) for the provided geometry. This is used to visualize vector attributes like normals, tangents, and bitangents.

| Name          | Type                      | Default  | Description                                                                                                             |
| ------------- | ------------------------- | -------- | ----------------------------------------------------------------------------------------------------------------------- |
| geometry      | [Geometry](Geometry.html) |          | The Geometry instance with the attribute.                                                                               |
| attributeName | string                    | 'normal' | optional The name of the attribute.                                                                                     |
| length        | number                    | 10000.0  | optional The length of each line segment in meters. This can be negative to point the vector in the opposite direction. |

##### Returns:

 A new `Geometry` instance with line segments for the vector.

##### Throws:

* [DeveloperError](DeveloperError.html): geometry.attributes must have an attribute with the same name as the attributeName parameter.

##### Example:

```javascript
const geometry = Cesium.GeometryPipeline.createLineSegmentsForVectors(instance.geometry, 'bitangent', 100000.0);
```

#### [](#.encodeAttribute) static Cesium.GeometryPipeline.encodeAttribute(geometry, attributeName, attributeHighName, attributeLowName) → [Geometry](Geometry.html) 

[engine/Source/Core/GeometryPipeline.js 728](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L728) 

 Encodes floating-point geometry attribute values as two separate attributes to improve rendering precision.

This is commonly used to create high-precision position vertex attributes.

| Name              | Type                      | Description                                          |
| ----------------- | ------------------------- | ---------------------------------------------------- |
| geometry          | [Geometry](Geometry.html) | The geometry to modify.                              |
| attributeName     | string                    | The name of the attribute.                           |
| attributeHighName | string                    | The name of the attribute for the encoded high bits. |
| attributeLowName  | string                    | The name of the attribute for the encoded low bits.  |

##### Returns:

 The modified `geometry` argument, with its encoded attribute.

##### Throws:

* [DeveloperError](DeveloperError.html): geometry must have attribute matching the attributeName argument.
* [DeveloperError](DeveloperError.html): The attribute componentDatatype must be ComponentDatatype.DOUBLE.

##### Example:

```javascript
geometry = Cesium.GeometryPipeline.encodeAttribute(geometry, 'position3D', 'position3DHigh', 'position3DLow');
```

#### [](#.fitToUnsignedShortIndices) static Cesium.GeometryPipeline.fitToUnsignedShortIndices(geometry) → Array.<[Geometry](Geometry.html)\> 

[engine/Source/Core/GeometryPipeline.js 496](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L496) 

 Splits a geometry into multiple geometries, if necessary, to ensure that indices in the`indices` fit into unsigned shorts. This is used to meet the WebGL requirements when unsigned int indices are not supported.

If the geometry does not have any `indices`, this function has no effect.

| Name     | Type                      | Description                                        |
| -------- | ------------------------- | -------------------------------------------------- |
| geometry | [Geometry](Geometry.html) | The geometry to be split into multiple geometries. |

##### Returns:

 An array of geometries, each with indices that fit into unsigned shorts.

##### Throws:

* [DeveloperError](DeveloperError.html): geometry.primitiveType must equal to PrimitiveType.TRIANGLES, PrimitiveType.LINES, or PrimitiveType.POINTS
* [DeveloperError](DeveloperError.html): All geometry attribute lists must have the same number of attributes.

##### Example:

```javascript
const geometries = Cesium.GeometryPipeline.fitToUnsignedShortIndices(geometry);
```

#### [](#.projectTo2D) static Cesium.GeometryPipeline.projectTo2D(geometry, attributeName, attributeName3D, attributeName2D, projection) → [Geometry](Geometry.html) 

[engine/Source/Core/GeometryPipeline.js 617](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L617) 

 Projects a geometry's 3D `position` attribute to 2D, replacing the `position`attribute with separate `position3D` and `position2D` attributes.

If the geometry does not have a `position`, this function has no effect.

| Name            | Type                      | Default                    | Description                      |
| --------------- | ------------------------- | -------------------------- | -------------------------------- |
| geometry        | [Geometry](Geometry.html) |                            | The geometry to modify.          |
| attributeName   | string                    |                            | The name of the attribute.       |
| attributeName3D | string                    |                            | The name of the attribute in 3D. |
| attributeName2D | string                    |                            | The name of the attribute in 2D. |
| projection      | object                    | new GeographicProjection() | optional The projection to use.  |

##### Returns:

 The modified `geometry` argument with `position3D` and `position2D` attributes.

##### Throws:

* [DeveloperError](DeveloperError.html): geometry must have attribute matching the attributeName argument.
* [DeveloperError](DeveloperError.html): The attribute componentDatatype must be ComponentDatatype.DOUBLE.
* [DeveloperError](DeveloperError.html): Could not project a point to 2D.

##### Example:

```javascript
geometry = Cesium.GeometryPipeline.projectTo2D(geometry, 'position', 'position3D', 'position2D');
```

#### [](#.reorderForPostVertexCache) static Cesium.GeometryPipeline.reorderForPostVertexCache(geometry, cacheCapacity) → [Geometry](Geometry.html) 

[engine/Source/Core/GeometryPipeline.js 410](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L410) 

 Reorders a geometry's `indices` to achieve better performance from the GPU's post vertex-shader cache by using the Tipsify algorithm. If the geometry `primitiveType`is not `TRIANGLES` or the geometry does not have an `indices`, this function has no effect.

| Name          | Type                      | Default | Description                                                                 |
| ------------- | ------------------------- | ------- | --------------------------------------------------------------------------- |
| geometry      | [Geometry](Geometry.html) |         | The geometry to modify.                                                     |
| cacheCapacity | number                    | 24      | optional The number of vertices that can be held in the GPU's vertex cache. |

##### Returns:

 The modified `geometry` argument, with its indices reordered for the post-vertex-shader cache.

##### Throws:

* [DeveloperError](DeveloperError.html): cacheCapacity must be greater than two.

##### Example:

```javascript
geometry = Cesium.GeometryPipeline.reorderForPostVertexCache(geometry);
```

##### See:

* [GeometryPipeline.reorderForPreVertexCache](GeometryPipeline.html#.reorderForPreVertexCache)
* [Fast Triangle Reordering for Vertex Locality and Reduced Overdraw](http://gfx.cs.princ0eton.edu/pubs/Sander%5F2007%5F%253ETR/tipsy.pdf)by Sander, Nehab, and Barczak

#### [](#.reorderForPreVertexCache) static Cesium.GeometryPipeline.reorderForPreVertexCache(geometry) → [Geometry](Geometry.html) 

[engine/Source/Core/GeometryPipeline.js 316](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L316) 

 Reorders a geometry's attributes and `indices` to achieve better performance from the GPU's pre-vertex-shader cache.

| Name     | Type                      | Description             |
| -------- | ------------------------- | ----------------------- |
| geometry | [Geometry](Geometry.html) | The geometry to modify. |

##### Returns:

 The modified `geometry` argument, with its attributes and indices reordered for the GPU's pre-vertex-shader cache.

##### Throws:

* [DeveloperError](DeveloperError.html): Each attribute array in geometry.attributes must have the same number of attributes.

##### Example:

```javascript
geometry = Cesium.GeometryPipeline.reorderForPreVertexCache(geometry);
```

##### See:

* [GeometryPipeline.reorderForPostVertexCache](GeometryPipeline.html#.reorderForPostVertexCache)

#### [](#.toWireframe) static Cesium.GeometryPipeline.toWireframe(geometry) → [Geometry](Geometry.html) 

[engine/Source/Core/GeometryPipeline.js 119](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L119) 

 Converts a geometry's triangle indices to line indices. If the geometry has an `indices`and its `primitiveType` is `TRIANGLES`, `TRIANGLE_STRIP`,`TRIANGLE_FAN`, it is converted to `LINES`; otherwise, the geometry is not changed.

This is commonly used to create a wireframe geometry for visual debugging.

| Name     | Type                      | Description             |
| -------- | ------------------------- | ----------------------- |
| geometry | [Geometry](Geometry.html) | The geometry to modify. |

##### Returns:

 The modified `geometry` argument, with its triangle indices converted to lines.

##### Throws:

* [DeveloperError](DeveloperError.html): geometry.primitiveType must be TRIANGLES, TRIANGLE\_STRIP, or TRIANGLE\_FAN.

##### Example:

```javascript
geometry = Cesium.GeometryPipeline.toWireframe(geometry);
```

#### [](#.transformToWorldCoordinates) static Cesium.GeometryPipeline.transformToWorldCoordinates(instance) → [GeometryInstance](GeometryInstance.html) 

[engine/Source/Core/GeometryPipeline.js 836](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryPipeline.js#L836) 

 Transforms a geometry instance to world coordinates. This changes the instance's `modelMatrix` to [Matrix4.IDENTITY](Matrix4.html#.IDENTITY) and transforms the following attributes if they are present: `position`, `normal`,`tangent`, and `bitangent`.

| Name     | Type                                      | Description                      |
| -------- | ----------------------------------------- | -------------------------------- |
| instance | [GeometryInstance](GeometryInstance.html) | The geometry instance to modify. |

##### Returns:

 The modified `instance` argument, with its attributes transforms to world coordinates.

##### Example:

```javascript
Cesium.GeometryPipeline.transformToWorldCoordinates(instance);
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

