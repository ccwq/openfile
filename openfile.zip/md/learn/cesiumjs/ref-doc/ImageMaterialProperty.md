# [![](Images/CesiumLogo.png)](index.html) ImageMaterialProperty 

#### [](#ImageMaterialProperty) new Cesium.ImageMaterialProperty(options) 

[engine/Source/DataSources/ImageMaterialProperty.js 25](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ImageMaterialProperty.js#L25) 

 A [MaterialProperty](MaterialProperty.html) that maps to image [Material](Material.html) uniforms.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description image [Property](Property.html)\|string|HTMLImageElement|HTMLCanvasElement|HTMLVideoElement optional A Property specifying the Image, URL, Canvas, or Video. repeat [Property](Property.html)|[Cartesian2](Cartesian2.html) new Cartesian2(1.0, 1.0) optional A [Cartesian2](Cartesian2.html) Property specifying the number of times the image repeats in each direction. color [Property](Property.html)|[Color](Color.html) Color.WHITE optional The color applied to the image transparent [Property](Property.html)|boolean false optional Set to true when the image has transparency (for example, when a png has transparent sections) |

### Members

#### [](#color) color : [Property](Property.html)|undefined 

[engine/Source/DataSources/ImageMaterialProperty.js 97](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ImageMaterialProperty.js#L97) 

 Gets or sets the Color Property specifying the desired color applied to the image.

Default Value: `1.0` 

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/ImageMaterialProperty.js 70](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ImageMaterialProperty.js#L70) 

 Gets the event that is raised whenever the definition of this property changes. The definition is considered to have changed if a call to getValue would return a different result for the same time.

#### [](#image) image : [Property](Property.html)|undefined 

[engine/Source/DataSources/ImageMaterialProperty.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ImageMaterialProperty.js#L81) 

 Gets or sets the Property specifying Image, URL, Canvas, or Video to use.

#### [](#isConstant) readonly isConstant : boolean 

[engine/Source/DataSources/ImageMaterialProperty.js 53](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ImageMaterialProperty.js#L53) 

 Gets a value indicating if this property is constant. A property is considered constant if getValue always returns the same result for the current definition.

#### [](#repeat) repeat : [Property](Property.html)|undefined 

[engine/Source/DataSources/ImageMaterialProperty.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ImageMaterialProperty.js#L89) 

 Gets or sets the [Cartesian2](Cartesian2.html) Property specifying the number of times the image repeats in each direction.

Default Value: `new Cartesian2(1, 1)` 

#### [](#transparent) transparent : [Property](Property.html)|undefined 

[engine/Source/DataSources/ImageMaterialProperty.js 105](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ImageMaterialProperty.js#L105) 

 Gets or sets the Boolean Property specifying whether the image has transparency

Default Value: `1.0` 

### Methods

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/ImageMaterialProperty.js 163](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ImageMaterialProperty.js#L163) 

 Compares this property to the provided property and returns`true` if they are equal, `false` otherwise.

| Name  | Type                      | Description                  |
| ----- | ------------------------- | ---------------------------- |
| other | [Property](Property.html) | optional The other property. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#getType) getType(time) → string 

[engine/Source/DataSources/ImageMaterialProperty.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ImageMaterialProperty.js#L114) 

 Gets the [Material](Material.html) type at the provided time.

| Name | Type                          | Description                              |
| ---- | ----------------------------- | ---------------------------------------- |
| time | [JulianDate](JulianDate.html) | The time for which to retrieve the type. |

##### Returns:

 The type of material.

#### [](#getValue) getValue(time, result) → object 

[engine/Source/DataSources/ImageMaterialProperty.js 127](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/ImageMaterialProperty.js#L127) 

 Gets the value of the property at the provided time.

| Name   | Type                          | Default          | Description                                                                                      |
| ------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------ |
| time   | [JulianDate](JulianDate.html) | JulianDate.now() | optional The time for which to retrieve the value. If omitted, the current system time is used.  |
| result | object                        |                  | optional The object to store the value into, if omitted, a new instance is created and returned. |

##### Returns:

 The modified result parameter or a new instance if the result parameter was not supplied.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

