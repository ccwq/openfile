# [![](Images/CesiumLogo.png)](index.html) OrthographicOffCenterFrustum 

#### [](#OrthographicOffCenterFrustum) new Cesium.OrthographicOffCenterFrustum(options) 

[engine/Source/Core/OrthographicOffCenterFrustum.js 38](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L38) 

 The viewing frustum is defined by 6 planes. Each plane is represented by a [Cartesian4](Cartesian4.html) object, where the x, y, and z components define the unit vector normal to the plane, and the w component is the distance of the plane from the origin/camera position.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional An object with the following properties: Name Type Default Description left number optional The left clipping plane distance. right number optional The right clipping plane distance. top number optional The top clipping plane distance. bottom number optional The bottom clipping plane distance. near number 1.0 optional The near clipping plane distance. far number 500000000.0 optional The far clipping plane distance. |

##### Example:

```javascript
const maxRadii = ellipsoid.maximumRadius;

const frustum = new Cesium.OrthographicOffCenterFrustum();
frustum.right = maxRadii * Cesium.Math.PI;
frustum.left = -c.frustum.right;
frustum.top = c.frustum.right * (canvas.clientHeight / canvas.clientWidth);
frustum.bottom = -c.frustum.top;
frustum.near = 0.01 * maxRadii;
frustum.far = 50.0 * maxRadii;
```

### Members

#### [](#bottom) bottom : number|undefined 

[engine/Source/Core/OrthographicOffCenterFrustum.js 70](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L70) 

 The bottom clipping plane.

Default Value: `undefined` 

#### [](#far) far : number 

[engine/Source/Core/OrthographicOffCenterFrustum.js 86](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L86) 

 The distance of the far plane.

Default Value: `500000000.0;` 

#### [](#left) left : number|undefined 

[engine/Source/Core/OrthographicOffCenterFrustum.js 46](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L46) 

 The left clipping plane.

Default Value: `undefined` 

#### [](#near) near : number 

[engine/Source/Core/OrthographicOffCenterFrustum.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L78) 

 The distance of the near plane.

Default Value: `1.0` 

#### [](#projectionMatrix) readonly projectionMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Core/OrthographicOffCenterFrustum.js 156](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L156) 

 Gets the orthographic projection matrix computed from the view frustum.

#### [](#right) right : number|undefined 

[engine/Source/Core/OrthographicOffCenterFrustum.js 54](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L54) 

 The right clipping plane.

Default Value: `undefined` 

#### [](#top) top : number|undefined 

[engine/Source/Core/OrthographicOffCenterFrustum.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L62) 

 The top clipping plane.

Default Value: `undefined` 

### Methods

#### [](#clone) clone(result) → [OrthographicOffCenterFrustum](OrthographicOffCenterFrustum.html) 

[engine/Source/Core/OrthographicOffCenterFrustum.js 363](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L363) 

 Returns a duplicate of a OrthographicOffCenterFrustum instance.

| Name   | Type                                                              | Description                                         |
| ------ | ----------------------------------------------------------------- | --------------------------------------------------- |
| result | [OrthographicOffCenterFrustum](OrthographicOffCenterFrustum.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new OrthographicOffCenterFrustum instance if one was not provided.

#### [](#computeCullingVolume) computeCullingVolume(position, direction, up) → [CullingVolume](CullingVolume.html) 

[engine/Source/Core/OrthographicOffCenterFrustum.js 182](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L182) 

 Creates a culling volume for this frustum.

| Name      | Type                          | Description         |
| --------- | ----------------------------- | ------------------- |
| position  | [Cartesian3](Cartesian3.html) | The eye position.   |
| direction | [Cartesian3](Cartesian3.html) | The view direction. |
| up        | [Cartesian3](Cartesian3.html) | The up direction.   |

##### Returns:

 A culling volume at the given position and orientation.

##### Example:

```javascript
// Check if a bounding volume intersects the frustum.
const cullingVolume = frustum.computeCullingVolume(cameraPosition, cameraDirection, cameraUp);
const intersect = cullingVolume.computeVisibility(boundingVolume);
```

#### [](#equals) equals(other) → boolean 

[engine/Source/Core/OrthographicOffCenterFrustum.js 393](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L393) 

 Compares the provided OrthographicOffCenterFrustum componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                                              | Description                                                |
| ----- | ----------------------------------------------------------------- | ---------------------------------------------------------- |
| other | [OrthographicOffCenterFrustum](OrthographicOffCenterFrustum.html) | optional The right hand side OrthographicOffCenterFrustum. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(other, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/OrthographicOffCenterFrustum.js 416](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L416) 

 Compares the provided OrthographicOffCenterFrustum componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                                                              | Default         | Description                                                          |
| --------------- | ----------------------------------------------------------------- | --------------- | -------------------------------------------------------------------- |
| other           | [OrthographicOffCenterFrustum](OrthographicOffCenterFrustum.html) |                 | The right hand side OrthographicOffCenterFrustum.                    |
| relativeEpsilon | number                                                            |                 | The relative epsilon tolerance to use for equality testing.          |
| absoluteEpsilon | number                                                            | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if this and other are within the provided epsilon, `false` otherwise.

#### [](#getPixelDimensions) getPixelDimensions(drawingBufferWidth, drawingBufferHeight, distance, pixelRatio, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/OrthographicOffCenterFrustum.js 312](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicOffCenterFrustum.js#L312) 

 Returns the pixel's width and height in meters.

| Name                | Type                          | Description                                              |
| ------------------- | ----------------------------- | -------------------------------------------------------- |
| drawingBufferWidth  | number                        | The width of the drawing buffer.                         |
| drawingBufferHeight | number                        | The height of the drawing buffer.                        |
| distance            | number                        | The distance to the near plane in meters.                |
| pixelRatio          | number                        | The scaling factor from pixel space to coordinate space. |
| result              | [Cartesian2](Cartesian2.html) | The object onto which to store the result.               |

##### Returns:

 The modified result parameter or a new instance of [Cartesian2](Cartesian2.html) with the pixel's width and height in the x and y properties, respectively.

##### Throws:

* [DeveloperError](DeveloperError.html): drawingBufferWidth must be greater than zero.
* [DeveloperError](DeveloperError.html): drawingBufferHeight must be greater than zero.
* [DeveloperError](DeveloperError.html): pixelRatio must be greater than zero.

##### Example:

```javascript
// Example 1
// Get the width and height of a pixel.
const pixelSize = camera.frustum.getPixelDimensions(scene.drawingBufferWidth, scene.drawingBufferHeight, 0.0, scene.pixelRatio, new Cesium.Cartesian2());
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

