# [![](Images/CesiumLogo.png)](index.html) Geocoder 

#### [](#Geocoder) new Cesium.Geocoder(options) 

[widgets/Source/Geocoder/Geocoder.js 31](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/Geocoder.js#L31) 

 A widget for finding addresses and landmarks, and flying the camera to them. Geocoding is performed using [Cesium ion](https://cesium.com/cesium-ion/).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description container Element\|string  The DOM element or ID that will contain the widget. scene [Scene](Scene.html)  The Scene instance to use. geocoderServices Array.<[GeocoderService](GeocoderService.html)\> optional The geocoder services to be used autoComplete boolean true optional True if the geocoder should query as the user types to autocomplete flightDuration number 1.5 optional The duration of the camera flight to an entered location, in seconds. destinationFound [Geocoder.DestinationFoundFunction](Geocoder.html#.DestinationFoundFunction) GeocoderViewModel.flyToDestination optional A callback function that is called after a successful geocode. If not supplied, the default behavior is to fly the camera to the result destination. |

### Members

#### [](#container) container : Element 

[widgets/Source/Geocoder/Geocoder.js 164](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/Geocoder.js#L164) 

 Gets the parent container.

#### [](#searchSuggestionsContainer) searchSuggestionsContainer : Element 

[widgets/Source/Geocoder/Geocoder.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/Geocoder.js#L176) 

 Gets the parent container.

#### [](#viewModel) viewModel : [GeocoderViewModel](GeocoderViewModel.html) 

[widgets/Source/Geocoder/Geocoder.js 188](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/Geocoder.js#L188) 

 Gets the view model.

### Methods

#### [](#destroy) destroy() 

[widgets/Source/Geocoder/Geocoder.js 206](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/Geocoder.js#L206) 

 Destroys the widget. Should be called if permanently removing the widget from layout.

#### [](#isDestroyed) isDestroyed() → boolean 

[widgets/Source/Geocoder/Geocoder.js 198](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/Geocoder.js#L198) 

##### Returns:

 true if the object has been destroyed, false otherwise.

### Type Definitions

#### [](#.DestinationFoundFunction) Cesium.Geocoder.DestinationFoundFunction(viewModel, destination) 

[widgets/Source/Geocoder/Geocoder.js 227](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/Geocoder.js#L227) 

 A function that handles the result of a successful geocode.

| Name        | Type                                                       | Description                            |
| ----------- | ---------------------------------------------------------- | -------------------------------------- |
| viewModel   | [GeocoderViewModel](GeocoderViewModel.html)                | The view model.                        |
| destination | [Cartesian3](Cartesian3.html)\|[Rectangle](Rectangle.html) | The destination result of the geocode. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

