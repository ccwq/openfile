# [![](Images/CesiumLogo.png)](index.html) MetadataClassProperty 

#### [](#MetadataClassProperty) new Cesium.MetadataClassProperty(options) 

[engine/Source/Scene/MetadataClassProperty.js 47](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L47) 

 A metadata property, as part of a [MetadataClass](MetadataClass.html).

See the [3D Metadata Specification](https://github.com/CesiumGS/3d-tiles/tree/main/specification/Metadata) for 3D Tiles

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | Object with the following properties: Name Type Default Description id string  The ID of the property. type [MetadataType](global.html#MetadataType)  The type of the property such as SCALAR, VEC2, VEC3. componentType [MetadataComponentType](global.html#MetadataComponentType) optional The component type of the property. This includes integer (e.g. INT8 or UINT16), and floating point (FLOAT32 and FLOAT64) values. enumType [MetadataEnum](MetadataEnum.html) optional The enum type of the property. Only defined when type is ENUM. isArray boolean false optional True if a property is an array (either fixed length or variable length), false otherwise. isVariableLengthArray boolean false optional True if a property is a variable length array, false otherwise. arrayLength number optional The number of array elements. Only defined for fixed length arrays. normalized boolean false optional Whether the property is normalized. min number\|Array.<number>|Array.<Array.<number>> optional A number or an array of numbers storing the minimum allowable value of this property. Only defined when type is a numeric type. max number|Array.<number>|Array.<Array.<number>> optional A number or an array of numbers storing the maximum allowable value of this property. Only defined when type is a numeric type. offset number|Array.<number>|Array.<Array.<number>> optional The offset to be added to property values as part of the value transform. scale number|Array.<number>|Array.<Array.<number>> optional The scale to be multiplied to property values as part of the value transform. noData boolean|number|string|Array optional The no-data sentinel value that represents null values. default boolean|number|string|Array optional A default value to use when an entity's property value is not defined. required boolean false optional Whether the property is required. name string optional The name of the property. description string optional The description of the property. semantic string optional An identifier that describes how this property should be interpreted. extras \* optional Extra user-defined properties. extensions object optional An object containing extensions. |

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

### Members

#### [](#arrayLength) readonly arrayLength : number 

[engine/Source/Scene/MetadataClassProperty.js 326](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L326) 

 The number of array elements. Only defined for fixed-size arrays.

#### [](#componentType) readonly componentType : [MetadataComponentType](global.html#MetadataComponentType) 

[engine/Source/Scene/MetadataClassProperty.js 269](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L269) 

 The component type of the property. This includes integer (e.g. INT8 or UINT16), and floating point (FLOAT32 and FLOAT64) values

#### [](#default) readonly default : boolean|number|string|Array 

[engine/Source/Scene/MetadataClassProperty.js 391](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L391) 

 A default value to use when an entity's property value is not defined.

#### [](#description) readonly description : string 

[engine/Source/Scene/MetadataClassProperty.js 229](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L229) 

 The description of the property.

#### [](#enumType) readonly enumType : [MetadataEnum](MetadataEnum.html) 

[engine/Source/Scene/MetadataClassProperty.js 255](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L255) 

 The enum type of the property. Only defined when type is ENUM.

#### [](#extensions) readonly extensions : object 

[engine/Source/Scene/MetadataClassProperty.js 492](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L492) 

 An object containing extensions.

#### [](#extras) readonly extras : \* 

[engine/Source/Scene/MetadataClassProperty.js 479](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L479) 

 Extra user-defined properties.

#### [](#id) readonly id : string 

[engine/Source/Scene/MetadataClassProperty.js 203](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L203) 

 The ID of the property.

#### [](#isArray) readonly isArray : boolean 

[engine/Source/Scene/MetadataClassProperty.js 299](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L299) 

 True if a property is an array (either fixed length or variable length), false otherwise.

#### [](#isVariableLengthArray) readonly isVariableLengthArray : boolean 

[engine/Source/Scene/MetadataClassProperty.js 312](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L312) 

 True if a property is a variable length array, false otherwise.

#### [](#max) readonly max : number|Array.<number>|Array.<Array.<number>> 

[engine/Source/Scene/MetadataClassProperty.js 352](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L352) 

 A number or an array of numbers storing the maximum allowable value of this property. Only defined when type is a numeric type.

#### [](#min) readonly min : number|Array.<number>|Array.<Array.<number>> 

[engine/Source/Scene/MetadataClassProperty.js 365](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L365) 

 A number or an array of numbers storing the minimum allowable value of this property. Only defined when type is a numeric type.

#### [](#name) readonly name : string 

[engine/Source/Scene/MetadataClassProperty.js 216](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L216) 

 The name of the property.

#### [](#noData) readonly noData : boolean|number|string|Array 

[engine/Source/Scene/MetadataClassProperty.js 378](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L378) 

 The no-data sentinel value that represents null values

#### [](#normalized) readonly normalized : boolean 

[engine/Source/Scene/MetadataClassProperty.js 339](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L339) 

 Whether the property is normalized.

#### [](#offset) readonly offset : number|Array.<number>|Array.<Array.<number>> 

[engine/Source/Scene/MetadataClassProperty.js 449](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L449) 

 The offset to be added to property values as part of the value transform. This is always defined, even when \`hasValueTransform\` is \`false\`. If the class property JSON itself did not define it, then it will be initialized to the default value.

#### [](#required) readonly required : boolean 

[engine/Source/Scene/MetadataClassProperty.js 404](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L404) 

 Whether the property is required.

#### [](#scale) readonly scale : number|Array.<number>|Array.<Array.<number>> 

[engine/Source/Scene/MetadataClassProperty.js 466](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L466) 

 The scale to be multiplied to property values as part of the value transform. This is always defined, even when \`hasValueTransform\` is \`false\`. If the class property JSON itself did not define it, then it will be initialized to the default value.

#### [](#semantic) readonly semantic : string 

[engine/Source/Scene/MetadataClassProperty.js 417](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L417) 

 An identifier that describes how this property should be interpreted.

#### [](#type) readonly type : [MetadataType](global.html#MetadataType) 

[engine/Source/Scene/MetadataClassProperty.js 242](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MetadataClassProperty.js#L242) 

 The type of the property such as SCALAR, VEC2, VEC3

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

