# [![](Images/CesiumLogo.png)](index.html) SphereGeometry 

#### [](#SphereGeometry) new Cesium.SphereGeometry(options) 

[engine/Source/Core/SphereGeometry.js 32](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SphereGeometry.js#L32) 

 A description of a sphere centered at the origin.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description radius number 1.0 optional The radius of the sphere. stackPartitions number 64 optional The number of times to partition the ellipsoid into stacks. slicePartitions number 64 optional The number of times to partition the ellipsoid into radial slices. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. |

##### Throws:

* [DeveloperError](DeveloperError.html): options.slicePartitions cannot be less than three.
* [DeveloperError](DeveloperError.html): options.stackPartitions cannot be less than three.

##### Example:

```javascript
const sphere = new Cesium.SphereGeometry({
  radius : 100.0,
  vertexFormat : Cesium.VertexFormat.POSITION_ONLY
});
const geometry = Cesium.SphereGeometry.createGeometry(sphere);
```

##### See:

* SphereGeometry#createGeometry

### Members

#### [](#.packedLength) static Cesium.SphereGeometry.packedLength : number 

[engine/Source/Core/SphereGeometry.js 50](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SphereGeometry.js#L50) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.SphereGeometry.createGeometry(sphereGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/SphereGeometry.js 115](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SphereGeometry.js#L115) 

 Computes the geometric representation of a sphere, including its vertices, indices, and a bounding sphere.

| Name           | Type                                  | Description                  |
| -------------- | ------------------------------------- | ---------------------------- |
| sphereGeometry | [SphereGeometry](SphereGeometry.html) | A description of the sphere. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.SphereGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/SphereGeometry.js 61](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SphereGeometry.js#L61) 

 Stores the provided instance into the provided array.

| Name          | Type                                  | Default | Description                                                               |
| ------------- | ------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [SphereGeometry](SphereGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                        |         | The array to pack into.                                                   |
| startingIndex | number                                | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.SphereGeometry.unpack(array, startingIndex, result) → [SphereGeometry](SphereGeometry.html) 

[engine/Source/Core/SphereGeometry.js 86](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SphereGeometry.js#L86) 

 Retrieves an instance from a packed array.

| Name          | Type                                  | Default | Description                                                |
| ------------- | ------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                        |         | The packed array.                                          |
| startingIndex | number                                | 0       | optional The starting index of the element to be unpacked. |
| result        | [SphereGeometry](SphereGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new SphereGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

