# [![](Images/CesiumLogo.png)](index.html) PostProcessStageLibrary 

[engine/Source/Scene/PostProcessStageLibrary.js 31](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L31) 

Contains functions for creating common post-process stages.

### Methods

#### [](#.createBlackAndWhiteStage) static Cesium.PostProcessStageLibrary.createBlackAndWhiteStage() → [PostProcessStage](PostProcessStage.html) 

[engine/Source/Scene/PostProcessStageLibrary.js 741](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L741) 

 Creates a post-process stage that renders the input texture with black and white gradations.

This stage has one uniform value, `gradations`, which scales the luminance of each pixel.

##### Returns:

 A post-process stage that renders the input texture with black and white gradations.

#### [](#.createBlurStage) static Cesium.PostProcessStageLibrary.createBlurStage() → [PostProcessStageComposite](PostProcessStageComposite.html) 

[engine/Source/Scene/PostProcessStageLibrary.js 119](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L119) 

 Creates a post-process stage that applies a Gaussian blur to the input texture. This stage is usually applied in conjunction with another stage.

This stage has the following uniforms: `delta`, `sigma`, and `stepSize`.

`delta` and `sigma` are used to compute the weights of a Gaussian filter. The equation is `exp((-0.5 * delta * delta) / (sigma * sigma))`. The default value for `delta` is `1.0`. The default value for `sigma` is `2.0`.`stepSize` is the distance to the next texel. The default is `1.0`.

##### Returns:

 A post-process stage that applies a Gaussian blur to the input texture.

#### [](#.createBrightnessStage) static Cesium.PostProcessStageLibrary.createBrightnessStage() → [PostProcessStage](PostProcessStage.html) 

[engine/Source/Scene/PostProcessStageLibrary.js 758](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L758) 

 Creates a post-process stage that saturates the input texture.

This stage has one uniform value, `brightness`, which scales the saturation of each pixel.

##### Returns:

 A post-process stage that saturates the input texture.

#### [](#.createDepthOfFieldStage) static Cesium.PostProcessStageLibrary.createDepthOfFieldStage() → [PostProcessStageComposite](PostProcessStageComposite.html) 

[engine/Source/Scene/PostProcessStageLibrary.js 141](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L141) 

 Creates a post-process stage that applies a depth of field effect.

Depth of field simulates camera focus. Objects in the scene that are in focus will be clear whereas objects not in focus will be blurred.

This stage has the following uniforms: `focalDistance`, `delta`, `sigma`, and `stepSize`.

`focalDistance` is the distance in meters from the camera to set the camera focus.

`delta`, `sigma`, and `stepSize` are the same properties as `PostProcessStageLibrary#createBlurStage`. The blur is applied to the areas out of focus.

##### Returns:

 A post-process stage that applies a depth of field effect.

#### [](#.createEdgeDetectionStage) static Cesium.PostProcessStageLibrary.createEdgeDetectionStage() → [PostProcessStage](PostProcessStage.html) 

[engine/Source/Scene/PostProcessStageLibrary.js 241](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L241) 

 Creates a post-process stage that detects edges.

Writes the color to the output texture with alpha set to 1.0 when it is on an edge.

This stage has the following uniforms: `color` and `length` 

* `color` is the color of the highlighted edge. The default is `Color#BLACK`.
* `length` is the length of the edges in pixels. The default is `0.5`.

This stage is not supported in 2D.

##### Returns:

 A post-process stage that applies an edge detection effect.

##### Example:

```javascript
// multiple silhouette effects
const yellowEdge = Cesium.PostProcessStageLibrary.createEdgeDetectionStage();
yellowEdge.uniforms.color = Cesium.Color.YELLOW;
yellowEdge.selected = [feature0];

const greenEdge = Cesium.PostProcessStageLibrary.createEdgeDetectionStage();
greenEdge.uniforms.color = Cesium.Color.LIME;
greenEdge.selected = [feature1];

// draw edges around feature0 and feature1
postProcessStages.add(Cesium.PostProcessStageLibrary.createSilhouetteStage([yellowEdge, greenEdge]);
```

#### [](#.createLensFlareStage) static Cesium.PostProcessStageLibrary.createLensFlareStage() → [PostProcessStage](PostProcessStage.html) 

[engine/Source/Scene/PostProcessStageLibrary.js 810](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L810) 

 Creates a post-process stage that applies an effect simulating light flaring a camera lens.

This stage has the following uniforms: `dirtTexture`, `starTexture`, `intensity`, `distortion`, `ghostDispersal`,`haloWidth`, `dirtAmount`, and `earthRadius`.
* `dirtTexture` is a texture sampled to simulate dirt on the lens.
* `starTexture` is the texture sampled for the star pattern of the flare.
* `intensity` is a scalar multiplied by the result of the lens flare. The default value is `2.0`.
* `distortion` is a scalar value that affects the chromatic effect distortion. The default value is `10.0`.
* `ghostDispersal` is a scalar indicating how far the halo effect is from the center of the texture. The default value is `0.4`.
* `haloWidth` is a scalar representing the width of the halo from the ghost dispersal. The default value is `0.4`.
* `dirtAmount` is a scalar representing the amount of dirt on the lens. The default value is `0.4`.
* `earthRadius` is the maximum radius of the earth. The default value is `Ellipsoid.WGS84.maximumRadius`.

##### Returns:

 A post-process stage for applying a lens flare effect.

#### [](#.createNightVisionStage) static Cesium.PostProcessStageLibrary.createNightVisionStage() → [PostProcessStage](PostProcessStage.html) 

[engine/Source/Scene/PostProcessStageLibrary.js 772](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L772) 

 Creates a post-process stage that adds a night vision effect to the input texture.

##### Returns:

 A post-process stage that adds a night vision effect to the input texture.

#### [](#.createSilhouetteStage) static Cesium.PostProcessStageLibrary.createSilhouetteStage(edgeDetectionStages) → [PostProcessStageComposite](PostProcessStageComposite.html) 

[engine/Source/Scene/PostProcessStageLibrary.js 331](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L331) 

 Creates a post-process stage that applies a silhouette effect.

A silhouette effect composites the color from the edge detection pass with input color texture.

This stage has the following uniforms when `edgeDetectionStages` is `undefined`: `color` and `length` 

`color` is the color of the highlighted edge. The default is `Color#BLACK`.`length` is the length of the edges in pixels. The default is `0.5`.

| Name                | Type                                               | Description                                              |
| ------------------- | -------------------------------------------------- | -------------------------------------------------------- |
| edgeDetectionStages | Array.<[PostProcessStage](PostProcessStage.html)\> | optional An array of edge detection post process stages. |

##### Returns:

 A post-process stage that applies a silhouette effect.

#### [](#.isAmbientOcclusionSupported) static Cesium.PostProcessStageLibrary.isAmbientOcclusionSupported(scene) → boolean 

[engine/Source/Scene/PostProcessStageLibrary.js 599](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L599) 

 Whether or not an ambient occlusion stage is supported.

This stage requires the WEBGL\_depth\_texture extension.

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| scene | [Scene](Scene.html) | The scene.  |

##### Returns:

 Whether this post process stage is supported.

##### See:

* {[Context#depthTexture](Context.html#depthTexture)}
* [WEBGL\_depth\_texture](http://www.khronos.org/registry/webgl/extensions/WEBGL%5Fdepth%5Ftexture/)

#### [](#.isDepthOfFieldSupported) static Cesium.PostProcessStageLibrary.isDepthOfFieldSupported(scene) → boolean 

[engine/Source/Scene/PostProcessStageLibrary.js 207](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L207) 

 Whether or not a depth of field stage is supported.

This stage requires the WEBGL\_depth\_texture extension.

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| scene | [Scene](Scene.html) | The scene.  |

##### Returns:

 Whether this post process stage is supported.

##### See:

* {[Context#depthTexture](Context.html#depthTexture)}
* [WEBGL\_depth\_texture](http://www.khronos.org/registry/webgl/extensions/WEBGL%5Fdepth%5Ftexture/)

#### [](#.isEdgeDetectionSupported) static Cesium.PostProcessStageLibrary.isEdgeDetectionSupported(scene) → boolean 

[engine/Source/Scene/PostProcessStageLibrary.js 266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L266) 

 Whether or not an edge detection stage is supported.

This stage requires the WEBGL\_depth\_texture extension.

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| scene | [Scene](Scene.html) | The scene.  |

##### Returns:

 Whether this post process stage is supported.

##### See:

* {[Context#depthTexture](Context.html#depthTexture)}
* [WEBGL\_depth\_texture](http://www.khronos.org/registry/webgl/extensions/WEBGL%5Fdepth%5Ftexture/)

#### [](#.isSilhouetteSupported) static Cesium.PostProcessStageLibrary.isSilhouetteSupported(scene) → boolean 

[engine/Source/Scene/PostProcessStageLibrary.js 361](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageLibrary.js#L361) 

 Whether or not a silhouette stage is supported.

This stage requires the WEBGL\_depth\_texture extension.

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| scene | [Scene](Scene.html) | The scene.  |

##### Returns:

 Whether this post process stage is supported.

##### See:

* {[Context#depthTexture](Context.html#depthTexture)}
* [WEBGL\_depth\_texture](http://www.khronos.org/registry/webgl/extensions/WEBGL%5Fdepth%5Ftexture/)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

