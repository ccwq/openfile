# [![](Images/CesiumLogo.png)](index.html) Ellipsoid 

#### [](#Ellipsoid) new Cesium.Ellipsoid(x, y, z) 

[engine/Source/Core/Ellipsoid.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L76) 

 A quadratic surface defined in Cartesian coordinates by the equation`(x / a)^2 + (y / b)^2 + (z / c)^2 = 1`. Primarily used by Cesium to represent the shape of planetary bodies. Rather than constructing this object directly, one of the provided constants is normally used.

| Name | Type   | Default | Description                             |
| ---- | ------ | ------- | --------------------------------------- |
| x    | number | 0       | optional The radius in the x direction. |
| y    | number | 0       | optional The radius in the y direction. |
| z    | number | 0       | optional The radius in the z direction. |

##### Throws:

* [DeveloperError](DeveloperError.html): All radii components must be greater than or equal to zero.

##### See:

* [Ellipsoid.fromCartesian3](Ellipsoid.html#.fromCartesian3)
* [Ellipsoid.WGS84](Ellipsoid.html#.WGS84)
* [Ellipsoid.UNIT\_SPHERE](Ellipsoid.html#.UNIT%5FSPHERE)

### Members

#### [](#.default) static Cesium.Ellipsoid.default : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/Ellipsoid.js 273](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L273) 

 The default ellipsoid used when not otherwise specified.

##### Example:

```javascript
Cesium.Ellipsoid.default = Cesium.Ellipsoid.MOON;

// Apollo 11 landing site
const position = Cesium.Cartesian3.fromRadians(
  0.67416,
  23.47315,
);
```

#### [](#.MOON) static constant Cesium.Ellipsoid.MOON : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/Ellipsoid.js 250](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L250) 

 An Ellipsoid instance initialized to a sphere with the lunar radius.

#### [](#.packedLength) static Cesium.Ellipsoid.packedLength : number 

[engine/Source/Core/Ellipsoid.js 307](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L307) 

 The number of elements used to pack the object into an array.

#### [](#.UNIT%5FSPHERE) static constant Cesium.Ellipsoid.UNIT\_SPHERE : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/Ellipsoid.js 242](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L242) 

 An Ellipsoid instance initialized to radii of (1.0, 1.0, 1.0).

#### [](#.WGS84) static constant Cesium.Ellipsoid.WGS84 : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/Ellipsoid.js 232](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L232) 

 An Ellipsoid instance initialized to the WGS84 standard.

#### [](#maximumRadius) readonly maximumRadius : number 

[engine/Source/Core/Ellipsoid.js 163](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L163) 

 Gets the maximum radius of the ellipsoid.

#### [](#minimumRadius) readonly minimumRadius : number 

[engine/Source/Core/Ellipsoid.js 152](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L152) 

 Gets the minimum radius of the ellipsoid.

#### [](#oneOverRadii) readonly oneOverRadii : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 130](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L130) 

 Gets one over the radii of the ellipsoid.

#### [](#oneOverRadiiSquared) readonly oneOverRadiiSquared : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 141](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L141) 

 Gets one over the squared radii of the ellipsoid.

#### [](#radii) readonly radii : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 97](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L97) 

 Gets the radii of the ellipsoid.

#### [](#radiiSquared) readonly radiiSquared : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L108) 

 Gets the squared radii of the ellipsoid.

#### [](#radiiToTheFourth) readonly radiiToTheFourth : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 119](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L119) 

 Gets the radii of the ellipsoid raise to the fourth power.

### Methods

#### [](#.clone) static Cesium.Ellipsoid.clone(ellipsoid, result) → [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/Ellipsoid.js 178](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L178) 

 Duplicates an Ellipsoid instance.

| Name      | Type                        | Description                                                                                           |
| --------- | --------------------------- | ----------------------------------------------------------------------------------------------------- |
| ellipsoid | [Ellipsoid](Ellipsoid.html) | The ellipsoid to duplicate.                                                                           |
| result    | [Ellipsoid](Ellipsoid.html) | optional The object onto which to store the result, or undefined if a new instance should be created. |

##### Returns:

 The cloned Ellipsoid. (Returns undefined if ellipsoid is undefined)

#### [](#.fromCartesian3) static Cesium.Ellipsoid.fromCartesian3(cartesian, result) → [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/Ellipsoid.js 213](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L213) 

 Computes an Ellipsoid from a Cartesian specifying the radii in x, y, and z directions.

| Name      | Type                          | Default         | Description                                                                                           |
| --------- | ----------------------------- | --------------- | ----------------------------------------------------------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | Cartesian3.ZERO | optional The ellipsoid's radius in the x, y, and z directions.                                        |
| result    | [Ellipsoid](Ellipsoid.html)   |                 | optional The object onto which to store the result, or undefined if a new instance should be created. |

##### Returns:

 A new Ellipsoid instance.

##### Throws:

* [DeveloperError](DeveloperError.html): All radii components must be greater than or equal to zero.

##### See:

* [Ellipsoid.WGS84](Ellipsoid.html#.WGS84)
* [Ellipsoid.UNIT\_SPHERE](Ellipsoid.html#.UNIT%5FSPHERE)

#### [](#.pack) static Cesium.Ellipsoid.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/Ellipsoid.js 318](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L318) 

 Stores the provided instance into the provided array.

| Name          | Type                        | Default | Description                                                               |
| ------------- | --------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [Ellipsoid](Ellipsoid.html) |         | The value to pack.                                                        |
| array         | Array.<number>              |         | The array to pack into.                                                   |
| startingIndex | number                      | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.Ellipsoid.unpack(array, startingIndex, result) → [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/Ellipsoid.js 339](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L339) 

 Retrieves an instance from a packed array.

| Name          | Type                        | Default | Description                                                |
| ------------- | --------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>              |         | The packed array.                                          |
| startingIndex | number                      | 0       | optional The starting index of the element to be unpacked. |
| result        | [Ellipsoid](Ellipsoid.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new Ellipsoid instance if one was not provided.

#### [](#cartesianArrayToCartographicArray) cartesianArrayToCartographicArray(cartesians, result) → Array.<[Cartographic](Cartographic.html)\> 

[engine/Source/Core/Ellipsoid.js 543](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L543) 

 Converts the provided array of cartesians to an array of cartographics.

| Name       | Type                                       | Description                                         |
| ---------- | ------------------------------------------ | --------------------------------------------------- |
| cartesians | Array.<[Cartesian3](Cartesian3.html)\>     | An array of Cartesian positions.                    |
| result     | Array.<[Cartographic](Cartographic.html)\> | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Array instance if none was provided.

##### Example:

```javascript
//Create an array of Cartesians and determine their Cartographic representation on a WGS84 ellipsoid.
const positions = [new Cesium.Cartesian3(17832.12, 83234.52, 952313.73),
                 new Cesium.Cartesian3(17832.13, 83234.53, 952313.73),
                 new Cesium.Cartesian3(17832.14, 83234.54, 952313.73)]
const cartographicPositions = Cesium.Ellipsoid.WGS84.cartesianArrayToCartographicArray(positions);
```

#### [](#cartesianToCartographic) cartesianToCartographic(cartesian, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/Ellipsoid.js 504](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L504) 

 Converts the provided cartesian to cartographic representation. The cartesian is undefined at the center of the ellipsoid.

| Name      | Type                              | Description                                                       |
| --------- | --------------------------------- | ----------------------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html)     | The Cartesian position to convert to cartographic representation. |
| result    | [Cartographic](Cartographic.html) | optional The object onto which to store the result.               |

##### Returns:

 The modified result parameter, new Cartographic instance if none was provided, or undefined if the cartesian is at the center of the ellipsoid.

##### Example:

```javascript
//Create a Cartesian and determine it's Cartographic representation on a WGS84 ellipsoid.
const position = new Cesium.Cartesian3(17832.12, 83234.52, 952313.73);
const cartographicPosition = Cesium.Ellipsoid.WGS84.cartesianToCartographic(position);
```

#### [](#cartographicArrayToCartesianArray) cartographicArrayToCartesianArray(cartographics, result) → Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/Ellipsoid.js 467](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L467) 

 Converts the provided array of cartographics to an array of Cartesians.

| Name          | Type                                       | Description                                         |
| ------------- | ------------------------------------------ | --------------------------------------------------- |
| cartographics | Array.<[Cartographic](Cartographic.html)\> | An array of cartographic positions.                 |
| result        | Array.<[Cartesian3](Cartesian3.html)\>     | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Array instance if none was provided.

##### Example:

```javascript
//Convert an array of Cartographics and determine their Cartesian representation on a WGS84 ellipsoid.
const positions = [new Cesium.Cartographic(Cesium.Math.toRadians(21), Cesium.Math.toRadians(78), 0),
                 new Cesium.Cartographic(Cesium.Math.toRadians(21.321), Cesium.Math.toRadians(78.123), 100),
                 new Cesium.Cartographic(Cesium.Math.toRadians(21.645), Cesium.Math.toRadians(78.456), 250)];
const cartesianPositions = Cesium.Ellipsoid.WGS84.cartographicArrayToCartesianArray(positions);
```

#### [](#cartographicToCartesian) cartographicToCartesian(cartographic, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 437](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L437) 

 Converts the provided cartographic to Cartesian representation.

| Name         | Type                              | Description                                         |
| ------------ | --------------------------------- | --------------------------------------------------- |
| cartographic | [Cartographic](Cartographic.html) | The cartographic position.                          |
| result       | [Cartesian3](Cartesian3.html)     | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if none was provided.

##### Example:

```javascript
//Create a Cartographic and determine it's Cartesian representation on a WGS84 ellipsoid.
const position = new Cesium.Cartographic(Cesium.Math.toRadians(21), Cesium.Math.toRadians(78), 5000);
const cartesianPosition = Cesium.Ellipsoid.WGS84.cartographicToCartesian(position);
```

#### [](#clone) clone(result) → [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/Ellipsoid.js 299](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L299) 

 Duplicates an Ellipsoid instance.

| Name   | Type                        | Description                                                                                           |
| ------ | --------------------------- | ----------------------------------------------------------------------------------------------------- |
| result | [Ellipsoid](Ellipsoid.html) | optional The object onto which to store the result, or undefined if a new instance should be created. |

##### Returns:

 The cloned Ellipsoid.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/Ellipsoid.js 664](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L664) 

 Compares this Ellipsoid against the provided Ellipsoid componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                        | Description                   |
| ----- | --------------------------- | ----------------------------- |
| right | [Ellipsoid](Ellipsoid.html) | optional The other Ellipsoid. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#geocentricSurfaceNormal) geocentricSurfaceNormal(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 358](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L358) 

 Computes the unit vector directed from the center of this ellipsoid toward the provided Cartesian position.

| Name      | Type                          | Description                                                    |
| --------- | ----------------------------- | -------------------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian for which to to determine the geocentric normal. |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result.            |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if none was provided.

#### [](#geodeticSurfaceNormal) geodeticSurfaceNormal(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 399](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L399) 

 Computes the normal of the plane tangent to the surface of the ellipsoid at the provided position.

| Name      | Type                          | Description                                                          |
| --------- | ----------------------------- | -------------------------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian position for which to to determine the surface normal. |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result.                  |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if none was provided, or undefined if a normal cannot be found.

#### [](#geodeticSurfaceNormalCartographic) geodeticSurfaceNormalCartographic(cartographic, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 367](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L367) 

 Computes the normal of the plane tangent to the surface of the ellipsoid at the provided position.

| Name         | Type                              | Description                                                              |
| ------------ | --------------------------------- | ------------------------------------------------------------------------ |
| cartographic | [Cartographic](Cartographic.html) | The cartographic position for which to to determine the geodetic normal. |
| result       | [Cartesian3](Cartesian3.html)     | optional The object onto which to store the result.                      |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if none was provided.

#### [](#getLocalCurvature) getLocalCurvature(surfacePosition, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/Ellipsoid.js 749](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L749) 

 Computes the ellipsoid curvatures at a given position on the surface.

| Name            | Type                          | Description                                                                                           |
| --------------- | ----------------------------- | ----------------------------------------------------------------------------------------------------- |
| surfacePosition | [Cartesian3](Cartesian3.html) | The position on the ellipsoid surface where curvatures will be calculated.                            |
| result          | [Cartesian2](Cartesian2.html) | optional The cartesian to which to copy the result, or undefined to create and return a new instance. |

##### Returns:

 The local curvature of the ellipsoid surface at the provided position, in east and north directions.

##### Throws:

* [DeveloperError](DeveloperError.html): position is required.

#### [](#getSurfaceNormalIntersectionWithZAxis) getSurfaceNormalIntersectionWithZAxis(position, buffer, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/Core/Ellipsoid.js 696](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L696) 

 Computes a point which is the intersection of the surface normal with the z-axis.

| Name     | Type                          | Default | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| -------- | ----------------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| position | [Cartesian3](Cartesian3.html) |         | the position. must be on the surface of the ellipsoid.                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| buffer   | number                        | 0.0     | optional A buffer to subtract from the ellipsoid size when checking if the point is inside the ellipsoid. In earth case, with common earth datums, there is no need for this buffer since the intersection point is always (relatively) very close to the center. In WGS84 datum, intersection point is at max z = +-42841.31151331382 (0.673% of z-axis). Intersection point could be outside the ellipsoid if the ratio of MajorAxis / AxisOfRotation is bigger than the square root of 2 |
| result   | [Cartesian3](Cartesian3.html) |         | optional The cartesian to which to copy the result, or undefined to create and return a new instance.                                                                                                                                                                                                                                                                                                                                                                                       |

##### Returns:

 the intersection point if it's inside the ellipsoid, undefined otherwise

##### Throws:

* [DeveloperError](DeveloperError.html): position is required.
* [DeveloperError](DeveloperError.html): Ellipsoid must be an ellipsoid of revolution (radii.x == radii.y).
* [DeveloperError](DeveloperError.html): Ellipsoid.radii.z must be greater than 0.

#### [](#scaleToGeocentricSurface) scaleToGeocentricSurface(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 590](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L590) 

 Scales the provided Cartesian position along the geocentric surface normal so that it is on the surface of this ellipsoid.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian position to scale.                    |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if none was provided.

#### [](#scaleToGeodeticSurface) scaleToGeodeticSurface(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 572](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L572) 

 Scales the provided Cartesian position along the geodetic surface normal so that it is on the surface of this ellipsoid. If the position is at the center of the ellipsoid, this function returns undefined.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian position to scale.                    |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter, a new Cartesian3 instance if none was provided, or undefined if the position is at the center.

#### [](#surfaceArea) surfaceArea(rectangle) → number 

[engine/Source/Core/Ellipsoid.js 841](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L841) 

 Computes an approximation of the surface area of a rectangle on the surface of an ellipsoid using Gauss-Legendre 10th order quadrature.

| Name      | Type                        | Description                                        |
| --------- | --------------------------- | -------------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html) | The rectangle used for computing the surface area. |

##### Returns:

 The approximate area of the rectangle on the surface of this ellipsoid.

#### [](#toString) toString() → string 

[engine/Source/Core/Ellipsoid.js 676](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L676) 

 Creates a string representing this Ellipsoid in the format '(radii.x, radii.y, radii.z)'.

##### Returns:

 A string representing this ellipsoid in the format '(radii.x, radii.y, radii.z)'.

#### [](#transformPositionFromScaledSpace) transformPositionFromScaledSpace(position, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 646](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L646) 

 Transforms a Cartesian X, Y, Z position from the ellipsoid-scaled space by multiplying its components by the result of [Ellipsoid#radii](Ellipsoid.html#radii).

| Name     | Type                          | Description                                                                                          |
| -------- | ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| position | [Cartesian3](Cartesian3.html) | The position to transform.                                                                           |
| result   | [Cartesian3](Cartesian3.html) | optional The position to which to copy the result, or undefined to create and return a new instance. |

##### Returns:

 The position expressed in the unscaled space. The returned instance is the one passed as the result parameter if it is not undefined, or a new instance of it is.

#### [](#transformPositionToScaledSpace) transformPositionToScaledSpace(position, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Ellipsoid.js 625](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Ellipsoid.js#L625) 

 Transforms a Cartesian X, Y, Z position to the ellipsoid-scaled space by multiplying its components by the result of [Ellipsoid#oneOverRadii](Ellipsoid.html#oneOverRadii).

| Name     | Type                          | Description                                                                                          |
| -------- | ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| position | [Cartesian3](Cartesian3.html) | The position to transform.                                                                           |
| result   | [Cartesian3](Cartesian3.html) | optional The position to which to copy the result, or undefined to create and return a new instance. |

##### Returns:

 The position expressed in the scaled space. The returned instance is the one passed as the result parameter if it is not undefined, or a new instance of it is.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

