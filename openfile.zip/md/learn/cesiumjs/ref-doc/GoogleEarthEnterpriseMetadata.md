# [![](Images/CesiumLogo.png)](index.html) GoogleEarthEnterpriseMetadata 

#### [](#GoogleEarthEnterpriseMetadata) new Cesium.GoogleEarthEnterpriseMetadata() 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 47](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L47) 

To construct GoogleEarthEnterpriseMetadata, call [GoogleEarthEnterpriseMetadata.fromUrl](GoogleEarthEnterpriseMetadata.html#.fromUrl). Do not call the constructor directly.

Provides metadata using the Google Earth Enterprise REST API. This is used by the GoogleEarthEnterpriseImageryProvider and GoogleEarthEnterpriseTerrainProvider to share metadata requests.

##### See:

* [GoogleEarthEnterpriseImageryProvider](GoogleEarthEnterpriseImageryProvider.html)
* [GoogleEarthEnterpriseTerrainProvider](GoogleEarthEnterpriseTerrainProvider.html)

### Members

#### [](#imageryPresent) imageryPresent : boolean 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 53](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L53) 

 True if imagery is available.

Default Value: `true` 

#### [](#key) key : ArrayBuffer 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 94](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L94) 

 Key used to decode packets

#### [](#negativeAltitudeExponentBias) negativeAltitudeExponentBias : number 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 74](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L74) 

 Exponent used to compute constant to calculate negative height values.

Default Value: `32` 

#### [](#negativeAltitudeThreshold) negativeAltitudeThreshold : number 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L81) 

 Threshold where any numbers smaller are actually negative values. They are multiplied by -2^negativeAltitudeExponentBias.

Default Value: `EPSILON12` 

#### [](#protoImagery) protoImagery : boolean|undefined 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L60) 

 True if imagery is sent as a protocol buffer, false if sent as plain images. If undefined we will try both.

Default Value: `undefined` 

#### [](#providers) providers : object 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L88) 

 Dictionary of provider id to copyright strings.

Default Value: `{}` 

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L121) 

 Gets the proxy used for metadata requests.

#### [](#resource) readonly resource : [Resource](Resource.html) 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 133](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L133) 

 Gets the resource used for metadata requests.

#### [](#terrainPresent) terrainPresent : boolean 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 67](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L67) 

 True if terrain is available.

Default Value: `true` 

#### [](#url) readonly url : string 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L109) 

 Gets the name of the Google Earth Enterprise server.

### Methods

#### [](#.fromUrl) static Cesium.GoogleEarthEnterpriseMetadata.fromUrl(resourceOrUrl) → Promise.<[GoogleEarthEnterpriseMetadata](GoogleEarthEnterpriseMetadata.html)\> 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 148](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L148) 

 Creates a metadata object using the Google Earth Enterprise REST API. This is used by the GoogleEarthEnterpriseImageryProvider and GoogleEarthEnterpriseTerrainProvider to share metadata requests.

| Name          | Type                              | Description                                                        |
| ------------- | --------------------------------- | ------------------------------------------------------------------ |
| resourceOrUrl | [Resource](Resource.html)\|String | The url of the Google Earth Enterprise server hosting the imagery. |

##### Returns:

 A promise which resolves to the created GoogleEarthEnterpriseMetadata instance/

#### [](#.quadKeyToTileXY) static Cesium.GoogleEarthEnterpriseMetadata.quadKeyToTileXY(quadkey) 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 232](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L232) 

 Converts a tile's quadkey used to request an image from a Google Earth Enterprise server into the (x, y, level) position.

| Name    | Type   | Description         |
| ------- | ------ | ------------------- |
| quadkey | string | The tile's quad key |

##### See:

* GoogleEarthEnterpriseMetadata#tileXYToQuadKey

#### [](#.tileXYToQuadKey) static Cesium.GoogleEarthEnterpriseMetadata.tileXYToQuadKey(x, y, level) 

[engine/Source/Core/GoogleEarthEnterpriseMetadata.js 192](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseMetadata.js#L192) 

 Converts a tiles (x, y, level) position into a quadkey used to request an image from a Google Earth Enterprise server.

| Name  | Type   | Description              |
| ----- | ------ | ------------------------ |
| x     | number | The tile's x coordinate. |
| y     | number | The tile's y coordinate. |
| level | number | The tile's zoom level.   |

##### See:

* GoogleEarthEnterpriseMetadata#quadKeyToTileXY

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

