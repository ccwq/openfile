# [![](Images/CesiumLogo.png)](index.html) RectangleGraphics 

#### [](#RectangleGraphics) new Cesium.RectangleGraphics(options) 

[engine/Source/DataSources/RectangleGraphics.js 46](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L46) 

 Describes graphics for a [Rectangle](Rectangle.html). The rectangle conforms to the curvature of the globe and can be placed on the surface or at altitude and can optionally be extruded into a volume.

| Name    | Type                                                                               | Description                                       |
| ------- | ---------------------------------------------------------------------------------- | ------------------------------------------------- |
| options | [RectangleGraphics.ConstructorOptions](RectangleGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle Rectangle Demo](https://sandcastle.cesium.com/index.html?src=Rectangle.html)

##### See:

* [Entity](Entity.html)

### Members

#### [](#classificationType) classificationType : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 240](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L240) 

 Gets or sets the [ClassificationType](global.html#ClassificationType) Property specifying whether this rectangle will classify terrain, 3D Tiles, or both when on the ground.

Default Value: `ClassificationType.BOTH` 

#### [](#coordinates) coordinates : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 115](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L115) 

 Gets or sets the Property specifying the [Rectangle](Rectangle.html).

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/RectangleGraphics.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L96) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 230](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L230) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this rectangle will be displayed.

#### [](#extrudedHeight) extrudedHeight : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L139) 

 Gets or sets the numeric Property specifying the altitude of the rectangle extrusion. Setting this property creates volume starting at height and ending at this altitude.

#### [](#extrudedHeightReference) extrudedHeightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 147](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L147) 

 Gets or sets the Property specifying the extruded [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#fill) fill : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 179](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L179) 

 Gets or sets the boolean Property specifying whether the rectangle is filled with the provided material.

Default Value: `true` 

#### [](#granularity) granularity : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 171](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L171) 

 Gets or sets the numeric Property specifying the angular distance between points on the rectangle.

Default Value: `{CesiumMath.RADIANS_PER_DEGREE}` 

#### [](#height) height : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 123](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L123) 

 Gets or sets the numeric Property specifying the altitude of the rectangle.

Default Value: `0.0` 

#### [](#heightReference) heightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 131](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L131) 

 Gets or sets the Property specifying the [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#material) material : [MaterialProperty](MaterialProperty.html) 

[engine/Source/DataSources/RectangleGraphics.js 187](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L187) 

 Gets or sets the Property specifying the material used to fill the rectangle.

Default Value: `Color.WHITE` 

#### [](#outline) outline : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 195](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L195) 

 Gets or sets the Property specifying whether the rectangle is outlined.

Default Value: `false` 

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 203](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L203) 

 Gets or sets the Property specifying the [Color](Color.html) of the outline.

Default Value: `Color.BLACK` 

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 214](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L214) 

 Gets or sets the numeric Property specifying the width of the outline.

Note: This property will be ignored on all major browsers on Windows platforms. For details, see (@link https://github.com/CesiumGS/cesium/issues/40}.

Default Value: `1.0` 

#### [](#rotation) rotation : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L155) 

 Gets or sets the numeric property specifying the rotation of the rectangle clockwise from north.

Default Value: `0` 

#### [](#shadows) shadows : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 223](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L223) 

 Get or sets the enum Property specifying whether the rectangle casts or receives shadows from light sources.

Default Value: `ShadowMode.DISABLED` 

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L108) 

 Gets or sets the boolean Property specifying the visibility of the rectangle.

Default Value: `true` 

#### [](#stRotation) stRotation : [Property](Property.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 163](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L163) 

 Gets or sets the numeric property specifying the rotation of the rectangle texture counter-clockwise from north.

Default Value: `0` 

#### [](#zIndex) zIndex : [ConstantProperty](ConstantProperty.html)|undefined 

[engine/Source/DataSources/RectangleGraphics.js 248](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L248) 

 Gets or sets the zIndex Property specifying the ordering of the rectangle. Only has an effect if the rectangle is constant and neither height or extrudedHeight are specified.

Default Value: `0` 

### Methods

#### [](#clone) clone(result) → [RectangleGraphics](RectangleGraphics.html) 

[engine/Source/DataSources/RectangleGraphics.js 257](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L257) 

 Duplicates this instance.

| Name   | Type                                        | Description                                         |
| ------ | ------------------------------------------- | --------------------------------------------------- |
| result | [RectangleGraphics](RectangleGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/RectangleGraphics.js 288](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L288) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                        | Description                               |
| ------ | ------------------------------------------- | ----------------------------------------- |
| source | [RectangleGraphics](RectangleGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.RectangleGraphics.ConstructorOptions

[engine/Source/DataSources/RectangleGraphics.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/RectangleGraphics.js#L8) 

 Initialization options for the RectangleGraphics constructor

##### Properties:

| Name                     | Type                                                                                 | Attributes | Default                          | Description                                                                                                                                                             |
| ------------------------ | ------------------------------------------------------------------------------------ | ---------- | -------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| show                     | [Property](Property.html)\|boolean                                                   | <optional> | true                             | A boolean Property specifying the visibility of the rectangle.                                                                                                          |
| coordinates              | [Property](Property.html)\|[Rectangle](Rectangle.html)                               | <optional> |                                  | The Property specifying the [Rectangle](Rectangle.html).                                                                                                                |
| height                   | [Property](Property.html)\|number                                                    | <optional> | 0                                | A numeric Property specifying the altitude of the rectangle relative to the ellipsoid surface.                                                                          |
| heightReference          | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE             | A Property specifying what the height is relative to.                                                                                                                   |
| extrudedHeight           | [Property](Property.html)\|number                                                    | <optional> |                                  | A numeric Property specifying the altitude of the rectangle's extruded face relative to the ellipsoid surface.                                                          |
| extrudedHeightReference  | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE             | A Property specifying what the extrudedHeight is relative to.                                                                                                           |
| rotation                 | [Property](Property.html)\|number                                                    | <optional> | 0.0                              | A numeric property specifying the rotation of the rectangle clockwise from north.                                                                                       |
| stRotation               | [Property](Property.html)\|number                                                    | <optional> | 0.0                              | A numeric property specifying the rotation of the rectangle texture counter-clockwise from north.                                                                       |
| granularity              | [Property](Property.html)\|number                                                    | <optional> | Cesium.Math.RADIANS\_PER\_DEGREE | A numeric Property specifying the angular distance between points on the rectangle.                                                                                     |
| fill                     | [Property](Property.html)\|boolean                                                   | <optional> | true                             | A boolean Property specifying whether the rectangle is filled with the provided material.                                                                               |
| material                 | [MaterialProperty](MaterialProperty.html)\|[Color](Color.html)                       | <optional> | Color.WHITE                      | A Property specifying the material used to fill the rectangle.                                                                                                          |
| outline                  | [Property](Property.html)\|boolean                                                   | <optional> | false                            | A boolean Property specifying whether the rectangle is outlined.                                                                                                        |
| outlineColor             | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.BLACK                      | A Property specifying the [Color](Color.html) of the outline.                                                                                                           |
| outlineWidth             | [Property](Property.html)\|number                                                    | <optional> | 1.0                              | A numeric Property specifying the width of the outline.                                                                                                                 |
| shadows                  | [Property](Property.html)\|[ShadowMode](global.html#ShadowMode)                      | <optional> | ShadowMode.DISABLED              | An enum Property specifying whether the rectangle casts or receives shadows from light sources.                                                                         |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                                  | A Property specifying at what distance from the camera that this rectangle will be displayed.                                                                           |
| classificationType       | [Property](Property.html)\|[ClassificationType](global.html#ClassificationType)      | <optional> | ClassificationType.BOTH          | An enum Property specifying whether this rectangle will classify terrain, 3D Tiles, or both when on the ground.                                                         |
| zIndex                   | [Property](Property.html)\|number                                                    | <optional> | 0                                | A Property specifying the zIndex used for ordering ground geometry. Only has an effect if the rectangle is constant and neither height or extrudedHeight are specified. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

