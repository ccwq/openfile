# [![](Images/CesiumLogo.png)](index.html) BoundingSphere 

#### [](#BoundingSphere) new Cesium.BoundingSphere(center, radius) 

[engine/Source/Core/BoundingSphere.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L27) 

 A bounding sphere with a center and a radius.

| Name   | Type                          | Default         | Description                                 |
| ------ | ----------------------------- | --------------- | ------------------------------------------- |
| center | [Cartesian3](Cartesian3.html) | Cartesian3.ZERO | optional The center of the bounding sphere. |
| radius | number                        | 0.0             | optional The radius of the bounding sphere. |

##### See:

* [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html)
* [BoundingRectangle](BoundingRectangle.html)
* [Packable](Packable.html)

### Members

#### [](#.packedLength) static Cesium.BoundingSphere.packedLength : number 

[engine/Source/Core/BoundingSphere.js 942](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L942) 

 The number of elements used to pack the object into an array.

#### [](#center) center : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/BoundingSphere.js 33](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L33) 

 The center point of the sphere.

Default Value: `[Cartesian3.ZERO](Cartesian3.html#.ZERO)` 

#### [](#radius) radius : number 

[engine/Source/Core/BoundingSphere.js 40](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L40) 

 The radius of the sphere.

Default Value: `0.0` 

### Methods

#### [](#.clone) static Cesium.BoundingSphere.clone(sphere, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 924](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L924) 

 Duplicates a BoundingSphere instance.

| Name   | Type                                  | Description                                         |
| ------ | ------------------------------------- | --------------------------------------------------- |
| sphere | [BoundingSphere](BoundingSphere.html) | The bounding sphere to duplicate.                   |
| result | [BoundingSphere](BoundingSphere.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided. (Returns undefined if sphere is undefined)

#### [](#.computePlaneDistances) static Cesium.BoundingSphere.computePlaneDistances(sphere, position, direction, result) → [Interval](Interval.html) 

[engine/Source/Core/BoundingSphere.js 1228](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1228) 

 The distances calculated by the vector from the center of the bounding sphere to position projected onto direction plus/minus the radius of the bounding sphere.  
If you imagine the infinite number of planes with normal direction, this computes the smallest distance to the closest and farthest planes from position that intersect the bounding sphere.

| Name      | Type                                  | Description                                                      |
| --------- | ------------------------------------- | ---------------------------------------------------------------- |
| sphere    | [BoundingSphere](BoundingSphere.html) | The bounding sphere to calculate the distance to.                |
| position  | [Cartesian3](Cartesian3.html)         | The position to calculate the distance from.                     |
| direction | [Cartesian3](Cartesian3.html)         | The direction from position.                                     |
| result    | [Interval](Interval.html)             | optional A Interval to store the nearest and farthest distances. |

##### Returns:

 The nearest and farthest distances on the bounding sphere from position in direction.

#### [](#.distanceSquaredTo) static Cesium.BoundingSphere.distanceSquaredTo(sphere, cartesian) → number 

[engine/Source/Core/BoundingSphere.js 1159](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1159) 

 Computes the estimated distance squared from the closest point on a bounding sphere to a point.

| Name      | Type                                  | Description |
| --------- | ------------------------------------- | ----------- |
| sphere    | [BoundingSphere](BoundingSphere.html) | The sphere. |
| cartesian | [Cartesian3](Cartesian3.html)         | The point   |

##### Returns:

 The distance squared from the bounding sphere to the point. Returns 0 if the point is inside the sphere.

##### Example:

```javascript
// Sort bounding spheres from back to front
spheres.sort(function(a, b) {
    return Cesium.BoundingSphere.distanceSquaredTo(b, camera.positionWC) - Cesium.BoundingSphere.distanceSquaredTo(a, camera.positionWC);
});
```

#### [](#.equals) static Cesium.BoundingSphere.equals(left, right) → boolean 

[engine/Source/Core/BoundingSphere.js 1404](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1404) 

 Compares the provided BoundingSphere componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                  | Description                         |
| ----- | ------------------------------------- | ----------------------------------- |
| left  | [BoundingSphere](BoundingSphere.html) | optional The first BoundingSphere.  |
| right | [BoundingSphere](BoundingSphere.html) | optional The second BoundingSphere. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.expand) static Cesium.BoundingSphere.expand(sphere, point, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 1067](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1067) 

 Computes a bounding sphere by enlarging the provided sphere to contain the provided point.

| Name   | Type                                  | Description                                         |
| ------ | ------------------------------------- | --------------------------------------------------- |
| sphere | [BoundingSphere](BoundingSphere.html) | A sphere to expand.                                 |
| point  | [Cartesian3](Cartesian3.html)         | A point to enclose in a bounding sphere.            |
| result | [BoundingSphere](BoundingSphere.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

#### [](#.fromBoundingSpheres) static Cesium.BoundingSphere.fromBoundingSpheres(boundingSpheres, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 803](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L803) 

 Computes a tight-fitting bounding sphere enclosing the provided array of bounding spheres.

| Name            | Type                                           | Description                                         |
| --------------- | ---------------------------------------------- | --------------------------------------------------- |
| boundingSpheres | Array.<[BoundingSphere](BoundingSphere.html)\> | optional The array of bounding spheres.             |
| result          | [BoundingSphere](BoundingSphere.html)          | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

#### [](#.fromCornerPoints) static Cesium.BoundingSphere.fromCornerPoints(corner, oppositeCorner, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 755](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L755) 

 Computes a bounding sphere from the corner points of an axis-aligned bounding box. The sphere tightly and fully encompasses the box.

| Name           | Type                                  | Description                                         |
| -------------- | ------------------------------------- | --------------------------------------------------- |
| corner         | [Cartesian3](Cartesian3.html)         | optional The minimum height over the rectangle.     |
| oppositeCorner | [Cartesian3](Cartesian3.html)         | optional The maximum height over the rectangle.     |
| result         | [BoundingSphere](BoundingSphere.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

##### Example:

```javascript
// Create a bounding sphere around the unit cube
const sphere = Cesium.BoundingSphere.fromCornerPoints(new Cesium.Cartesian3(-0.5, -0.5, -0.5), new Cesium.Cartesian3(0.5, 0.5, 0.5));
```

#### [](#.fromEllipsoid) static Cesium.BoundingSphere.fromEllipsoid(ellipsoid, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 780](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L780) 

 Creates a bounding sphere encompassing an ellipsoid.

| Name      | Type                                  | Description                                             |
| --------- | ------------------------------------- | ------------------------------------------------------- |
| ellipsoid | [Ellipsoid](Ellipsoid.html)           | The ellipsoid around which to create a bounding sphere. |
| result    | [BoundingSphere](BoundingSphere.html) | optional The object onto which to store the result.     |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

##### Example:

```javascript
const boundingSphere = Cesium.BoundingSphere.fromEllipsoid(ellipsoid);
```

#### [](#.fromEncodedCartesianVertices) static Cesium.BoundingSphere.fromEncodedCartesianVertices(positionsHigh, positionsLow, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 568](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L568) 

 Computes a tight-fitting bounding sphere enclosing a list of EncodedCartesian3s, where the points are stored in parallel flat arrays in X, Y, Z, order. The bounding sphere is computed by running two algorithms, a naive algorithm and Ritter's algorithm. The smaller of the two spheres is used to ensure a tight fit.

| Name          | Type                                  | Description                                                                                                                                                                 |
| ------------- | ------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| positionsHigh | Array.<number>                        | optional An array of high bits of the encoded cartesians that the bounding sphere will enclose. Each point is formed from three elements in the array in the order X, Y, Z. |
| positionsLow  | Array.<number>                        | optional An array of low bits of the encoded cartesians that the bounding sphere will enclose. Each point is formed from three elements in the array in the order X, Y, Z.  |
| result        | [BoundingSphere](BoundingSphere.html) | optional The object onto which to store the result.                                                                                                                         |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if one was not provided.

##### See:

* [Bounding Sphere computation article](http://blogs.agi.com/insight3d/index.php/2008/02/04/a-bounding/)

#### [](#.fromOrientedBoundingBox) static Cesium.BoundingSphere.fromOrientedBoundingBox(orientedBoundingBox, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 857](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L857) 

 Computes a tight-fitting bounding sphere enclosing the provided oriented bounding box.

| Name                | Type                                            | Description                                         |
| ------------------- | ----------------------------------------------- | --------------------------------------------------- |
| orientedBoundingBox | [OrientedBoundingBox](OrientedBoundingBox.html) | The oriented bounding box.                          |
| result              | [BoundingSphere](BoundingSphere.html)           | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

#### [](#.fromPoints) static Cesium.BoundingSphere.fromPoints(positions, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 68](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L68) 

 Computes a tight-fitting bounding sphere enclosing a list of 3D Cartesian points. The bounding sphere is computed by running two algorithms, a naive algorithm and Ritter's algorithm. The smaller of the two spheres is used to ensure a tight fit.

| Name      | Type                                   | Description                                                                                                     |
| --------- | -------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| positions | Array.<[Cartesian3](Cartesian3.html)\> | optional An array of points that the bounding sphere will enclose. Each point must have x, y, and z properties. |
| result    | [BoundingSphere](BoundingSphere.html)  | optional The object onto which to store the result.                                                             |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if one was not provided.

##### See:

* [Bounding Sphere computation article](http://help.agi.com/AGIComponents/html/BlogBoundingSphere.htm)

#### [](#.fromRectangle2D) static Cesium.BoundingSphere.fromRectangle2D(rectangle, projection, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 240](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L240) 

 Computes a bounding sphere from a rectangle projected in 2D.

| Name       | Type                                  | Default              | Description                                                      |
| ---------- | ------------------------------------- | -------------------- | ---------------------------------------------------------------- |
| rectangle  | [Rectangle](Rectangle.html)           |                      | optional The rectangle around which to create a bounding sphere. |
| projection | object                                | GeographicProjection | optional The projection used to project the rectangle into 2D.   |
| result     | [BoundingSphere](BoundingSphere.html) |                      | optional The object onto which to store the result.              |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

#### [](#.fromRectangle3D) static Cesium.BoundingSphere.fromRectangle3D(rectangle, ellipsoid, surfaceHeight, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 320](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L320) 

 Computes a bounding sphere from a rectangle in 3D. The bounding sphere is created using a subsample of points on the ellipsoid and contained in the rectangle. It may not be accurate for all rectangles on all types of ellipsoids.

| Name          | Type                                  | Default           | Description                                                          |
| ------------- | ------------------------------------- | ----------------- | -------------------------------------------------------------------- |
| rectangle     | [Rectangle](Rectangle.html)           |                   | optional The valid rectangle used to create a bounding sphere.       |
| ellipsoid     | [Ellipsoid](Ellipsoid.html)           | Ellipsoid.default | optional The ellipsoid used to determine positions of the rectangle. |
| surfaceHeight | number                                | 0.0               | optional The height above the surface of the ellipsoid.              |
| result        | [BoundingSphere](BoundingSphere.html) |                   | optional The object onto which to store the result.                  |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

#### [](#.fromRectangleWithHeights2D) static Cesium.BoundingSphere.fromRectangleWithHeights2D(rectangle, projection, minimumHeight, maximumHeight, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L261) 

 Computes a bounding sphere from a rectangle projected in 2D. The bounding sphere accounts for the object's minimum and maximum heights over the rectangle.

| Name          | Type                                  | Default              | Description                                                      |
| ------------- | ------------------------------------- | -------------------- | ---------------------------------------------------------------- |
| rectangle     | [Rectangle](Rectangle.html)           |                      | optional The rectangle around which to create a bounding sphere. |
| projection    | object                                | GeographicProjection | optional The projection used to project the rectangle into 2D.   |
| minimumHeight | number                                | 0.0                  | optional The minimum height over the rectangle.                  |
| maximumHeight | number                                | 0.0                  | optional The maximum height over the rectangle.                  |
| result        | [BoundingSphere](BoundingSphere.html) |                      | optional The object onto which to store the result.              |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

#### [](#.fromTransformation) static Cesium.BoundingSphere.fromTransformation(transformation, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 893](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L893) 

 Computes a tight-fitting bounding sphere enclosing the provided affine transformation.

| Name           | Type                                  | Description                                         |
| -------------- | ------------------------------------- | --------------------------------------------------- |
| transformation | [Matrix4](Matrix4.html)               | The affine transformation.                          |
| result         | [BoundingSphere](BoundingSphere.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

#### [](#.fromVertices) static Cesium.BoundingSphere.fromVertices(positions, center, stride, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 380](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L380) 

 Computes a tight-fitting bounding sphere enclosing a list of 3D points, where the points are stored in a flat array in X, Y, Z, order. The bounding sphere is computed by running two algorithms, a naive algorithm and Ritter's algorithm. The smaller of the two spheres is used to ensure a tight fit.

| Name      | Type                                  | Default         | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| --------- | ------------------------------------- | --------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| positions | Array.<number>                        |                 | optional An array of points that the bounding sphere will enclose. Each point is formed from three elements in the array in the order X, Y, Z.                                                                                                                                                                                                                                                                                                                                           |
| center    | [Cartesian3](Cartesian3.html)         | Cartesian3.ZERO | optional The position to which the positions are relative, which need not be the origin of the coordinate system. This is useful when the positions are to be used for relative-to-center (RTC) rendering.                                                                                                                                                                                                                                                                               |
| stride    | number                                | 3               | optional The number of array elements per vertex. It must be at least 3, but it may be higher. Regardless of the value of this parameter, the X coordinate of the first position is at array index 0, the Y coordinate is at array index 1, and the Z coordinate is at array index 2\. When stride is 3, the X coordinate of the next position then begins at array index 3\. If the stride is 5, however, two array elements are skipped and the next position begins at array index 5. |
| result    | [BoundingSphere](BoundingSphere.html) |                 | optional The object onto which to store the result.                                                                                                                                                                                                                                                                                                                                                                                                                                      |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if one was not provided.

##### Example:

```javascript
// Compute the bounding sphere from 3 positions, each specified relative to a center.
// In addition to the X, Y, and Z coordinates, the points array contains two additional
// elements per point which are ignored for the purpose of computing the bounding sphere.
const center = new Cesium.Cartesian3(1.0, 2.0, 3.0);
const points = [1.0, 2.0, 3.0, 0.1, 0.2,
              4.0, 5.0, 6.0, 0.1, 0.2,
              7.0, 8.0, 9.0, 0.1, 0.2];
const sphere = Cesium.BoundingSphere.fromVertices(points, center, 5);
```

##### See:

* [Bounding Sphere computation article](http://blogs.agi.com/insight3d/index.php/2008/02/04/a-bounding/)

#### [](#.intersectPlane) static Cesium.BoundingSphere.intersectPlane(sphere, plane) → [Intersect](global.html#Intersect) 

[engine/Source/Core/BoundingSphere.js 1095](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1095) 

 Determines which side of a plane a sphere is located.

| Name   | Type                                  | Description                  |
| ------ | ------------------------------------- | ---------------------------- |
| sphere | [BoundingSphere](BoundingSphere.html) | The bounding sphere to test. |
| plane  | [Plane](Plane.html)                   | The plane to test against.   |

##### Returns:

[Intersect.INSIDE](global.html#Intersect#.INSIDE) if the entire sphere is on the side of the plane the normal is pointing, [Intersect.OUTSIDE](global.html#Intersect#.OUTSIDE) if the entire sphere is on the opposite side, and [Intersect.INTERSECTING](global.html#Intersect#.INTERSECTING) if the sphere intersects the plane.

#### [](#.isOccluded) static Cesium.BoundingSphere.isOccluded(sphere, occluder) → boolean 

[engine/Source/Core/BoundingSphere.js 1388](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1388) 

 Determines whether or not a sphere is hidden from view by the occluder.

| Name     | Type                                  | Description                                          |
| -------- | ------------------------------------- | ---------------------------------------------------- |
| sphere   | [BoundingSphere](BoundingSphere.html) | The bounding sphere surrounding the occluded object. |
| occluder | [Occluder](Occluder.html)             | The occluder.                                        |

##### Returns:

`true` if the sphere is not visible; otherwise `false`.

#### [](#.pack) static Cesium.BoundingSphere.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/BoundingSphere.js 953](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L953) 

 Stores the provided instance into the provided array.

| Name          | Type                                  | Default | Description                                                               |
| ------------- | ------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [BoundingSphere](BoundingSphere.html) |         | The value to pack.                                                        |
| array         | Array.<number>                        |         | The array to pack into.                                                   |
| startingIndex | number                                | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.projectTo2D) static Cesium.BoundingSphere.projectTo2D(sphere, projection, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 1276](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1276) 

 Creates a bounding sphere in 2D from a bounding sphere in 3D world coordinates.

| Name       | Type                                  | Default              | Description                                         |
| ---------- | ------------------------------------- | -------------------- | --------------------------------------------------- |
| sphere     | [BoundingSphere](BoundingSphere.html) |                      | The bounding sphere to transform to 2D.             |
| projection | object                                | GeographicProjection | optional The projection to 2D.                      |
| result     | [BoundingSphere](BoundingSphere.html) |                      | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

#### [](#.transform) static Cesium.BoundingSphere.transform(sphere, transform, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 1124](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1124) 

 Applies a 4x4 affine transformation matrix to a bounding sphere.

| Name      | Type                                  | Description                                                |
| --------- | ------------------------------------- | ---------------------------------------------------------- |
| sphere    | [BoundingSphere](BoundingSphere.html) | The bounding sphere to apply the transformation to.        |
| transform | [Matrix4](Matrix4.html)               | The transformation matrix to apply to the bounding sphere. |
| result    | [BoundingSphere](BoundingSphere.html) | optional The object onto which to store the result.        |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

#### [](#.transformWithoutScale) static Cesium.BoundingSphere.transformWithoutScale(sphere, transform, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 1194](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1194) 

 Applies a 4x4 affine transformation matrix to a bounding sphere where there is no scale The transformation matrix is not verified to have a uniform scale of 1\. This method is faster than computing the general bounding sphere transform using [BoundingSphere.transform](BoundingSphere.html#.transform).

| Name      | Type                                  | Description                                                |
| --------- | ------------------------------------- | ---------------------------------------------------------- |
| sphere    | [BoundingSphere](BoundingSphere.html) | The bounding sphere to apply the transformation to.        |
| transform | [Matrix4](Matrix4.html)               | The transformation matrix to apply to the bounding sphere. |
| result    | [BoundingSphere](BoundingSphere.html) | optional The object onto which to store the result.        |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

##### Example:

```javascript
const modelMatrix = Cesium.Transforms.eastNorthUpToFixedFrame(positionOnEllipsoid);
const boundingSphere = new Cesium.BoundingSphere();
const newBoundingSphere = Cesium.BoundingSphere.transformWithoutScale(boundingSphere, modelMatrix);
```

#### [](#.union) static Cesium.BoundingSphere.union(left, right, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 1007](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1007) 

 Computes a bounding sphere that contains both the left and right bounding spheres.

| Name   | Type                                  | Description                                         |
| ------ | ------------------------------------- | --------------------------------------------------- |
| left   | [BoundingSphere](BoundingSphere.html) | A sphere to enclose in a bounding sphere.           |
| right  | [BoundingSphere](BoundingSphere.html) | A sphere to enclose in a bounding sphere.           |
| result | [BoundingSphere](BoundingSphere.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

#### [](#.unpack) static Cesium.BoundingSphere.unpack(array, startingIndex, result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 978](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L978) 

 Retrieves an instance from a packed array.

| Name          | Type                                  | Default | Description                                                |
| ------------- | ------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                        |         | The packed array.                                          |
| startingIndex | number                                | 0       | optional The starting index of the element to be unpacked. |
| result        | [BoundingSphere](BoundingSphere.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if one was not provided.

#### [](#clone) clone(result) → [BoundingSphere](BoundingSphere.html) 

[engine/Source/Core/BoundingSphere.js 1495](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1495) 

 Duplicates this BoundingSphere instance.

| Name   | Type                                  | Description                                         |
| ------ | ------------------------------------- | --------------------------------------------------- |
| result | [BoundingSphere](BoundingSphere.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new BoundingSphere instance if none was provided.

#### [](#computePlaneDistances) computePlaneDistances(position, direction, result) → [Interval](Interval.html) 

[engine/Source/Core/BoundingSphere.js 1455](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1455) 

 The distances calculated by the vector from the center of the bounding sphere to position projected onto direction plus/minus the radius of the bounding sphere.  
If you imagine the infinite number of planes with normal direction, this computes the smallest distance to the closest and farthest planes from position that intersect the bounding sphere.

| Name      | Type                          | Description                                                      |
| --------- | ----------------------------- | ---------------------------------------------------------------- |
| position  | [Cartesian3](Cartesian3.html) | The position to calculate the distance from.                     |
| direction | [Cartesian3](Cartesian3.html) | The direction from position.                                     |
| result    | [Interval](Interval.html)     | optional A Interval to store the nearest and farthest distances. |

##### Returns:

 The nearest and farthest distances on the bounding sphere from position in direction.

#### [](#distanceSquaredTo) distanceSquaredTo(cartesian) → number 

[engine/Source/Core/BoundingSphere.js 1439](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1439) 

 Computes the estimated distance squared from the closest point on a bounding sphere to a point.

| Name      | Type                          | Description |
| --------- | ----------------------------- | ----------- |
| cartesian | [Cartesian3](Cartesian3.html) | The point   |

##### Returns:

 The estimated distance squared from the bounding sphere to the point.

##### Example:

```javascript
// Sort bounding spheres from back to front
spheres.sort(function(a, b) {
    return b.distanceSquaredTo(camera.positionWC) - a.distanceSquaredTo(camera.positionWC);
});
```

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/BoundingSphere.js 1485](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1485) 

 Compares this BoundingSphere against the provided BoundingSphere componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                  | Description                                  |
| ----- | ------------------------------------- | -------------------------------------------- |
| right | [BoundingSphere](BoundingSphere.html) | optional The right hand side BoundingSphere. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#intersectPlane) intersectPlane(plane) → [Intersect](global.html#Intersect) 

[engine/Source/Core/BoundingSphere.js 1423](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1423) 

 Determines which side of a plane the sphere is located.

| Name  | Type                | Description                |
| ----- | ------------------- | -------------------------- |
| plane | [Plane](Plane.html) | The plane to test against. |

##### Returns:

[Intersect.INSIDE](global.html#Intersect#.INSIDE) if the entire sphere is on the side of the plane the normal is pointing, [Intersect.OUTSIDE](global.html#Intersect#.OUTSIDE) if the entire sphere is on the opposite side, and [Intersect.INTERSECTING](global.html#Intersect#.INTERSECTING) if the sphere intersects the plane.

#### [](#isOccluded) isOccluded(occluder) → boolean 

[engine/Source/Core/BoundingSphere.js 1474](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1474) 

 Determines whether or not a sphere is hidden from view by the occluder.

| Name     | Type                      | Description   |
| -------- | ------------------------- | ------------- |
| occluder | [Occluder](Occluder.html) | The occluder. |

##### Returns:

`true` if the sphere is not visible; otherwise `false`.

#### [](#volume) volume() → number 

[engine/Source/Core/BoundingSphere.js 1503](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoundingSphere.js#L1503) 

 Computes the radius of the BoundingSphere.

##### Returns:

 The radius of the BoundingSphere.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

