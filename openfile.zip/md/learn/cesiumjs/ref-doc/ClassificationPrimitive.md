# [![](Images/CesiumLogo.png)](index.html) ClassificationPrimitive 

#### [](#ClassificationPrimitive) new Cesium.ClassificationPrimitive(options) 

[engine/Source/Scene/ClassificationPrimitive.js 72](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L72) 

 A classification primitive represents a volume enclosing geometry in the [Scene](Scene.html) to be highlighted.

A primitive combines geometry instances with an [Appearance](Appearance.html) that describes the full shading, including[Material](Material.html) and `RenderState`. Roughly, the geometry instance defines the structure and placement, and the appearance defines the visual characteristics. Decoupling geometry and appearance allows us to mix and match most of them and add a new geometry or appearance independently of each other. Only [PerInstanceColorAppearance](PerInstanceColorAppearance.html) with the same color across all instances is supported at this time when using ClassificationPrimitive directly. For full [Appearance](Appearance.html) support when classifying terrain or 3D Tiles use [GroundPrimitive](GroundPrimitive.html) instead.

For correct rendering, this feature requires the EXT\_frag\_depth WebGL extension. For hardware that do not support this extension, there will be rendering artifacts for some viewing angles.

Valid geometries are [BoxGeometry](BoxGeometry.html), [CylinderGeometry](CylinderGeometry.html), [EllipsoidGeometry](EllipsoidGeometry.html), [PolylineVolumeGeometry](PolylineVolumeGeometry.html), and [SphereGeometry](SphereGeometry.html).

Geometries that follow the surface of the ellipsoid, such as [CircleGeometry](CircleGeometry.html), [CorridorGeometry](CorridorGeometry.html), [EllipseGeometry](EllipseGeometry.html), [PolygonGeometry](PolygonGeometry.html), and [RectangleGeometry](RectangleGeometry.html), are also valid if they are extruded volumes; otherwise, they will not be rendered.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description geometryInstances Array\|[GeometryInstance](GeometryInstance.html) optional The geometry instances to render. This can either be a single instance or an array of length one. appearance [Appearance](Appearance.html) optional The appearance used to render the primitive. Defaults to PerInstanceColorAppearance when GeometryInstances have a color attribute. show boolean true optional Determines if this primitive will be shown. vertexCacheOptimize boolean false optional When true, geometry vertices are optimized for the pre and post-vertex-shader caches. interleave boolean false optional When true, geometry vertex attributes are interleaved, which can slightly improve rendering performance but increases load time. compressVertices boolean true optional When true, the geometry vertices are compressed, which will save memory. releaseGeometryInstances boolean true optional When true, the primitive does not keep a reference to the input geometryInstances to save memory. allowPicking boolean true optional When true, each geometry instance will only be pickable with [Scene#pick](Scene.html#pick). When false, GPU memory is saved. asynchronous boolean true optional Determines if the primitive will be created asynchronously or block until ready. If false initializeTerrainHeights() must be called first. classificationType [ClassificationType](global.html#ClassificationType) ClassificationType.BOTH optional Determines whether terrain, 3D Tiles or both will be classified. debugShowBoundingVolume boolean false optional For debugging only. Determines if this primitive's commands' bounding spheres are shown. debugShowShadowVolume boolean false optional For debugging only. Determines if the shadow volume for each geometry in the primitive is drawn. Must be true on creation for the volumes to be created before the geometry is released or options.releaseGeometryInstance must be false. |

##### See:

* [Primitive](Primitive.html)
* [GroundPrimitive](GroundPrimitive.html)
* [GeometryInstance](GeometryInstance.html)
* [Appearance](Appearance.html)

### Members

#### [](#allowPicking) readonly allowPicking : boolean 

[engine/Source/Scene/ClassificationPrimitive.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L261) 

 When `true`, each geometry instance will only be pickable with [Scene#pick](Scene.html#pick). When `false`, GPU memory is saved.

Default Value: `true` 

#### [](#asynchronous) readonly asynchronous : boolean 

[engine/Source/Scene/ClassificationPrimitive.js 277](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L277) 

 Determines if the geometry instances will be created and batched on a web worker.

Default Value: `true` 

#### [](#classificationType) classificationType : [ClassificationType](global.html#ClassificationType) 

[engine/Source/Scene/ClassificationPrimitive.js 111](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L111) 

 Determines whether terrain, 3D Tiles or both will be classified.

Default Value: `ClassificationType.BOTH` 

#### [](#compressVertices) readonly compressVertices : boolean 

[engine/Source/Scene/ClassificationPrimitive.js 293](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L293) 

 When `true`, geometry vertices are compressed, which will save memory.

Default Value: `true` 

#### [](#debugShowBoundingVolume) debugShowBoundingVolume : boolean 

[engine/Source/Scene/ClassificationPrimitive.js 125](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L125) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the bounding sphere for each draw command in the primitive.

Default Value: `false` 

#### [](#debugShowShadowVolume) debugShowShadowVolume : boolean 

[engine/Source/Scene/ClassificationPrimitive.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L139) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the shadow volume for each geometry in the primitive.

Default Value: `false` 

#### [](#geometryInstances) readonly geometryInstances : Array|[GeometryInstance](GeometryInstance.html) 

[engine/Source/Scene/ClassificationPrimitive.js 94](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L94) 

 The geometry instance rendered with this primitive. This may be `undefined` if `options.releaseGeometryInstances`is `true` when the primitive is constructed.

Changing this property after the primitive is rendered has no effect.

Because of the rendering technique used, all geometry instances must be the same color. If there is an instance with a differing color, a `DeveloperError` will be thrown on the first attempt to render.

Default Value: `undefined` 

#### [](#interleave) readonly interleave : boolean 

[engine/Source/Scene/ClassificationPrimitive.js 229](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L229) 

 Determines if geometry vertex attributes are interleaved, which can slightly improve rendering performance.

Default Value: `false` 

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/ClassificationPrimitive.js 309](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L309) 

 Determines if the primitive is complete and ready to render. If this property is true, the primitive will be rendered the next time that [ClassificationPrimitive#update](ClassificationPrimitive.html#update)is called.

#### [](#releaseGeometryInstances) readonly releaseGeometryInstances : boolean 

[engine/Source/Scene/ClassificationPrimitive.js 245](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L245) 

 When `true`, the primitive does not keep a reference to the input `geometryInstances` to save memory.

Default Value: `true` 

#### [](#show) show : boolean 

[engine/Source/Scene/ClassificationPrimitive.js 103](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L103) 

 Determines if the primitive will be shown. This affects all geometry instances in the primitive.

Default Value: `true` 

#### [](#vertexCacheOptimize) readonly vertexCacheOptimize : boolean 

[engine/Source/Scene/ClassificationPrimitive.js 213](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L213) 

 When `true`, geometry vertices are optimized for the pre and post-vertex-shader caches.

Default Value: `true` 

### Methods

#### [](#.isSupported) static Cesium.ClassificationPrimitive.isSupported(scene) → boolean 

[engine/Source/Scene/ClassificationPrimitive.js 339](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L339) 

 Determines if ClassificationPrimitive rendering is supported.

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| scene | [Scene](Scene.html) | The scene.  |

##### Returns:

`true` if ClassificationPrimitives are supported; otherwise, returns `false` 

#### [](#destroy) destroy() 

[engine/Source/Scene/ClassificationPrimitive.js 1387](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L1387) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.

Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
e = e && e.destroy();
```

##### See:

* [ClassificationPrimitive#isDestroyed](ClassificationPrimitive.html#isDestroyed)

#### [](#getGeometryInstanceAttributes) getGeometryInstanceAttributes(id) → object 

[engine/Source/Scene/ClassificationPrimitive.js 1343](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L1343) 

 Returns the modifiable per-instance attributes for a [GeometryInstance](GeometryInstance.html).

| Name | Type | Description                                              |
| ---- | ---- | -------------------------------------------------------- |
| id   | \*   | The id of the [GeometryInstance](GeometryInstance.html). |

##### Returns:

 The typed array in the attribute's format or undefined if the is no instance with id.

##### Throws:

* [DeveloperError](DeveloperError.html): must call update before calling getGeometryInstanceAttributes.

##### Example:

```javascript
const attributes = primitive.getGeometryInstanceAttributes('an id');
attributes.color = Cesium.ColorGeometryInstanceAttribute.toValue(Cesium.Color.AQUA);
attributes.show = Cesium.ShowGeometryInstanceAttribute.toValue(true);
```

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/ClassificationPrimitive.js 1367](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L1367) 

 Returns true if this object was destroyed; otherwise, false.

If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [ClassificationPrimitive#destroy](ClassificationPrimitive.html#destroy)

#### [](#update) update() 

[engine/Source/Scene/ClassificationPrimitive.js 1051](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ClassificationPrimitive.js#L1051) 

 Called when [Viewer](Viewer.html) or [CesiumWidget](CesiumWidget.html) render the scene to get the draw commands needed to render this primitive.

Do not call this function directly. This is documented just to list the exceptions that may be propagated when the scene is rendered:

##### Throws:

* [DeveloperError](DeveloperError.html): All instance geometries must have the same primitiveType.
* [DeveloperError](DeveloperError.html): Appearance and material have a uniform with the same name.
* [DeveloperError](DeveloperError.html): Not all of the geometry instances have the same color attribute.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

