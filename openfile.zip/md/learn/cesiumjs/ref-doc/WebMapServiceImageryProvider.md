# [![](Images/CesiumLogo.png)](index.html) WebMapServiceImageryProvider 

#### [](#WebMapServiceImageryProvider) new Cesium.WebMapServiceImageryProvider(options) 

[engine/Source/Scene/WebMapServiceImageryProvider.js 103](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L103) 

 Provides tiled imagery hosted by a Web Map Service (WMS) server.

| Name    | Type                                                                                                     | Description                              |
| ------- | -------------------------------------------------------------------------------------------------------- | ---------------------------------------- |
| options | [WebMapServiceImageryProvider.ConstructorOptions](WebMapServiceImageryProvider.html#.ConstructorOptions) | Object describing initialization options |

##### Example:

```javascript
const provider = new Cesium.WebMapServiceImageryProvider({
    url : 'https://sampleserver1.arcgisonline.com/ArcGIS/services/Specialty/ESRI_StatesCitiesRivers_USA/MapServer/WMSServer',
    layers : '0',
    proxy: new Cesium.DefaultProxy('/proxy/')
});
const imageryLayer = new Cesium.ImageryLayer(provider);
viewer.imageryLayers.add(imageryLayer);
```

##### See:

* [ArcGisMapServerImageryProvider](ArcGisMapServerImageryProvider.html)
* [BingMapsImageryProvider](BingMapsImageryProvider.html)
* [GoogleEarthEnterpriseMapsProvider](GoogleEarthEnterpriseMapsProvider.html)
* [OpenStreetMapImageryProvider](OpenStreetMapImageryProvider.html)
* [SingleTileImageryProvider](SingleTileImageryProvider.html)
* [TileMapServiceImageryProvider](TileMapServiceImageryProvider.html)
* [WebMapTileServiceImageryProvider](WebMapTileServiceImageryProvider.html)
* [UrlTemplateImageryProvider](UrlTemplateImageryProvider.html)
* [ArcGIS Server REST API](http://resources.esri.com/help/9.3/arcgisserver/apis/rest/)
* [Cross-Origin Resource Sharing](http://www.w3.org/TR/cors/)

### Members

#### [](#.DefaultParameters) static constant Cesium.WebMapServiceImageryProvider.DefaultParameters : object 

[engine/Source/Scene/WebMapServiceImageryProvider.js 617](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L617) 

 The default parameters to include in the WMS URL to obtain images. The values are as follows: service=WMS version=1.1.1 request=GetMap styles= format=image/jpeg

#### [](#.GetFeatureInfoDefaultParameters) static constant Cesium.WebMapServiceImageryProvider.GetFeatureInfoDefaultParameters : object 

[engine/Source/Scene/WebMapServiceImageryProvider.js 634](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L634) 

 The default parameters to include in the WMS URL to get feature information. The values are as follows: service=WMS version=1.1.1 request=GetFeatureInfo

#### [](#clock) clock : [Clock](Clock.html) 

[engine/Source/Scene/WebMapServiceImageryProvider.js 490](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L490) 

 Gets or sets a clock that is used to get keep the time used for time dynamic parameters.

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/WebMapServiceImageryProvider.js 444](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L444) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

#### [](#enablePickFeatures) enablePickFeatures : boolean 

[engine/Source/Scene/WebMapServiceImageryProvider.js 476](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L476) 

 Gets or sets a value indicating whether feature picking is enabled. If true, [WebMapServiceImageryProvider#pickFeatures](WebMapServiceImageryProvider.html#pickFeatures) will invoke the `GetFeatureInfo` service on the WMS server and attempt to interpret the features included in the response. If false,[WebMapServiceImageryProvider#pickFeatures](WebMapServiceImageryProvider.html#pickFeatures) will immediately return undefined (indicating no pickable features) without communicating with the server. Set this property to false if you know your data source does not support picking features or if you don't want this provider's features to be pickable.

Default Value: `true` 

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/WebMapServiceImageryProvider.js 431](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L431) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#getFeatureInfoUrl) readonly getFeatureInfoUrl : [Resource](Resource.html)|string 

[engine/Source/Scene/WebMapServiceImageryProvider.js 520](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L520) 

 Gets the getFeatureInfo URL of the WMS server.

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/WebMapServiceImageryProvider.js 460](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L460) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. When this property is false, memory usage and texture upload time are reduced.

#### [](#layers) readonly layers : string 

[engine/Source/Scene/WebMapServiceImageryProvider.js 331](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L331) 

 Gets the names of the WMS layers, separated by commas.

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/WebMapServiceImageryProvider.js 367](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L367) 

 Gets the maximum level-of-detail that can be requested.

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/WebMapServiceImageryProvider.js 379](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L379) 

 Gets the minimum level-of-detail that can be requested.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/WebMapServiceImageryProvider.js 319](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L319) 

 Gets the proxy used by this provider.

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/WebMapServiceImageryProvider.js 403](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L403) 

 Gets the rectangle, in radians, of the imagery provided by this instance.

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/WebMapServiceImageryProvider.js 417](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L417) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/WebMapServiceImageryProvider.js 355](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L355) 

 Gets the height of each tile, in pixels.

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/WebMapServiceImageryProvider.js 343](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L343) 

 Gets the width of each tile, in pixels.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/WebMapServiceImageryProvider.js 391](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L391) 

 Gets the tiling scheme used by this provider.

#### [](#times) times : [TimeIntervalCollection](TimeIntervalCollection.html) 

[engine/Source/Scene/WebMapServiceImageryProvider.js 505](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L505) 

 Gets or sets a time interval collection that is used to get time dynamic parameters. The data of each TimeInterval is an object containing the keys and values of the properties that are used during tile requests.

#### [](#url) readonly url : string 

[engine/Source/Scene/WebMapServiceImageryProvider.js 307](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L307) 

 Gets the URL of the WMS server.

### Methods

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/WebMapServiceImageryProvider.js 535](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L535) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → Promise.<Array.<[ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html)\>>|undefined 

[engine/Source/Scene/WebMapServiceImageryProvider.js 591](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L591) 

 Asynchronously determines what features, if any, are located at a given longitude and latitude within a tile.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 A promise for the picked features that will resolve when the asynchronous picking completes. The resolved value is an array of [ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html) instances. The array may be empty if no features are found at the given location.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<[ImageryTypes](global.html#ImageryTypes)\>|undefined 

[engine/Source/Scene/WebMapServiceImageryProvider.js 549](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L549) 

 Requests the image for a given tile.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the image that will resolve when the image is available, or undefined if there are too many active requests to the server, and the request should be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.WebMapServiceImageryProvider.ConstructorOptions

[engine/Source/Scene/WebMapServiceImageryProvider.js 34](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapServiceImageryProvider.js#L34) 

 Initialization options for the WebMapServiceImageryProvider constructor

##### Properties:

| Name                     | Type                                                       | Attributes | Default                                                      | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| ------------------------ | ---------------------------------------------------------- | ---------- | ------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| url                      | [Resource](Resource.html)\|string                          |            |                                                              | The URL of the WMS service. The URL supports the same keywords as the [UrlTemplateImageryProvider](UrlTemplateImageryProvider.html).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| layers                   | string                                                     |            |                                                              | The layers to include, separated by commas.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| parameters               | object                                                     | <optional> | WebMapServiceImageryProvider.DefaultParameters               | Additional parameters to pass to the WMS server in the GetMap URL.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| getFeatureInfoParameters | object                                                     | <optional> | WebMapServiceImageryProvider.GetFeatureInfoDefaultParameters | Additional parameters to pass to the WMS server in the GetFeatureInfo URL.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| enablePickFeatures       | boolean                                                    | <optional> | true                                                         | If true, [WebMapServiceImageryProvider#pickFeatures](WebMapServiceImageryProvider.html#pickFeatures) will invoke the GetFeatureInfo operation on the WMS server and return the features included in the response. If false,[WebMapServiceImageryProvider#pickFeatures](WebMapServiceImageryProvider.html#pickFeatures) will immediately return undefined (indicating no pickable features) without communicating with the server. Set this property to false if you know your WMS server does not support GetFeatureInfo or if you don't want this provider's features to be pickable. Note that this can be dynamically overridden by modifying the WebMapServiceImageryProvider#enablePickFeatures property. |
| getFeatureInfoFormats    | Array.<[GetFeatureInfoFormat](GetFeatureInfoFormat.html)\> | <optional> | WebMapServiceImageryProvider.DefaultGetFeatureInfoFormats    | The formats in which to try WMS GetFeatureInfo requests.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| rectangle                | [Rectangle](Rectangle.html)                                | <optional> | Rectangle.MAX\_VALUE                                         | The rectangle of the layer.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| tilingScheme             | [TilingScheme](TilingScheme.html)                          | <optional> | new GeographicTilingScheme()                                 | The tiling scheme to use to divide the world into tiles.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ellipsoid                | [Ellipsoid](Ellipsoid.html)                                | <optional> |                                                              | The ellipsoid. If the tilingScheme is specified, this parameter is ignored and the tiling scheme's ellipsoid is used instead. If neither parameter is specified, the WGS84 ellipsoid is used.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| tileWidth                | number                                                     | <optional> | 256                                                          | The width of each tile in pixels.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| tileHeight               | number                                                     | <optional> | 256                                                          | The height of each tile in pixels.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| minimumLevel             | number                                                     | <optional> | 0                                                            | The minimum level-of-detail supported by the imagery provider. Take care when specifying this that the number of tiles at the minimum level is small, such as four or less. A larger number is likely to result in rendering problems.                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| maximumLevel             | number                                                     | <optional> |                                                              | The maximum level-of-detail supported by the imagery provider, or undefined if there is no limit. If not specified, there is no limit.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| crs                      | string                                                     | <optional> |                                                              | CRS specification, for use with WMS specification >= 1.3.0.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| srs                      | string                                                     | <optional> |                                                              | SRS specification, for use with WMS specification 1.1.0 or 1.1.1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| credit                   | [Credit](Credit.html)\|string                              | <optional> |                                                              | A credit for the data source, which is displayed on the canvas.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| subdomains               | string\|Array.<string>                                     | <optional> | 'abc'                                                        | The subdomains to use for the {s} placeholder in the URL template. If this parameter is a single string, each character in the string is a subdomain. If it is an array, each element in the array is a subdomain.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| clock                    | [Clock](Clock.html)                                        | <optional> |                                                              | A Clock instance that is used when determining the value for the time dimension. Required when \`times\` is specified.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| times                    | [TimeIntervalCollection](TimeIntervalCollection.html)      | <optional> |                                                              | TimeIntervalCollection with its data property being an object containing time dynamic dimension and their values.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| getFeatureInfoUrl        | [Resource](Resource.html)\|string                          | <optional> |                                                              | The getFeatureInfo URL of the WMS service. If the property is not defined then we use the property value of url.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

