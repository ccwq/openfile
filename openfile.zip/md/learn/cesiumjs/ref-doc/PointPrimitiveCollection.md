# [![](Images/CesiumLogo.png)](index.html) PointPrimitiveCollection 

#### [](#PointPrimitiveCollection) new Cesium.PointPrimitiveCollection(options) 

[engine/Source/Scene/PointPrimitiveCollection.js 93](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L93) 

 A renderable collection of points.  
  
Points are added and removed from the collection using [PointPrimitiveCollection#add](PointPrimitiveCollection.html#add)and [PointPrimitiveCollection#remove](PointPrimitiveCollection.html#remove).

##### Performance:

For best performance, prefer a few collections, each with many points, to many collections with only a few points each. Organize collections so that points with the same update frequency are in the same collection, i.e., points that do not change should be in one collection; points that change every frame should be in another collection; and so on.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description modelMatrix [Matrix4](Matrix4.html) Matrix4.IDENTITY optional The 4x4 transformation matrix that transforms each point from model to world coordinates. debugShowBoundingVolume boolean false optional For debugging only. Determines if this primitive's commands' bounding spheres are shown. blendOption [BlendOption](global.html#BlendOption) BlendOption.OPAQUE\_AND\_TRANSLUCENT optional The point blending option. The default is used for rendering both opaque and translucent points. However, if either all of the points are completely opaque or all are completely translucent, setting the technique to BlendOption.OPAQUE or BlendOption.TRANSLUCENT can improve performance by up to 2x. show boolean true optional Determines if the primitives in the collection will be shown. |

##### Example:

```javascript
// Create a pointPrimitive collection with two points
const points = scene.primitives.add(new Cesium.PointPrimitiveCollection());
points.add({
  position : new Cesium.Cartesian3(1.0, 2.0, 3.0),
  color : Cesium.Color.YELLOW
});
points.add({
  position : new Cesium.Cartesian3(4.0, 5.0, 6.0),
  color : Cesium.Color.CYAN
});
```

##### See:

* [PointPrimitiveCollection#add](PointPrimitiveCollection.html#add)
* [PointPrimitiveCollection#remove](PointPrimitiveCollection.html#remove)
* [PointPrimitive](PointPrimitive.html)

### Members

#### [](#blendOption) blendOption : [BlendOption](global.html#BlendOption) 

[engine/Source/Scene/PointPrimitiveCollection.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L200) 

 The point blending option. The default is used for rendering both opaque and translucent points. However, if either all of the points are completely opaque or all are completely translucent, setting the technique to BlendOption.OPAQUE or BlendOption.TRANSLUCENT can improve performance by up to 2x.

Default Value: `BlendOption.OPAQUE_AND_TRANSLUCENT` 

#### [](#debugShowBoundingVolume) debugShowBoundingVolume : boolean 

[engine/Source/Scene/PointPrimitiveCollection.js 187](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L187) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the bounding sphere for each draw command in the primitive.

Default Value: `false` 

#### [](#length) length : number 

[engine/Source/Scene/PointPrimitiveCollection.js 238](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L238) 

 Returns the number of points in this collection. This is commonly used with[PointPrimitiveCollection#get](PointPrimitiveCollection.html#get) to iterate over all the points in the collection.

#### [](#modelMatrix) modelMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/PointPrimitiveCollection.js 172](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L172) 

 The 4x4 transformation matrix that transforms each point in this collection from model to world coordinates. When this is the identity matrix, the pointPrimitives are drawn in world coordinates, i.e., Earth's WGS84 coordinates. Local reference frames can be used by providing a different transformation matrix, like that returned by [Transforms.eastNorthUpToFixedFrame](Transforms.html#.eastNorthUpToFixedFrame).

Default Value: `[Matrix4.IDENTITY](Matrix4.html#.IDENTITY)` 

##### Example:

```javascript
const center = Cesium.Cartesian3.fromDegrees(-75.59777, 40.03883);
pointPrimitives.modelMatrix = Cesium.Transforms.eastNorthUpToFixedFrame(center);
pointPrimitives.add({
  color : Cesium.Color.ORANGE,
  position : new Cesium.Cartesian3(0.0, 0.0, 0.0) // center
});
pointPrimitives.add({
  color : Cesium.Color.YELLOW,
  position : new Cesium.Cartesian3(1000000.0, 0.0, 0.0) // east
});
pointPrimitives.add({
  color : Cesium.Color.GREEN,
  position : new Cesium.Cartesian3(0.0, 1000000.0, 0.0) // north
});
pointPrimitives.add({
  color : Cesium.Color.CYAN,
  position : new Cesium.Cartesian3(0.0, 0.0, 1000000.0) // up
});
```

##### See:

* [Transforms.eastNorthUpToFixedFrame](Transforms.html#.eastNorthUpToFixedFrame)

#### [](#show) show : boolean 

[engine/Source/Scene/PointPrimitiveCollection.js 138](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L138) 

 Determines if primitives in this collection will be shown.

Default Value: `true` 

### Methods

#### [](#add) add(options) → [PointPrimitive](PointPrimitive.html) 

[engine/Source/Scene/PointPrimitiveCollection.js 290](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L290) 

 Creates and adds a point with the specified initial properties to the collection. The added point is returned so it can be modified or removed from the collection later.

##### Performance:

Calling `add` is expected constant time. However, the collection's vertex buffer is rewritten - an `O(n)` operation that also incurs CPU to GPU overhead. For best performance, add as many pointPrimitives as possible before calling `update`.

| Name    | Type   | Description                                                                  |
| ------- | ------ | ---------------------------------------------------------------------------- |
| options | object | optional A template describing the point's properties as shown in Example 1. |

##### Returns:

 The point that was added to the collection.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Examples:

```javascript
// Example 1:  Add a point, specifying all the default values.
const p = pointPrimitives.add({
  show : true,
  position : Cesium.Cartesian3.ZERO,
  pixelSize : 10.0,
  color : Cesium.Color.WHITE,
  outlineColor : Cesium.Color.TRANSPARENT,
  outlineWidth : 0.0,
  id : undefined
});
```

```javascript
// Example 2:  Specify only the point's cartographic position.
const p = pointPrimitives.add({
  position : Cesium.Cartesian3.fromDegrees(longitude, latitude, height)
});
```

##### See:

* [PointPrimitiveCollection#remove](PointPrimitiveCollection.html#remove)
* [PointPrimitiveCollection#removeAll](PointPrimitiveCollection.html#removeAll)

#### [](#contains) contains(pointPrimitive) → boolean 

[engine/Source/Scene/PointPrimitiveCollection.js 401](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L401) 

 Check whether this collection contains a given point.

| Name           | Type                                  | Description                      |
| -------------- | ------------------------------------- | -------------------------------- |
| pointPrimitive | [PointPrimitive](PointPrimitive.html) | optional The point to check for. |

##### Returns:

 true if this collection contains the point, false otherwise.

##### See:

* [PointPrimitiveCollection#get](PointPrimitiveCollection.html#get)

#### [](#destroy) destroy() 

[engine/Source/Scene/PointPrimitiveCollection.js 1222](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L1222) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
pointPrimitives = pointPrimitives && pointPrimitives.destroy();
```

##### See:

* [PointPrimitiveCollection#isDestroyed](PointPrimitiveCollection.html#isDestroyed)

#### [](#get) get(index) → [PointPrimitive](PointPrimitive.html) 

[engine/Source/Scene/PointPrimitiveCollection.js 434](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L434) 

 Returns the point in the collection at the specified index. Indices are zero-based and increase as points are added. Removing a point shifts all points after it to the left, changing their indices. This function is commonly used with[PointPrimitiveCollection#length](PointPrimitiveCollection.html#length) to iterate over all the points in the collection.

##### Performance:

Expected constant time. If points were removed from the collection and`PointPrimitiveCollection#update` was not called, an implicit `O(n)`operation is performed.

| Name  | Type   | Description                        |
| ----- | ------ | ---------------------------------- |
| index | number | The zero-based index of the point. |

##### Returns:

 The point at the specified index.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
// Toggle the show property of every point in the collection
const len = pointPrimitives.length;
for (let i = 0; i < len; ++i) {
  const p = pointPrimitives.get(i);
  p.show = !p.show;
}
```

##### See:

* [PointPrimitiveCollection#length](PointPrimitiveCollection.html#length)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/PointPrimitiveCollection.js 1202](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L1202) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [PointPrimitiveCollection#destroy](PointPrimitiveCollection.html#destroy)

#### [](#remove) remove(pointPrimitive) → boolean 

[engine/Source/Scene/PointPrimitiveCollection.js 323](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L323) 

 Removes a point from the collection.

##### Performance:

Calling `remove` is expected constant time. However, the collection's vertex buffer is rewritten - an `O(n)` operation that also incurs CPU to GPU overhead. For best performance, remove as many points as possible before calling `update`. If you intend to temporarily hide a point, it is usually more efficient to call[PointPrimitive#show](PointPrimitive.html#show) instead of removing and re-adding the point.

| Name           | Type                                  | Description          |
| -------------- | ------------------------------------- | -------------------- |
| pointPrimitive | [PointPrimitive](PointPrimitive.html) | The point to remove. |

##### Returns:

`true` if the point was removed; `false` if the point was not found in the collection.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
const p = pointPrimitives.add(...);
pointPrimitives.remove(p);  // Returns true
```

##### See:

* [PointPrimitiveCollection#add](PointPrimitiveCollection.html#add)
* [PointPrimitiveCollection#removeAll](PointPrimitiveCollection.html#removeAll)
* [PointPrimitive#show](PointPrimitive.html#show)

#### [](#removeAll) removeAll() 

[engine/Source/Scene/PointPrimitiveCollection.js 352](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitiveCollection.js#L352) 

 Removes all points from the collection.

##### Performance:

`O(n)`. It is more efficient to remove all the points from a collection and then add new ones than to create a new collection entirely.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
pointPrimitives.add(...);
pointPrimitives.add(...);
pointPrimitives.removeAll();
```

##### See:

* [PointPrimitiveCollection#add](PointPrimitiveCollection.html#add)
* [PointPrimitiveCollection#remove](PointPrimitiveCollection.html#remove)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

