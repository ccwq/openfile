# [![](Images/CesiumLogo.png)](index.html) NearFarScalar 

#### [](#NearFarScalar) new Cesium.NearFarScalar(near, nearValue, far, farValue) 

[engine/Source/Core/NearFarScalar.js 17](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L17) 

 Represents a scalar value's lower and upper bound at a near distance and far distance in eye space.

| Name      | Type   | Default | Description                                                |
| --------- | ------ | ------- | ---------------------------------------------------------- |
| near      | number | 0.0     | optional The lower bound of the camera range.              |
| nearValue | number | 0.0     | optional The value at the lower bound of the camera range. |
| far       | number | 1.0     | optional The upper bound of the camera range.              |
| farValue  | number | 0.0     | optional The value at the upper bound of the camera range. |

##### See:

* [Packable](Packable.html)

### Members

#### [](#.packedLength) static Cesium.NearFarScalar.packedLength : number 

[engine/Source/Core/NearFarScalar.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L76) 

 The number of elements used to pack the object into an array.

#### [](#far) far : number 

[engine/Source/Core/NearFarScalar.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L35) 

 The upper bound of the camera range.

Default Value: `1.0` 

#### [](#farValue) farValue : number 

[engine/Source/Core/NearFarScalar.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L41) 

 The value at the upper bound of the camera range.

Default Value: `0.0` 

#### [](#near) near : number 

[engine/Source/Core/NearFarScalar.js 23](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L23) 

 The lower bound of the camera range.

Default Value: `0.0` 

#### [](#nearValue) nearValue : number 

[engine/Source/Core/NearFarScalar.js 29](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L29) 

 The value at the lower bound of the camera range.

Default Value: `0.0` 

### Methods

#### [](#.clone) static Cesium.NearFarScalar.clone(nearFarScalar, result) → [NearFarScalar](NearFarScalar.html) 

[engine/Source/Core/NearFarScalar.js 51](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L51) 

 Duplicates a NearFarScalar instance.

| Name          | Type                                | Description                                         |
| ------------- | ----------------------------------- | --------------------------------------------------- |
| nearFarScalar | [NearFarScalar](NearFarScalar.html) | The NearFarScalar to duplicate.                     |
| result        | [NearFarScalar](NearFarScalar.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new NearFarScalar instance if one was not provided. (Returns undefined if nearFarScalar is undefined)

#### [](#.equals) static Cesium.NearFarScalar.equals(left, right) → boolean 

[engine/Source/Core/NearFarScalar.js 142](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L142) 

 Compares the provided NearFarScalar and returns `true` if they are equal,`false` otherwise.

| Name  | Type                                | Description                        |
| ----- | ----------------------------------- | ---------------------------------- |
| left  | [NearFarScalar](NearFarScalar.html) | optional The first NearFarScalar.  |
| right | [NearFarScalar](NearFarScalar.html) | optional The second NearFarScalar. |

##### Returns:

`true` if left and right are equal; otherwise `false`.

#### [](#.pack) static Cesium.NearFarScalar.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/NearFarScalar.js 87](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L87) 

 Stores the provided instance into the provided array.

| Name          | Type                                | Default | Description                                                               |
| ------------- | ----------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [NearFarScalar](NearFarScalar.html) |         | The value to pack.                                                        |
| array         | Array.<number>                      |         | The array to pack into.                                                   |
| startingIndex | number                              | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.NearFarScalar.unpack(array, startingIndex, result) → [NearFarScalar](NearFarScalar.html) 

[engine/Source/Core/NearFarScalar.js 115](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L115) 

 Retrieves an instance from a packed array.

| Name          | Type                                | Default | Description                                                |
| ------------- | ----------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                      |         | The packed array.                                          |
| startingIndex | number                              | 0       | optional The starting index of the element to be unpacked. |
| result        | [NearFarScalar](NearFarScalar.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new NearFarScalar instance if one was not provided.

#### [](#clone) clone(result) → [NearFarScalar](NearFarScalar.html) 

[engine/Source/Core/NearFarScalar.js 160](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L160) 

 Duplicates this instance.

| Name   | Type                                | Description                                         |
| ------ | ----------------------------------- | --------------------------------------------------- |
| result | [NearFarScalar](NearFarScalar.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new NearFarScalar instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/NearFarScalar.js 171](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/NearFarScalar.js#L171) 

 Compares this instance to the provided NearFarScalar and returns `true` if they are equal,`false` otherwise.

| Name  | Type                                | Description                                 |
| ----- | ----------------------------------- | ------------------------------------------- |
| right | [NearFarScalar](NearFarScalar.html) | optional The right hand side NearFarScalar. |

##### Returns:

`true` if left and right are equal; otherwise `false`.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

