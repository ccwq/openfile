# [![](Images/CesiumLogo.png)](index.html) SceneModePickerViewModel 

#### [](#SceneModePickerViewModel) new Cesium.SceneModePickerViewModel(scene, duration) 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 20](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L20) 

 The view model for [SceneModePicker](SceneModePicker.html).

| Name     | Type                | Default | Description                                                 |
| -------- | ------------------- | ------- | ----------------------------------------------------------- |
| scene    | [Scene](Scene.html) |         | The Scene to morph                                          |
| duration | number              | 2.0     | optional The duration of scene morph animations, in seconds |

### Members

#### [](#dropDownVisible) dropDownVisible : boolean 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 52](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L52) 

 Gets or sets whether the button drop-down is currently visible. This property is observable.

Default Value: `false` 

#### [](#duration) duration : number 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 137](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L137) 

 Gets or sets the the duration of scene mode transition animations in seconds. A value of zero causes the scene to instantly change modes.

#### [](#morphTo2D) morphTo2D : [Command](Command.html) 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 170](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L170) 

 Gets the command to morph to 2D.

#### [](#morphTo3D) morphTo3D : [Command](Command.html) 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 182](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L182) 

 Gets the command to morph to 3D.

#### [](#morphToColumbusView) morphToColumbusView : [Command](Command.html) 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 194](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L194) 

 Gets the command to morph to Columbus View.

#### [](#scene) scene : [Scene](Scene.html) 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 125](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L125) 

 Gets the scene

#### [](#sceneMode) sceneMode : [SceneMode](global.html#SceneMode) 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 45](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L45) 

 Gets or sets the current SceneMode. This property is observable.

#### [](#selectedTooltip) selectedTooltip : string 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 87](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L87) 

 Gets the currently active tooltip. This property is observable.

#### [](#toggleDropDown) toggleDropDown : [Command](Command.html) 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 158](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L158) 

 Gets the command to toggle the drop down box.

#### [](#tooltip2D) tooltip2D : string 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 59](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L59) 

 Gets or sets the 2D tooltip. This property is observable.

Default Value: `'2D'` 

#### [](#tooltip3D) tooltip3D : string 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 66](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L66) 

 Gets or sets the 3D tooltip. This property is observable.

Default Value: `'3D'` 

#### [](#tooltipColumbusView) tooltipColumbusView : string 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 73](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L73) 

 Gets or sets the Columbus View tooltip. This property is observable.

Default Value: `'Columbus View'` 

### Methods

#### [](#destroy) destroy() 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 211](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L211) 

 Destroys the view model.

#### [](#isDestroyed) isDestroyed() → boolean 

[widgets/Source/SceneModePicker/SceneModePickerViewModel.js 204](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/SceneModePicker/SceneModePickerViewModel.js#L204) 

##### Returns:

 true if the object has been destroyed, false otherwise.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

