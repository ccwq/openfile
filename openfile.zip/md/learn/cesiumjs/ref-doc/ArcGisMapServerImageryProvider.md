# [![](Images/CesiumLogo.png)](index.html) ArcGisMapServerImageryProvider 

#### [](#ArcGisMapServerImageryProvider) new Cesium.ArcGisMapServerImageryProvider(options) 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 302](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L302) 

This object is normally not instantiated directly, use [ArcGisMapServerImageryProvider.fromBasemapType](ArcGisMapServerImageryProvider.html#.fromBasemapType) or [ArcGisMapServerImageryProvider.fromUrl](ArcGisMapServerImageryProvider.html#.fromUrl).

Provides tiled imagery hosted by an ArcGIS MapServer. By default, the server's pre-cached tiles are used, if available.  
An [ ArcGIS Access Token ](https://developers.arcgis.com/documentation/mapping-apis-and-services/security) is required to authenticate requests to an ArcGIS Image Tile service. To access secure ArcGIS resources, it's required to create an ArcGIS developer account or an ArcGIS online account, then implement an authentication method to obtain an access token.

| Name    | Type                                                                                                         | Description                                       |
| ------- | ------------------------------------------------------------------------------------------------------------ | ------------------------------------------------- |
| options | [ArcGisMapServerImageryProvider.ConstructorOptions](ArcGisMapServerImageryProvider.html#.ConstructorOptions) | optional Object describing initialization options |

##### Examples:

```javascript
// Set the default access token for accessing ArcGIS Image Tile service
Cesium.ArcGisMapService.defaultAccessToken = "<ArcGIS Access Token>";

// Add a base layer from a default ArcGIS basemap
const viewer = new Cesium.Viewer("cesiumContainer", {
  baseLayer: Cesium.ImageryLayer.fromProviderAsync(
    Cesium.ArcGisMapServerImageryProvider.fromBasemapType(
      Cesium.ArcGisBaseMapType.SATELLITE
    )
  ),
});
```

```javascript
// Create an imagery provider from the url directly
const esri = await Cesium.ArcGisMapServerImageryProvider.fromUrl(
  "https://ibasemaps-api.arcgis.com/arcgis/rest/services/World_Imagery/MapServer", {
    token: "<ArcGIS Access Token>"
});
```

##### See:

* [ArcGisMapServerImageryProvider.fromBasemapType](ArcGisMapServerImageryProvider.html#.fromBasemapType)
* [ArcGisMapServerImageryProvider.fromUrl](ArcGisMapServerImageryProvider.html#.fromUrl)
* [ArcGIS Server REST API](https://developers.arcgis.com/rest/)
* [ ArcGIS Access Token ](https://developers.arcgis.com/documentation/mapping-apis-and-services/security)

### Members

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 642](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L642) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

#### [](#enablePickFeatures) enablePickFeatures : boolean 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 346](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L346) 

 Gets or sets a value indicating whether feature picking is enabled. If true, [ArcGisMapServerImageryProvider#pickFeatures](ArcGisMapServerImageryProvider.html#pickFeatures) will invoke the "identify" operation on the ArcGIS server and return the features included in the response. If false,[ArcGisMapServerImageryProvider#pickFeatures](ArcGisMapServerImageryProvider.html#pickFeatures) will immediately return undefined (indicating no pickable features) without communicating with the server.

Default Value: `true` 

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 629](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L629) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 675](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L675) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. When this property is false, memory usage and texture upload time are reduced.

Default Value: `true` 

#### [](#layers) layers : string 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 687](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L687) 

 Gets the comma-separated list of layer IDs to show.

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 565](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L565) 

 Gets the maximum level-of-detail that can be requested.

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 577](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L577) 

 Gets the minimum level-of-detail that can be requested.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 529](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L529) 

 Gets the proxy used by this provider.

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 601](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L601) 

 Gets the rectangle, in radians, of the imagery provided by this instance.

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 615](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L615) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 553](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L553) 

 Gets the height of each tile, in pixels.

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 541](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L541) 

 Gets the width of each tile, in pixels.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 589](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L589) 

 Gets the tiling scheme used by this provider.

#### [](#token) readonly token : string 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 517](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L517) 

 Gets the ArcGIS token used to authenticate with the ArcGis MapServer service.

#### [](#url) readonly url : string 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 505](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L505) 

 Gets the URL of the ArcGIS MapServer.

#### [](#usingPrecachedTiles) readonly usingPrecachedTiles : boolean 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 657](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L657) 

 Gets a value indicating whether this imagery provider is using pre-cached tiles from the ArcGIS MapServer.

Default Value: `true` 

### Methods

#### [](#.fromBasemapType) static Cesium.ArcGisMapServerImageryProvider.fromBasemapType(style, options) → Promise.<[ArcGisMapServerImageryProvider](ArcGisMapServerImageryProvider.html)\> 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 378](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L378) 

 Creates an [ImageryProvider](ImageryProvider.html) which provides tiled imagery from an ArcGIS base map.

| Name    | Type                                                                                                         | Description                                                                                                                                                                                                                                                                          |
| ------- | ------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| style   | [ArcGisBaseMapType](global.html#ArcGisBaseMapType)                                                           | The style of the ArcGIS base map imagery. Valid options are [ArcGisBaseMapType.SATELLITE](global.html#ArcGisBaseMapType#.SATELLITE), [ArcGisBaseMapType.OCEANS](global.html#ArcGisBaseMapType#.OCEANS), and [ArcGisBaseMapType.HILLSHADE](global.html#ArcGisBaseMapType#.HILLSHADE). |
| options | [ArcGisMapServerImageryProvider.ConstructorOptions](ArcGisMapServerImageryProvider.html#.ConstructorOptions) | optional Object describing initialization options.                                                                                                                                                                                                                                   |

##### Returns:

 A promise that resolves to the created ArcGisMapServerImageryProvider.

##### Examples:

```javascript
// Set the default access token for accessing ArcGIS Image Tile service
Cesium.ArcGisMapService.defaultAccessToken = "<ArcGIS Access Token>";

// Add a base layer from a default ArcGIS basemap
const provider = await Cesium.ArcGisMapServerImageryProvider.fromBasemapType(
  Cesium.ArcGisBaseMapType.SATELLITE);
```

```javascript
// Add a base layer from a default ArcGIS Basemap
const viewer = new Cesium.Viewer("cesiumContainer", {
  baseLayer: Cesium.ImageryLayer.fromProviderAsync(
    Cesium.ArcGisMapServerImageryProvider.fromBasemapType(
      Cesium.ArcGisBaseMapType.HILLSHADE, {
        token: "<ArcGIS Access Token>"
      }
    )
  ),
});
```

#### [](#.fromUrl) static Cesium.ArcGisMapServerImageryProvider.fromUrl(url, options) → Promise.<[ArcGisMapServerImageryProvider](ArcGisMapServerImageryProvider.html)\> 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 710](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L710) 

 Creates an [ImageryProvider](ImageryProvider.html) which provides tiled imagery hosted by an ArcGIS MapServer. By default, the server's pre-cached tiles are used, if available.

| Name    | Type                                                                                                         | Description                                        |
| ------- | ------------------------------------------------------------------------------------------------------------ | -------------------------------------------------- |
| url     | [Resource](Resource.html)\|String                                                                            | The URL of the ArcGIS MapServer service.           |
| options | [ArcGisMapServerImageryProvider.ConstructorOptions](ArcGisMapServerImageryProvider.html#.ConstructorOptions) | optional Object describing initialization options. |

##### Returns:

 A promise that resolves to the created ArcGisMapServerImageryProvider.

##### Throws:

* [RuntimeError](RuntimeError.html): metadata spatial reference specifies an unknown WKID
* [RuntimeError](RuntimeError.html): metadata fullExtent.spatialReference specifies an unknown WKID

##### Example:

```javascript
const esri = await Cesium.ArcGisMapServerImageryProvider.fromUrl(
    "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer"
);
```

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 746](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L746) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → Promise.<Array.<[ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html)\>>|undefined 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 790](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L790) 

 /\*\* Asynchronously determines what features, if any, are located at a given longitude and latitude within a tile.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 A promise for the picked features that will resolve when the asynchronous picking completes. The resolved value is an array of [ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html) instances. The array may be empty if no features are found at the given location.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<[ImageryTypes](global.html#ImageryTypes)\>|undefined 

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 764](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L764) 

 Requests the image for a given tile.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the image that will resolve when the image is available, or undefined if there are too many active requests to the server, and the request should be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.ArcGisMapServerImageryProvider.ConstructorOptions

[engine/Source/Scene/ArcGisMapServerImageryProvider.js 24](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ArcGisMapServerImageryProvider.js#L24) 

 Initialization options for the ArcGisMapServerImageryProvider constructor

##### Properties:

| Name                         | Type                                        | Attributes | Default                      | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| ---------------------------- | ------------------------------------------- | ---------- | ---------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| tileDiscardPolicy            | [TileDiscardPolicy](TileDiscardPolicy.html) | <optional> |                              | The policy that determines if a tile is invalid and should be discarded. If this value is not specified, a default[DiscardMissingTileImagePolicy](DiscardMissingTileImagePolicy.html) is used for tiled map servers, and a[NeverTileDiscardPolicy](NeverTileDiscardPolicy.html) is used for non-tiled map servers. In the former case, we request tile 0,0 at the maximum tile level and check pixels (0,0), (200,20), (20,200), (80,110), and (160, 130). If all of these pixels are transparent, the discard check is disabled and no tiles are discarded. If any of them have a non-transparent color, any tile that has the same values in these pixel locations is discarded. The end result of these defaults should be correct tile discarding for a standard ArcGIS Server. To ensure that no tiles are discarded, construct and pass a [NeverTileDiscardPolicy](NeverTileDiscardPolicy.html) for this parameter. |
| usePreCachedTilesIfAvailable | boolean                                     | <optional> | true                         | If true, the server's pre-cached tiles are used if they are available. Exporting Tiles is only supported with deprecated APIs.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| layers                       | string                                      | <optional> |                              | A comma-separated list of the layers to show, or undefined if all layers should be shown.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| enablePickFeatures           | boolean                                     | <optional> | true                         | If true, [ArcGisMapServerImageryProvider#pickFeatures](ArcGisMapServerImageryProvider.html#pickFeatures) will invoke the Identify service on the MapServer and return the features included in the response. If false,[ArcGisMapServerImageryProvider#pickFeatures](ArcGisMapServerImageryProvider.html#pickFeatures) will immediately return undefined (indicating no pickable features) without communicating with the server. Set this property to false if you don't want this provider's features to be pickable. Can be overridden by setting the [ArcGisMapServerImageryProvider#enablePickFeatures](ArcGisMapServerImageryProvider.html#enablePickFeatures) property on the object.                                                                                                                                                                                                                               |
| rectangle                    | [Rectangle](Rectangle.html)                 | <optional> | Rectangle.MAX\_VALUE         | The rectangle of the layer. This parameter is ignored when accessing a tiled layer.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| tilingScheme                 | [TilingScheme](TilingScheme.html)           | <optional> | new GeographicTilingScheme() | The tiling scheme to use to divide the world into tiles. This parameter is ignored when accessing a tiled server.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ellipsoid                    | [Ellipsoid](Ellipsoid.html)                 | <optional> | Ellipsoid.default            | The ellipsoid. If the tilingScheme is specified and used, this parameter is ignored and the tiling scheme's ellipsoid is used instead. If neither parameter is specified, the default ellipsoid is used.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| credit                       | [Credit](Credit.html)\|string               | <optional> |                              | A credit for the data source, which is displayed on the canvas. This parameter is ignored when accessing a tiled server.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| tileWidth                    | number                                      | <optional> | 256                          | The width of each tile in pixels. This parameter is ignored when accessing a tiled server.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| tileHeight                   | number                                      | <optional> | 256                          | The height of each tile in pixels. This parameter is ignored when accessing a tiled server.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| maximumLevel                 | number                                      | <optional> |                              | The maximum tile level to request, or undefined if there is no maximum. This parameter is ignored when accessing a tiled server.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

