# [![](Images/CesiumLogo.png)](index.html) PostProcessStageComposite 

#### [](#PostProcessStageComposite) new Cesium.PostProcessStageComposite(options) 

[engine/Source/Scene/PostProcessStageComposite.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageComposite.js#L76) 

 A collection of [PostProcessStage](PostProcessStage.html)s or other post-process composite stages that execute together logically.

All stages are executed in the order of the array. The input texture changes based on the value of `inputPreviousStageTexture`. If `inputPreviousStageTexture` is `true`, the input to each stage is the output texture rendered to by the scene or of the stage that executed before it. If `inputPreviousStageTexture` is `false`, the input texture is the same for each stage in the composite. The input texture is the texture rendered to by the scene or the output texture of the previous stage.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | An object with the following properties: Name Type Default Description stages Array  An array of [PostProcessStage](PostProcessStage.html)s or composites to be executed in order. inputPreviousStageTexture boolean true optional Whether to execute each post-process stage where the input to one stage is the output of the previous. Otherwise, the input to each contained stage is the output of the stage that executed before the composite. name string createGuid() optional The unique name of this post-process stage for reference by other composites. If a name is not supplied, a GUID will be generated. uniforms object optional An alias to the uniforms of post-process stages. |

##### Throws:

* [DeveloperError](DeveloperError.html): options.stages.length must be greater than 0.0.

##### Examples:

```javascript
// Example 1: separable blur filter
// The input to blurXDirection is the texture rendered to by the scene or the output of the previous stage.
// The input to blurYDirection is the texture rendered to by blurXDirection.
scene.postProcessStages.add(new Cesium.PostProcessStageComposite({
    stages : [blurXDirection, blurYDirection]
}));
```

```javascript
// Example 2: referencing the output of another post-process stage
scene.postProcessStages.add(new Cesium.PostProcessStageComposite({
    inputPreviousStageTexture : false,
    stages : [
        // The same as Example 1.
        new Cesium.PostProcessStageComposite({
            inputPreviousStageTexture : true
            stages : [blurXDirection, blurYDirection],
            name : 'blur'
        }),
        // The input texture for this stage is the same input texture to blurXDirection since inputPreviousStageTexture is false
        new Cesium.PostProcessStage({
            fragmentShader : compositeShader,
            uniforms : {
                blurTexture : 'blur' // The output of the composite with name 'blur' (the texture that blurYDirection rendered to).
            }
        })
    ]
});
```

```javascript
// Example 3: create a uniform alias
const uniforms = {};
Cesium.defineProperties(uniforms, {
    filterSize : {
        get : function() {
            return blurXDirection.uniforms.filterSize;
        },
        set : function(value) {
            blurXDirection.uniforms.filterSize = blurYDirection.uniforms.filterSize = value;
        }
    }
});
scene.postProcessStages.add(new Cesium.PostProcessStageComposite({
    stages : [blurXDirection, blurYDirection],
    uniforms : uniforms
}));
```

##### See:

* [PostProcessStage](PostProcessStage.html)

### Members

#### [](#enabled) enabled : boolean 

[engine/Source/Scene/PostProcessStageComposite.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageComposite.js#L155) 

 Whether or not to execute this post-process stage when ready.

#### [](#inputPreviousStageTexture) readonly inputPreviousStageTexture : boolean 

[engine/Source/Scene/PostProcessStageComposite.js 187](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageComposite.js#L187) 

 All post-process stages are executed in the order of the array. The input texture changes based on the value of `inputPreviousStageTexture`. If `inputPreviousStageTexture` is `true`, the input to each stage is the output texture rendered to by the scene or of the stage that executed before it. If `inputPreviousStageTexture` is `false`, the input texture is the same for each stage in the composite. The input texture is the texture rendered to by the scene or the output texture of the previous stage.

#### [](#length) readonly length : number 

[engine/Source/Scene/PostProcessStageComposite.js 199](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageComposite.js#L199) 

 The number of post-process stages in this composite.

#### [](#name) readonly name : string 

[engine/Source/Scene/PostProcessStageComposite.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageComposite.js#L144) 

 The unique name of this post-process stage for reference by other stages in a PostProcessStageComposite.

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/PostProcessStageComposite.js 125](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageComposite.js#L125) 

 Determines if this post-process stage is ready to be executed.

#### [](#selected) selected : Array 

[engine/Source/Scene/PostProcessStageComposite.js 210](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageComposite.js#L210) 

 The features selected for applying the post-process.

#### [](#uniforms) uniforms : object 

[engine/Source/Scene/PostProcessStageComposite.js 172](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageComposite.js#L172) 

 An alias to the uniform values of the post-process stages. May be `undefined`; in which case, get each stage to set uniform values.

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/PostProcessStageComposite.js 354](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageComposite.js#L354) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.

Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### See:

* [PostProcessStageComposite#isDestroyed](PostProcessStageComposite.html#isDestroyed)

#### [](#get) get(index) → [PostProcessStage](PostProcessStage.html)|[PostProcessStageComposite](PostProcessStageComposite.html) 

[engine/Source/Scene/PostProcessStageComposite.js 254](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageComposite.js#L254) 

 Gets the post-process stage at `index` 

| Name  | Type   | Description                                       |
| ----- | ------ | ------------------------------------------------- |
| index | number | The index of the post-process stage or composite. |

##### Returns:

 The post-process stage or composite at index.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be greater than or equal to 0.
* [DeveloperError](DeveloperError.html): index must be less than [PostProcessStageComposite#length](PostProcessStageComposite.html#length).

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/PostProcessStageComposite.js 337](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageComposite.js#L337) 

 Returns true if this object was destroyed; otherwise, false.

If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [PostProcessStageComposite#destroy](PostProcessStageComposite.html#destroy)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

