# [![](Images/CesiumLogo.png)](index.html) TilingScheme 

#### [](#TilingScheme) new Cesium.TilingScheme() 

[engine/Source/Core/TilingScheme.js 16](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TilingScheme.js#L16) 

 A tiling scheme for geometry or imagery on the surface of an ellipsoid. At level-of-detail zero, the coarsest, least-detailed level, the number of tiles is configurable. At level of detail one, each of the level zero tiles has four children, two in each direction. At level of detail two, each of the level one tiles has four children, two in each direction. This continues for as many levels as are present in the geometry or imagery source.

##### See:

* [WebMercatorTilingScheme](WebMercatorTilingScheme.html)
* [GeographicTilingScheme](GeographicTilingScheme.html)

### Members

#### [](#ellipsoid) ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/TilingScheme.js 30](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TilingScheme.js#L30) 

 Gets the ellipsoid that is tiled by the tiling scheme.

#### [](#projection) projection : [MapProjection](MapProjection.html) 

[engine/Source/Core/TilingScheme.js 48](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TilingScheme.js#L48) 

 Gets the map projection used by the tiling scheme.

#### [](#rectangle) rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Core/TilingScheme.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TilingScheme.js#L39) 

 Gets the rectangle, in radians, covered by this tiling scheme.

### Methods

#### [](#getNumberOfXTilesAtLevel) getNumberOfXTilesAtLevel(level) → number 

[engine/Source/Core/TilingScheme.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TilingScheme.js#L60) 

 Gets the total number of tiles in the X direction at a specified level-of-detail.

| Name  | Type   | Description          |
| ----- | ------ | -------------------- |
| level | number | The level-of-detail. |

##### Returns:

 The number of tiles in the X direction at the given level.

#### [](#getNumberOfYTilesAtLevel) getNumberOfYTilesAtLevel(level) → number 

[engine/Source/Core/TilingScheme.js 70](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TilingScheme.js#L70) 

 Gets the total number of tiles in the Y direction at a specified level-of-detail.

| Name  | Type   | Description          |
| ----- | ------ | -------------------- |
| level | number | The level-of-detail. |

##### Returns:

 The number of tiles in the Y direction at the given level.

#### [](#positionToTileXY) positionToTileXY(position, level, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/TilingScheme.js 130](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TilingScheme.js#L130) 

 Calculates the tile x, y coordinates of the tile containing a given cartographic position.

| Name     | Type                              | Description                                                                                          |
| -------- | --------------------------------- | ---------------------------------------------------------------------------------------------------- |
| position | [Cartographic](Cartographic.html) | The position.                                                                                        |
| level    | number                            | The tile level-of-detail. Zero is the least detailed.                                                |
| result   | [Cartesian2](Cartesian2.html)     | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the tile x, y coordinates if 'result' is undefined.

#### [](#rectangleToNativeRectangle) rectangleToNativeRectangle(rectangle, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/TilingScheme.js 84](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TilingScheme.js#L84) 

 Transforms a rectangle specified in geodetic radians to the native coordinate system of this tiling scheme.

| Name      | Type                        | Description                                                                                          |
| --------- | --------------------------- | ---------------------------------------------------------------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html) | The rectangle to transform.                                                                          |
| result    | [Rectangle](Rectangle.html) | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the native rectangle if 'result' is undefined.

#### [](#tileXYToNativeRectangle) tileXYToNativeRectangle(x, y, level, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/TilingScheme.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TilingScheme.js#L100) 

 Converts tile x, y coordinates and level to a rectangle expressed in the native coordinates of the tiling scheme.

| Name   | Type   | Description                                                                                          |
| ------ | ------ | ---------------------------------------------------------------------------------------------------- |
| x      | number | The integer x coordinate of the tile.                                                                |
| y      | number | The integer y coordinate of the tile.                                                                |
| level  | number | The tile level-of-detail. Zero is the least detailed.                                                |
| result | object | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the rectangle if 'result' is undefined.

#### [](#tileXYToRectangle) tileXYToRectangle(x, y, level, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/TilingScheme.js 115](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TilingScheme.js#L115) 

 Converts tile x, y coordinates and level to a cartographic rectangle in radians.

| Name   | Type   | Description                                                                                          |
| ------ | ------ | ---------------------------------------------------------------------------------------------------- |
| x      | number | The integer x coordinate of the tile.                                                                |
| y      | number | The integer y coordinate of the tile.                                                                |
| level  | number | The tile level-of-detail. Zero is the least detailed.                                                |
| result | object | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the rectangle if 'result' is undefined.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

