# [![](Images/CesiumLogo.png)](index.html) EllipseGeometry 

#### [](#EllipseGeometry) new Cesium.EllipseGeometry(options) 

[engine/Source/Core/EllipseGeometry.js 920](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipseGeometry.js#L920) 

 A description of an ellipse on an ellipsoid. Ellipse geometry can be rendered with both [Primitive](Primitive.html) and [GroundPrimitive](GroundPrimitive.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description center [Cartesian3](Cartesian3.html)  The ellipse's center point in the fixed frame. semiMajorAxis number  The length of the ellipse's semi-major axis in meters. semiMinorAxis number  The length of the ellipse's semi-minor axis in meters. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid the ellipse will be on. height number 0.0 optional The distance in meters between the ellipse and the ellipsoid surface. extrudedHeight number optional The distance in meters between the ellipse's extruded face and the ellipsoid surface. rotation number 0.0 optional The angle of rotation counter-clockwise from north. stRotation number 0.0 optional The rotation of the texture coordinates counter-clockwise from north. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The angular distance between points on the ellipse in radians. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. |

##### Throws:

* [DeveloperError](DeveloperError.html): semiMajorAxis and semiMinorAxis must be greater than zero.
* [DeveloperError](DeveloperError.html): semiMajorAxis must be greater than or equal to the semiMinorAxis.
* [DeveloperError](DeveloperError.html): granularity must be greater than zero.

##### Example:

```javascript
// Create an ellipse.
const ellipse = new Cesium.EllipseGeometry({
  center : Cesium.Cartesian3.fromDegrees(-75.59777, 40.03883),
  semiMajorAxis : 500000.0,
  semiMinorAxis : 300000.0,
  rotation : Cesium.Math.toRadians(60.0)
});
const geometry = Cesium.EllipseGeometry.createGeometry(ellipse);
```

##### See:

* [EllipseGeometry.createGeometry](EllipseGeometry.html#.createGeometry)

### Members

#### [](#.packedLength) static Cesium.EllipseGeometry.packedLength : number 

[engine/Source/Core/EllipseGeometry.js 972](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipseGeometry.js#L972) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.computeRectangle) static Cesium.EllipseGeometry.computeRectangle(options, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/EllipseGeometry.js 1119](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipseGeometry.js#L1119) 

 Computes the bounding rectangle based on the provided options

| Name    | Type                        | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| ------- | --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object                      | Object with the following properties: Name Type Default Description center [Cartesian3](Cartesian3.html)  The ellipse's center point in the fixed frame. semiMajorAxis number  The length of the ellipse's semi-major axis in meters. semiMinorAxis number  The length of the ellipse's semi-minor axis in meters. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid the ellipse will be on. rotation number 0.0 optional The angle of rotation counter-clockwise from north. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The angular distance between points on the ellipse in radians. |
| result  | [Rectangle](Rectangle.html) | optional An object in which to store the result                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |

##### Returns:

 The result rectangle

#### [](#.createGeometry) static Cesium.EllipseGeometry.createGeometry(ellipseGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/EllipseGeometry.js 1163](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipseGeometry.js#L1163) 

 Computes the geometric representation of a ellipse on an ellipsoid, including its vertices, indices, and a bounding sphere.

| Name            | Type                                    | Description                   |
| --------------- | --------------------------------------- | ----------------------------- |
| ellipseGeometry | [EllipseGeometry](EllipseGeometry.html) | A description of the ellipse. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.EllipseGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/EllipseGeometry.js 987](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipseGeometry.js#L987) 

 Stores the provided instance into the provided array.

| Name          | Type                                    | Default | Description                                                               |
| ------------- | --------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [EllipseGeometry](EllipseGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                          |         | The array to pack into.                                                   |
| startingIndex | number                                  | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.EllipseGeometry.unpack(array, startingIndex, result) → [EllipseGeometry](EllipseGeometry.html) 

[engine/Source/Core/EllipseGeometry.js 1043](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipseGeometry.js#L1043) 

 Retrieves an instance from a packed array.

| Name          | Type                                    | Default | Description                                                |
| ------------- | --------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                          |         | The packed array.                                          |
| startingIndex | number                                  | 0       | optional The starting index of the element to be unpacked. |
| result        | [EllipseGeometry](EllipseGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new EllipseGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

