# [![](Images/CesiumLogo.png)](index.html) DataSourceClock 

#### [](#DataSourceClock) new Cesium.DataSourceClock() 

[engine/Source/DataSources/DataSourceClock.js 16](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L16) 

 Represents desired clock settings for a particular [DataSource](DataSource.html). These settings may be applied to the [Clock](Clock.html) when the DataSource is loaded.

### Members

#### [](#clockRange) clockRange : [ClockRange](global.html#ClockRange) 

[engine/Source/DataSources/DataSourceClock.js 70](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L70) 

 Gets or sets the desired clock range setting. See [Clock#clockRange](Clock.html#clockRange).

#### [](#clockStep) clockStep : [ClockStep](global.html#ClockStep) 

[engine/Source/DataSources/DataSourceClock.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L78) 

 Gets or sets the desired clock step setting. See [Clock#clockStep](Clock.html#clockStep).

#### [](#currentTime) currentTime : [JulianDate](JulianDate.html) 

[engine/Source/DataSources/DataSourceClock.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L62) 

 Gets or sets the desired current time when this data source is loaded. See [Clock#currentTime](Clock.html#currentTime).

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/DataSourceClock.js 34](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L34) 

 Gets the event that is raised whenever a new property is assigned.

#### [](#multiplier) multiplier : number 

[engine/Source/DataSources/DataSourceClock.js 86](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L86) 

 Gets or sets the desired clock multiplier. See [Clock#multiplier](Clock.html#multiplier).

#### [](#startTime) startTime : [JulianDate](JulianDate.html) 

[engine/Source/DataSources/DataSourceClock.js 46](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L46) 

 Gets or sets the desired start time of the clock. See [Clock#startTime](Clock.html#startTime).

#### [](#stopTime) stopTime : [JulianDate](JulianDate.html) 

[engine/Source/DataSources/DataSourceClock.js 54](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L54) 

 Gets or sets the desired stop time of the clock. See [Clock#stopTime](Clock.html#stopTime).

### Methods

#### [](#clone) clone(result) → [DataSourceClock](DataSourceClock.html) 

[engine/Source/DataSources/DataSourceClock.js 95](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L95) 

 Duplicates a DataSourceClock instance.

| Name   | Type                                    | Description                                         |
| ------ | --------------------------------------- | --------------------------------------------------- |
| result | [DataSourceClock](DataSourceClock.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#equals) equals(other) → boolean 

[engine/Source/DataSources/DataSourceClock.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L114) 

 Returns true if this DataSourceClock is equivalent to the other

| Name  | Type                                    | Description                                       |
| ----- | --------------------------------------- | ------------------------------------------------- |
| other | [DataSourceClock](DataSourceClock.html) | optional The other DataSourceClock to compare to. |

##### Returns:

`true` if the DataSourceClocks are equal; otherwise, `false`.

#### [](#getValue) getValue() → [Clock](Clock.html) 

[engine/Source/DataSources/DataSourceClock.js 153](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L153) 

 Gets the value of this clock instance as a [Clock](Clock.html) object.

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/DataSourceClock.js 133](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/DataSourceClock.js#L133) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                    | Description                               |
| ------ | --------------------------------------- | ----------------------------------------- |
| source | [DataSourceClock](DataSourceClock.html) | The object to be merged into this object. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

