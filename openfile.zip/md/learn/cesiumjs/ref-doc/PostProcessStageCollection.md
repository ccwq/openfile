# [![](Images/CesiumLogo.png)](index.html) PostProcessStageCollection 

#### [](#PostProcessStageCollection) new Cesium.PostProcessStageCollection() 

[engine/Source/Scene/PostProcessStageCollection.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L35) 

 A collection of [PostProcessStage](PostProcessStage.html)s and/or [PostProcessStageComposite](PostProcessStageComposite.html)s.

The input texture for each post-process stage is the texture rendered to by the scene or the texture rendered to by the previous stage in the collection.

If the ambient occlusion or bloom stages are enabled, they will execute before all other stages.

If the FXAA stage is enabled, it will execute after all other stages.

### Members

#### [](#ambientOcclusion) readonly ambientOcclusion : [PostProcessStageComposite](PostProcessStageComposite.html) 

[engine/Source/Scene/PostProcessStageCollection.js 179](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L179) 

 A post-process stage that applies Horizon-based Ambient Occlusion (HBAO) to the input texture.

Ambient occlusion simulates shadows from ambient light. These shadows would always be present when the surface receives light and regardless of the light's position.

The uniforms have the following properties:
* `intensity` is a scalar value used to lighten or darken the shadows exponentially. Higher values make the shadows darker. The default value is `3.0`.
* `bias` is a scalar value representing an angle in radians. If the dot product between the normal of the sample and the vector to the camera is less than this value, sampling stops in the current direction. This is used to remove shadows from near planar edges. The default value is `0.1`.
* `lengthCap` is a scalar value representing a length in meters. If the distance from the current sample to first sample is greater than this value, sampling stops in the current direction. The default value is `0.26`.
* `directionCount` is the number of directions along which the ray marching will search for occluders. The default value is `8`.
* `stepCount` is the number of steps the ray marching will take along each direction. The default value is `32`.
* `randomTexture` is a texture where the red channel is a random value in \[0.0, 1.0\]. The default value is `undefined`. This texture needs to be set.
* `ambientOcclusionOnly` is a boolean value. When `true`, only the shadows generated are written to the output. When `false`, the input texture is modulated with the ambient occlusion. This is a useful debug option for seeing the effects of changing the uniform values. The default value is `false`.

When enabled, this stage will execute before all others.

#### [](#bloom) readonly bloom : [PostProcessStageComposite](PostProcessStageComposite.html) 

[engine/Source/Scene/PostProcessStageCollection.js 214](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L214) 

 A post-process stage for a bloom effect.

A bloom effect adds glow effect, makes bright areas brighter, and dark areas darker.

This stage has the following uniforms: `contrast`, `brightness`, `glowOnly`,`delta`, `sigma`, and `stepSize`.

* `contrast` is a scalar value in the range \[-255.0, 255.0\] and affects the contract of the effect. The default value is `128.0`.
* `brightness` is a scalar value. The input texture RGB value is converted to hue, saturation, and brightness (HSB) then this value is added to the brightness. The default value is `-0.3`.
* `glowOnly` is a boolean value. When `true`, only the glow effect will be shown. When `false`, the glow will be added to the input texture. The default value is `false`. This is a debug option for viewing the effects when changing the other uniform values.

`delta`, `sigma`, and `stepSize` are the same properties as `PostProcessStageLibrary#createBlurStage`. The blur is applied to the shadows generated from the image to make them smoother.

When enabled, this stage will execute before all others.

#### [](#exposure) exposure : number 

[engine/Source/Scene/PostProcessStageCollection.js 397](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L397) 

 Control the exposure when HDR is on. Less than 1.0 makes the tonemapping darker while greater than 1.0 makes it brighter.

Default Value: `1.0` 

##### Example:

```javascript
viewer.scene.postProcessStages.exposure = 1.0;
```

#### [](#fxaa) readonly fxaa : [PostProcessStage](PostProcessStage.html) 

[engine/Source/Scene/PostProcessStageCollection.js 146](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L146) 

 A post-process stage for Fast Approximate Anti-aliasing.

When enabled, this stage will execute after all others.

#### [](#length) readonly length : number 

[engine/Source/Scene/PostProcessStageCollection.js 226](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L226) 

 The number of post-process stages in this collection.

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/PostProcessStageCollection.js 112](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L112) 

 Determines if all of the post-process stages in the collection are ready to be executed.

#### [](#tonemapper) tonemapper : [Tonemapper](global.html#Tonemapper) 

[engine/Source/Scene/PostProcessStageCollection.js 314](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L314) 

 Specifies the tonemapping algorithm used when rendering with high dynamic range.[Sandcastle Demo](https://sandcastle.cesium.com/?src=High%2520Dynamic%2520Range.html) 

Default Value: `Tonemapper.PBR_NEUTRAL` 

##### Example:

```javascript
viewer.scene.postProcessStages.tonemapper = Cesium.Tonemapper.ACES;
```

### Methods

#### [](#add) add(stage) → [PostProcessStage](PostProcessStage.html)|[PostProcessStageComposite](PostProcessStageComposite.html) 

[engine/Source/Scene/PostProcessStageCollection.js 436](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L436) 

 Adds the post-process stage to the collection.

| Name  | Type                                                                                                   | Description                                      |
| ----- | ------------------------------------------------------------------------------------------------------ | ------------------------------------------------ |
| stage | [PostProcessStage](PostProcessStage.html)\|[PostProcessStageComposite](PostProcessStageComposite.html) | The post-process stage to add to the collection. |

##### Returns:

 The post-process stage that was added to the collection.

##### Throws:

* [DeveloperError](DeveloperError.html): The post-process stage has already been added to the collection or does not have a unique name.

#### [](#contains) contains(stage) → boolean 

[engine/Source/Scene/PostProcessStageCollection.js 514](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L514) 

 Returns whether the collection contains a post-process stage.

| Name  | Type                                                                                                   | Description             |
| ----- | ------------------------------------------------------------------------------------------------------ | ----------------------- |
| stage | [PostProcessStage](PostProcessStage.html)\|[PostProcessStageComposite](PostProcessStageComposite.html) | The post-process stage. |

##### Returns:

 Whether the collection contains the post-process stage.

#### [](#destroy) destroy() 

[engine/Source/Scene/PostProcessStageCollection.js 890](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L890) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.

Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### See:

* [PostProcessStageCollection#isDestroyed](PostProcessStageCollection.html#isDestroyed)

#### [](#get) get(index) → [PostProcessStage](PostProcessStage.html)|[PostProcessStageComposite](PostProcessStageComposite.html) 

[engine/Source/Scene/PostProcessStageCollection.js 528](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L528) 

 Gets the post-process stage at `index`.

| Name  | Type   | Description                          |
| ----- | ------ | ------------------------------------ |
| index | number | The index of the post-process stage. |

##### Returns:

 The post-process stage at index.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/PostProcessStageCollection.js 873](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L873) 

 Returns true if this object was destroyed; otherwise, false.

If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [PostProcessStageCollection#destroy](PostProcessStageCollection.html#destroy)

#### [](#remove) remove(stage) → boolean 

[engine/Source/Scene/PostProcessStageCollection.js 478](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L478) 

 Removes a post-process stage from the collection and destroys it.

| Name  | Type                                                                                                   | Description                                           |
| ----- | ------------------------------------------------------------------------------------------------------ | ----------------------------------------------------- |
| stage | [PostProcessStage](PostProcessStage.html)\|[PostProcessStageComposite](PostProcessStageComposite.html) | The post-process stage to remove from the collection. |

##### Returns:

 Whether the post-process stage was removed.

#### [](#removeAll) removeAll() 

[engine/Source/Scene/PostProcessStageCollection.js 543](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PostProcessStageCollection.js#L543) 

 Removes all post-process stages from the collection and destroys them.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

