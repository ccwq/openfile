# [![](Images/CesiumLogo.png)](index.html) PolygonGraphics 

#### [](#PolygonGraphics) new Cesium.PolygonGraphics(options) 

[engine/Source/DataSources/PolygonGraphics.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L60) 

 Describes a polygon defined by an hierarchy of linear rings which make up the outer shape and any nested holes. The polygon conforms to the curvature of the globe and can be placed on the surface or at altitude and can optionally be extruded into a volume.

| Name    | Type                                                                           | Description                                       |
| ------- | ------------------------------------------------------------------------------ | ------------------------------------------------- |
| options | [PolygonGraphics.ConstructorOptions](PolygonGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle Polygon Demo](https://sandcastle.cesium.com/index.html?src=Polygon.html)

##### See:

* [Entity](Entity.html)

### Members

#### [](#arcType) arcType : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 264](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L264) 

 Gets or sets the [ArcType](global.html#ArcType) Property specifying the type of lines the polygon edges use.

Default Value: `ArcType.GEODESIC` 

#### [](#classificationType) classificationType : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 290](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L290) 

 Gets or sets the [ClassificationType](global.html#ClassificationType) Property specifying whether this polygon will classify terrain, 3D Tiles, or both when on the ground.

Default Value: `ClassificationType.BOTH` 

#### [](#closeBottom) closeBottom : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 256](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L256) 

 Gets or sets a boolean specifying whether or not the bottom of an extruded polygon is included.

#### [](#closeTop) closeTop : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L249) 

 Gets or sets a boolean specifying whether or not the top of an extruded polygon is included.

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/PolygonGraphics.js 118](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L118) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 280](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L280) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this polygon will be displayed.

#### [](#extrudedHeight) extrudedHeight : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 166](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L166) 

 Gets or sets the numeric Property specifying the altitude of the polygon extrusion. If [PolygonGraphics#perPositionHeight](PolygonGraphics.html#perPositionHeight) is false, the volume starts at [PolygonGraphics#height](PolygonGraphics.html#height) and ends at this altitude. If [PolygonGraphics#perPositionHeight](PolygonGraphics.html#perPositionHeight) is true, the volume starts at the height of each [PolygonGraphics#hierarchy](PolygonGraphics.html#hierarchy) position and ends at this altitude.

#### [](#extrudedHeightReference) extrudedHeightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 174](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L174) 

 Gets or sets the Property specifying the extruded [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#fill) fill : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 198](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L198) 

 Gets or sets the boolean Property specifying whether the polygon is filled with the provided material.

Default Value: `true` 

#### [](#granularity) granularity : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 190](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L190) 

 Gets or sets the numeric Property specifying the angular distance between points on the polygon.

Default Value: `{CesiumMath.RADIANS_PER_DEGREE}` 

#### [](#height) height : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 149](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L149) 

 Gets or sets the numeric Property specifying the constant altitude of the polygon.

Default Value: `0.0` 

#### [](#heightReference) heightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 157](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L157) 

 Gets or sets the Property specifying the [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#hierarchy) hierarchy : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 137](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L137) 

 Gets or sets the Property specifying the [PolygonHierarchy](PolygonHierarchy.html).

#### [](#material) material : [MaterialProperty](MaterialProperty.html) 

[engine/Source/DataSources/PolygonGraphics.js 206](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L206) 

 Gets or sets the Property specifying the material used to fill the polygon.

Default Value: `Color.WHITE` 

#### [](#outline) outline : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 214](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L214) 

 Gets or sets the Property specifying whether the polygon is outlined.

Default Value: `false` 

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 222](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L222) 

 Gets or sets the Property specifying the [Color](Color.html) of the outline.

Default Value: `Color.BLACK` 

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 233](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L233) 

 Gets or sets the numeric Property specifying the width of the outline.

Note: This property will be ignored on all major browsers on Windows platforms. For details, see (@link https://github.com/CesiumGS/cesium/issues/40}.

Default Value: `1.0` 

#### [](#perPositionHeight) perPositionHeight : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 242](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L242) 

 Gets or sets the boolean specifying whether or not the the height of each position is used. If true, the shape will have non-uniform altitude defined by the height of each [PolygonGraphics#hierarchy](PolygonGraphics.html#hierarchy) position. If false, the shape will have a constant altitude as specified by [PolygonGraphics#height](PolygonGraphics.html#height).

#### [](#shadows) shadows : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 273](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L273) 

 Get or sets the enum Property specifying whether the polygon casts or receives shadows from light sources.

Default Value: `ShadowMode.DISABLED` 

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 130](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L130) 

 Gets or sets the boolean Property specifying the visibility of the polygon.

Default Value: `true` 

#### [](#stRotation) stRotation : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 182](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L182) 

 Gets or sets the numeric property specifying the rotation of the polygon texture counter-clockwise from north. Only has an effect if textureCoordinates is not defined.

Default Value: `0` 

#### [](#textureCoordinates) textureCoordinates : [Property](Property.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 305](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L305) 

 A Property specifying texture coordinates as a [PolygonHierarchy](PolygonHierarchy.html) of [Cartesian2](Cartesian2.html) points. Has no effect for ground primitives.

#### [](#zIndex) zIndex : [ConstantProperty](ConstantProperty.html)|undefined 

[engine/Source/DataSources/PolygonGraphics.js 298](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L298) 

 Gets or sets the zIndex Prperty specifying the ordering of ground geometry. Only has an effect if the polygon is constant and neither height or extrudedHeight are specified.

Default Value: `0` 

### Methods

#### [](#clone) clone(result) → [PolygonGraphics](PolygonGraphics.html) 

[engine/Source/DataSources/PolygonGraphics.js 314](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L314) 

 Duplicates this instance.

| Name   | Type                                    | Description                                         |
| ------ | --------------------------------------- | --------------------------------------------------- |
| result | [PolygonGraphics](PolygonGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/PolygonGraphics.js 349](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L349) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                    | Description                               |
| ------ | --------------------------------------- | ----------------------------------------- |
| source | [PolygonGraphics](PolygonGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.PolygonGraphics.ConstructorOptions

[engine/Source/DataSources/PolygonGraphics.js 18](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PolygonGraphics.js#L18) 

 Initialization options for the PolygonGraphics constructor

##### Properties:

| Name                     | Type                                                                                                        | Attributes | Default                          | Description                                                                                                                                                            |
| ------------------------ | ----------------------------------------------------------------------------------------------------------- | ---------- | -------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| show                     | [Property](Property.html)\|boolean                                                                          | <optional> | true                             | A boolean Property specifying the visibility of the polygon.                                                                                                           |
| hierarchy                | [Property](Property.html)\|[PolygonHierarchy](PolygonHierarchy.html)|Array.<[Cartesian3](Cartesian3.html)\> | <optional> |                                  | A Property specifying the [PolygonHierarchy](PolygonHierarchy.html).                                                                                                   |
| height                   | [Property](Property.html)\|number                                                                           | <optional> | 0                                | A numeric Property specifying the altitude of the polygon relative to the ellipsoid surface.                                                                           |
| heightReference          | [Property](Property.html)\|[HeightReference](global.html#HeightReference)                                   | <optional> | HeightReference.NONE             | A Property specifying what the height is relative to.                                                                                                                  |
| extrudedHeight           | [Property](Property.html)\|number                                                                           | <optional> |                                  | A numeric Property specifying the altitude of the polygon's extruded face relative to the ellipsoid surface.                                                           |
| extrudedHeightReference  | [Property](Property.html)\|[HeightReference](global.html#HeightReference)                                   | <optional> | HeightReference.NONE             | A Property specifying what the extrudedHeight is relative to.                                                                                                          |
| stRotation               | [Property](Property.html)\|number                                                                           | <optional> | 0.0                              | A numeric property specifying the rotation of the polygon texture counter-clockwise from north. Only has an effect if textureCoordinates is not defined.               |
| granularity              | [Property](Property.html)\|number                                                                           | <optional> | Cesium.Math.RADIANS\_PER\_DEGREE | A numeric Property specifying the angular distance between each latitude and longitude point.                                                                          |
| fill                     | [Property](Property.html)\|boolean                                                                          | <optional> | true                             | A boolean Property specifying whether the polygon is filled with the provided material.                                                                                |
| material                 | [MaterialProperty](MaterialProperty.html)\|[Color](Color.html)                                              | <optional> | Color.WHITE                      | A Property specifying the material used to fill the polygon.                                                                                                           |
| outline                  | [Property](Property.html)\|boolean                                                                          | <optional> | false                            | A boolean Property specifying whether the polygon is outlined.                                                                                                         |
| outlineColor             | [Property](Property.html)\|[Color](Color.html)                                                              | <optional> | Color.BLACK                      | A Property specifying the [Color](Color.html) of the outline.                                                                                                          |
| outlineWidth             | [Property](Property.html)\|number                                                                           | <optional> | 1.0                              | A numeric Property specifying the width of the outline.                                                                                                                |
| perPositionHeight        | [Property](Property.html)\|boolean                                                                          | <optional> | false                            | A boolean specifying whether or not the height of each position is used.                                                                                               |
| closeTop                 | boolean\|boolean                                                                                            | <optional> | true                             | When false, leaves off the top of an extruded polygon open.                                                                                                            |
| closeBottom              | boolean\|boolean                                                                                            | <optional> | true                             | When false, leaves off the bottom of an extruded polygon open.                                                                                                         |
| arcType                  | [Property](Property.html)\|[ArcType](global.html#ArcType)                                                   | <optional> | ArcType.GEODESIC                 | The type of line the polygon edges must follow.                                                                                                                        |
| shadows                  | [Property](Property.html)\|[ShadowMode](global.html#ShadowMode)                                             | <optional> | ShadowMode.DISABLED              | An enum Property specifying whether the polygon casts or receives shadows from light sources.                                                                          |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html)                        | <optional> |                                  | A Property specifying at what distance from the camera that this polygon will be displayed.                                                                            |
| classificationType       | [Property](Property.html)\|[ClassificationType](global.html#ClassificationType)                             | <optional> | ClassificationType.BOTH          | An enum Property specifying whether this polygon will classify terrain, 3D Tiles, or both when on the ground.                                                          |
| zIndex                   | [ConstantProperty](ConstantProperty.html)\|number                                                           | <optional> | 0                                | A property specifying the zIndex used for ordering ground geometry. Only has an effect if the polygon is constant and neither height or extrudedHeight are specified.  |
| textureCoordinates       | [Property](Property.html)\|[PolygonHierarchy](PolygonHierarchy.html)                                        | <optional> |                                  | A Property specifying texture coordinates as a [PolygonHierarchy](PolygonHierarchy.html) of [Cartesian2](Cartesian2.html) points. Has no effect for ground primitives. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

