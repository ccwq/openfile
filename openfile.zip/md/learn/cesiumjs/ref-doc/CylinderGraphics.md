# [![](Images/CesiumLogo.png)](index.html) CylinderGraphics 

#### [](#CylinderGraphics) new Cesium.CylinderGraphics(options) 

[engine/Source/DataSources/CylinderGraphics.js 38](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L38) 

 Describes a cylinder, truncated cone, or cone defined by a length, top radius, and bottom radius. The center position and orientation are determined by the containing [Entity](Entity.html).

| Name    | Type                                                                             | Description                                       |
| ------- | -------------------------------------------------------------------------------- | ------------------------------------------------- |
| options | [CylinderGraphics.ConstructorOptions](CylinderGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

### Members

#### [](#bottomRadius) bottomRadius : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 113](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L113) 

 Gets or sets the numeric Property specifying the radius of the bottom of the cylinder.

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/CylinderGraphics.js 80](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L80) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 196](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L196) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this cylinder will be displayed.

#### [](#fill) fill : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 129](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L129) 

 Gets or sets the boolean Property specifying whether the cylinder is filled with the provided material.

Default Value: `true` 

#### [](#heightReference) heightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L121) 

 Gets or sets the Property specifying the [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#length) length : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 99](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L99) 

 Gets or sets the numeric Property specifying the length of the cylinder.

#### [](#material) material : [MaterialProperty](MaterialProperty.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 137](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L137) 

 Gets or sets the Property specifying the material used to fill the cylinder.

Default Value: `Color.WHITE` 

#### [](#numberOfVerticalLines) numberOfVerticalLines : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 172](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L172) 

 Gets or sets the Property specifying the number of vertical lines to draw along the perimeter for the outline.

Default Value: `16` 

#### [](#outline) outline : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 145](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L145) 

 Gets or sets the boolean Property specifying whether the cylinder is outlined.

Default Value: `false` 

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 153](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L153) 

 Gets or sets the Property specifying the [Color](Color.html) of the outline.

Default Value: `Color.BLACK` 

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 164](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L164) 

 Gets or sets the numeric Property specifying the width of the outline.

Note: This property will be ignored on all major browsers on Windows platforms. For details, see (@link https://github.com/CesiumGS/cesium/issues/40}.

Default Value: `1.0` 

#### [](#shadows) shadows : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 189](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L189) 

 Get or sets the enum Property specifying whether the cylinder casts or receives shadows from light sources.

Default Value: `ShadowMode.DISABLED` 

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 92](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L92) 

 Gets or sets the boolean Property specifying the visibility of the cylinder.

Default Value: `true` 

#### [](#slices) slices : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 180](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L180) 

 Gets or sets the Property specifying the number of edges around the perimeter of the cylinder.

Default Value: `128` 

#### [](#topRadius) topRadius : [Property](Property.html)|undefined 

[engine/Source/DataSources/CylinderGraphics.js 106](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L106) 

 Gets or sets the numeric Property specifying the radius of the top of the cylinder.

### Methods

#### [](#clone) clone(result) → [CylinderGraphics](CylinderGraphics.html) 

[engine/Source/DataSources/CylinderGraphics.js 207](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L207) 

 Duplicates this instance.

| Name   | Type                                      | Description                                         |
| ------ | ----------------------------------------- | --------------------------------------------------- |
| result | [CylinderGraphics](CylinderGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/CylinderGraphics.js 234](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L234) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                      | Description                               |
| ------ | ----------------------------------------- | ----------------------------------------- |
| source | [CylinderGraphics](CylinderGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.CylinderGraphics.ConstructorOptions

[engine/Source/DataSources/CylinderGraphics.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CylinderGraphics.js#L8) 

 Initialization options for the CylinderGraphics constructor

##### Properties:

| Name                     | Type                                                                                 | Attributes | Default              | Description                                                                                             |
| ------------------------ | ------------------------------------------------------------------------------------ | ---------- | -------------------- | ------------------------------------------------------------------------------------------------------- |
| show                     | [Property](Property.html)\|boolean                                                   | <optional> | true                 | A boolean Property specifying the visibility of the cylinder.                                           |
| length                   | [Property](Property.html)\|number                                                    | <optional> |                      | A numeric Property specifying the length of the cylinder.                                               |
| topRadius                | [Property](Property.html)\|number                                                    | <optional> |                      | A numeric Property specifying the radius of the top of the cylinder.                                    |
| bottomRadius             | [Property](Property.html)\|number                                                    | <optional> |                      | A numeric Property specifying the radius of the bottom of the cylinder.                                 |
| heightReference          | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE | A Property specifying what the height from the entity position is relative to.                          |
| fill                     | [Property](Property.html)\|boolean                                                   | <optional> | true                 | A boolean Property specifying whether the cylinder is filled with the provided material.                |
| material                 | [MaterialProperty](MaterialProperty.html)\|[Color](Color.html)                       | <optional> | Color.WHITE          | A Property specifying the material used to fill the cylinder.                                           |
| outline                  | [Property](Property.html)\|boolean                                                   | <optional> | false                | A boolean Property specifying whether the cylinder is outlined.                                         |
| outlineColor             | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.BLACK          | A Property specifying the [Color](Color.html) of the outline.                                           |
| outlineWidth             | [Property](Property.html)\|number                                                    | <optional> | 1.0                  | A numeric Property specifying the width of the outline.                                                 |
| numberOfVerticalLines    | [Property](Property.html)\|number                                                    | <optional> | 16                   | A numeric Property specifying the number of vertical lines to draw along the perimeter for the outline. |
| slices                   | [Property](Property.html)\|number                                                    | <optional> | 128                  | The number of edges around the perimeter of the cylinder.                                               |
| shadows                  | [Property](Property.html)\|[ShadowMode](global.html#ShadowMode)                      | <optional> | ShadowMode.DISABLED  | An enum Property specifying whether the cylinder casts or receives shadows from light sources.          |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                      | A Property specifying at what distance from the camera that this cylinder will be displayed.            |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

