# [![](Images/CesiumLogo.png)](index.html) PathGraphics 

#### [](#PathGraphics) new Cesium.PathGraphics(options) 

[engine/Source/DataSources/PathGraphics.js 30](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L30) 

 Describes a polyline defined as the path made by an [Entity](Entity.html) as it moves over time.

| Name    | Type                                                                     | Description                                       |
| ------- | ------------------------------------------------------------------------ | ------------------------------------------------- |
| options | [PathGraphics.ConstructorOptions](PathGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/PathGraphics.js 57](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L57) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/PathGraphics.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L114) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this path will be displayed.

#### [](#leadTime) leadTime : [Property](Property.html)|undefined 

[engine/Source/DataSources/PathGraphics.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L76) 

 Gets or sets the Property specifying the number of seconds in front of the object to show.

#### [](#material) material : [MaterialProperty](MaterialProperty.html) 

[engine/Source/DataSources/PathGraphics.js 107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L107) 

 Gets or sets the Property specifying the material used to draw the path.

Default Value: `Color.WHITE` 

#### [](#resolution) resolution : [Property](Property.html)|undefined 

[engine/Source/DataSources/PathGraphics.js 99](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L99) 

 Gets or sets the Property specifying the maximum number of seconds to step when sampling the position.

Default Value: `60` 

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/PathGraphics.js 69](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L69) 

 Gets or sets the boolean Property specifying the visibility of the path.

Default Value: `true` 

#### [](#trailTime) trailTime : [Property](Property.html)|undefined 

[engine/Source/DataSources/PathGraphics.js 83](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L83) 

 Gets or sets the Property specifying the number of seconds behind the object to show.

#### [](#width) width : [Property](Property.html)|undefined 

[engine/Source/DataSources/PathGraphics.js 91](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L91) 

 Gets or sets the numeric Property specifying the width in pixels.

Default Value: `1.0` 

### Methods

#### [](#clone) clone(result) → [PathGraphics](PathGraphics.html) 

[engine/Source/DataSources/PathGraphics.js 125](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L125) 

 Duplicates this instance.

| Name   | Type                              | Description                                         |
| ------ | --------------------------------- | --------------------------------------------------- |
| result | [PathGraphics](PathGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/PathGraphics.js 145](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L145) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                              | Description                               |
| ------ | --------------------------------- | ----------------------------------------- |
| source | [PathGraphics](PathGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.PathGraphics.ConstructorOptions

[engine/Source/DataSources/PathGraphics.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/PathGraphics.js#L8) 

 Initialization options for the PathGraphics constructor

##### Properties:

| Name                     | Type                                                                                 | Attributes | Default     | Description                                                                                     |
| ------------------------ | ------------------------------------------------------------------------------------ | ---------- | ----------- | ----------------------------------------------------------------------------------------------- |
| show                     | [Property](Property.html)\|boolean                                                   | <optional> | true        | A boolean Property specifying the visibility of the path.                                       |
| leadTime                 | [Property](Property.html)\|number                                                    | <optional> |             | A Property specifying the number of seconds in front the object to show.                        |
| trailTime                | [Property](Property.html)\|number                                                    | <optional> |             | A Property specifying the number of seconds behind of the object to show.                       |
| width                    | [Property](Property.html)\|number                                                    | <optional> | 1.0         | A numeric Property specifying the width in pixels.                                              |
| resolution               | [Property](Property.html)\|number                                                    | <optional> | 60          | A numeric Property specifying the maximum number of seconds to step when sampling the position. |
| material                 | [MaterialProperty](MaterialProperty.html)\|[Color](Color.html)                       | <optional> | Color.WHITE | A Property specifying the material used to draw the path.                                       |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |             | A Property specifying at what distance from the camera that this path will be displayed.        |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

