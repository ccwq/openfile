# [![](Images/CesiumLogo.png)](index.html) WallOutlineGeometry 

#### [](#WallOutlineGeometry) new Cesium.WallOutlineGeometry(options) 

[engine/Source/Core/WallOutlineGeometry.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallOutlineGeometry.js#L55) 

 A description of a wall outline. A wall is defined by a series of points, which extrude down to the ground. Optionally, they can extrude downwards to a specified height.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of Cartesian objects, which are the points of the wall. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The distance, in radians, between each latitude and longitude. Determines the number of positions in the buffer. maximumHeights Array.<number> optional An array parallel to positions that give the maximum height of the wall at positions. If undefined, the height of each position in used. minimumHeights Array.<number> optional An array parallel to positions that give the minimum height of the wall at positions. If undefined, the height at each position is 0.0. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid for coordinate manipulation |

##### Throws:

* [DeveloperError](DeveloperError.html): positions length must be greater than or equal to 2.
* [DeveloperError](DeveloperError.html): positions and maximumHeights must have the same length.
* [DeveloperError](DeveloperError.html): positions and minimumHeights must have the same length.

##### Example:

```javascript
// create a wall outline that spans from ground level to 10000 meters
const wall = new Cesium.WallOutlineGeometry({
  positions : Cesium.Cartesian3.fromDegreesArrayHeights([
    19.0, 47.0, 10000.0,
    19.0, 48.0, 10000.0,
    20.0, 48.0, 10000.0,
    20.0, 47.0, 10000.0,
    19.0, 47.0, 10000.0
  ])
});
const geometry = Cesium.WallOutlineGeometry.createGeometry(wall);
```

##### See:

* WallGeometry#createGeometry
* WallGeometry#fromConstantHeight

### Members

#### [](#packedLength) packedLength : number 

[engine/Source/Core/WallOutlineGeometry.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallOutlineGeometry.js#L109) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.WallOutlineGeometry.createGeometry(wallGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/WallOutlineGeometry.js 328](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallOutlineGeometry.js#L328) 

 Computes the geometric representation of a wall outline, including its vertices, indices, and a bounding sphere.

| Name         | Type                                            | Description                        |
| ------------ | ----------------------------------------------- | ---------------------------------- |
| wallGeometry | [WallOutlineGeometry](WallOutlineGeometry.html) | A description of the wall outline. |

##### Returns:

 The computed vertices and indices.

#### [](#.fromConstantHeights) static Cesium.WallOutlineGeometry.fromConstantHeights(options) → [WallOutlineGeometry](WallOutlineGeometry.html) 

[engine/Source/Core/WallOutlineGeometry.js 279](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallOutlineGeometry.js#L279) 

 A description of a walloutline. A wall is defined by a series of points, which extrude down to the ground. Optionally, they can extrude downwards to a specified height.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | Object with the following properties: Name Type Default Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of Cartesian objects, which are the points of the wall. maximumHeight number optional A constant that defines the maximum height of the wall at positions. If undefined, the height of each position in used. minimumHeight number optional A constant that defines the minimum height of the wall at positions. If undefined, the height at each position is 0.0. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid for coordinate manipulation |

##### Returns:

##### Example:

```javascript
// create a wall that spans from 10000 meters to 20000 meters
const wall = Cesium.WallOutlineGeometry.fromConstantHeights({
  positions : Cesium.Cartesian3.fromDegreesArray([
    19.0, 47.0,
    19.0, 48.0,
    20.0, 48.0,
    20.0, 47.0,
    19.0, 47.0,
  ]),
  minimumHeight : 20000.0,
  maximumHeight : 10000.0
});
const geometry = Cesium.WallOutlineGeometry.createGeometry(wall);
```

##### See:

* WallOutlineGeometry#createGeometry

#### [](#.pack) static Cesium.WallOutlineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/WallOutlineGeometry.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallOutlineGeometry.js#L121) 

 Stores the provided instance into the provided array.

| Name          | Type                                            | Default | Description                                                               |
| ------------- | ----------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [WallOutlineGeometry](WallOutlineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                  |         | The array to pack into.                                                   |
| startingIndex | number                                          | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.WallOutlineGeometry.unpack(array, startingIndex, result) → [WallOutlineGeometry](WallOutlineGeometry.html) 

[engine/Source/Core/WallOutlineGeometry.js 188](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallOutlineGeometry.js#L188) 

 Retrieves an instance from a packed array.

| Name          | Type                                            | Default | Description                                                |
| ------------- | ----------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                  |         | The packed array.                                          |
| startingIndex | number                                          | 0       | optional The starting index of the element to be unpacked. |
| result        | [WallOutlineGeometry](WallOutlineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new WallOutlineGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

