# [![](Images/CesiumLogo.png)](index.html) BingMapsImageryProvider 

#### [](#BingMapsImageryProvider) new Cesium.BingMapsImageryProvider(options) 

[engine/Source/Scene/BingMapsImageryProvider.js 207](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L207) 

To construct a BingMapsImageryProvider, call [BingMapsImageryProvider.fromUrl](BingMapsImageryProvider.html#.fromUrl). Do not call the constructor directly.

Provides tiled imagery using the Bing Maps Imagery REST API.

| Name    | Type                                                                                           | Description                              |
| ------- | ---------------------------------------------------------------------------------------------- | ---------------------------------------- |
| options | [BingMapsImageryProvider.ConstructorOptions](BingMapsImageryProvider.html#.ConstructorOptions) | Object describing initialization options |

##### Example:

```javascript
const bing = await Cesium.BingMapsImageryProvider.fromUrl(
  "https://dev.virtualearth.net", {
    key: "get-yours-at-https://www.bingmapsportal.com/",
    mapStyle: Cesium.BingMapsStyle.AERIAL
});
```

##### See:

* [BingMapsImageryProvider.fromUrl](BingMapsImageryProvider.html#.fromUrl)
* [ArcGisMapServerImageryProvider](ArcGisMapServerImageryProvider.html)
* [GoogleEarthEnterpriseMapsProvider](GoogleEarthEnterpriseMapsProvider.html)
* [OpenStreetMapImageryProvider](OpenStreetMapImageryProvider.html)
* [SingleTileImageryProvider](SingleTileImageryProvider.html)
* [TileMapServiceImageryProvider](TileMapServiceImageryProvider.html)
* [WebMapServiceImageryProvider](WebMapServiceImageryProvider.html)
* [WebMapTileServiceImageryProvider](WebMapTileServiceImageryProvider.html)
* [UrlTemplateImageryProvider](UrlTemplateImageryProvider.html)
* [Bing Maps REST Services](http://msdn.microsoft.com/en-us/library/ff701713.aspx)
* [Cross-Origin Resource Sharing](http://www.w3.org/TR/cors/)

### Members

#### [](#.logoUrl) static Cesium.BingMapsImageryProvider.logoUrl : string 

[engine/Source/Scene/BingMapsImageryProvider.js 682](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L682) 

 Gets or sets the URL to the Bing logo for display in the credit.

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/BingMapsImageryProvider.js 434](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L434) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

#### [](#culture) readonly culture : string 

[engine/Source/Scene/BingMapsImageryProvider.js 321](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L321) 

 The culture to use when requesting Bing Maps imagery. Not all cultures are supported. See <http://msdn.microsoft.com/en-us/library/hh441729.aspx>for information on the supported cultures.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/BingMapsImageryProvider.js 421](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L421) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/BingMapsImageryProvider.js 450](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L450) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. Setting this property to false reduces memory usage and texture upload time.

#### [](#key) readonly key : string 

[engine/Source/Scene/BingMapsImageryProvider.js 283](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L283) 

 Gets the Bing Maps key.

#### [](#mapLayer) readonly mapLayer : string 

[engine/Source/Scene/BingMapsImageryProvider.js 307](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L307) 

 Gets the additional map layer options as defined in <https://learn.microsoft.com/en-us/bingmaps/rest-services/imagery/get-imagery-metadata#template-parameters>/

#### [](#mapStyle) readonly mapStyle : [BingMapsStyle](global.html#BingMapsStyle) 

[engine/Source/Scene/BingMapsImageryProvider.js 295](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L295) 

 Gets the type of Bing Maps imagery to load.

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/BingMapsImageryProvider.js 357](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L357) 

 Gets the maximum level-of-detail that can be requested.

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/BingMapsImageryProvider.js 369](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L369) 

 Gets the minimum level-of-detail that can be requested.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/BingMapsImageryProvider.js 271](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L271) 

 Gets the proxy used by this provider.

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/BingMapsImageryProvider.js 393](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L393) 

 Gets the rectangle, in radians, of the imagery provided by this instance.

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/BingMapsImageryProvider.js 407](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L407) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/BingMapsImageryProvider.js 345](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L345) 

 Gets the height of each tile, in pixels.

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/BingMapsImageryProvider.js 333](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L333) 

 Gets the width of each tile, in pixels.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/BingMapsImageryProvider.js 381](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L381) 

 Gets the tiling scheme used by this provider.

#### [](#url) readonly url : string 

[engine/Source/Scene/BingMapsImageryProvider.js 259](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L259) 

 Gets the name of the BingMaps server url hosting the imagery.

### Methods

#### [](#.fromUrl) static Cesium.BingMapsImageryProvider.fromUrl(url, options) → Promise.<[BingMapsImageryProvider](BingMapsImageryProvider.html)\> 

[engine/Source/Scene/BingMapsImageryProvider.js 473](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L473) 

 Creates an [ImageryProvider](ImageryProvider.html) which provides tiled imagery using the Bing Maps Imagery REST API.

| Name    | Type                                                                                           | Description                                          |
| ------- | ---------------------------------------------------------------------------------------------- | ---------------------------------------------------- |
| url     | [Resource](Resource.html)\|String                                                              | The url of the Bing Maps server hosting the imagery. |
| options | [BingMapsImageryProvider.ConstructorOptions](BingMapsImageryProvider.html#.ConstructorOptions) | Object describing initialization options             |

##### Returns:

 A promise that resolves to the created BingMapsImageryProvider

##### Throws:

* [RuntimeError](RuntimeError.html): metadata does not specify one resource in resourceSets

##### Example:

```javascript
const bing = await Cesium.BingMapsImageryProvider.fromUrl(
  "https://dev.virtualearth.net", {
    key: "get-yours-at-https://www.bingmapsportal.com/",
    mapStyle: Cesium.BingMapsStyle.AERIAL
});
```

#### [](#.quadKeyToTileXY) static Cesium.BingMapsImageryProvider.quadKeyToTileXY(quadkey) 

[engine/Source/Scene/BingMapsImageryProvider.js 651](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L651) 

 Converts a tile's quadkey used to request an image from a Bing Maps server into the (x, y, level) position.

| Name    | Type   | Description         |
| ------- | ------ | ------------------- |
| quadkey | string | The tile's quad key |

##### See:

* [Bing Maps Tile System](http://msdn.microsoft.com/en-us/library/bb259689.aspx)
* BingMapsImageryProvider#tileXYToQuadKey

#### [](#.tileXYToQuadKey) static Cesium.BingMapsImageryProvider.tileXYToQuadKey(x, y, level) 

[engine/Source/Scene/BingMapsImageryProvider.js 623](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L623) 

 Converts a tiles (x, y, level) position into a quadkey used to request an image from a Bing Maps server.

| Name  | Type   | Description              |
| ----- | ------ | ------------------------ |
| x     | number | The tile's x coordinate. |
| y     | number | The tile's y coordinate. |
| level | number | The tile's zoom level.   |

##### See:

* [Bing Maps Tile System](http://msdn.microsoft.com/en-us/library/bb259689.aspx)
* BingMapsImageryProvider#quadKeyToTileXY

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/BingMapsImageryProvider.js 539](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L539) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → undefined 

[engine/Source/Scene/BingMapsImageryProvider.js 602](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L602) 

 Picking features is not currently supported by this imagery provider, so this function simply returns undefined.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 Undefined since picking is not supported.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<[ImageryTypes](global.html#ImageryTypes)\>|undefined 

[engine/Source/Scene/BingMapsImageryProvider.js 565](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L565) 

 Requests the image for a given tile.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the image that will resolve when the image is available, or undefined if there are too many active requests to the server, and the request should be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.BingMapsImageryProvider.ConstructorOptions

[engine/Source/Scene/BingMapsImageryProvider.js 17](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BingMapsImageryProvider.js#L17) 

 Initialization options for the BingMapsImageryProvider constructor

##### Properties:

| Name              | Type                                        | Attributes | Default              | Description                                                                                                                                                                                                                                                                                                                                                                                                   |
| ----------------- | ------------------------------------------- | ---------- | -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| key               | string                                      | <optional> |                      | The Bing Maps key for your application, which can be created at <https://www.bingmapsportal.com/>.                                                                                                                                                                                                                                                                                                            |
| tileProtocol      | string                                      | <optional> |                      | The protocol to use when loading tiles, e.g. 'http' or 'https'. By default, tiles are loaded using the same protocol as the page.                                                                                                                                                                                                                                                                             |
| mapStyle          | [BingMapsStyle](global.html#BingMapsStyle)  | <optional> | BingMapsStyle.AERIAL | The type of Bing Maps imagery to load.                                                                                                                                                                                                                                                                                                                                                                        |
| mapLayer          | string                                      | <optional> |                      | Additional display layer options as defined on <https://learn.microsoft.com/en-us/bingmaps/rest-services/imagery/get-imagery-metadata#template-parameters>                                                                                                                                                                                                                                                    |
| culture           | string                                      | <optional> | ''                   | The culture to use when requesting Bing Maps imagery. Not all cultures are supported. See <http://msdn.microsoft.com/en-us/library/hh441729.aspx> for information on the supported cultures.                                                                                                                                                                                                                  |
| ellipsoid         | [Ellipsoid](Ellipsoid.html)                 | <optional> | Ellipsoid.default    | The ellipsoid. If not specified, the default ellipsoid is used.                                                                                                                                                                                                                                                                                                                                               |
| tileDiscardPolicy | [TileDiscardPolicy](TileDiscardPolicy.html) | <optional> |                      | The policy that determines if a tile is invalid and should be discarded. By default, a [DiscardEmptyTileImagePolicy](DiscardEmptyTileImagePolicy.html) will be used, with the expectation that the Bing Maps server will send a zero-length response for missing tiles. To ensure that no tiles are discarded, construct and pass a [NeverTileDiscardPolicy](NeverTileDiscardPolicy.html) for this parameter. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

