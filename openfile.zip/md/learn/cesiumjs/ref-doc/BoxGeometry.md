# [![](Images/CesiumLogo.png)](index.html) BoxGeometry 

#### [](#BoxGeometry) new Cesium.BoxGeometry(options) 

[engine/Source/Core/BoxGeometry.js 42](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxGeometry.js#L42) 

 Describes a cube centered at the origin.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                          |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description minimum [Cartesian3](Cartesian3.html)  The minimum x, y, and z coordinates of the box. maximum [Cartesian3](Cartesian3.html)  The maximum x, y, and z coordinates of the box. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. |

##### Example:

```javascript
const box = new Cesium.BoxGeometry({
  vertexFormat : Cesium.VertexFormat.POSITION_ONLY,
  maximum : new Cesium.Cartesian3(250000.0, 250000.0, 250000.0),
  minimum : new Cesium.Cartesian3(-250000.0, -250000.0, -250000.0)
});
const geometry = Cesium.BoxGeometry.createGeometry(box);
```

##### Demo:

* [Cesium Sandcastle Box Demo](https://sandcastle.cesium.com/index.html?src=Box.html)

##### See:

* [BoxGeometry.fromDimensions](BoxGeometry.html#.fromDimensions)
* [BoxGeometry.createGeometry](BoxGeometry.html#.createGeometry)
* [Packable](Packable.html)

### Members

#### [](#.packedLength) static Cesium.BoxGeometry.packedLength : number 

[engine/Source/Core/BoxGeometry.js 146](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxGeometry.js#L146) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.BoxGeometry.createGeometry(boxGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/BoxGeometry.js 246](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxGeometry.js#L246) 

 Computes the geometric representation of a box, including its vertices, indices, and a bounding sphere.

| Name        | Type                            | Description               |
| ----------- | ------------------------------- | ------------------------- |
| boxGeometry | [BoxGeometry](BoxGeometry.html) | A description of the box. |

##### Returns:

 The computed vertices and indices.

#### [](#.fromAxisAlignedBoundingBox) static Cesium.BoxGeometry.fromAxisAlignedBoundingBox(boundingBox) → [BoxGeometry](BoxGeometry.html) 

[engine/Source/Core/BoxGeometry.js 131](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxGeometry.js#L131) 

 Creates a cube from the dimensions of an AxisAlignedBoundingBox.

| Name        | Type                                                  | Description                                  |
| ----------- | ----------------------------------------------------- | -------------------------------------------- |
| boundingBox | [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) | A description of the AxisAlignedBoundingBox. |

##### Returns:

##### Example:

```javascript
const aabb = Cesium.AxisAlignedBoundingBox.fromPoints(Cesium.Cartesian3.fromDegreesArray([
     -72.0, 40.0,
     -70.0, 35.0,
     -75.0, 30.0,
     -70.0, 30.0,
     -68.0, 40.0
]));
const box = Cesium.BoxGeometry.fromAxisAlignedBoundingBox(aabb);
```

##### See:

* [BoxGeometry.createGeometry](BoxGeometry.html#.createGeometry)

#### [](#.fromDimensions) static Cesium.BoxGeometry.fromDimensions(options) → [BoxGeometry](BoxGeometry.html) 

[engine/Source/Core/BoxGeometry.js 90](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxGeometry.js#L90) 

 Creates a cube centered at the origin given its dimensions.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                     |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description dimensions [Cartesian3](Cartesian3.html)  The width, depth, and height of the box stored in the x, y, and z coordinates of the Cartesian3, respectively. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. |

##### Returns:

##### Throws:

* [DeveloperError](DeveloperError.html): All dimensions components must be greater than or equal to zero.

##### Example:

```javascript
const box = Cesium.BoxGeometry.fromDimensions({
  vertexFormat : Cesium.VertexFormat.POSITION_ONLY,
  dimensions : new Cesium.Cartesian3(500000.0, 500000.0, 500000.0)
});
const geometry = Cesium.BoxGeometry.createGeometry(box);
```

##### See:

* [BoxGeometry.createGeometry](BoxGeometry.html#.createGeometry)

#### [](#.pack) static Cesium.BoxGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/BoxGeometry.js 158](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxGeometry.js#L158) 

 Stores the provided instance into the provided array.

| Name          | Type                            | Default | Description                                                               |
| ------------- | ------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [BoxGeometry](BoxGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                  |         | The array to pack into.                                                   |
| startingIndex | number                          | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.BoxGeometry.unpack(array, startingIndex, result) → [BoxGeometry](BoxGeometry.html) 

[engine/Source/Core/BoxGeometry.js 202](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxGeometry.js#L202) 

 Retrieves an instance from a packed array.

| Name          | Type                            | Default | Description                                                |
| ------------- | ------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                  |         | The packed array.                                          |
| startingIndex | number                          | 0       | optional The starting index of the element to be unpacked. |
| result        | [BoxGeometry](BoxGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new BoxGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

