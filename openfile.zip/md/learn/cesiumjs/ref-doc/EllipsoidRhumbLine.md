# [![](Images/CesiumLogo.png)](index.html) EllipsoidRhumbLine 

#### [](#EllipsoidRhumbLine) new Cesium.EllipsoidRhumbLine(start, end, ellipsoid) 

[engine/Source/Core/EllipsoidRhumbLine.js 393](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L393) 

 Initializes a rhumb line on the ellipsoid connecting the two provided planetodetic points.

| Name      | Type                              | Default           | Description                                          |
| --------- | --------------------------------- | ----------------- | ---------------------------------------------------- |
| start     | [Cartographic](Cartographic.html) |                   | optional The initial planetodetic point on the path. |
| end       | [Cartographic](Cartographic.html) |                   | optional The final planetodetic point on the path.   |
| ellipsoid | [Ellipsoid](Ellipsoid.html)       | Ellipsoid.default | optional The ellipsoid on which the rhumb line lies. |

##### Throws:

* [DeveloperError](DeveloperError.html): angle between start and end must be at least 0.0125 radians.

### Members

#### [](#ellipsoid) readonly ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/EllipsoidRhumbLine.js 416](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L416) 

 Gets the ellipsoid.

#### [](#end) readonly end : [Cartographic](Cartographic.html) 

[engine/Source/Core/EllipsoidRhumbLine.js 456](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L456) 

 Gets the final planetodetic point on the path.

#### [](#heading) readonly heading : number 

[engine/Source/Core/EllipsoidRhumbLine.js 468](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L468) 

 Gets the heading from the start point to the end point.

#### [](#start) readonly start : [Cartographic](Cartographic.html) 

[engine/Source/Core/EllipsoidRhumbLine.js 444](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L444) 

 Gets the initial planetodetic point on the path.

#### [](#surfaceDistance) readonly surfaceDistance : number 

[engine/Source/Core/EllipsoidRhumbLine.js 428](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L428) 

 Gets the surface distance between the start and end point

### Methods

#### [](#.fromStartHeadingDistance) static Cesium.EllipsoidRhumbLine.fromStartHeadingDistance(start, heading, distance, ellipsoid, result) → [EllipsoidRhumbLine](EllipsoidRhumbLine.html) 

[engine/Source/Core/EllipsoidRhumbLine.js 489](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L489) 

 Create a rhumb line using an initial position with a heading and distance.

| Name      | Type                                          | Default           | Description                                              |
| --------- | --------------------------------------------- | ----------------- | -------------------------------------------------------- |
| start     | [Cartographic](Cartographic.html)             |                   | The initial planetodetic point on the path.              |
| heading   | number                                        |                   | The heading in radians.                                  |
| distance  | number                                        |                   | The rhumb line distance between the start and end point. |
| ellipsoid | [Ellipsoid](Ellipsoid.html)                   | Ellipsoid.default | optional The ellipsoid on which the rhumb line lies.     |
| result    | [EllipsoidRhumbLine](EllipsoidRhumbLine.html) |                   | optional The object in which to store the result.        |

##### Returns:

 The EllipsoidRhumbLine object.

#### [](#findIntersectionWithLatitude) findIntersectionWithLatitude(intersectionLatitude, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/EllipsoidRhumbLine.js 708](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L708) 

 Provides the location of a point at the indicated latitude along the rhumb line. If the latitude is outside the range of start and end points, the first intersection with the latitude from that start point in the direction of the heading is returned. This follows the spiral property of a rhumb line.

| Name                 | Type                              | Description                                                                                                  |
| -------------------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| intersectionLatitude | number                            | The latitude, in radians, at which to find the intersection point from the starting point using the heading. |
| result               | [Cartographic](Cartographic.html) | optional The object in which to store the result.                                                            |

##### Returns:

 The location of the intersection point along the rhumb line, undefined if there is no intersection or infinite intersections.

##### Throws:

* [DeveloperError](DeveloperError.html): start and end must be set before calling function findIntersectionWithLongitude.

#### [](#findIntersectionWithLongitude) findIntersectionWithLongitude(intersectionLongitude, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/EllipsoidRhumbLine.js 604](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L604) 

 Provides the location of a point at the indicated longitude along the rhumb line. If the longitude is outside the range of start and end points, the first intersection with the longitude from the start point in the direction of the heading is returned. This follows the spiral property of a rhumb line.

| Name                  | Type                              | Description                                                                                                   |
| --------------------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| intersectionLongitude | number                            | The longitude, in radians, at which to find the intersection point from the starting point using the heading. |
| result                | [Cartographic](Cartographic.html) | optional The object in which to store the result.                                                             |

##### Returns:

 The location of the intersection point along the rhumb line, undefined if there is no intersection or infinite intersections.

##### Throws:

* [DeveloperError](DeveloperError.html): start and end must be set before calling function findIntersectionWithLongitude.

#### [](#interpolateUsingFraction) interpolateUsingFraction(fraction, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/EllipsoidRhumbLine.js 552](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L552) 

 Provides the location of a point at the indicated portion along the rhumb line.

| Name     | Type                              | Description                                                       |
| -------- | --------------------------------- | ----------------------------------------------------------------- |
| fraction | number                            | The portion of the distance between the initial and final points. |
| result   | [Cartographic](Cartographic.html) | optional The object in which to store the result.                 |

##### Returns:

 The location of the point along the rhumb line.

#### [](#interpolateUsingSurfaceDistance) interpolateUsingSurfaceDistance(distance, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/EllipsoidRhumbLine.js 571](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L571) 

 Provides the location of a point at the indicated distance along the rhumb line.

| Name     | Type                              | Description                                                                       |
| -------- | --------------------------------- | --------------------------------------------------------------------------------- |
| distance | number                            | The distance from the initial point to the point of interest along the rhumbLine. |
| result   | [Cartographic](Cartographic.html) | optional The object in which to store the result.                                 |

##### Returns:

 The location of the point along the rhumb line.

##### Throws:

* [DeveloperError](DeveloperError.html): start and end must be set before calling function interpolateUsingSurfaceDistance

#### [](#setEndPoints) setEndPoints(start, end) 

[engine/Source/Core/EllipsoidRhumbLine.js 536](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidRhumbLine.js#L536) 

 Sets the start and end points of the rhumb line.

| Name  | Type                              | Description                                 |
| ----- | --------------------------------- | ------------------------------------------- |
| start | [Cartographic](Cartographic.html) | The initial planetodetic point on the path. |
| end   | [Cartographic](Cartographic.html) | The final planetodetic point on the path.   |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

