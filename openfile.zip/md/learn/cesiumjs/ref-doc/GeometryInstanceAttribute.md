# [![](Images/CesiumLogo.png)](index.html) GeometryInstanceAttribute 

#### [](#GeometryInstanceAttribute) new Cesium.GeometryInstanceAttribute(options) 

[engine/Source/Core/GeometryInstanceAttribute.js 42](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryInstanceAttribute.js#L42) 

 Values and type information for per-instance geometry attributes.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | Object with the following properties: Name Type Default Description componentDatatype [ComponentDatatype](global.html#ComponentDatatype)  The datatype of each component in the attribute, e.g., individual elements in values. componentsPerAttribute number  A number between 1 and 4 that defines the number of components in an attributes. normalize boolean false optional When true and componentDatatype is an integer format, indicate that the components should be mapped to the range \[0, 1\] (unsigned) or \[-1, 1\] (signed) when they are accessed as floating-point for rendering. value Array.<number>  The value for the attribute. |

##### Throws:

* [DeveloperError](DeveloperError.html): options.componentsPerAttribute must be between 1 and 4.

##### Example:

```javascript
const instance = new Cesium.GeometryInstance({
  geometry : Cesium.BoxGeometry.fromDimensions({
    dimensions : new Cesium.Cartesian3(1000000.0, 1000000.0, 500000.0)
  }),
  modelMatrix : Cesium.Matrix4.multiplyByTranslation(Cesium.Transforms.eastNorthUpToFixedFrame(
    Cesium.Cartesian3.fromDegrees(0.0, 0.0)), new Cesium.Cartesian3(0.0, 0.0, 1000000.0), new Cesium.Matrix4()),
  id : 'box',
  attributes : {
    color : new Cesium.GeometryInstanceAttribute({
      componentDatatype : Cesium.ComponentDatatype.UNSIGNED_BYTE,
      componentsPerAttribute : 4,
      normalize : true,
      value : [255, 255, 0, 255]
    })
  }
});
```

##### See:

* [ColorGeometryInstanceAttribute](ColorGeometryInstanceAttribute.html)
* [ShowGeometryInstanceAttribute](ShowGeometryInstanceAttribute.html)
* [DistanceDisplayConditionGeometryInstanceAttribute](DistanceDisplayConditionGeometryInstanceAttribute.html)

### Members

#### [](#componentDatatype) componentDatatype : [ComponentDatatype](global.html#ComponentDatatype) 

[engine/Source/Core/GeometryInstanceAttribute.js 72](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryInstanceAttribute.js#L72) 

 The datatype of each component in the attribute, e.g., individual elements in[GeometryInstanceAttribute#value](GeometryInstanceAttribute.html#value).

#### [](#componentsPerAttribute) componentsPerAttribute : number 

[engine/Source/Core/GeometryInstanceAttribute.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryInstanceAttribute.js#L89) 

 A number between 1 and 4 that defines the number of components in an attributes. For example, a position attribute with x, y, and z components would have 3 as shown in the code example.

##### Example:

```javascript
show : new Cesium.GeometryInstanceAttribute({
  componentDatatype : Cesium.ComponentDatatype.UNSIGNED_BYTE,
  componentsPerAttribute : 1,
  normalize : true,
  value : [1.0]
})
```

#### [](#normalize) normalize : boolean 

[engine/Source/Core/GeometryInstanceAttribute.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryInstanceAttribute.js#L114) 

 When `true` and `componentDatatype` is an integer format, indicate that the components should be mapped to the range \[0, 1\] (unsigned) or \[-1, 1\] (signed) when they are accessed as floating-point for rendering.

This is commonly used when storing colors using [ComponentDatatype.UNSIGNED\_BYTE](global.html#ComponentDatatype#.UNSIGNED%5FBYTE).

Default Value: `false` 

##### Example:

```javascript
attribute.componentDatatype = Cesium.ComponentDatatype.UNSIGNED_BYTE;
attribute.componentsPerAttribute = 4;
attribute.normalize = true;
attribute.value = [
  Cesium.Color.floatToByte(color.red),
  Cesium.Color.floatToByte(color.green),
  Cesium.Color.floatToByte(color.blue),
  Cesium.Color.floatToByte(color.alpha)
];
```

#### [](#value) value : Array.<number> 

[engine/Source/Core/GeometryInstanceAttribute.js 131](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GeometryInstanceAttribute.js#L131) 

 The values for the attributes stored in a typed array. In the code example, every three elements in `values` defines one attributes since`componentsPerAttribute` is 3.

##### Example:

```javascript
show : new Cesium.GeometryInstanceAttribute({
  componentDatatype : Cesium.ComponentDatatype.UNSIGNED_BYTE,
  componentsPerAttribute : 1,
  normalize : true,
  value : [1.0]
})
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

