# [![](Images/CesiumLogo.png)](index.html) Request 

#### [](#Request) new Cesium.Request(options) 

[engine/Source/Core/Request.js 23](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L23) 

 Stores information for making a request. In general this does not need to be constructed directly.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional An object with the following properties: Name Type Default Description url string optional The url to request. requestFunction [Request.RequestCallback](Request.html#.RequestCallback) optional The function that makes the actual data request. cancelFunction [Request.CancelCallback](Request.html#.CancelCallback) optional The function that is called when the request is cancelled. priorityFunction [Request.PriorityCallback](Request.html#.PriorityCallback) optional The function that is called to update the request's priority, which occurs once per frame. priority number 0.0 optional The initial priority of the request. throttle boolean false optional Whether to throttle and prioritize the request. If false, the request will be sent immediately. If true, the request will be throttled and sent based on priority. throttleByServer boolean false optional Whether to throttle the request by server. type [RequestType](global.html#RequestType) RequestType.OTHER optional The type of request. serverKey string optional A key used to identify the server that a request is going to. |

### Members

#### [](#cancelFunction) cancelFunction : [Request.CancelCallback](Request.html#.CancelCallback) 

[engine/Source/Core/Request.js 48](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L48) 

 The function that is called when the request is cancelled.

#### [](#priority) priority : number 

[engine/Source/Core/Request.js 67](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L67) 

 Priority is a unit-less value where lower values represent higher priority. For world-based objects, this is usually the distance from the camera. A request that does not have a priority function defaults to a priority of 0\. If priorityFunction is defined, this value is updated every frame with the result of that call.

Default Value: `0.0` 

#### [](#priorityFunction) priorityFunction : [Request.PriorityCallback](Request.html#.PriorityCallback) 

[engine/Source/Core/Request.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L55) 

 The function that is called to update the request's priority, which occurs once per frame.

#### [](#requestFunction) requestFunction : [Request.RequestCallback](Request.html#.RequestCallback) 

[engine/Source/Core/Request.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L41) 

 The function that makes the actual data request.

#### [](#state) readonly state : [RequestState](global.html#RequestState) 

[engine/Source/Core/Request.js 117](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L117) 

 The current state of the request.

#### [](#throttle) readonly throttle : boolean 

[engine/Source/Core/Request.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L78) 

 Whether to throttle and prioritize the request. If false, the request will be sent immediately. If true, the request will be throttled and sent based on priority.

Default Value: `false` 

#### [](#throttleByServer) readonly throttleByServer : boolean 

[engine/Source/Core/Request.js 90](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L90) 

 Whether to throttle the request by server. Browsers typically support about 6-8 parallel connections for HTTP/1 servers, and an unlimited amount of connections for HTTP/2 servers. Setting this value to `true` is preferable for requests going through HTTP/1 servers.

Default Value: `false` 

#### [](#type) readonly type : [RequestType](global.html#RequestType) 

[engine/Source/Core/Request.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L100) 

 Type of request.

Default Value: `RequestType.OTHER` 

#### [](#url) url : string 

[engine/Source/Core/Request.js 34](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L34) 

 The URL to request.

### Methods

#### [](#clone) clone(result) → [Request](Request.html) 

[engine/Source/Core/Request.js 154](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L154) 

 Duplicates a Request instance.

| Name   | Type                    | Description                                         |
| ------ | ----------------------- | --------------------------------------------------- |
| result | [Request](Request.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Resource instance if one was not provided.

### Type Definitions

#### [](#.CancelCallback) Cesium.Request.CancelCallback() 

[engine/Source/Core/Request.js 183](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L183) 

 The function that is called when the request is cancelled.

#### [](#.PriorityCallback) Cesium.Request.PriorityCallback() → number 

[engine/Source/Core/Request.js 188](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L188) 

 The function that is called to update the request's priority, which occurs once per frame.

##### Returns:

 The updated priority value.

#### [](#.RequestCallback) Cesium.Request.RequestCallback() → Promise.<void> 

[engine/Source/Core/Request.js 177](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Request.js#L177) 

 The function that makes the actual data request.

##### Returns:

 A promise for the requested data.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

