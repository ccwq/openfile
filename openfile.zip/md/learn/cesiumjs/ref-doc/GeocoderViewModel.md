# [![](Images/CesiumLogo.png)](index.html) GeocoderViewModel 

#### [](#GeocoderViewModel) new Cesium.GeocoderViewModel(options) 

[widgets/Source/Geocoder/GeocoderViewModel.js 36](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L36) 

 The view model for the [Geocoder](Geocoder.html) widget.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | Object with the following properties: Name Type Default Description scene [Scene](Scene.html)  The Scene instance to use. geocoderServices Array.<[GeocoderService](GeocoderService.html)\> optional Geocoder services to use for geocoding queries. If more than one are supplied, suggestions will be gathered for the geocoders that support it, and if no suggestion is selected the result from the first geocoder service wil be used. flightDuration number optional The duration of the camera flight to an entered location, in seconds. destinationFound [Geocoder.DestinationFoundFunction](Geocoder.html#.DestinationFoundFunction) GeocoderViewModel.flyToDestination optional A callback function that is called after a successful geocode. If not supplied, the default behavior is to fly the camera to the result destination. |

### Members

#### [](#.flyToDestination) static Cesium.GeocoderViewModel.flyToDestination : [Geocoder.DestinationFoundFunction](Geocoder.html#.DestinationFoundFunction) 

[widgets/Source/Geocoder/GeocoderViewModel.js 596](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L596) 

 A function to fly to the destination found by a successful geocode.

#### [](#autoComplete) autoComplete : boolean 

[widgets/Source/Geocoder/GeocoderViewModel.js 156](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L156) 

 True if the geocoder should query as the user types to autocomplete

Default Value: `true` 

#### [](#complete) complete : [Event](Event.html) 

[widgets/Source/Geocoder/GeocoderViewModel.js 253](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L253) 

 Gets the event triggered on flight completion.

#### [](#destinationFound) destinationFound : [Geocoder.DestinationFoundFunction](Geocoder.html#.DestinationFoundFunction) 

[widgets/Source/Geocoder/GeocoderViewModel.js 162](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L162) 

 Gets and sets the command called when a geocode destination is found

#### [](#flightDuration) flightDuration : number|undefined 

[widgets/Source/Geocoder/GeocoderViewModel.js 229](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L229) 

 Gets or sets the the duration of the camera flight in seconds. A value of zero causes the camera to instantly switch to the geocoding location. The duration will be computed based on the distance when undefined.

Default Value: `undefined` 

#### [](#isSearchInProgress) isSearchInProgress : boolean 

[widgets/Source/Geocoder/GeocoderViewModel.js 189](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L189) 

 Gets a value indicating whether a search is currently in progress. This property is observable.

#### [](#keepExpanded) keepExpanded : boolean 

[widgets/Source/Geocoder/GeocoderViewModel.js 149](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L149) 

 Gets or sets a value indicating if this instance should always show its text input field.

Default Value: `false` 

#### [](#scene) scene : [Scene](Scene.html) 

[widgets/Source/Geocoder/GeocoderViewModel.js 265](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L265) 

 Gets the scene to control.

#### [](#search) search : [Command](Command.html) 

[widgets/Source/Geocoder/GeocoderViewModel.js 277](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L277) 

 Gets the Command that is executed when the button is clicked.

#### [](#searchText) searchText : string 

[widgets/Source/Geocoder/GeocoderViewModel.js 202](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L202) 

 Gets or sets the text to search for. The text can be an address, or longitude, latitude, and optional height, where longitude and latitude are in degrees and height is in meters.

#### [](#selectedSuggestion) selectedSuggestion : object 

[widgets/Source/Geocoder/GeocoderViewModel.js 289](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L289) 

 Gets the currently selected geocoder search suggestion

#### [](#suggestions) suggestions : Array.<Object> 

[widgets/Source/Geocoder/GeocoderViewModel.js 301](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L301) 

 Gets the list of geocoder search suggestions

### Methods

#### [](#destroy) destroy() 

[widgets/Source/Geocoder/GeocoderViewModel.js 312](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L312) 

 Destroys the widget. Should be called if permanently removing the widget from layout.

#### [](#destroy) destroy() 

[widgets/Source/Geocoder/GeocoderViewModel.js 613](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L613) 

 Destroys the widget. Should be called if permanently removing the widget from layout.

#### [](#isDestroyed) isDestroyed() → boolean 

[widgets/Source/Geocoder/GeocoderViewModel.js 605](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/Geocoder/GeocoderViewModel.js#L605) 

##### Returns:

 true if the object has been destroyed, false otherwise.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

