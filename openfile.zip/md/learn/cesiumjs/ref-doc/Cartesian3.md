# [![](Images/CesiumLogo.png)](index.html) Cartesian3 

#### [](#Cartesian3) new Cesium.Cartesian3(x, y, z) 

[engine/Source/Core/Cartesian3.js 20](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L20) 

 A 3D Cartesian point.

| Name | Type   | Default | Description               |
| ---- | ------ | ------- | ------------------------- |
| x    | number | 0.0     | optional The X component. |
| y    | number | 0.0     | optional The Y component. |
| z    | number | 0.0     | optional The Z component. |

##### See:

* [Cartesian2](Cartesian2.html)
* [Cartesian4](Cartesian4.html)
* [Packable](Packable.html)

### Members

#### [](#x) x : number 

[engine/Source/Core/Cartesian3.js 26](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L26) 

 The X component.

Default Value: `0.0` 

#### [](#y) y : number 

[engine/Source/Core/Cartesian3.js 33](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L33) 

 The Y component.

Default Value: `0.0` 

#### [](#z) z : number 

[engine/Source/Core/Cartesian3.js 40](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L40) 

 The Z component.

Default Value: `0.0` 

#### [](#.ONE) static constant Cesium.Cartesian3.ONE : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 1143](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1143) 

 An immutable Cartesian3 instance initialized to (1.0, 1.0, 1.0).

#### [](#.packedLength) static Cesium.Cartesian3.packedLength : number 

[engine/Source/Core/Cartesian3.js 125](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L125) 

 The number of elements used to pack the object into an array.

#### [](#.UNIT%5FX) static constant Cesium.Cartesian3.UNIT\_X : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 1151](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1151) 

 An immutable Cartesian3 instance initialized to (1.0, 0.0, 0.0).

#### [](#.UNIT%5FY) static constant Cesium.Cartesian3.UNIT\_Y : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 1159](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1159) 

 An immutable Cartesian3 instance initialized to (0.0, 1.0, 0.0).

#### [](#.UNIT%5FZ) static constant Cesium.Cartesian3.UNIT\_Z : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 1167](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1167) 

 An immutable Cartesian3 instance initialized to (0.0, 0.0, 1.0).

#### [](#.ZERO) static constant Cesium.Cartesian3.ZERO : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 1135](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1135) 

 An immutable Cartesian3 instance initialized to (0.0, 0.0, 0.0).

### Methods

#### [](#clone) clone(result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 1175](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1175) 

 Duplicates this Cartesian3 instance.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| result | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/Cartesian3.js 1186](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1186) 

 Compares this Cartesian against the provided Cartesian componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                          | Description                             |
| ----- | ----------------------------- | --------------------------------------- |
| right | [Cartesian3](Cartesian3.html) | optional The right hand side Cartesian. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(right, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/Cartesian3.js 1200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1200) 

 Compares this Cartesian against the provided Cartesian componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                          | Default         | Description                                                          |
| --------------- | ----------------------------- | --------------- | -------------------------------------------------------------------- |
| right           | [Cartesian3](Cartesian3.html) |                 | optional The right hand side Cartesian.                              |
| relativeEpsilon | number                        | 0               | optional The relative epsilon tolerance to use for equality testing. |
| absoluteEpsilon | number                        | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if they are within the provided epsilon, `false` otherwise.

#### [](#toString) toString() → string 

[engine/Source/Core/Cartesian3.js 1218](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1218) 

 Creates a string representing this Cartesian in the format '(x, y, z)'.

##### Returns:

 A string representing this Cartesian in the format '(x, y, z)'.

#### [](#.abs) static Cesium.Cartesian3.abs(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 625](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L625) 

 Computes the absolute value of the provided Cartesian.

| Name      | Type                          | Description                                           |
| --------- | ----------------------------- | ----------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian whose absolute value is to be computed. |
| result    | [Cartesian3](Cartesian3.html) | The object onto which to store the result.            |

##### Returns:

 The modified result parameter.

#### [](#.add) static Cesium.Cartesian3.add(left, right, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 523](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L523) 

 Computes the componentwise sum of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian3](Cartesian3.html) | The first Cartesian.                       |
| right  | [Cartesian3](Cartesian3.html) | The second Cartesian.                      |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.angleBetween) static Cesium.Cartesian3.angleBetween(left, right) → number 

[engine/Source/Core/Cartesian3.js 669](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L669) 

 Returns the angle, in radians, between the provided Cartesians.

| Name  | Type                          | Description           |
| ----- | ----------------------------- | --------------------- |
| left  | [Cartesian3](Cartesian3.html) | The first Cartesian.  |
| right | [Cartesian3](Cartesian3.html) | The second Cartesian. |

##### Returns:

 The angle between the Cartesians.

#### [](#.clamp) static Cesium.Cartesian3.clamp(cartesian, min, max, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 337](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L337) 

 Constrain a value to lie between two values.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian3](Cartesian3.html) | The value to clamp.                        |
| min       | [Cartesian3](Cartesian3.html) | The minimum bound.                         |
| max       | [Cartesian3](Cartesian3.html) | The maximum bound.                         |
| result    | [Cartesian3](Cartesian3.html) | The object into which to store the result. |

##### Returns:

 The clamped value such that min <= value <= max.

#### [](#.clone) static Cesium.Cartesian3.clone(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L96) 

 Duplicates a Cartesian3 instance.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian to duplicate.                         |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if one was not provided. (Returns undefined if cartesian is undefined)

#### [](#.cross) static Cesium.Cartesian3.cross(left, right, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 818](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L818) 

 Computes the cross (outer) product of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian3](Cartesian3.html) | The first Cartesian.                       |
| right  | [Cartesian3](Cartesian3.html) | The second Cartesian.                      |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The cross product.

#### [](#.distance) static Cesium.Cartesian3.distance(left, right) → number 

[engine/Source/Core/Cartesian3.js 397](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L397) 

 Computes the distance between two points.

| Name  | Type                          | Description                                   |
| ----- | ----------------------------- | --------------------------------------------- |
| left  | [Cartesian3](Cartesian3.html) | The first point to compute the distance from. |
| right | [Cartesian3](Cartesian3.html) | The second point to compute the distance to.  |

##### Returns:

 The distance between two points.

##### Example:

```javascript
// Returns 1.0
const d = Cesium.Cartesian3.distance(new Cesium.Cartesian3(1.0, 0.0, 0.0), new Cesium.Cartesian3(2.0, 0.0, 0.0));
```

#### [](#.distanceSquared) static Cesium.Cartesian3.distanceSquared(left, right) → number 

[engine/Source/Core/Cartesian3.js 419](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L419) 

 Computes the squared distance between two points. Comparing squared distances using this function is more efficient than comparing distances using `Cartesian3#distance`.

| Name  | Type                          | Description                                   |
| ----- | ----------------------------- | --------------------------------------------- |
| left  | [Cartesian3](Cartesian3.html) | The first point to compute the distance from. |
| right | [Cartesian3](Cartesian3.html) | The second point to compute the distance to.  |

##### Returns:

 The distance between two points.

##### Example:

```javascript
// Returns 4.0, not 2.0
const d = Cesium.Cartesian3.distanceSquared(new Cesium.Cartesian3(1.0, 0.0, 0.0), new Cesium.Cartesian3(3.0, 0.0, 0.0));
```

#### [](#.divideByScalar) static Cesium.Cartesian3.divideByScalar(cartesian, scalar, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 586](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L586) 

 Divides the provided Cartesian componentwise by the provided scalar.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian to be divided.               |
| scalar    | number                        | The scalar to divide by.                   |
| result    | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.divideComponents) static Cesium.Cartesian3.divideComponents(left, right, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 502](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L502) 

 Computes the componentwise quotient of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian3](Cartesian3.html) | The first Cartesian.                       |
| right  | [Cartesian3](Cartesian3.html) | The second Cartesian.                      |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.dot) static Cesium.Cartesian3.dot(left, right) → number 

[engine/Source/Core/Cartesian3.js 464](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L464) 

 Computes the dot (scalar) product of two Cartesians.

| Name  | Type                          | Description           |
| ----- | ----------------------------- | --------------------- |
| left  | [Cartesian3](Cartesian3.html) | The first Cartesian.  |
| right | [Cartesian3](Cartesian3.html) | The second Cartesian. |

##### Returns:

 The dot product.

#### [](#.equals) static Cesium.Cartesian3.equals(left, right) → boolean 

[engine/Source/Core/Cartesian3.js 746](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L746) 

 Compares the provided Cartesians componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                          | Description                    |
| ----- | ----------------------------- | ------------------------------ |
| left  | [Cartesian3](Cartesian3.html) | optional The first Cartesian.  |
| right | [Cartesian3](Cartesian3.html) | optional The second Cartesian. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

#### [](#.equalsEpsilon) static Cesium.Cartesian3.equalsEpsilon(left, right, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/Cartesian3.js 779](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L779) 

 Compares the provided Cartesians componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                          | Default         | Description                                                          |
| --------------- | ----------------------------- | --------------- | -------------------------------------------------------------------- |
| left            | [Cartesian3](Cartesian3.html) |                 | optional The first Cartesian.                                        |
| right           | [Cartesian3](Cartesian3.html) |                 | optional The second Cartesian.                                       |
| relativeEpsilon | number                        | 0               | optional The relative epsilon tolerance to use for equality testing. |
| absoluteEpsilon | number                        | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if left and right are within the provided epsilon, `false` otherwise.

#### [](#.fromArray) static Cesium.Cartesian3.fromArray(array, startingIndex, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 255](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L255) 

 Creates a Cartesian3 from three consecutive elements in an array.

| Name          | Type                          | Default | Description                                                                                        |
| ------------- | ----------------------------- | ------- | -------------------------------------------------------------------------------------------------- |
| array         | Array.<number>                |         | The array whose three consecutive elements correspond to the x, y, and z components, respectively. |
| startingIndex | number                        | 0       | optional The offset into the array of the first element, which corresponds to the x component.     |
| result        | [Cartesian3](Cartesian3.html) |         | optional The object onto which to store the result.                                                |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if one was not provided.

##### Example:

```javascript
// Create a Cartesian3 with (1.0, 2.0, 3.0)
const v = [1.0, 2.0, 3.0];
const p = Cesium.Cartesian3.fromArray(v);

// Create a Cartesian3 with (1.0, 2.0, 3.0) using an offset into an array
const v2 = [0.0, 0.0, 1.0, 2.0, 3.0];
const p2 = Cesium.Cartesian3.fromArray(v2, 2);
```

#### [](#.fromCartesian4) static Cesium.Cartesian3.fromCartesian4(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 119](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L119) 

 Creates a Cartesian3 instance from an existing Cartesian4\. This simply takes the x, y, and z properties of the Cartesian4 and drops w.

| Name      | Type                          | Description                                                   |
| --------- | ----------------------------- | ------------------------------------------------------------- |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian4 instance to create a Cartesian3 instance from. |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result.           |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if one was not provided.

#### [](#.fromDegrees) static Cesium.Cartesian3.fromDegrees(longitude, latitude, height, ellipsoid, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 876](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L876) 

 Returns a Cartesian3 position from longitude and latitude values given in degrees.

| Name      | Type                          | Default           | Description                                          |
| --------- | ----------------------------- | ----------------- | ---------------------------------------------------- |
| longitude | number                        |                   | The longitude, in degrees                            |
| latitude  | number                        |                   | The latitude, in degrees                             |
| height    | number                        | 0.0               | optional The height, in meters, above the ellipsoid. |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | Ellipsoid.default | optional The ellipsoid on which the position lies.   |
| result    | [Cartesian3](Cartesian3.html) |                   | optional The object onto which to store the result.  |

##### Returns:

 The position

##### Example:

```javascript
const position = Cesium.Cartesian3.fromDegrees(-115.0, 37.0);
```

#### [](#.fromDegreesArray) static Cesium.Cartesian3.fromDegreesArray(coordinates, ellipsoid, result) → Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/Cartesian3.js 962](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L962) 

 Returns an array of Cartesian3 positions given an array of longitude and latitude values given in degrees.

| Name        | Type                                   | Default           | Description                                                                                                |
| ----------- | -------------------------------------- | ----------------- | ---------------------------------------------------------------------------------------------------------- |
| coordinates | Array.<number>                         |                   | A list of longitude and latitude values. Values alternate \[longitude, latitude, longitude, latitude...\]. |
| ellipsoid   | [Ellipsoid](Ellipsoid.html)            | Ellipsoid.default | optional The ellipsoid on which the coordinates lie.                                                       |
| result      | Array.<[Cartesian3](Cartesian3.html)\> |                   | optional An array of Cartesian3 objects to store the result.                                               |

##### Returns:

 The array of positions.

##### Example:

```javascript
const positions = Cesium.Cartesian3.fromDegreesArray([-115.0, 37.0, -107.0, 33.0]);
```

#### [](#.fromDegreesArrayHeights) static Cesium.Cartesian3.fromDegreesArrayHeights(coordinates, ellipsoid, result) → Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/Cartesian3.js 1050](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1050) 

 Returns an array of Cartesian3 positions given an array of longitude, latitude and height values where longitude and latitude are given in degrees.

| Name        | Type                                   | Default           | Description                                                                                                                        |
| ----------- | -------------------------------------- | ----------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| coordinates | Array.<number>                         |                   | A list of longitude, latitude and height values. Values alternate \[longitude, latitude, height, longitude, latitude, height...\]. |
| ellipsoid   | [Ellipsoid](Ellipsoid.html)            | Ellipsoid.default | optional The ellipsoid on which the position lies.                                                                                 |
| result      | Array.<[Cartesian3](Cartesian3.html)\> |                   | optional An array of Cartesian3 objects to store the result.                                                                       |

##### Returns:

 The array of positions.

##### Example:

```javascript
const positions = Cesium.Cartesian3.fromDegreesArrayHeights([-115.0, 37.0, 100000.0, -107.0, 33.0, 150000.0]);
```

#### [](#.fromElements) static Cesium.Cartesian3.fromElements(x, y, z, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L78) 

 Creates a Cartesian3 instance from x, y and z coordinates.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| x      | number                        | The x coordinate.                                   |
| y      | number                        | The y coordinate.                                   |
| z      | number                        | The z coordinate.                                   |
| result | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if one was not provided.

#### [](#.fromRadians) static Cesium.Cartesian3.fromRadians(longitude, latitude, height, ellipsoid, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 916](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L916) 

 Returns a Cartesian3 position from longitude and latitude values given in radians.

| Name      | Type                          | Default           | Description                                          |
| --------- | ----------------------------- | ----------------- | ---------------------------------------------------- |
| longitude | number                        |                   | The longitude, in radians                            |
| latitude  | number                        |                   | The latitude, in radians                             |
| height    | number                        | 0.0               | optional The height, in meters, above the ellipsoid. |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | Ellipsoid.default | optional The ellipsoid on which the position lies.   |
| result    | [Cartesian3](Cartesian3.html) |                   | optional The object onto which to store the result.  |

##### Returns:

 The position

##### Example:

```javascript
const position = Cesium.Cartesian3.fromRadians(-2.007, 0.645);
```

#### [](#.fromRadiansArray) static Cesium.Cartesian3.fromRadiansArray(coordinates, ellipsoid, result) → Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/Cartesian3.js 1006](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1006) 

 Returns an array of Cartesian3 positions given an array of longitude and latitude values given in radians.

| Name        | Type                                   | Default           | Description                                                                                                |
| ----------- | -------------------------------------- | ----------------- | ---------------------------------------------------------------------------------------------------------- |
| coordinates | Array.<number>                         |                   | A list of longitude and latitude values. Values alternate \[longitude, latitude, longitude, latitude...\]. |
| ellipsoid   | [Ellipsoid](Ellipsoid.html)            | Ellipsoid.default | optional The ellipsoid on which the coordinates lie.                                                       |
| result      | Array.<[Cartesian3](Cartesian3.html)\> |                   | optional An array of Cartesian3 objects to store the result.                                               |

##### Returns:

 The array of positions.

##### Example:

```javascript
const positions = Cesium.Cartesian3.fromRadiansArray([-2.007, 0.645, -1.867, .575]);
```

#### [](#.fromRadiansArrayHeights) static Cesium.Cartesian3.fromRadiansArrayHeights(coordinates, ellipsoid, result) → Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/Cartesian3.js 1095](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L1095) 

 Returns an array of Cartesian3 positions given an array of longitude, latitude and height values where longitude and latitude are given in radians.

| Name        | Type                                   | Default           | Description                                                                                                                        |
| ----------- | -------------------------------------- | ----------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| coordinates | Array.<number>                         |                   | A list of longitude, latitude and height values. Values alternate \[longitude, latitude, height, longitude, latitude, height...\]. |
| ellipsoid   | [Ellipsoid](Ellipsoid.html)            | Ellipsoid.default | optional The ellipsoid on which the position lies.                                                                                 |
| result      | Array.<[Cartesian3](Cartesian3.html)\> |                   | optional An array of Cartesian3 objects to store the result.                                                                       |

##### Returns:

 The array of positions.

##### Example:

```javascript
const positions = Cesium.Cartesian3.fromRadiansArrayHeights([-2.007, 0.645, 100000.0, -1.867, .575, 150000.0]);
```

#### [](#.fromSpherical) static Cesium.Cartesian3.fromSpherical(spherical, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 50](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L50) 

 Converts the provided Spherical into Cartesian3 coordinates.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| spherical | [Spherical](Spherical.html)   | The Spherical to be converted to Cartesian3.        |
| result    | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if one was not provided.

#### [](#.lerp) static Cesium.Cartesian3.lerp(start, end, t, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 647](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L647) 

 Computes the linear interpolation or extrapolation at t using the provided cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| start  | [Cartesian3](Cartesian3.html) | The value corresponding to t at 0.0.       |
| end    | [Cartesian3](Cartesian3.html) | The value corresponding to t at 1.0.       |
| t      | number                        | The point along t at which to interpolate. |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.magnitude) static Cesium.Cartesian3.magnitude(cartesian) → number 

[engine/Source/Core/Cartesian3.js 380](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L380) 

 Computes the Cartesian's magnitude (length).

| Name      | Type                          | Description                                               |
| --------- | ----------------------------- | --------------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian instance whose magnitude is to be computed. |

##### Returns:

 The magnitude.

#### [](#.magnitudeSquared) static Cesium.Cartesian3.magnitudeSquared(cartesian) → number 

[engine/Source/Core/Cartesian3.js 362](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L362) 

 Computes the provided Cartesian's squared magnitude.

| Name      | Type                          | Description                                                       |
| --------- | ----------------------------- | ----------------------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian instance whose squared magnitude is to be computed. |

##### Returns:

 The squared magnitude.

#### [](#.maximumByComponent) static Cesium.Cartesian3.maximumByComponent(first, second, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 315](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L315) 

 Compares two Cartesians and computes a Cartesian which contains the maximum components of the supplied Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| first  | [Cartesian3](Cartesian3.html) | A cartesian to compare.                    |
| second | [Cartesian3](Cartesian3.html) | A cartesian to compare.                    |
| result | [Cartesian3](Cartesian3.html) | The object into which to store the result. |

##### Returns:

 A cartesian with the maximum components.

#### [](#.maximumComponent) static Cesium.Cartesian3.maximumComponent(cartesian) → number 

[engine/Source/Core/Cartesian3.js 263](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L263) 

 Computes the value of the maximum component for the supplied Cartesian.

| Name      | Type                          | Description           |
| --------- | ----------------------------- | --------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The cartesian to use. |

##### Returns:

 The value of the maximum component.

#### [](#.midpoint) static Cesium.Cartesian3.midpoint(left, right, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 849](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L849) 

 Computes the midpoint between the right and left Cartesian.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian3](Cartesian3.html) | The first Cartesian.                       |
| right  | [Cartesian3](Cartesian3.html) | The second Cartesian.                      |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The midpoint.

#### [](#.minimumByComponent) static Cesium.Cartesian3.minimumByComponent(first, second, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 293](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L293) 

 Compares two Cartesians and computes a Cartesian which contains the minimum components of the supplied Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| first  | [Cartesian3](Cartesian3.html) | A cartesian to compare.                    |
| second | [Cartesian3](Cartesian3.html) | A cartesian to compare.                    |
| result | [Cartesian3](Cartesian3.html) | The object into which to store the result. |

##### Returns:

 A cartesian with the minimum components.

#### [](#.minimumComponent) static Cesium.Cartesian3.minimumComponent(cartesian) → number 

[engine/Source/Core/Cartesian3.js 277](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L277) 

 Computes the value of the minimum component for the supplied Cartesian.

| Name      | Type                          | Description           |
| --------- | ----------------------------- | --------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The cartesian to use. |

##### Returns:

 The value of the minimum component.

#### [](#.mostOrthogonalAxis) static Cesium.Cartesian3.mostOrthogonalAxis(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 696](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L696) 

 Returns the axis that is most orthogonal to the provided Cartesian.

| Name      | Type                          | Description                                              |
| --------- | ----------------------------- | -------------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian on which to find the most orthogonal axis. |
| result    | [Cartesian3](Cartesian3.html) | The object onto which to store the result.               |

##### Returns:

 The most orthogonal axis.

#### [](#.multiplyByScalar) static Cesium.Cartesian3.multiplyByScalar(cartesian, scalar, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 565](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L565) 

 Multiplies the provided Cartesian componentwise by the provided scalar.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian to be scaled.                |
| scalar    | number                        | The scalar to multiply with.               |
| result    | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiplyComponents) static Cesium.Cartesian3.multiplyComponents(left, right, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 481](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L481) 

 Computes the componentwise product of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian3](Cartesian3.html) | The first Cartesian.                       |
| right  | [Cartesian3](Cartesian3.html) | The second Cartesian.                      |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.negate) static Cesium.Cartesian3.negate(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 606](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L606) 

 Negates the provided Cartesian.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian to be negated.               |
| result    | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.normalize) static Cesium.Cartesian3.normalize(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 436](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L436) 

 Computes the normalized form of the supplied Cartesian.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| cartesian | [Cartesian3](Cartesian3.html) | The Cartesian to be normalized.            |
| result    | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.pack) static Cesium.Cartesian3.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/Cartesian3.js 136](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L136) 

 Stores the provided instance into the provided array.

| Name          | Type                          | Default | Description                                                               |
| ------------- | ----------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [Cartesian3](Cartesian3.html) |         | The value to pack.                                                        |
| array         | Array.<number>                |         | The array to pack into.                                                   |
| startingIndex | number                        | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.packArray) static Cesium.Cartesian3.packArray(array, result) → Array.<number> 

[engine/Source/Core/Cartesian3.js 182](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L182) 

 Flattens an array of Cartesian3s into an array of components.

| Name   | Type                                   | Description                                                                                                                                                                                                                                                             |
| ------ | -------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| array  | Array.<[Cartesian3](Cartesian3.html)\> | The array of cartesians to pack.                                                                                                                                                                                                                                        |
| result | Array.<number>                         | optional The array onto which to store the result. If this is a typed array, it must have array.length \* 3 components, else a [DeveloperError](DeveloperError.html) will be thrown. If it is a regular array, it will be resized to have (array.length \* 3) elements. |

##### Returns:

 The packed array.

#### [](#.projectVector) static Cesium.Cartesian3.projectVector(a, b, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 727](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L727) 

 Projects vector a onto vector b

| Name   | Type                          | Description                      |
| ------ | ----------------------------- | -------------------------------- |
| a      | [Cartesian3](Cartesian3.html) | The vector that needs projecting |
| b      | [Cartesian3](Cartesian3.html) | The vector to project onto       |
| result | [Cartesian3](Cartesian3.html) | The result cartesian             |

##### Returns:

 The modified result parameter

#### [](#.subtract) static Cesium.Cartesian3.subtract(left, right, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 544](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L544) 

 Computes the componentwise difference of two Cartesians.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| left   | [Cartesian3](Cartesian3.html) | The first Cartesian.                       |
| right  | [Cartesian3](Cartesian3.html) | The second Cartesian.                      |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.unpack) static Cesium.Cartesian3.unpack(array, startingIndex, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Cartesian3.js 159](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L159) 

 Retrieves an instance from a packed array.

| Name          | Type                          | Default | Description                                                |
| ------------- | ----------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                |         | The packed array.                                          |
| startingIndex | number                        | 0       | optional The starting index of the element to be unpacked. |
| result        | [Cartesian3](Cartesian3.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if one was not provided.

#### [](#.unpackArray) static Cesium.Cartesian3.unpackArray(array, result) → Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/Cartesian3.js 214](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Cartesian3.js#L214) 

 Unpacks an array of cartesian components into an array of Cartesian3s.

| Name   | Type                                   | Description                                        |
| ------ | -------------------------------------- | -------------------------------------------------- |
| array  | Array.<number>                         | The array of components to unpack.                 |
| result | Array.<[Cartesian3](Cartesian3.html)\> | optional The array onto which to store the result. |

##### Returns:

 The unpacked array.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

