# [![](Images/CesiumLogo.png)](index.html) BaseLayerPickerViewModel 

#### [](#BaseLayerPickerViewModel) new Cesium.BaseLayerPickerViewModel(options) 

[widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js#L27) 

 The view model for [BaseLayerPicker](BaseLayerPicker.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description globe [Globe](Globe.html)  The Globe to use. imageryProviderViewModels Array.<[ProviderViewModel](ProviderViewModel.html)\> \[\] optional The array of ProviderViewModel instances to use for imagery. selectedImageryProviderViewModel [ProviderViewModel](ProviderViewModel.html) optional The view model for the current base imagery layer, if not supplied the first available imagery layer is used. terrainProviderViewModels Array.<[ProviderViewModel](ProviderViewModel.html)\> \[\] optional The array of ProviderViewModel instances to use for terrain. selectedTerrainProviderViewModel [ProviderViewModel](ProviderViewModel.html) optional The view model for the current base terrain layer, if not supplied the first available terrain layer is used. |

##### Throws:

* [DeveloperError](DeveloperError.html): imageryProviderViewModels must be an array.
* [DeveloperError](DeveloperError.html): terrainProviderViewModels must be an array.

### Members

#### [](#buttonImageUrl) buttonImageUrl : string 

[widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js 165](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js#L165) 

 Gets the button background image. This property is observable.

#### [](#buttonTooltip) buttonTooltip : string 

[widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js 141](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js#L141) 

 Gets the button tooltip. This property is observable.

#### [](#dropDownVisible) dropDownVisible : boolean 

[widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js 67](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js#L67) 

 Gets or sets whether the imagery selection drop-down is currently visible.

Default Value: `false` 

#### [](#globe) globe : [Globe](Globe.html) 

[widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js 331](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js#L331) 

 Gets the globe.

#### [](#imageryProviderViewModels) imageryProviderViewModels : Array.<[ProviderViewModel](ProviderViewModel.html)\> 

[widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js 53](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js#L53) 

 Gets or sets an array of ProviderViewModel instances available for imagery selection. This property is observable.

#### [](#selectedImagery) selectedImagery : [ProviderViewModel](ProviderViewModel.html) 

[widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js 178](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js#L178) 

 Gets or sets the currently selected imagery. This property is observable.

Default Value: `undefined` 

#### [](#selectedTerrain) selectedTerrain : [ProviderViewModel](ProviderViewModel.html) 

[widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js 245](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js#L245) 

 Gets or sets the currently selected terrain. This property is observable.

Default Value: `undefined` 

#### [](#terrainProviderViewModels) terrainProviderViewModels : Array.<[ProviderViewModel](ProviderViewModel.html)\> 

[widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js#L60) 

 Gets or sets an array of ProviderViewModel instances available for terrain selection. This property is observable.

#### [](#toggleDropDown) toggleDropDown : [Command](Command.html) 

[widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js 319](https://github.com/CesiumGS/cesium/blob/1.127/packages/widgets/Source/BaseLayerPicker/BaseLayerPickerViewModel.js#L319) 

 Gets the command to toggle the visibility of the drop down.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

