# [![](Images/CesiumLogo.png)](index.html) TimeInterval 

#### [](#TimeInterval) new Cesium.TimeInterval(options) 

[engine/Source/Core/TimeInterval.js 60](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L60) 

 An interval defined by a start and a stop time; optionally including those times as part of the interval. Arbitrary data can optionally be associated with each instance for used with [TimeIntervalCollection](TimeIntervalCollection.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description start [JulianDate](JulianDate.html) new JulianDate() optional The start time of the interval. stop [JulianDate](JulianDate.html) new JulianDate() optional The stop time of the interval. isStartIncluded boolean true optional true if options.start is included in the interval, false otherwise. isStopIncluded boolean true optional true if options.stop is included in the interval, false otherwise. data object optional Arbitrary data associated with this interval. |

##### Examples:

```javascript
// Create an instance that spans August 1st, 1980 and is associated
// with a Cartesian position.
const timeInterval = new Cesium.TimeInterval({
    start : Cesium.JulianDate.fromIso8601('1980-08-01T00:00:00Z'),
    stop : Cesium.JulianDate.fromIso8601('1980-08-02T00:00:00Z'),
    isStartIncluded : true,
    isStopIncluded : false,
    data : Cesium.Cartesian3.fromDegrees(39.921037, -75.170082)
});
```

```javascript
// Create two instances from ISO 8601 intervals with associated numeric data
// then compute their intersection, summing the data they contain.
const left = Cesium.TimeInterval.fromIso8601({
    iso8601 : '2000/2010',
    data : 2
});

const right = Cesium.TimeInterval.fromIso8601({
    iso8601 : '1995/2005',
    data : 3
});

//The result of the below intersection will be an interval equivalent to
//const intersection = Cesium.TimeInterval.fromIso8601({
//  iso8601 : '2000/2005',
//  data : 5
//});
const intersection = new Cesium.TimeInterval();
Cesium.TimeInterval.intersect(left, right, intersection, function(leftData, rightData) {
    return leftData + rightData;
});
```

```javascript
// Check if an interval contains a specific time.
const dateToCheck = Cesium.JulianDate.fromIso8601('1982-09-08T11:30:00Z');
const containsDate = Cesium.TimeInterval.contains(timeInterval, dateToCheck);
```

### Members

#### [](#.EMPTY) static constant Cesium.TimeInterval.EMPTY : [TimeInterval](TimeInterval.html) 

[engine/Source/Core/TimeInterval.js 413](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L413) 

 An immutable empty interval.

#### [](#data) data : \* 

[engine/Source/Core/TimeInterval.js 82](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L82) 

 Gets or sets the data associated with this interval.

#### [](#isEmpty) readonly isEmpty : boolean 

[engine/Source/Core/TimeInterval.js 106](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L106) 

 Gets whether or not this interval is empty.

#### [](#isStartIncluded) isStartIncluded : boolean 

[engine/Source/Core/TimeInterval.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L89) 

 Gets or sets whether or not the start time is included in this interval.

Default Value: `true` 

#### [](#isStopIncluded) isStopIncluded : boolean 

[engine/Source/Core/TimeInterval.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L96) 

 Gets or sets whether or not the stop time is included in this interval.

Default Value: `true` 

#### [](#start) start : [JulianDate](JulianDate.html) 

[engine/Source/Core/TimeInterval.js 66](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L66) 

 Gets or sets the start time of this interval.

#### [](#stop) stop : [JulianDate](JulianDate.html) 

[engine/Source/Core/TimeInterval.js 74](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L74) 

 Gets or sets the stop time of this interval.

### Methods

#### [](#.clone) static Cesium.TimeInterval.clone(timeInterval, result) → [TimeInterval](TimeInterval.html) 

[engine/Source/Core/TimeInterval.js 199](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L199) 

 Duplicates the provided instance.

| Name         | Type                              | Description                                          |
| ------------ | --------------------------------- | ---------------------------------------------------- |
| timeInterval | [TimeInterval](TimeInterval.html) | optional The instance to clone.                      |
| result       | [TimeInterval](TimeInterval.html) | optional An existing instance to use for the result. |

##### Returns:

 The modified result parameter or a new instance if none was provided.

#### [](#.contains) static Cesium.TimeInterval.contains(timeInterval, julianDate) → boolean 

[engine/Source/Core/TimeInterval.js 336](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L336) 

 Checks if the specified date is inside the provided interval.

| Name         | Type                              | Description        |
| ------------ | --------------------------------- | ------------------ |
| timeInterval | [TimeInterval](TimeInterval.html) | The interval.      |
| julianDate   | [JulianDate](JulianDate.html)     | The date to check. |

##### Returns:

`true` if the interval contains the specified date, `false` otherwise.

#### [](#.equals) static Cesium.TimeInterval.equals(left, right, dataComparer) → boolean 

[engine/Source/Core/TimeInterval.js 222](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L222) 

 Compares two instances and returns `true` if they are equal, `false` otherwise.

| Name         | Type                                                         | Description                                                                                               |
| ------------ | ------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------- |
| left         | [TimeInterval](TimeInterval.html)                            | optional The first instance.                                                                              |
| right        | [TimeInterval](TimeInterval.html)                            | optional The second instance.                                                                             |
| dataComparer | [TimeInterval.DataComparer](TimeInterval.html#.DataComparer) | optional A function which compares the data of the two intervals. If omitted, reference equality is used. |

##### Returns:

`true` if the dates are equal; otherwise, `false`.

#### [](#.equalsEpsilon) static Cesium.TimeInterval.equalsEpsilon(left, right, epsilon, dataComparer) → boolean 

[engine/Source/Core/TimeInterval.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L249) 

 Compares two instances and returns `true` if they are within `epsilon` seconds of each other. That is, in order for the dates to be considered equal (and for this function to return `true`), the absolute value of the difference between them, in seconds, must be less than `epsilon`.

| Name         | Type                                                         | Default | Description                                                                                               |
| ------------ | ------------------------------------------------------------ | ------- | --------------------------------------------------------------------------------------------------------- |
| left         | [TimeInterval](TimeInterval.html)                            |         | optional The first instance.                                                                              |
| right        | [TimeInterval](TimeInterval.html)                            |         | optional The second instance.                                                                             |
| epsilon      | number                                                       | 0       | optional The maximum number of seconds that should separate the two instances.                            |
| dataComparer | [TimeInterval.DataComparer](TimeInterval.html#.DataComparer) |         | optional A function which compares the data of the two intervals. If omitted, reference equality is used. |

##### Returns:

`true` if the two dates are within `epsilon` seconds of each other; otherwise `false`.

#### [](#.fromIso8601) static Cesium.TimeInterval.fromIso8601(options, result) → [TimeInterval](TimeInterval.html) 

[engine/Source/Core/TimeInterval.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L139) 

 Creates a new instance from a [ISO 8601](http://en.wikipedia.org/wiki/ISO%5F8601) interval.

| Name    | Type                              | Description                                                                                                                                                                                                                                                                                                                                                                                    |
| ------- | --------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object                            | Object with the following properties: Name Type Default Description iso8601 string  An ISO 8601 interval. isStartIncluded boolean true optional true if options.start is included in the interval, false otherwise. isStopIncluded boolean true optional true if options.stop is included in the interval, false otherwise. data object optional Arbitrary data associated with this interval. |
| result  | [TimeInterval](TimeInterval.html) | optional An existing instance to use for the result.                                                                                                                                                                                                                                                                                                                                           |

##### Returns:

 The modified result parameter or a new instance if none was provided.

##### Throws:

* DeveloperError if options.iso8601 does not match proper formatting.

#### [](#.intersect) static Cesium.TimeInterval.intersect(left, right, result, mergeCallback) → [TimeInterval](TimeInterval.html) 

[engine/Source/Core/TimeInterval.js 275](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L275) 

 Computes the intersection of two intervals, optionally merging their data.

| Name          | Type                                                           | Description                                                                                                               |
| ------------- | -------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| left          | [TimeInterval](TimeInterval.html)                              | The first interval.                                                                                                       |
| right         | [TimeInterval](TimeInterval.html)                              | optional The second interval.                                                                                             |
| result        | [TimeInterval](TimeInterval.html)                              | optional An existing instance to use for the result.                                                                      |
| mergeCallback | [TimeInterval.MergeCallback](TimeInterval.html#.MergeCallback) | optional A function which merges the data of the two intervals. If omitted, the data from the left interval will be used. |

##### Returns:

 The modified result parameter.

#### [](#.toIso8601) static Cesium.TimeInterval.toIso8601(timeInterval, precision) → string 

[engine/Source/Core/TimeInterval.js 181](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L181) 

 Creates an ISO8601 representation of the provided interval.

| Name         | Type                              | Description                                                                                                                            |
| ------------ | --------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| timeInterval | [TimeInterval](TimeInterval.html) | The interval to be converted.                                                                                                          |
| precision    | number                            | optional The number of fractional digits used to represent the seconds component. By default, the most precise representation is used. |

##### Returns:

 The ISO8601 representation of the provided interval.

#### [](#clone) clone(result) → [TimeInterval](TimeInterval.html) 

[engine/Source/Core/TimeInterval.js 368](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L368) 

 Duplicates this instance.

| Name   | Type                              | Description                                          |
| ------ | --------------------------------- | ---------------------------------------------------- |
| result | [TimeInterval](TimeInterval.html) | optional An existing instance to use for the result. |

##### Returns:

 The modified result parameter or a new instance if none was provided.

#### [](#equals) equals(right, dataComparer) → boolean 

[engine/Source/Core/TimeInterval.js 380](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L380) 

 Compares this instance against the provided instance componentwise and returns`true` if they are equal, `false` otherwise.

| Name         | Type                                                         | Description                                                                                               |
| ------------ | ------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------- |
| right        | [TimeInterval](TimeInterval.html)                            | optional The right hand side interval.                                                                    |
| dataComparer | [TimeInterval.DataComparer](TimeInterval.html#.DataComparer) | optional A function which compares the data of the two intervals. If omitted, reference equality is used. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(right, epsilon, dataComparer) → boolean 

[engine/Source/Core/TimeInterval.js 394](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L394) 

 Compares this instance against the provided instance componentwise and returns`true` if they are within the provided epsilon,`false` otherwise.

| Name         | Type                                                         | Default | Description                                                                                               |
| ------------ | ------------------------------------------------------------ | ------- | --------------------------------------------------------------------------------------------------------- |
| right        | [TimeInterval](TimeInterval.html)                            |         | optional The right hand side interval.                                                                    |
| epsilon      | number                                                       | 0       | optional The epsilon to use for equality testing.                                                         |
| dataComparer | [TimeInterval.DataComparer](TimeInterval.html#.DataComparer) |         | optional A function which compares the data of the two intervals. If omitted, reference equality is used. |

##### Returns:

`true` if they are within the provided epsilon, `false` otherwise.

#### [](#toString) toString() → string 

[engine/Source/Core/TimeInterval.js 403](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L403) 

 Creates a string representing this TimeInterval in ISO8601 format.

##### Returns:

 A string representing this TimeInterval in ISO8601 format.

### Type Definitions

#### [](#.DataComparer) Cesium.TimeInterval.DataComparer(leftData, rightData) → boolean 

[engine/Source/Core/TimeInterval.js 431](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L431) 

 Function interface for comparing interval data.

| Name      | Type | Description               |
| --------- | ---- | ------------------------- |
| leftData  | \*   | The first data instance.  |
| rightData | \*   | The second data instance. |

##### Returns:

`true` if the provided instances are equal, `false` otherwise.

#### [](#.MergeCallback) Cesium.TimeInterval.MergeCallback(leftData, rightData) → \* 

[engine/Source/Core/TimeInterval.js 422](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TimeInterval.js#L422) 

 Function interface for merging interval data.

| Name      | Type | Description               |
| --------- | ---- | ------------------------- |
| leftData  | \*   | The first data instance.  |
| rightData | \*   | The second data instance. |

##### Returns:

 The result of merging the two data instances.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

