# [![](Images/CesiumLogo.png)](index.html) Math 

#### [](#Math) Math() 

[engine/Source/Core/Math.js 13](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L13) 

 Math functions.

### Members

#### [](#.DEGREES%5FPER%5FRADIAN) static constant Cesium.Math.DEGREES\_PER\_RADIAN : number 

[engine/Source/Core/Math.js 423](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L423) 

 The number of degrees in a radian.

#### [](#.EPSILON1) static constant Cesium.Math.EPSILON1 : number 

[engine/Source/Core/Math.js 20](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L20) 

 0.1

#### [](#.EPSILON2) static constant Cesium.Math.EPSILON2 : number 

[engine/Source/Core/Math.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L27) 

 0.01

#### [](#.EPSILON3) static constant Cesium.Math.EPSILON3 : number 

[engine/Source/Core/Math.js 34](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L34) 

 0.001

#### [](#.EPSILON4) static constant Cesium.Math.EPSILON4 : number 

[engine/Source/Core/Math.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L41) 

 0.0001

#### [](#.EPSILON5) static constant Cesium.Math.EPSILON5 : number 

[engine/Source/Core/Math.js 48](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L48) 

 0.00001

#### [](#.EPSILON6) static constant Cesium.Math.EPSILON6 : number 

[engine/Source/Core/Math.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L55) 

 0.000001

#### [](#.EPSILON7) static constant Cesium.Math.EPSILON7 : number 

[engine/Source/Core/Math.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L62) 

 0.0000001

#### [](#.EPSILON8) static constant Cesium.Math.EPSILON8 : number 

[engine/Source/Core/Math.js 69](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L69) 

 0.00000001

#### [](#.EPSILON9) static constant Cesium.Math.EPSILON9 : number 

[engine/Source/Core/Math.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L76) 

 0.000000001

#### [](#.EPSILON10) static constant Cesium.Math.EPSILON10 : number 

[engine/Source/Core/Math.js 83](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L83) 

 0.0000000001

#### [](#.EPSILON11) static constant Cesium.Math.EPSILON11 : number 

[engine/Source/Core/Math.js 90](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L90) 

 0.00000000001

#### [](#.EPSILON12) static constant Cesium.Math.EPSILON12 : number 

[engine/Source/Core/Math.js 97](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L97) 

 0.000000000001

#### [](#.EPSILON13) static constant Cesium.Math.EPSILON13 : number 

[engine/Source/Core/Math.js 104](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L104) 

 0.0000000000001

#### [](#.EPSILON14) static constant Cesium.Math.EPSILON14 : number 

[engine/Source/Core/Math.js 111](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L111) 

 0.00000000000001

#### [](#.EPSILON15) static constant Cesium.Math.EPSILON15 : number 

[engine/Source/Core/Math.js 118](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L118) 

 0.000000000000001

#### [](#.EPSILON16) static constant Cesium.Math.EPSILON16 : number 

[engine/Source/Core/Math.js 125](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L125) 

 0.0000000000000001

#### [](#.EPSILON17) static constant Cesium.Math.EPSILON17 : number 

[engine/Source/Core/Math.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L132) 

 0.00000000000000001

#### [](#.EPSILON18) static constant Cesium.Math.EPSILON18 : number 

[engine/Source/Core/Math.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L139) 

 0.000000000000000001

#### [](#.EPSILON19) static constant Cesium.Math.EPSILON19 : number 

[engine/Source/Core/Math.js 146](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L146) 

 0.0000000000000000001

#### [](#.EPSILON20) static constant Cesium.Math.EPSILON20 : number 

[engine/Source/Core/Math.js 153](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L153) 

 0.00000000000000000001

#### [](#.EPSILON21) static constant Cesium.Math.EPSILON21 : number 

[engine/Source/Core/Math.js 160](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L160) 

 0.000000000000000000001

#### [](#.FOUR%5FGIGABYTES) static constant Cesium.Math.FOUR\_GIGABYTES : number 

[engine/Source/Core/Math.js 198](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L198) 

 4 \* 1024 \* 1024 \* 1024

#### [](#.GRAVITATIONALPARAMETER) static constant Cesium.Math.GRAVITATIONALPARAMETER : number 

[engine/Source/Core/Math.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L168) 

 The gravitational parameter of the Earth in meters cubed per second squared as defined by the WGS84 model: 3.986004418e14

#### [](#.LUNAR%5FRADIUS) static constant Cesium.Math.LUNAR\_RADIUS : number 

[engine/Source/Core/Math.js 184](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L184) 

 The mean radius of the moon, according to the "Report of the IAU/IAG Working Group on Cartographic Coordinates and Rotational Elements of the Planets and satellites: 2000", Celestial Mechanics 82: 83-110, 2002.

#### [](#.ONE%5FOVER%5FPI) static constant Cesium.Math.ONE\_OVER\_PI : number 

[engine/Source/Core/Math.js 351](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L351) 

 1/pi

#### [](#.ONE%5FOVER%5FTWO%5FPI) static constant Cesium.Math.ONE\_OVER\_TWO\_PI : number 

[engine/Source/Core/Math.js 407](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L407) 

 1/2pi

#### [](#.PI) static constant Cesium.Math.PI : number 

[engine/Source/Core/Math.js 343](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L343) 

 pi

#### [](#.PI%5FOVER%5FFOUR) static constant Cesium.Math.PI\_OVER\_FOUR : number 

[engine/Source/Core/Math.js 375](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L375) 

 pi/4

#### [](#.PI%5FOVER%5FSIX) static constant Cesium.Math.PI\_OVER\_SIX : number 

[engine/Source/Core/Math.js 383](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L383) 

 pi/6

#### [](#.PI%5FOVER%5FTHREE) static constant Cesium.Math.PI\_OVER\_THREE : number 

[engine/Source/Core/Math.js 367](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L367) 

 pi/3

#### [](#.PI%5FOVER%5FTWO) static constant Cesium.Math.PI\_OVER\_TWO : number 

[engine/Source/Core/Math.js 359](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L359) 

 pi/2

#### [](#.RADIANS%5FPER%5FARCSECOND) static constant Cesium.Math.RADIANS\_PER\_ARCSECOND : number 

[engine/Source/Core/Math.js 431](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L431) 

 The number of radians in an arc second.

#### [](#.RADIANS%5FPER%5FDEGREE) static constant Cesium.Math.RADIANS\_PER\_DEGREE : number 

[engine/Source/Core/Math.js 415](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L415) 

 The number of radians in a degree.

#### [](#.SIXTY%5FFOUR%5FKILOBYTES) static constant Cesium.Math.SIXTY\_FOUR\_KILOBYTES : number 

[engine/Source/Core/Math.js 191](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L191) 

 64 \* 1024

#### [](#.SOLAR%5FRADIUS) static constant Cesium.Math.SOLAR\_RADIUS : number 

[engine/Source/Core/Math.js 175](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L175) 

 Radius of the sun in meters: 6.955e8

#### [](#.THREE%5FPI%5FOVER%5FTWO) static constant Cesium.Math.THREE\_PI\_OVER\_TWO : number 

[engine/Source/Core/Math.js 391](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L391) 

 3pi/2

#### [](#.TWO%5FPI) static constant Cesium.Math.TWO\_PI : number 

[engine/Source/Core/Math.js 399](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L399) 

 2pi

### Methods

#### [](#.acosClamped) static Cesium.Math.acosClamped(value) → number 

[engine/Source/Core/Math.js 962](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L962) 

 Computes `Math.acos(value)`, but first clamps `value` to the range \[-1.0, 1.0\] so that the function will never return NaN.

| Name  | Type   | Description                          |
| ----- | ------ | ------------------------------------ |
| value | number | The value for which to compute acos. |

##### Returns:

 The acos of the value if the value is in the range \[-1.0, 1.0\], or the acos of -1.0 or 1.0, whichever is closer, if the value is outside the range.

#### [](#.asinClamped) static Cesium.Math.asinClamped(value) → number 

[engine/Source/Core/Math.js 979](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L979) 

 Computes `Math.asin(value)`, but first clamps `value` to the range \[-1.0, 1.0\] so that the function will never return NaN.

| Name  | Type   | Description                          |
| ----- | ------ | ------------------------------------ |
| value | number | The value for which to compute asin. |

##### Returns:

 The asin of the value if the value is in the range \[-1.0, 1.0\], or the asin of -1.0 or 1.0, whichever is closer, if the value is outside the range.

#### [](#.cbrt) static Cesium.Math.cbrt(number) → number 

[engine/Source/Core/Math.js 1034](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L1034) 

 Finds the cube root of a number. Returns NaN if `number` is not provided.

| Name   | Type   | Description          |
| ------ | ------ | -------------------- |
| number | number | optional The number. |

##### Returns:

 The result.

#### [](#.chordLength) static Cesium.Math.chordLength(angle, radius) → number 

[engine/Source/Core/Math.js 995](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L995) 

 Finds the chord length between two points given the circle's radius and the angle between the points.

| Name   | Type   | Description                       |
| ------ | ------ | --------------------------------- |
| angle  | number | The angle between the two points. |
| radius | number | The radius of the circle.         |

##### Returns:

 The chord length.

#### [](#.clamp) static Cesium.Math.clamp(value, min, max) → number 

[engine/Source/Core/Math.js 902](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L902) 

 Constraint a value to lie between two values.

| Name  | Type   | Description         |
| ----- | ------ | ------------------- |
| value | number | The value to clamp. |
| min   | number | The minimum value.  |
| max   | number | The maximum value.  |

##### Returns:

 The clamped value such that min <= result <= max.

#### [](#.clampToLatitudeRange) static Cesium.Math.clampToLatitudeRange(angle) → number 

[engine/Source/Core/Math.js 502](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L502) 

 Convenience function that clamps a latitude value, in radians, to the range \[`-Math.PI/2`, `Math.PI/2`). Useful for sanitizing data before use in objects requiring correct range.

| Name  | Type   | Description                                                                      |
| ----- | ------ | -------------------------------------------------------------------------------- |
| angle | number | The latitude value, in radians, to clamp to the range \[\-Math.PI/2, Math.PI/2). |

##### Returns:

 The latitude value clamped to the range \[`-Math.PI/2`, `Math.PI/2`).

##### Example:

```javascript
// Clamp 108 degrees latitude to 90 degrees latitude
const latitude = Cesium.Math.clampToLatitudeRange(Cesium.Math.toRadians(108.0));
```

#### [](#.convertLongitudeRange) static Cesium.Math.convertLongitudeRange(angle) → number 

[engine/Source/Core/Math.js 471](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L471) 

 Converts a longitude value, in radians, to the range \[`-Math.PI`, `Math.PI`).

| Name  | Type   | Description                                                                     |
| ----- | ------ | ------------------------------------------------------------------------------- |
| angle | number | The longitude value, in radians, to convert to the range \[\-Math.PI, Math.PI). |

##### Returns:

 The equivalent longitude value in the range \[`-Math.PI`, `Math.PI`).

##### Example:

```javascript
// Convert 270 degrees to -90 degrees longitude
const longitude = Cesium.Math.convertLongitudeRange(Cesium.Math.toRadians(270.0));
```

#### [](#.cosh) static Cesium.Math.cosh(value) → number 

[engine/Source/Core/Math.js 318](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L318) 

 Returns the hyperbolic cosine of a number. The hyperbolic cosine of **value** is defined to be (_ex \+ e\-x_)/2.0 where _e_ is Euler's number, approximately 2.71828183.

Special cases:
* If the argument is NaN, then the result is NaN.
* If the argument is infinite, then the result is positive infinity.
* If the argument is zero, then the result is 1.0.

| Name  | Type   | Description                                           |
| ----- | ------ | ----------------------------------------------------- |
| value | number | The number whose hyperbolic cosine is to be returned. |

##### Returns:

 The hyperbolic cosine of `value`.

#### [](#.equalsEpsilon) static Cesium.Math.equalsEpsilon(left, right, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/Math.js 609](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L609) 

 Determines if two values are equal using an absolute or relative tolerance test. This is useful to avoid problems due to roundoff error when comparing floating-point values directly. The values are first compared using an absolute tolerance test. If that fails, a relative tolerance test is performed. Use this test if you are unsure of the magnitudes of left and right.

| Name            | Type   | Default         | Description                                                                                  |
| --------------- | ------ | --------------- | -------------------------------------------------------------------------------------------- |
| left            | number |                 | The first value to compare.                                                                  |
| right           | number |                 | The other value to compare.                                                                  |
| relativeEpsilon | number | 0               | optional The maximum inclusive delta between left and right for the relative tolerance test. |
| absoluteEpsilon | number | relativeEpsilon | optional The maximum inclusive delta between left and right for the absolute tolerance test. |

##### Returns:

`true` if the values are equal within the epsilon; otherwise, `false`.

##### Example:

```javascript
const a = Cesium.Math.equalsEpsilon(0.0, 0.01, Cesium.Math.EPSILON2); // true
const b = Cesium.Math.equalsEpsilon(0.0, 0.1, Cesium.Math.EPSILON2);  // false
const c = Cesium.Math.equalsEpsilon(3699175.1634344, 3699175.2, Cesium.Math.EPSILON7); // true
const d = Cesium.Math.equalsEpsilon(3699175.1634344, 3699175.2, Cesium.Math.EPSILON9); // false
```

#### [](#.factorial) static Cesium.Math.factorial(n) → number 

[engine/Source/Core/Math.js 752](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L752) 

 Computes the factorial of the provided number.

| Name | Type   | Description                                   |
| ---- | ------ | --------------------------------------------- |
| n    | number | The number whose factorial is to be computed. |

##### Returns:

 The factorial of the provided number or undefined if the number is less than 0.

##### Throws:

* [DeveloperError](DeveloperError.html): A number greater than or equal to 0 is required.

##### Example:

```javascript
//Compute 7!, which is equal to 5040
const computedFactorial = Cesium.Math.factorial(7);
```

##### See:

* [Factorial on Wikipedia](http://en.wikipedia.org/wiki/Factorial)

#### [](#.fastApproximateAtan) static Cesium.Math.fastApproximateAtan(x) → number 

[engine/Source/Core/Math.js 1071](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L1071) 

 Computes a fast approximation of Atan for input in the range \[-1, 1\]. Based on Michal Drobot's approximation from ShaderFastLibs, which in turn is based on "Efficient approximations for the arctangent function," Rajan, S. Sichun Wang Inkol, R. Joyal, A., May 2006\. Adapted from ShaderFastLibs under MIT License.

| Name | Type   | Description                            |
| ---- | ------ | -------------------------------------- |
| x    | number | An input number in the range \[-1, 1\] |

##### Returns:

 An approximation of atan(x)

#### [](#.fastApproximateAtan2) static Cesium.Math.fastApproximateAtan2(x, y) → number 

[engine/Source/Core/Math.js 1088](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L1088) 

 Computes a fast approximation of Atan2(x, y) for arbitrary input scalars. Range reduction math based on nvidia's cg reference implementation: http://developer.download.nvidia.com/cg/atan2.html

| Name | Type   | Description                                   |
| ---- | ------ | --------------------------------------------- |
| x    | number | An input number that isn't zero if y is zero. |
| y    | number | An input number that isn't zero if x is zero. |

##### Returns:

 An approximation of atan2(x, y)

#### [](#.fromSNorm) static Cesium.Math.fromSNorm(value, rangeMaximum) → number 

[engine/Source/Core/Math.js 251](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L251) 

 Converts a SNORM value in the range \[0, rangeMaximum\] to a scalar in the range \[-1.0, 1.0\].

| Name         | Type   | Default | Description                                                    |
| ------------ | ------ | ------- | -------------------------------------------------------------- |
| value        | number |         | SNORM value in the range \[0, rangeMaximum\]                   |
| rangeMaximum | number | 255     | optional The maximum value in the SNORM range, 255 by default. |

##### Returns:

 Scalar in the range \[-1.0, 1.0\].

##### See:

* CesiumMath.toSNorm

#### [](#.greaterThan) static Cesium.Math.greaterThan(left, right, absoluteEpsilon) → boolean 

[engine/Source/Core/Math.js 695](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L695) 

 Determines if the left value is greater the right value. If the two values are within`absoluteEpsilon` of each other, they are considered equal and this function returns false.

| Name            | Type   | Description                                |
| --------------- | ------ | ------------------------------------------ |
| left            | number | The first number to compare.               |
| right           | number | The second number to compare.              |
| absoluteEpsilon | number | The absolute epsilon to use in comparison. |

##### Returns:

`true` if `left` is greater than `right` by more than`absoluteEpsilon`. `false` if `left` is less or if the two values are nearly equal. 

#### [](#.greaterThanOrEquals) static Cesium.Math.greaterThanOrEquals(left, right, absoluteEpsilon) → boolean 

[engine/Source/Core/Math.js 720](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L720) 

 Determines if the left value is greater than or equal to the right value. If the two values are within`absoluteEpsilon` of each other, they are considered equal and this function returns true.

| Name            | Type   | Description                                |
| --------------- | ------ | ------------------------------------------ |
| left            | number | The first number to compare.               |
| right           | number | The second number to compare.              |
| absoluteEpsilon | number | The absolute epsilon to use in comparison. |

##### Returns:

`true` if `left` is greater than `right` or if the the values are nearly equal.

#### [](#.incrementWrap) static Cesium.Math.incrementWrap(n, maximumValue, minimumValue) → number 

[engine/Source/Core/Math.js 787](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L787) 

 Increments a number with a wrapping to a minimum value if the number exceeds the maximum value.

| Name         | Type   | Default | Description                                                                      |
| ------------ | ------ | ------- | -------------------------------------------------------------------------------- |
| n            | number |         | optional The number to be incremented.                                           |
| maximumValue | number |         | optional The maximum incremented value before rolling over to the minimum value. |
| minimumValue | number | 0.0     | optional The number reset to after the maximum value has been exceeded.          |

##### Returns:

 The incremented number.

##### Throws:

* [DeveloperError](DeveloperError.html): Maximum value must be greater than minimum value.

##### Example:

```javascript
const n = Cesium.Math.incrementWrap(5, 10, 0); // returns 6
const m = Cesium.Math.incrementWrap(10, 10, 0); // returns 0
```

#### [](#.isPowerOfTwo) static Cesium.Math.isPowerOfTwo(n) → boolean 

[engine/Source/Core/Math.js 819](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L819) 

 Determines if a non-negative integer is a power of two. The maximum allowed input is (2^32)-1 due to 32-bit bitwise operator limitation in Javascript.

| Name | Type   | Description                                       |
| ---- | ------ | ------------------------------------------------- |
| n    | number | The integer to test in the range \[0, (2^32)-1\]. |

##### Returns:

`true` if the number if a power of two; otherwise, `false`.

##### Throws:

* [DeveloperError](DeveloperError.html): A number between 0 and (2^32)-1 is required.

##### Example:

```javascript
const t = Cesium.Math.isPowerOfTwo(16); // true
const f = Cesium.Math.isPowerOfTwo(20); // false
```

#### [](#.lerp) static Cesium.Math.lerp(p, q, time) → number 

[engine/Source/Core/Math.js 333](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L333) 

 Computes the linear interpolation of two values.

| Name | Type   | Description                                                    |
| ---- | ------ | -------------------------------------------------------------- |
| p    | number | The start value to interpolate.                                |
| q    | number | The end value to interpolate.                                  |
| time | number | The time of interpolation generally in the range \[0.0, 1.0\]. |

##### Returns:

 The linearly interpolated value.

##### Example:

```javascript
const n = Cesium.Math.lerp(0.0, 2.0, 0.5); // returns 1.0
```

#### [](#.lessThan) static Cesium.Math.lessThan(left, right, absoluteEpsilon) → boolean 

[engine/Source/Core/Math.js 644](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L644) 

 Determines if the left value is less than the right value. If the two values are within`absoluteEpsilon` of each other, they are considered equal and this function returns false.

| Name            | Type   | Description                                |
| --------------- | ------ | ------------------------------------------ |
| left            | number | The first number to compare.               |
| right           | number | The second number to compare.              |
| absoluteEpsilon | number | The absolute epsilon to use in comparison. |

##### Returns:

`true` if `left` is less than `right` by more than`absoluteEpsilon`. `false` if `left` is greater or if the two values are nearly equal. 

#### [](#.lessThanOrEquals) static Cesium.Math.lessThanOrEquals(left, right, absoluteEpsilon) → boolean 

[engine/Source/Core/Math.js 669](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L669) 

 Determines if the left value is less than or equal to the right value. If the two values are within`absoluteEpsilon` of each other, they are considered equal and this function returns true.

| Name            | Type   | Description                                |
| --------------- | ------ | ------------------------------------------ |
| left            | number | The first number to compare.               |
| right           | number | The second number to compare.              |
| absoluteEpsilon | number | The absolute epsilon to use in comparison. |

##### Returns:

`true` if `left` is less than `right` or if the the values are nearly equal.

#### [](#.log2) static Cesium.Math.log2(number) → number 

[engine/Source/Core/Math.js 1046](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L1046) 

 Finds the base 2 logarithm of a number.

| Name   | Type   | Description |
| ------ | ------ | ----------- |
| number | number | The number. |

##### Returns:

 The result.

#### [](#.logBase) static Cesium.Math.logBase(number, base) → number 

[engine/Source/Core/Math.js 1014](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L1014) 

 Finds the logarithm of a number to a base.

| Name   | Type   | Description |
| ------ | ------ | ----------- |
| number | number | The number. |
| base   | number | The base.   |

##### Returns:

 The result.

#### [](#.mod) static Cesium.Math.mod(m, n) → number 

[engine/Source/Core/Math.js 570](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L570) 

 The modulo operation that also works for negative dividends.

| Name | Type   | Description   |
| ---- | ------ | ------------- |
| m    | number | The dividend. |
| n    | number | The divisor.  |

##### Returns:

 The remainder.

#### [](#.negativePiToPi) static Cesium.Math.negativePiToPi(angle) → number 

[engine/Source/Core/Math.js 522](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L522) 

 Produces an angle in the range -Pi <= angle <= Pi which is equivalent to the provided angle.

| Name  | Type   | Description |
| ----- | ------ | ----------- |
| angle | number | in radians  |

##### Returns:

 The angle in the range \[`-CesiumMath.PI`, `CesiumMath.PI`\].

#### [](#.nextPowerOfTwo) static Cesium.Math.nextPowerOfTwo(n) → number 

[engine/Source/Core/Math.js 842](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L842) 

 Computes the next power-of-two integer greater than or equal to the provided non-negative integer. The maximum allowed input is 2^31 due to 32-bit bitwise operator limitation in Javascript.

| Name | Type   | Description                                   |
| ---- | ------ | --------------------------------------------- |
| n    | number | The integer to test in the range \[0, 2^31\]. |

##### Returns:

 The next power-of-two integer.

##### Throws:

* [DeveloperError](DeveloperError.html): A number between 0 and 2^31 is required.

##### Example:

```javascript
const n = Cesium.Math.nextPowerOfTwo(29); // 32
const m = Cesium.Math.nextPowerOfTwo(32); // 32
```

#### [](#.nextRandomNumber) static Cesium.Math.nextRandomNumber() → number 

[engine/Source/Core/Math.js 939](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L939) 

 Generates a random floating point number in the range of \[0.0, 1.0) using a Mersenne twister.

##### Returns:

 A random number in the range of \[0.0, 1.0).

##### See:

* CesiumMath.setRandomNumberSeed
* [Mersenne twister on Wikipedia](http://en.wikipedia.org/wiki/Mersenne%5Ftwister)

#### [](#.normalize) static Cesium.Math.normalize(value, rangeMinimum, rangeMaximum) → number 

[engine/Source/Core/Math.js 265](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L265) 

 Converts a scalar value in the range \[rangeMinimum, rangeMaximum\] to a scalar in the range \[0.0, 1.0\]

| Name         | Type   | Description                                                  |
| ------------ | ------ | ------------------------------------------------------------ |
| value        | number | The scalar value in the range \[rangeMinimum, rangeMaximum\] |
| rangeMinimum | number | The minimum value in the mapped range.                       |
| rangeMaximum | number | The maximum value in the mapped range.                       |

##### Returns:

 A scalar value, where rangeMinimum maps to 0.0 and rangeMaximum maps to 1.0.

#### [](#.previousPowerOfTwo) static Cesium.Math.previousPowerOfTwo(n) → number 

[engine/Source/Core/Math.js 874](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L874) 

 Computes the previous power-of-two integer less than or equal to the provided non-negative integer. The maximum allowed input is (2^32)-1 due to 32-bit bitwise operator limitation in Javascript.

| Name | Type   | Description                                       |
| ---- | ------ | ------------------------------------------------- |
| n    | number | The integer to test in the range \[0, (2^32)-1\]. |

##### Returns:

 The previous power-of-two integer.

##### Throws:

* [DeveloperError](DeveloperError.html): A number between 0 and (2^32)-1 is required.

##### Example:

```javascript
const n = Cesium.Math.previousPowerOfTwo(29); // 16
const m = Cesium.Math.previousPowerOfTwo(32); // 32
```

#### [](#.randomBetween) static Cesium.Math.randomBetween(min, max) → number 

[engine/Source/Core/Math.js 950](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L950) 

 Generates a random number between two numbers.

| Name | Type   | Description        |
| ---- | ------ | ------------------ |
| min  | number | The minimum value. |
| max  | number | The maximum value. |

##### Returns:

 A random number between the min and max.

#### [](#.setRandomNumberSeed) static Cesium.Math.setRandomNumberSeed(seed) 

[engine/Source/Core/Math.js 920](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L920) 

 Sets the seed used by the random number generator in `CesiumMath#nextRandomNumber`.

| Name | Type   | Description                  |
| ---- | ------ | ---------------------------- |
| seed | number | An integer used as the seed. |

#### [](#.sign) static Cesium.Math.sign(value) → number 

[engine/Source/Core/Math.js 208](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L208) 

 Returns the sign of the value; 1 if the value is positive, -1 if the value is negative, or 0 if the value is 0.

| Name  | Type   | Description                      |
| ----- | ------ | -------------------------------- |
| value | number | The value to return the sign of. |

##### Returns:

 The sign of value.

#### [](#.signNotZero) static Cesium.Math.signNotZero(value) → number 

[engine/Source/Core/Math.js 224](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L224) 

 Returns 1.0 if the given value is positive or zero, and -1.0 if it is negative. This is similar to `CesiumMath#sign` except that returns 1.0 instead of 0.0 when the input value is 0.0.

| Name  | Type   | Description                      |
| ----- | ------ | -------------------------------- |
| value | number | The value to return the sign of. |

##### Returns:

 The sign of value.

#### [](#.sinh) static Cesium.Math.sinh(value) → number 

[engine/Source/Core/Math.js 294](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L294) 

 Returns the hyperbolic sine of a number. The hyperbolic sine of _value_ is defined to be (_ex \- e\-x_)/2.0 where _e_ is Euler's number, approximately 2.71828183.

Special cases:
* If the argument is NaN, then the result is NaN.
* If the argument is infinite, then the result is an infinity with the same sign as the argument.
* If the argument is zero, then the result is a zero with the same sign as the argument.

| Name  | Type   | Description                                         |
| ----- | ------ | --------------------------------------------------- |
| value | number | The number whose hyperbolic sine is to be returned. |

##### Returns:

 The hyperbolic sine of `value`.

#### [](#.toDegrees) static Cesium.Math.toDegrees(radians) → number 

[engine/Source/Core/Math.js 452](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L452) 

 Converts radians to degrees.

| Name    | Type   | Description                      |
| ------- | ------ | -------------------------------- |
| radians | number | The angle to convert in radians. |

##### Returns:

 The corresponding angle in degrees.

#### [](#.toRadians) static Cesium.Math.toRadians(degrees) → number 

[engine/Source/Core/Math.js 438](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L438) 

 Converts degrees to radians.

| Name    | Type   | Description                      |
| ------- | ------ | -------------------------------- |
| degrees | number | The angle to convert in degrees. |

##### Returns:

 The corresponding angle in radians.

#### [](#.toSNorm) static Cesium.Math.toSNorm(value, rangeMaximum) → number 

[engine/Source/Core/Math.js 236](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L236) 

 Converts a scalar value in the range \[-1.0, 1.0\] to a SNORM in the range \[0, rangeMaximum\]

| Name         | Type   | Default | Description                                                     |
| ------------ | ------ | ------- | --------------------------------------------------------------- |
| value        | number |         | The scalar value in the range \[-1.0, 1.0\]                     |
| rangeMaximum | number | 255     | optional The maximum value in the mapped range, 255 by default. |

##### Returns:

 A SNORM value, where 0 maps to -1.0 and rangeMaximum maps to 1.0.

##### See:

* CesiumMath.fromSNorm

#### [](#.zeroToTwoPi) static Cesium.Math.zeroToTwoPi(angle) → number 

[engine/Source/Core/Math.js 542](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Math.js#L542) 

 Produces an angle in the range 0 <= angle <= 2Pi which is equivalent to the provided angle.

| Name  | Type   | Description |
| ----- | ------ | ----------- |
| angle | number | in radians  |

##### Returns:

 The angle in the range \[0, `CesiumMath.TWO_PI`\].

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

