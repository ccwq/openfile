# [![](Images/CesiumLogo.png)](index.html) GeoJsonDataSource 

#### [](#GeoJsonDataSource) new Cesium.GeoJsonDataSource(name) 

[engine/Source/DataSources/GeoJsonDataSource.js 593](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L593) 

 A [DataSource](DataSource.html) which processes both[GeoJSON](http://www.geojson.org/) and [TopoJSON](https://github.com/mbostock/topojson) data.[simplestyle-spec](https://github.com/mapbox/simplestyle-spec) properties will also be used if they are present.

| Name | Type   | Description                                                                                                  |
| ---- | ------ | ------------------------------------------------------------------------------------------------------------ |
| name | string | optional The name of this data source. If undefined, a name will be taken from the name of the GeoJSON file. |

##### Example:

```javascript
const viewer = new Cesium.Viewer('cesiumContainer');
viewer.dataSources.add(Cesium.GeoJsonDataSource.load('../../SampleData/ne_10m_us_states.topojson', {
  stroke: Cesium.Color.HOTPINK,
  fill: Cesium.Color.PINK,
  strokeWidth: 3,
  markerSymbol: '?'
}));
```

##### Demo:

* [Cesium Sandcastle GeoJSON and TopoJSON Demo](https://sandcastle.cesium.com/index.html?src=GeoJSON%2520and%2520TopoJSON.html)
* [Cesium Sandcastle GeoJSON simplestyle Demo](https://sandcastle.cesium.com/index.html?src=GeoJSON%2520simplestyle.html)

### Members

#### [](#.clampToGround) static Cesium.GeoJsonDataSource.clampToGround : boolean 

[engine/Source/DataSources/GeoJsonDataSource.js 711](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L711) 

 Gets or sets default of whether to clamp to the ground.

Default Value: `false` 

#### [](#.crsLinkHrefs) static Cesium.GeoJsonDataSource.crsLinkHrefs : object 

[engine/Source/DataSources/GeoJsonDataSource.js 743](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L743) 

 Gets an object that maps the href property of a crs link to a callback function which takes the crs properties object and returns a Promise that resolves to a function that takes a GeoJSON coordinate and transforms it into a WGS84 Earth-fixed Cartesian. Items in this object take precedence over those defined in `crsLinkHrefs`, assuming the link has a type specified.

#### [](#.crsLinkTypes) static Cesium.GeoJsonDataSource.crsLinkTypes : object 

[engine/Source/DataSources/GeoJsonDataSource.js 757](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L757) 

 Gets an object that maps the type property of a crs link to a callback function which takes the crs properties object and returns a Promise that resolves to a function that takes a GeoJSON coordinate and transforms it into a WGS84 Earth-fixed Cartesian. Items in `crsLinkHrefs` take precedence over this object.

#### [](#.crsNames) static Cesium.GeoJsonDataSource.crsNames : object 

[engine/Source/DataSources/GeoJsonDataSource.js 728](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L728) 

 Gets an object that maps the name of a crs to a callback function which takes a GeoJSON coordinate and transforms it into a WGS84 Earth-fixed Cartesian. Older versions of GeoJSON which supported the EPSG type can be added to this list as well, by specifying the complete EPSG name, for example 'EPSG:4326'.

#### [](#.fill) static Cesium.GeoJsonDataSource.fill : [Color](Color.html) 

[engine/Source/DataSources/GeoJsonDataSource.js 697](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L697) 

 Gets or sets default color for polygon interiors.

Default Value: `Color.YELLOW` 

#### [](#.markerColor) static Cesium.GeoJsonDataSource.markerColor : [Color](Color.html) 

[engine/Source/DataSources/GeoJsonDataSource.js 655](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L655) 

 Gets or sets the default color of the map pin created for each point.

Default Value: `Color.ROYALBLUE` 

#### [](#.markerSize) static Cesium.GeoJsonDataSource.markerSize : number 

[engine/Source/DataSources/GeoJsonDataSource.js 626](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L626) 

 Gets or sets the default size of the map pin created for each point, in pixels.

Default Value: `48` 

#### [](#.markerSymbol) static Cesium.GeoJsonDataSource.markerSymbol : string 

[engine/Source/DataSources/GeoJsonDataSource.js 641](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L641) 

 Gets or sets the default symbol of the map pin created for each point. This can be any valid [Maki](http://mapbox.com/maki/) identifier, any single character, or blank if no symbol is to be used.

#### [](#.stroke) static Cesium.GeoJsonDataSource.stroke : [Color](Color.html) 

[engine/Source/DataSources/GeoJsonDataSource.js 669](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L669) 

 Gets or sets the default color of polylines and polygon outlines.

Default Value: `Color.BLACK` 

#### [](#.strokeWidth) static Cesium.GeoJsonDataSource.strokeWidth : number 

[engine/Source/DataSources/GeoJsonDataSource.js 683](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L683) 

 Gets or sets the default width of polylines and polygon outlines.

Default Value: `2.0` 

#### [](#changedEvent) changedEvent : [Event](Event.html) 

[engine/Source/DataSources/GeoJsonDataSource.js 815](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L815) 

 Gets an event that will be raised when the underlying data changes.

#### [](#clock) clock : [DataSourceClock](DataSourceClock.html) 

[engine/Source/DataSources/GeoJsonDataSource.js 786](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L786) 

 This DataSource only defines static data, therefore this property is always undefined.

#### [](#clustering) clustering : [EntityCluster](EntityCluster.html) 

[engine/Source/DataSources/GeoJsonDataSource.js 860](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L860) 

 Gets or sets the clustering options for this data source. This object can be shared between multiple data sources.

#### [](#credit) credit : [Credit](Credit.html) 

[engine/Source/DataSources/GeoJsonDataSource.js 878](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L878) 

 Gets the credit that will be displayed for the data source

#### [](#entities) entities : [EntityCollection](EntityCollection.html) 

[engine/Source/DataSources/GeoJsonDataSource.js 795](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L795) 

 Gets the collection of [Entity](Entity.html) instances.

#### [](#errorEvent) errorEvent : [Event](Event.html) 

[engine/Source/DataSources/GeoJsonDataSource.js 825](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L825) 

 Gets an event that will be raised if an error is encountered during processing.

#### [](#isLoading) isLoading : boolean 

[engine/Source/DataSources/GeoJsonDataSource.js 805](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L805) 

 Gets a value indicating if the data source is currently loading data.

#### [](#loadingEvent) loadingEvent : [Event](Event.html) 

[engine/Source/DataSources/GeoJsonDataSource.js 835](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L835) 

 Gets an event that will be raised when the data source either starts or stops loading.

#### [](#name) name : string 

[engine/Source/DataSources/GeoJsonDataSource.js 770](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L770) 

 Gets or sets a human-readable name for this instance.

#### [](#show) show : boolean 

[engine/Source/DataSources/GeoJsonDataSource.js 845](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L845) 

 Gets whether or not this data source should be displayed.

### Methods

#### [](#.load) static Cesium.GeoJsonDataSource.load(data, options) → Promise.<[GeoJsonDataSource](GeoJsonDataSource.html)\> 

[engine/Source/DataSources/GeoJsonDataSource.js 615](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L615) 

 Creates a Promise to a new instance loaded with the provided GeoJSON or TopoJSON data.

| Name    | Type                                                                 | Description                                             |
| ------- | -------------------------------------------------------------------- | ------------------------------------------------------- |
| data    | [Resource](Resource.html)\|string|object                             | A url, GeoJSON object, or TopoJSON object to be loaded. |
| options | [GeoJsonDataSource.LoadOptions](GeoJsonDataSource.html#.LoadOptions) | optional An object specifying configuration options     |

##### Returns:

 A promise that will resolve when the data is loaded.

#### [](#load) load(data, options) → Promise.<[GeoJsonDataSource](GeoJsonDataSource.html)\> 

[engine/Source/DataSources/GeoJsonDataSource.js 893](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L893) 

 Asynchronously loads the provided GeoJSON or TopoJSON data, replacing any existing data.

| Name    | Type                                                                 | Description                                             |
| ------- | -------------------------------------------------------------------- | ------------------------------------------------------- |
| data    | [Resource](Resource.html)\|string|object                             | A url, GeoJSON object, or TopoJSON object to be loaded. |
| options | [GeoJsonDataSource.LoadOptions](GeoJsonDataSource.html#.LoadOptions) | optional An object specifying configuration options     |

##### Returns:

 a promise that will resolve when the GeoJSON is loaded.

#### [](#process) process(data, options) → Promise.<[GeoJsonDataSource](GeoJsonDataSource.html)\> 

[engine/Source/DataSources/GeoJsonDataSource.js 905](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L905) 

 Asynchronously loads the provided GeoJSON or TopoJSON data, without replacing any existing data.

| Name    | Type                                                                 | Description                                             |
| ------- | -------------------------------------------------------------------- | ------------------------------------------------------- |
| data    | [Resource](Resource.html)\|string|object                             | A url, GeoJSON object, or TopoJSON object to be loaded. |
| options | [GeoJsonDataSource.LoadOptions](GeoJsonDataSource.html#.LoadOptions) | optional An object specifying configuration options     |

##### Returns:

 a promise that will resolve when the GeoJSON is loaded.

#### [](#update) update(time) → boolean 

[engine/Source/DataSources/GeoJsonDataSource.js 981](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L981) 

 Updates the data source to the provided time. This function is optional and is not required to be implemented. It is provided for data sources which retrieve data based on the current animation time or scene state. If implemented, update will be called by [DataSourceDisplay](DataSourceDisplay.html) once a frame.

| Name | Type                          | Description          |
| ---- | ----------------------------- | -------------------- |
| time | [JulianDate](JulianDate.html) | The simulation time. |

##### Returns:

 True if this data source is ready to be displayed at the provided time, false otherwise.

### Type Definitions

#### [](#.describe) Cesium.GeoJsonDataSource.describe(properties, nameProperty) 

[engine/Source/DataSources/GeoJsonDataSource.js 1058](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L1058) 

 This callback is displayed as part of the GeoJsonDataSource class.

| Name         | Type   | Description                                                             |
| ------------ | ------ | ----------------------------------------------------------------------- |
| properties   | object | The properties of the feature.                                          |
| nameProperty | string | The property key that Cesium estimates to have the name of the feature. |

#### [](#.LoadOptions) Cesium.GeoJsonDataSource.LoadOptions

[engine/Source/DataSources/GeoJsonDataSource.js 552](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GeoJsonDataSource.js#L552) 

 Initialization options for the `load` method.

##### Properties:

| Name          | Type                                                           | Attributes | Default                                   | Description                                                                            |
| ------------- | -------------------------------------------------------------- | ---------- | ----------------------------------------- | -------------------------------------------------------------------------------------- |
| sourceUri     | string                                                         | <optional> |                                           | Overrides the url to use for resolving relative links.                                 |
| describe      | [GeoJsonDataSource.describe](GeoJsonDataSource.html#.describe) | <optional> | GeoJsonDataSource.defaultDescribeProperty | A function which returns a Property object (or just a string).                         |
| markerSize    | number                                                         | <optional> | GeoJsonDataSource.markerSize              | The default size of the map pin created for each point, in pixels.                     |
| markerSymbol  | string                                                         | <optional> | GeoJsonDataSource.markerSymbol            | The default symbol of the map pin created for each point.                              |
| markerColor   | [Color](Color.html)                                            | <optional> | GeoJsonDataSource.markerColor             | The default color of the map pin created for each point.                               |
| stroke        | [Color](Color.html)                                            | <optional> | GeoJsonDataSource.stroke                  | The default color of polylines and polygon outlines.                                   |
| strokeWidth   | number                                                         | <optional> | GeoJsonDataSource.strokeWidth             | The default width of polylines and polygon outlines.                                   |
| fill          | [Color](Color.html)                                            | <optional> | GeoJsonDataSource.fill                    | The default color for polygon interiors.                                               |
| clampToGround | boolean                                                        | <optional> | GeoJsonDataSource.clampToGround           | true if we want the geometry features (polygons or linestrings) clamped to the ground. |
| credit        | [Credit](Credit.html)\|string                                  | <optional> |                                           | A credit for the data source, which is displayed on the canvas.                        |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

