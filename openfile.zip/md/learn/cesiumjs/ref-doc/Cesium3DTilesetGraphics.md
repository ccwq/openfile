# [![](Images/CesiumLogo.png)](index.html) Cesium3DTilesetGraphics 

#### [](#Cesium3DTilesetGraphics) new Cesium.Cesium3DTilesetGraphics(options) 

[engine/Source/DataSources/Cesium3DTilesetGraphics.js 27](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Cesium3DTilesetGraphics.js#L27) 

 A 3D Tiles tileset represented by an [Entity](Entity.html). The tileset modelMatrix is determined by the containing Entity position and orientation or is left unset if position is undefined.

| Name    | Type                                                                                           | Description                                       |
| ------- | ---------------------------------------------------------------------------------------------- | ------------------------------------------------- |
| options | [Cesium3DTilesetGraphics.ConstructorOptions](Cesium3DTilesetGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/Cesium3DTilesetGraphics.js 46](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Cesium3DTilesetGraphics.js#L46) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#maximumScreenSpaceError) maximumScreenSpaceError : [Property](Property.html)|undefined 

[engine/Source/DataSources/Cesium3DTilesetGraphics.js 72](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Cesium3DTilesetGraphics.js#L72) 

 Gets or sets the maximum screen space error used to drive level of detail refinement.

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/Cesium3DTilesetGraphics.js 58](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Cesium3DTilesetGraphics.js#L58) 

 Gets or sets the boolean Property specifying the visibility of the model.

Default Value: `true` 

#### [](#uri) uri : [Property](Property.html)|undefined 

[engine/Source/DataSources/Cesium3DTilesetGraphics.js 65](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Cesium3DTilesetGraphics.js#L65) 

 Gets or sets the string Property specifying the URI of the glTF asset.

### Methods

#### [](#clone) clone(result) → [Cesium3DTilesetGraphics](Cesium3DTilesetGraphics.html) 

[engine/Source/DataSources/Cesium3DTilesetGraphics.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Cesium3DTilesetGraphics.js#L81) 

 Duplicates this instance.

| Name   | Type                                                    | Description                                         |
| ------ | ------------------------------------------------------- | --------------------------------------------------- |
| result | [Cesium3DTilesetGraphics](Cesium3DTilesetGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/Cesium3DTilesetGraphics.js 98](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Cesium3DTilesetGraphics.js#L98) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                                    | Description                               |
| ------ | ------------------------------------------------------- | ----------------------------------------- |
| source | [Cesium3DTilesetGraphics](Cesium3DTilesetGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.Cesium3DTilesetGraphics.ConstructorOptions

[engine/Source/DataSources/Cesium3DTilesetGraphics.js 7](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Cesium3DTilesetGraphics.js#L7) 

 Initialization options for the Cesium3DTilesetGraphics constructor

##### Properties:

| Name                    | Type                                                        | Attributes | Default | Description                                                                                              |
| ----------------------- | ----------------------------------------------------------- | ---------- | ------- | -------------------------------------------------------------------------------------------------------- |
| show                    | [Property](Property.html)\|boolean                          | <optional> | true    | A boolean Property specifying the visibility of the tileset.                                             |
| uri                     | [Property](Property.html)\|string|[Resource](Resource.html) | <optional> |         | A string or Resource Property specifying the URI of the tileset.                                         |
| maximumScreenSpaceError | [Property](Property.html)\|number                           | <optional> |         | A number or Property specifying the maximum screen space error used to drive level of detail refinement. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

