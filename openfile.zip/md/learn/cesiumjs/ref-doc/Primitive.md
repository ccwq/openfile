# [![](Images/CesiumLogo.png)](index.html) Primitive 

#### [](#Primitive) new Cesium.Primitive(options) 

[engine/Source/Scene/Primitive.js 154](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L154) 

 A primitive represents geometry in the [Scene](Scene.html). The geometry can be from a single [GeometryInstance](GeometryInstance.html)as shown in example 1 below, or from an array of instances, even if the geometry is from different geometry types, e.g., an [RectangleGeometry](RectangleGeometry.html) and an [EllipsoidGeometry](EllipsoidGeometry.html) as shown in Code Example 2.

A primitive combines geometry instances with an [Appearance](Appearance.html) that describes the full shading, including[Material](Material.html) and `RenderState`. Roughly, the geometry instance defines the structure and placement, and the appearance defines the visual characteristics. Decoupling geometry and appearance allows us to mix and match most of them and add a new geometry or appearance independently of each other.

Combining multiple instances into one primitive is called batching, and significantly improves performance for static data. Instances can be individually picked; [Scene#pick](Scene.html#pick) returns their [GeometryInstance#id](GeometryInstance.html#id). Using per-instance appearances like [PerInstanceColorAppearance](PerInstanceColorAppearance.html), each instance can also have a unique color.

[Geometry](Geometry.html) can either be created and batched on a web worker or the main thread. The first two examples show geometry that will be created on a web worker by using the descriptions of the geometry. The third example shows how to create the geometry on the main thread by explicitly calling the `createGeometry` method.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description geometryInstances Array.<[GeometryInstance](GeometryInstance.html)\>\|[GeometryInstance](GeometryInstance.html) optional The geometry instances - or a single geometry instance - to render. appearance [Appearance](Appearance.html) optional The appearance used to render the primitive. depthFailAppearance [Appearance](Appearance.html) optional The appearance used to shade this primitive when it fails the depth test. show boolean true optional Determines if this primitive will be shown. modelMatrix [Matrix4](Matrix4.html) Matrix4.IDENTITY optional The 4x4 transformation matrix that transforms the primitive (all geometry instances) from model to world coordinates. vertexCacheOptimize boolean false optional When true, geometry vertices are optimized for the pre and post-vertex-shader caches. interleave boolean false optional When true, geometry vertex attributes are interleaved, which can slightly improve rendering performance but increases load time. compressVertices boolean true optional When true, the geometry vertices are compressed, which will save memory. releaseGeometryInstances boolean true optional When true, the primitive does not keep a reference to the input geometryInstances to save memory. allowPicking boolean true optional When true, each geometry instance will only be pickable with [Scene#pick](Scene.html#pick). When false, GPU memory is saved. cull boolean true optional When true, the renderer frustum culls and horizon culls the primitive's commands based on their bounding volume. Set this to false for a small performance gain if you are manually culling the primitive. asynchronous boolean true optional Determines if the primitive will be created asynchronously or block until ready. debugShowBoundingVolume boolean false optional For debugging only. Determines if this primitive's commands' bounding spheres are shown. shadows [ShadowMode](global.html#ShadowMode) ShadowMode.DISABLED optional Determines whether this primitive casts or receives shadows from light sources. |

##### Examples:

```javascript
// 1. Draw a translucent ellipse on the surface with a checkerboard pattern
const instance = new Cesium.GeometryInstance({
  geometry : new Cesium.EllipseGeometry({
      center : Cesium.Cartesian3.fromDegrees(-100.0, 20.0),
      semiMinorAxis : 500000.0,
      semiMajorAxis : 1000000.0,
      rotation : Cesium.Math.PI_OVER_FOUR,
      vertexFormat : Cesium.VertexFormat.POSITION_AND_ST
  }),
  id : 'object returned when this instance is picked and to get/set per-instance attributes'
});
scene.primitives.add(new Cesium.Primitive({
  geometryInstances : instance,
  appearance : new Cesium.EllipsoidSurfaceAppearance({
    material : Cesium.Material.fromType('Checkerboard')
  })
}));
```

```javascript
// 2. Draw different instances each with a unique color
const rectangleInstance = new Cesium.GeometryInstance({
  geometry : new Cesium.RectangleGeometry({
    rectangle : Cesium.Rectangle.fromDegrees(-140.0, 30.0, -100.0, 40.0),
    vertexFormat : Cesium.PerInstanceColorAppearance.VERTEX_FORMAT
  }),
  id : 'rectangle',
  attributes : {
    color : new Cesium.ColorGeometryInstanceAttribute(0.0, 1.0, 1.0, 0.5)
  }
});
const ellipsoidInstance = new Cesium.GeometryInstance({
  geometry : new Cesium.EllipsoidGeometry({
    radii : new Cesium.Cartesian3(500000.0, 500000.0, 1000000.0),
    vertexFormat : Cesium.VertexFormat.POSITION_AND_NORMAL
  }),
  modelMatrix : Cesium.Matrix4.multiplyByTranslation(Cesium.Transforms.eastNorthUpToFixedFrame(
    Cesium.Cartesian3.fromDegrees(-95.59777, 40.03883)), new Cesium.Cartesian3(0.0, 0.0, 500000.0), new Cesium.Matrix4()),
  id : 'ellipsoid',
  attributes : {
    color : Cesium.ColorGeometryInstanceAttribute.fromColor(Cesium.Color.AQUA)
  }
});
scene.primitives.add(new Cesium.Primitive({
  geometryInstances : [rectangleInstance, ellipsoidInstance],
  appearance : new Cesium.PerInstanceColorAppearance()
}));
```

```javascript
// 3. Create the geometry on the main thread.
scene.primitives.add(new Cesium.Primitive({
  geometryInstances : new Cesium.GeometryInstance({
    geometry : Cesium.EllipsoidGeometry.createGeometry(new Cesium.EllipsoidGeometry({
      radii : new Cesium.Cartesian3(500000.0, 500000.0, 1000000.0),
      vertexFormat : Cesium.VertexFormat.POSITION_AND_NORMAL
    })),
    modelMatrix : Cesium.Matrix4.multiplyByTranslation(Cesium.Transforms.eastNorthUpToFixedFrame(
      Cesium.Cartesian3.fromDegrees(-95.59777, 40.03883)), new Cesium.Cartesian3(0.0, 0.0, 500000.0), new Cesium.Matrix4()),
    id : 'ellipsoid',
    attributes : {
      color : Cesium.ColorGeometryInstanceAttribute.fromColor(Cesium.Color.AQUA)
    }
  }),
  appearance : new Cesium.PerInstanceColorAppearance(),
  asynchronous : false
}));
```

##### See:

* [GeometryInstance](GeometryInstance.html)
* [Appearance](Appearance.html)
* [ClassificationPrimitive](ClassificationPrimitive.html)
* [GroundPrimitive](GroundPrimitive.html)

### Members

#### [](#allowPicking) readonly allowPicking : boolean 

[engine/Source/Scene/Primitive.js 424](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L424) 

 When `true`, each geometry instance will only be pickable with [Scene#pick](Scene.html#pick). When `false`, GPU memory is saved. \*

Default Value: `true` 

#### [](#appearance) appearance : [Appearance](Appearance.html) 

[engine/Source/Scene/Primitive.js 182](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L182) 

 The [Appearance](Appearance.html) used to shade this primitive. Each geometry instance is shaded with the same appearance. Some appearances, like[PerInstanceColorAppearance](PerInstanceColorAppearance.html) allow giving each instance unique properties.

Default Value: `undefined` 

#### [](#asynchronous) readonly asynchronous : boolean 

[engine/Source/Scene/Primitive.js 440](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L440) 

 Determines if the geometry instances will be created and batched on a web worker.

Default Value: `true` 

#### [](#compressVertices) readonly compressVertices : boolean 

[engine/Source/Scene/Primitive.js 456](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L456) 

 When `true`, geometry vertices are compressed, which will save memory.

Default Value: `true` 

#### [](#cull) cull : boolean 

[engine/Source/Scene/Primitive.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L261) 

 When `true`, the renderer frustum culls and horizon culls the primitive's commands based on their bounding volume. Set this to `false` for a small performance gain if you are manually culling the primitive.

Default Value: `true` 

#### [](#debugShowBoundingVolume) debugShowBoundingVolume : boolean 

[engine/Source/Scene/Primitive.js 273](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L273) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the bounding sphere for each draw command in the primitive.

Default Value: `false` 

#### [](#depthFailAppearance) depthFailAppearance : [Appearance](Appearance.html) 

[engine/Source/Scene/Primitive.js 205](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L205) 

 The [Appearance](Appearance.html) used to shade this primitive when it fails the depth test. Each geometry instance is shaded with the same appearance. Some appearances, like[PerInstanceColorAppearance](PerInstanceColorAppearance.html) allow giving each instance unique properties.

When using an appearance that requires a color attribute, like PerInstanceColorAppearance, add a depthFailColor per-instance attribute instead.

Requires the EXT\_frag\_depth WebGL extension to render properly. If the extension is not supported, there may be artifacts.

Default Value: `undefined` 

#### [](#geometryInstances) readonly geometryInstances : Array.<[GeometryInstance](GeometryInstance.html)\>|[GeometryInstance](GeometryInstance.html) 

[engine/Source/Scene/Primitive.js 170](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L170) 

 The geometry instances rendered with this primitive. This may be `undefined` if `options.releaseGeometryInstances`is `true` when the primitive is constructed.

Changing this property after the primitive is rendered has no effect.

Default Value: `undefined` 

#### [](#interleave) readonly interleave : boolean 

[engine/Source/Scene/Primitive.js 392](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L392) 

 Determines if geometry vertex attributes are interleaved, which can slightly improve rendering performance.

Default Value: `false` 

#### [](#modelMatrix) modelMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/Primitive.js 227](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L227) 

 The 4x4 transformation matrix that transforms the primitive (all geometry instances) from model to world coordinates. When this is the identity matrix, the primitive is drawn in world coordinates, i.e., Earth's WGS84 coordinates. Local reference frames can be used by providing a different transformation matrix, like that returned by [Transforms.eastNorthUpToFixedFrame](Transforms.html#.eastNorthUpToFixedFrame).

This property is only supported in 3D mode.

Default Value: `Matrix4.IDENTITY` 

##### Example:

```javascript
const origin = Cesium.Cartesian3.fromDegrees(-95.0, 40.0, 200000.0);
p.modelMatrix = Cesium.Transforms.eastNorthUpToFixedFrame(origin);
```

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/Primitive.js 485](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L485) 

 Determines if the primitive is complete and ready to render. If this property is true, the primitive will be rendered the next time that [Primitive#update](Primitive.html#update)is called.

##### Example:

```javascript
// Wait for a primitive to become ready before accessing attributes
const removeListener = scene.postRender.addEventListener(() => {
  if (!frustumPrimitive.ready) {
    return;
  }

  const attributes = primitive.getGeometryInstanceAttributes('an id');
  attributes.color = Cesium.ColorGeometryInstanceAttribute.toValue(Cesium.Color.AQUA);

  removeListener();
});
```

#### [](#releaseGeometryInstances) readonly releaseGeometryInstances : boolean 

[engine/Source/Scene/Primitive.js 408](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L408) 

 When `true`, the primitive does not keep a reference to the input `geometryInstances` to save memory.

Default Value: `true` 

#### [](#shadows) shadows : [ShadowMode](global.html#ShadowMode) 

[engine/Source/Scene/Primitive.js 303](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L303) 

 Determines whether this primitive casts or receives shadows from light sources.

Default Value: `ShadowMode.DISABLED` 

#### [](#show) show : boolean 

[engine/Source/Scene/Primitive.js 240](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L240) 

 Determines if the primitive will be shown. This affects all geometry instances in the primitive.

Default Value: `true` 

#### [](#vertexCacheOptimize) readonly vertexCacheOptimize : boolean 

[engine/Source/Scene/Primitive.js 376](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L376) 

 When `true`, geometry vertices are optimized for the pre and post-vertex-shader caches.

Default Value: `true` 

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/Primitive.js 2478](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L2478) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.

Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
e = e && e.destroy();
```

##### See:

* [Primitive#isDestroyed](Primitive.html#isDestroyed)

#### [](#getGeometryInstanceAttributes) getGeometryInstanceAttributes(id) → object 

[engine/Source/Scene/Primitive.js 2389](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L2389) 

 Returns the modifiable per-instance attributes for a [GeometryInstance](GeometryInstance.html).

| Name | Type | Description                                              |
| ---- | ---- | -------------------------------------------------------- |
| id   | \*   | The id of the [GeometryInstance](GeometryInstance.html). |

##### Returns:

 The typed array in the attribute's format or undefined if the is no instance with id.

##### Throws:

* [DeveloperError](DeveloperError.html): must call update before calling getGeometryInstanceAttributes.

##### Example:

```javascript
const attributes = primitive.getGeometryInstanceAttributes('an id');
attributes.color = Cesium.ColorGeometryInstanceAttribute.toValue(Cesium.Color.AQUA);
attributes.show = Cesium.ShowGeometryInstanceAttribute.toValue(true);
attributes.distanceDisplayCondition = Cesium.DistanceDisplayConditionGeometryInstanceAttribute.toValue(100.0, 10000.0);
attributes.offset = Cesium.OffsetGeometryInstanceAttribute.toValue(Cartesian3.IDENTITY);
```

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/Primitive.js 2457](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L2457) 

 Returns true if this object was destroyed; otherwise, false.

If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [Primitive#destroy](Primitive.html#destroy)

#### [](#update) update() 

[engine/Source/Scene/Primitive.js 2090](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Primitive.js#L2090) 

 Called when [Viewer](Viewer.html) or [CesiumWidget](CesiumWidget.html) render the scene to get the draw commands needed to render this primitive.

Do not call this function directly. This is documented just to list the exceptions that may be propagated when the scene is rendered:

##### Throws:

* [DeveloperError](DeveloperError.html): All instance geometries must have the same primitiveType.
* [DeveloperError](DeveloperError.html): Appearance and material have a uniform with the same name.
* [DeveloperError](DeveloperError.html): Primitive.modelMatrix is only supported in 3D mode.
* [RuntimeError](RuntimeError.html): Vertex texture fetch support is required to render primitives with per-instance attributes. The maximum number of vertex texture image units must be greater than zero.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

