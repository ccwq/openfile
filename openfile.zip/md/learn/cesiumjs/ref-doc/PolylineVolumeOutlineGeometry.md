# [![](Images/CesiumLogo.png)](index.html) PolylineVolumeOutlineGeometry 

#### [](#PolylineVolumeOutlineGeometry) new Cesium.PolylineVolumeOutlineGeometry(options) 

[engine/Source/Core/PolylineVolumeOutlineGeometry.js 110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolylineVolumeOutlineGeometry.js#L110) 

 A description of a polyline with a volume (a 2D shape extruded along a polyline).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description polylinePositions Array.<[Cartesian3](Cartesian3.html)\>  An array of positions that define the center of the polyline volume. shapePositions Array.<[Cartesian2](Cartesian2.html)\>  An array of positions that define the shape to be extruded along the polyline ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid to be used as a reference. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The distance, in radians, between each latitude and longitude. Determines the number of positions in the buffer. cornerType [CornerType](global.html#CornerType) CornerType.ROUNDED optional Determines the style of the corners. |

##### Example:

```javascript
function computeCircle(radius) {
  const positions = [];
  for (let i = 0; i < 360; i++) {
    const radians = Cesium.Math.toRadians(i);
    positions.push(new Cesium.Cartesian2(radius * Math.cos(radians), radius * Math.sin(radians)));
  }
  return positions;
}

const volumeOutline = new Cesium.PolylineVolumeOutlineGeometry({
  polylinePositions : Cesium.Cartesian3.fromDegreesArray([
    -72.0, 40.0,
    -70.0, 35.0
  ]),
  shapePositions : computeCircle(100000.0)
});
```

##### See:

* PolylineVolumeOutlineGeometry#createGeometry

### Members

#### [](#packedLength) packedLength : number 

[engine/Source/Core/PolylineVolumeOutlineGeometry.js 143](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolylineVolumeOutlineGeometry.js#L143) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.PolylineVolumeOutlineGeometry.createGeometry(polylineVolumeOutlineGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/PolylineVolumeOutlineGeometry.js 268](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolylineVolumeOutlineGeometry.js#L268) 

 Computes the geometric representation of the outline of a polyline with a volume, including its vertices, indices, and a bounding sphere.

| Name                          | Type                                                                | Description                                   |
| ----------------------------- | ------------------------------------------------------------------- | --------------------------------------------- |
| polylineVolumeOutlineGeometry | [PolylineVolumeOutlineGeometry](PolylineVolumeOutlineGeometry.html) | A description of the polyline volume outline. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.PolylineVolumeOutlineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/PolylineVolumeOutlineGeometry.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolylineVolumeOutlineGeometry.js#L155) 

 Stores the provided instance into the provided array.

| Name          | Type                                                                | Default | Description                                                               |
| ------------- | ------------------------------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [PolylineVolumeOutlineGeometry](PolylineVolumeOutlineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                                      |         | The array to pack into.                                                   |
| startingIndex | number                                                              | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.PolylineVolumeOutlineGeometry.unpack(array, startingIndex, result) → [PolylineVolumeOutlineGeometry](PolylineVolumeOutlineGeometry.html) 

[engine/Source/Core/PolylineVolumeOutlineGeometry.js 212](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PolylineVolumeOutlineGeometry.js#L212) 

 Retrieves an instance from a packed array.

| Name          | Type                                                                | Default | Description                                                |
| ------------- | ------------------------------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                                      |         | The packed array.                                          |
| startingIndex | number                                                              | 0       | optional The starting index of the element to be unpacked. |
| result        | [PolylineVolumeOutlineGeometry](PolylineVolumeOutlineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new PolylineVolumeOutlineGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

