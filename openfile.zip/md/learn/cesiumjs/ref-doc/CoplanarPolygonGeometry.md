# [![](Images/CesiumLogo.png)](index.html) CoplanarPolygonGeometry 

#### [](#CoplanarPolygonGeometry) new Cesium.CoplanarPolygonGeometry(options) 

[engine/Source/Core/CoplanarPolygonGeometry.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonGeometry.js#L249) 

 A description of a polygon composed of arbitrary coplanar positions.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | Object with the following properties: Name Type Default Description polygonHierarchy [PolygonHierarchy](PolygonHierarchy.html)  A polygon hierarchy that can include holes. stRotation number 0.0 optional The rotation of the texture coordinates, in radians. A positive rotation is counter-clockwise. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid to be used as a reference. textureCoordinates [PolygonHierarchy](PolygonHierarchy.html) optional Texture coordinates as a [PolygonHierarchy](PolygonHierarchy.html) of [Cartesian2](Cartesian2.html) points. |

##### Example:

```javascript
const polygonGeometry = new Cesium.CoplanarPolygonGeometry({
 polygonHierarchy: new Cesium.PolygonHierarchy(
    Cesium.Cartesian3.fromDegreesArrayHeights([
     -90.0, 30.0, 0.0,
     -90.0, 30.0, 300000.0,
     -80.0, 30.0, 300000.0,
     -80.0, 30.0, 0.0
  ]))
});
```

### Members

#### [](#packedLength) packedLength : number 

[engine/Source/Core/CoplanarPolygonGeometry.js 271](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonGeometry.js#L271) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.CoplanarPolygonGeometry.createGeometry(polygonGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/CoplanarPolygonGeometry.js 453](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonGeometry.js#L453) 

 Computes the geometric representation of an arbitrary coplanar polygon, including its vertices, indices, and a bounding sphere.

| Name            | Type                                                    | Description                   |
| --------------- | ------------------------------------------------------- | ----------------------------- |
| polygonGeometry | [CoplanarPolygonGeometry](CoplanarPolygonGeometry.html) | A description of the polygon. |

##### Returns:

 The computed vertices and indices.

#### [](#.fromPositions) static Cesium.CoplanarPolygonGeometry.fromPositions(options) → [CoplanarPolygonGeometry](CoplanarPolygonGeometry.html) 

[engine/Source/Core/CoplanarPolygonGeometry.js 313](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonGeometry.js#L313) 

 A description of a coplanar polygon from an array of positions.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of positions that defined the corner points of the polygon. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. stRotation number 0.0 optional The rotation of the texture coordinates, in radians. A positive rotation is counter-clockwise. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid to be used as a reference. textureCoordinates [PolygonHierarchy](PolygonHierarchy.html) optional Texture coordinates as a [PolygonHierarchy](PolygonHierarchy.html) of [Cartesian2](Cartesian2.html) points. |

##### Returns:

##### Example:

```javascript
// create a polygon from points
const polygon = Cesium.CoplanarPolygonGeometry.fromPositions({
  positions : Cesium.Cartesian3.fromDegreesArray([
    -72.0, 40.0,
    -70.0, 35.0,
    -75.0, 30.0,
    -70.0, 30.0,
    -68.0, 40.0
  ])
});
const geometry = Cesium.PolygonGeometry.createGeometry(polygon);
```

##### See:

* PolygonGeometry#createGeometry

#### [](#.pack) static Cesium.CoplanarPolygonGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/CoplanarPolygonGeometry.js 341](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonGeometry.js#L341) 

 Stores the provided instance into the provided array.

| Name          | Type                                                    | Default | Description                                                               |
| ------------- | ------------------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [CoplanarPolygonGeometry](CoplanarPolygonGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                          |         | The array to pack into.                                                   |
| startingIndex | number                                                  | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.CoplanarPolygonGeometry.unpack(array, startingIndex, result) → [CoplanarPolygonGeometry](CoplanarPolygonGeometry.html) 

[engine/Source/Core/CoplanarPolygonGeometry.js 391](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CoplanarPolygonGeometry.js#L391) 

 Retrieves an instance from a packed array.

| Name          | Type                                                    | Default | Description                                                |
| ------------- | ------------------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                          |         | The packed array.                                          |
| startingIndex | number                                                  | 0       | optional The starting index of the element to be unpacked. |
| result        | [CoplanarPolygonGeometry](CoplanarPolygonGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new CoplanarPolygonGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

