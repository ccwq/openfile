# [![](Images/CesiumLogo.png)](index.html) WebMapTileServiceImageryProvider 

#### [](#WebMapTileServiceImageryProvider) new Cesium.WebMapTileServiceImageryProvider(options) 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 116](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L116) 

 Provides tiled imagery served by [WMTS 1.0.0](http://www.opengeospatial.org/standards/wmts) compliant servers. This provider supports HTTP KVP-encoded and RESTful GetTile requests, but does not yet support the SOAP encoding.

| Name    | Type                                                                                                             | Description                              |
| ------- | ---------------------------------------------------------------------------------------------------------------- | ---------------------------------------- |
| options | [WebMapTileServiceImageryProvider.ConstructorOptions](WebMapTileServiceImageryProvider.html#.ConstructorOptions) | Object describing initialization options |

##### Examples:

```javascript
// Example 1. USGS shaded relief tiles (KVP)
const shadedRelief1 = new Cesium.WebMapTileServiceImageryProvider({
    url : 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSShadedReliefOnly/MapServer/WMTS',
    layer : 'USGSShadedReliefOnly',
    style : 'default',
    format : 'image/jpeg',
    tileMatrixSetID : 'default028mm',
    // tileMatrixLabels : ['default028mm:0', 'default028mm:1', 'default028mm:2' ...],
    maximumLevel: 19,
    credit : new Cesium.Credit('U. S. Geological Survey')
});
viewer.imageryLayers.addImageryProvider(shadedRelief1);
```

```javascript
// Example 2. USGS shaded relief tiles (RESTful)
const shadedRelief2 = new Cesium.WebMapTileServiceImageryProvider({
    url : 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSShadedReliefOnly/MapServer/WMTS/tile/1.0.0/USGSShadedReliefOnly/{Style}/{TileMatrixSet}/{TileMatrix}/{TileRow}/{TileCol}.jpg',
    layer : 'USGSShadedReliefOnly',
    style : 'default',
    format : 'image/jpeg',
    tileMatrixSetID : 'default028mm',
    maximumLevel: 19,
    credit : new Cesium.Credit('U. S. Geological Survey')
});
viewer.imageryLayers.addImageryProvider(shadedRelief2);
```

```javascript
// Example 3. NASA time dynamic weather data (RESTful)
const times = Cesium.TimeIntervalCollection.fromIso8601({
    iso8601: '2015-07-30/2017-06-16/P1D',
    dataCallback: function dataCallback(interval, index) {
        return {
            Time: Cesium.JulianDate.toIso8601(interval.start)
        };
    }
});
const weather = new Cesium.WebMapTileServiceImageryProvider({
    url : 'https://gibs.earthdata.nasa.gov/wmts/epsg4326/best/AMSR2_Snow_Water_Equivalent/default/{Time}/{TileMatrixSet}/{TileMatrix}/{TileRow}/{TileCol}.png',
    layer : 'AMSR2_Snow_Water_Equivalent',
    style : 'default',
    tileMatrixSetID : '2km',
    maximumLevel : 5,
    format : 'image/png',
    clock: clock,
    times: times,
    credit : new Cesium.Credit('NASA Global Imagery Browse Services for EOSDIS')
});
viewer.imageryLayers.addImageryProvider(weather);
```

##### Demo:

* [Cesium Sandcastle Web Map Tile Service with Time Demo](https://sandcastle.cesium.com/index.html?src=Web%2520Map%2520Tile%2520Service%2520with%2520Time.html)

##### See:

* [ArcGisMapServerImageryProvider](ArcGisMapServerImageryProvider.html)
* [BingMapsImageryProvider](BingMapsImageryProvider.html)
* [GoogleEarthEnterpriseMapsProvider](GoogleEarthEnterpriseMapsProvider.html)
* [OpenStreetMapImageryProvider](OpenStreetMapImageryProvider.html)
* [SingleTileImageryProvider](SingleTileImageryProvider.html)
* [TileMapServiceImageryProvider](TileMapServiceImageryProvider.html)
* [WebMapServiceImageryProvider](WebMapServiceImageryProvider.html)
* [UrlTemplateImageryProvider](UrlTemplateImageryProvider.html)

### Members

#### [](#clock) clock : [Clock](Clock.html) 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 482](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L482) 

 Gets or sets a clock that is used to get keep the time used for time dynamic parameters.

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 456](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L456) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

#### [](#dimensions) dimensions : object 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 510](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L510) 

 Gets or sets an object that contains static dimensions and their values.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 431](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L431) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#format) readonly format : string 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 443](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L443) 

 Gets the mime type of images returned by this imagery provider.

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 472](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L472) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. When this property is false, memory usage and texture upload time are reduced.

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 367](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L367) 

 Gets the maximum level-of-detail that can be requested.

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 379](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L379) 

 Gets the minimum level-of-detail that can be requested.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 331](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L331) 

 Gets the proxy used by this provider.

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 403](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L403) 

 Gets the rectangle, in radians, of the imagery provided by this instance.

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 417](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L417) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 355](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L355) 

 Gets the height of each tile, in pixels.

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 343](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L343) 

 Gets the width of each tile, in pixels.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 391](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L391) 

 Gets the tiling scheme used by this provider.

#### [](#times) times : [TimeIntervalCollection](TimeIntervalCollection.html) 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 497](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L497) 

 Gets or sets a time interval collection that is used to get time dynamic parameters. The data of each TimeInterval is an object containing the keys and values of the properties that are used during tile requests.

#### [](#url) readonly url : string 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 319](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L319) 

 Gets the URL of the service hosting the imagery.

### Methods

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 533](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L533) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → undefined 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 591](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L591) 

 Picking features is not currently supported by this imagery provider, so this function simply returns undefined.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 Undefined since picking is not supported.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<[ImageryTypes](global.html#ImageryTypes)\>|undefined 

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 551](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L551) 

 Requests the image for a given tile.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the image that will resolve when the image is available, or undefined if there are too many active requests to the server, and the request should be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.WebMapTileServiceImageryProvider.ConstructorOptions

[engine/Source/Scene/WebMapTileServiceImageryProvider.js 19](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/WebMapTileServiceImageryProvider.js#L19) 

 Initialization options for the WebMapTileServiceImageryProvider constructor

##### Properties:

| Name             | Type                                                  | Attributes | Default              | Description                                                                                                                                                                                                                                                                                                                                                                                     |
| ---------------- | ----------------------------------------------------- | ---------- | -------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| url              | [Resource](Resource.html)\|string                     |            |                      | The base URL for the WMTS GetTile operation (for KVP-encoded requests) or the tile-URL template (for RESTful requests). The tile-URL template should contain the following variables: {style}, {TileMatrixSet}, {TileMatrix}, {TileRow}, {TileCol}. The first two are optional if actual values are hardcoded or not required by the server. The {s} keyword may be used to specify subdomains. |
| format           | string                                                | <optional> | 'image/jpeg'         | The MIME type for images to retrieve from the server.                                                                                                                                                                                                                                                                                                                                           |
| layer            | string                                                |            |                      | The layer name for WMTS requests.                                                                                                                                                                                                                                                                                                                                                               |
| style            | string                                                |            |                      | The style name for WMTS requests.                                                                                                                                                                                                                                                                                                                                                               |
| tileMatrixSetID  | string                                                |            |                      | The identifier of the TileMatrixSet to use for WMTS requests.                                                                                                                                                                                                                                                                                                                                   |
| tileMatrixLabels | Array                                                 | <optional> |                      | A list of identifiers in the TileMatrix to use for WMTS requests, one per TileMatrix level.                                                                                                                                                                                                                                                                                                     |
| clock            | [Clock](Clock.html)                                   | <optional> |                      | A Clock instance that is used when determining the value for the time dimension. Required when \`times\` is specified.                                                                                                                                                                                                                                                                          |
| times            | [TimeIntervalCollection](TimeIntervalCollection.html) | <optional> |                      | TimeIntervalCollection with its data property being an object containing time dynamic dimension and their values.                                                                                                                                                                                                                                                                               |
| dimensions       | object                                                | <optional> |                      | A object containing static dimensions and their values.                                                                                                                                                                                                                                                                                                                                         |
| tileWidth        | number                                                | <optional> | 256                  | The tile width in pixels.                                                                                                                                                                                                                                                                                                                                                                       |
| tileHeight       | number                                                | <optional> | 256                  | The tile height in pixels.                                                                                                                                                                                                                                                                                                                                                                      |
| tilingScheme     | [TilingScheme](TilingScheme.html)                     | <optional> |                      | The tiling scheme corresponding to the organization of the tiles in the TileMatrixSet.                                                                                                                                                                                                                                                                                                          |
| rectangle        | [Rectangle](Rectangle.html)                           | <optional> | Rectangle.MAX\_VALUE | The rectangle covered by the layer.                                                                                                                                                                                                                                                                                                                                                             |
| minimumLevel     | number                                                | <optional> | 0                    | The minimum level-of-detail supported by the imagery provider.                                                                                                                                                                                                                                                                                                                                  |
| maximumLevel     | number                                                | <optional> |                      | The maximum level-of-detail supported by the imagery provider, or undefined if there is no limit.                                                                                                                                                                                                                                                                                               |
| ellipsoid        | [Ellipsoid](Ellipsoid.html)                           | <optional> |                      | The ellipsoid. If not specified, the WGS84 ellipsoid is used.                                                                                                                                                                                                                                                                                                                                   |
| credit           | [Credit](Credit.html)\|string                         | <optional> |                      | A credit for the data source, which is displayed on the canvas.                                                                                                                                                                                                                                                                                                                                 |
| subdomains       | string\|Array.<string>                                | <optional> | 'abc'                | The subdomains to use for the {s} placeholder in the URL template. If this parameter is a single string, each character in the string is a subdomain. If it is an array, each element in the array is a subdomain.                                                                                                                                                                              |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

