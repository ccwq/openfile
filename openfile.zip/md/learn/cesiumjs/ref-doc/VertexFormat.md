# [![](Images/CesiumLogo.png)](index.html) VertexFormat 

#### [](#VertexFormat) new Cesium.VertexFormat(options) 

[engine/Source/Core/VertexFormat.js 25](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L25) 

 A vertex format defines what attributes make up a vertex. A VertexFormat can be provided to a [Geometry](Geometry.html) to request that certain properties be computed, e.g., just position, position and normal, etc.

| Name    | Type   | Description                                                                                                       |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------- |
| options | object | optional An object with boolean properties corresponding to VertexFormat properties as shown in the code example. |

##### Example:

```javascript
// Create a vertex format with position and 2D texture coordinate attributes.
const format = new Cesium.VertexFormat({
  position : true,
  st : true
});
```

##### See:

* [Geometry#attributes](Geometry.html#attributes)
* [Packable](Packable.html)

### Members

#### [](#.ALL) static constant Cesium.VertexFormat.ALL : [VertexFormat](VertexFormat.html) 

[engine/Source/Core/VertexFormat.js 197](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L197) 

 An immutable vertex format with well-known attributes: position, normal, st, tangent, and bitangent.

##### See:

* [VertexFormat#position](VertexFormat.html#position)
* [VertexFormat#normal](VertexFormat.html#normal)
* [VertexFormat#st](VertexFormat.html#st)
* [VertexFormat#tangent](VertexFormat.html#tangent)
* [VertexFormat#bitangent](VertexFormat.html#bitangent)

#### [](#.DEFAULT) static constant Cesium.VertexFormat.DEFAULT : [VertexFormat](VertexFormat.html) 

[engine/Source/Core/VertexFormat.js 219](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L219) 

 An immutable vertex format with position, normal, and st attributes. This is compatible with most appearances and materials; however normal and st attributes are not always required. When this is known in advance, another `VertexFormat` should be used.

##### See:

* [VertexFormat#position](VertexFormat.html#position)
* [VertexFormat#normal](VertexFormat.html#normal)

#### [](#.packedLength) static Cesium.VertexFormat.packedLength : number 

[engine/Source/Core/VertexFormat.js 225](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L225) 

 The number of elements used to pack the object into an array.

#### [](#.POSITION%5FAND%5FCOLOR) static constant Cesium.VertexFormat.POSITION\_AND\_COLOR : [VertexFormat](VertexFormat.html) 

[engine/Source/Core/VertexFormat.js 178](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L178) 

 An immutable vertex format with position and color attributes.

##### See:

* [VertexFormat#position](VertexFormat.html#position)
* [VertexFormat#color](VertexFormat.html#color)

#### [](#.POSITION%5FAND%5FNORMAL) static constant Cesium.VertexFormat.POSITION\_AND\_NORMAL : [VertexFormat](VertexFormat.html) 

[engine/Source/Core/VertexFormat.js 125](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L125) 

 An immutable vertex format with position and normal attributes. This is compatible with per-instance color appearances like [PerInstanceColorAppearance](PerInstanceColorAppearance.html).

##### See:

* [VertexFormat#position](VertexFormat.html#position)
* [VertexFormat#normal](VertexFormat.html#normal)

#### [](#.POSITION%5FAND%5FST) static constant Cesium.VertexFormat.POSITION\_AND\_ST : [VertexFormat](VertexFormat.html) 

[engine/Source/Core/VertexFormat.js 162](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L162) 

 An immutable vertex format with position and st attributes. This is compatible with [EllipsoidSurfaceAppearance](EllipsoidSurfaceAppearance.html).

##### See:

* [VertexFormat#position](VertexFormat.html#position)
* [VertexFormat#st](VertexFormat.html#st)

#### [](#.POSITION%5FNORMAL%5FAND%5FST) static constant Cesium.VertexFormat.POSITION\_NORMAL\_AND\_ST : [VertexFormat](VertexFormat.html) 

[engine/Source/Core/VertexFormat.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L144) 

 An immutable vertex format with position, normal, and st attributes. This is compatible with [MaterialAppearance](MaterialAppearance.html) when [MaterialAppearance#materialSupport](MaterialAppearance.html#materialSupport)is TEXTURED/code>. 

##### See:

* [VertexFormat#position](VertexFormat.html#position)
* [VertexFormat#normal](VertexFormat.html#normal)
* [VertexFormat#st](VertexFormat.html#st)

#### [](#.POSITION%5FONLY) static constant Cesium.VertexFormat.POSITION\_ONLY : [VertexFormat](VertexFormat.html) 

[engine/Source/Core/VertexFormat.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L109) 

 An immutable vertex format with only a position attribute.

##### See:

* [VertexFormat#position](VertexFormat.html#position)

#### [](#bitangent) bitangent : boolean 

[engine/Source/Core/VertexFormat.js 74](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L74) 

 When `true`, the vertex has a bitangent attribute (normalized), which is used for tangent-space effects like bump mapping.

32-bit floating-point. 3 components per attribute.

Default Value: `false` 

#### [](#color) color : boolean 

[engine/Source/Core/VertexFormat.js 98](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L98) 

 When `true`, the vertex has an RGB color attribute.

8-bit unsigned byte. 3 components per attribute.

Default Value: `false` 

#### [](#normal) normal : boolean 

[engine/Source/Core/VertexFormat.js 50](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L50) 

 When `true`, the vertex has a normal attribute (normalized), which is commonly used for lighting.

32-bit floating-point. 3 components per attribute.

Default Value: `false` 

#### [](#position) position : boolean 

[engine/Source/Core/VertexFormat.js 38](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L38) 

 When `true`, the vertex has a 3D position attribute.

64-bit floating-point (for precision). 3 components per attribute.

Default Value: `false` 

#### [](#st) st : boolean 

[engine/Source/Core/VertexFormat.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L62) 

 When `true`, the vertex has a 2D texture coordinate attribute.

32-bit floating-point. 2 components per attribute

Default Value: `false` 

#### [](#tangent) tangent : boolean 

[engine/Source/Core/VertexFormat.js 86](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L86) 

 When `true`, the vertex has a tangent attribute (normalized), which is used for tangent-space effects like bump mapping.

32-bit floating-point. 3 components per attribute.

Default Value: `false` 

### Methods

#### [](#.clone) static Cesium.VertexFormat.clone(vertexFormat, result) → [VertexFormat](VertexFormat.html) 

[engine/Source/Core/VertexFormat.js 295](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L295) 

 Duplicates a VertexFormat instance.

| Name         | Type                              | Description                                         |
| ------------ | --------------------------------- | --------------------------------------------------- |
| vertexFormat | [VertexFormat](VertexFormat.html) | The vertex format to duplicate.                     |
| result       | [VertexFormat](VertexFormat.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new VertexFormat instance if one was not provided. (Returns undefined if vertexFormat is undefined)

#### [](#.pack) static Cesium.VertexFormat.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/VertexFormat.js 236](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L236) 

 Stores the provided instance into the provided array.

| Name          | Type                              | Default | Description                                                               |
| ------------- | --------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [VertexFormat](VertexFormat.html) |         | The value to pack.                                                        |
| array         | Array.<number>                    |         | The array to pack into.                                                   |
| startingIndex | number                            | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.VertexFormat.unpack(array, startingIndex, result) → [VertexFormat](VertexFormat.html) 

[engine/Source/Core/VertexFormat.js 266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/VertexFormat.js#L266) 

 Retrieves an instance from a packed array.

| Name          | Type                              | Default | Description                                                |
| ------------- | --------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                    |         | The packed array.                                          |
| startingIndex | number                            | 0       | optional The starting index of the element to be unpacked. |
| result        | [VertexFormat](VertexFormat.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new VertexFormat instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

