# [![](Images/CesiumLogo.png)](index.html) CreditDisplay 

#### [](#CreditDisplay) new Cesium.CreditDisplay(container, delimiter, viewport) 

[engine/Source/Scene/CreditDisplay.js 305](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CreditDisplay.js#L305) 

 The credit display is responsible for displaying credits on screen.

| Name      | Type        | Default       | Description                                                   |
| --------- | ----------- | ------------- | ------------------------------------------------------------- |
| container | HTMLElement |               | The HTML element where credits will be displayed              |
| delimiter | string      | '•'           | optional The string to separate text credits                  |
| viewport  | HTMLElement | document.body | optional The HTML element that will contain the credits popup |

##### Examples:

```javascript
// Add a credit with a tooltip, image and link to display onscreen
const credit = new Cesium.Credit(`<a href="https://cesium.com/" target="_blank"><img src="/images/cesium_logo.png" title="Cesium"/></a>`, true);
viewer.creditDisplay.addStaticCredit(credit);
```

```javascript
// Add a credit with a plaintext link to display in the lightbox
const credit = new Cesium.Credit('<a href="https://cesium.com/" target="_blank">Cesium</a>');
viewer.creditDisplay.addStaticCredit(credit);
```

### Members

#### [](#.cesiumCredit) static Cesium.CreditDisplay.cesiumCredit : [Credit](Credit.html) 

[engine/Source/Scene/CreditDisplay.js 645](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CreditDisplay.js#L645) 

 Gets or sets the Cesium logo credit.

#### [](#container) container : HTMLElement 

[engine/Source/Scene/CreditDisplay.js 393](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CreditDisplay.js#L393) 

 The HTML element where credits will be displayed.

### Methods

#### [](#addCreditToNextFrame) addCreditToNextFrame(credit) 

[engine/Source/Scene/CreditDisplay.js 425](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CreditDisplay.js#L425) 

 Adds a [Credit](Credit.html) that will show on screen or in the lightbox until the next frame. This is mostly for internal use. Use `CreditDisplay.addStaticCredit` to add a persistent credit to the screen.

| Name   | Type                  | Description                              |
| ------ | --------------------- | ---------------------------------------- |
| credit | [Credit](Credit.html) | The credit to display in the next frame. |

##### See:

* CreditDisplay.addStaticCredit

#### [](#addStaticCredit) addStaticCredit(credit) 

[engine/Source/Scene/CreditDisplay.js 465](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CreditDisplay.js#L465) 

 Adds a [Credit](Credit.html) that will show on screen or in the lightbox until removed with `CreditDisplay.removeStaticCredit`.

| Name   | Type                  | Description         |
| ------ | --------------------- | ------------------- |
| credit | [Credit](Credit.html) | The credit to added |

##### Examples:

```javascript
// Add a credit with a tooltip, image and link to display onscreen
const credit = new Cesium.Credit(`<a href="https://cesium.com/" target="_blank"><img src="/images/cesium_logo.png" title="Cesium"/></a>`, true);
viewer.creditDisplay.addStaticCredit(credit);
```

```javascript
// Add a credit with a plaintext link to display in the lightbox
const credit = new Cesium.Credit('<a href="https://cesium.com/" target="_blank">Cesium</a>');
viewer.creditDisplay.addStaticCredit(credit);
```

#### [](#beginFrame) beginFrame() 

[engine/Source/Scene/CreditDisplay.js 521](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CreditDisplay.js#L521) 

 Resets the credit display to a beginning of frame state, clearing out current credits.

#### [](#destroy) destroy() 

[engine/Source/Scene/CreditDisplay.js 586](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CreditDisplay.js#L586) 

 Destroys the resources held by this object. Destroying an object allows for deterministic release of resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

#### [](#endFrame) endFrame() 

[engine/Source/Scene/CreditDisplay.js 559](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CreditDisplay.js#L559) 

 Sets the credit display to the end of frame state, displaying credits from the last frame in the credit container.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/CreditDisplay.js 603](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CreditDisplay.js#L603) 

 Returns true if this object was destroyed; otherwise, false.  
  
##### Returns:

`true` if this object was destroyed; otherwise, `false`.

#### [](#removeStaticCredit) removeStaticCredit(credit) 

[engine/Source/Scene/CreditDisplay.js 481](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CreditDisplay.js#L481) 

 Removes a static credit shown on screen or in the lightbox.

| Name   | Type                  | Description               |
| ------ | --------------------- | ------------------------- |
| credit | [Credit](Credit.html) | The credit to be removed. |

#### [](#update) update() 

[engine/Source/Scene/CreditDisplay.js 512](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CreditDisplay.js#L512) 

 Updates the credit display before a new frame is rendered.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

