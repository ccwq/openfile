# [![](Images/CesiumLogo.png)](index.html) Globe 

#### [](#Globe) new Cesium.Globe(ellipsoid) 

[engine/Source/Scene/Globe.js 43](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L43) 

 The globe rendered in the scene, including its terrain ([Globe#terrainProvider](Globe.html#terrainProvider)) and imagery layers ([Globe#imageryLayers](Globe.html#imageryLayers)). Access the globe using [Scene#globe](Scene.html#globe).

| Name      | Type                        | Default           | Description                                          |
| --------- | --------------------------- | ----------------- | ---------------------------------------------------- |
| ellipsoid | [Ellipsoid](Ellipsoid.html) | Ellipsoid.default | optional Determines the size and shape of the globe. |

### Members

#### [](#atmosphereBrightnessShift) atmosphereBrightnessShift : number 

[engine/Source/Scene/Globe.js 344](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L344) 

 The brightness shift to apply to the atmosphere. Defaults to 0.0 (no shift). A brightness shift of -1.0 is complete darkness, which will let space show through.

Default Value: `0.0` 

#### [](#atmosphereHueShift) atmosphereHueShift : number 

[engine/Source/Scene/Globe.js 328](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L328) 

 The hue shift to apply to the atmosphere. Defaults to 0.0 (no shift). A hue shift of 1.0 indicates a complete rotation of the hues available.

Default Value: `0.0` 

#### [](#atmosphereLightIntensity) atmosphereLightIntensity : number 

[engine/Source/Scene/Globe.js 205](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L205) 

 The intensity of the light that is used for computing the ground atmosphere color.

Default Value: `10.0` 

#### [](#atmosphereMieAnisotropy) atmosphereMieAnisotropy : number 

[engine/Source/Scene/Globe.js 247](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L247) 

 The anisotropy of the medium to consider for Mie scattering.

Valid values are between -1.0 and 1.0.

Default Value: `0.9` 

#### [](#atmosphereMieCoefficient) atmosphereMieCoefficient : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Globe.js 221](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L221) 

 The Mie scattering coefficient used in the atmospheric scattering equations for the ground atmosphere.

Default Value: `Cartesian3(21e-6, 21e-6, 21e-6)` 

#### [](#atmosphereMieScaleHeight) atmosphereMieScaleHeight : number 

[engine/Source/Scene/Globe.js 237](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L237) 

 The Mie scale height used in the atmospheric scattering equations for the ground atmosphere, in meters.

Default Value: `3200.0` 

#### [](#atmosphereRayleighCoefficient) atmosphereRayleighCoefficient : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Globe.js 213](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L213) 

 The Rayleigh scattering coefficient used in the atmospheric scattering equations for the ground atmosphere.

Default Value: `Cartesian3(5.5e-6, 13.0e-6, 28.4e-6)` 

#### [](#atmosphereRayleighScaleHeight) atmosphereRayleighScaleHeight : number 

[engine/Source/Scene/Globe.js 229](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L229) 

 The Rayleigh scale height used in the atmospheric scattering equations for the ground atmosphere, in meters.

Default Value: `10000.0` 

#### [](#atmosphereSaturationShift) atmosphereSaturationShift : number 

[engine/Source/Scene/Globe.js 336](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L336) 

 The saturation shift to apply to the atmosphere. Defaults to 0.0 (no shift). A saturation shift of -1.0 is monochrome.

Default Value: `0.0` 

#### [](#backFaceCulling) backFaceCulling : boolean 

[engine/Source/Scene/Globe.js 361](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L361) 

 Whether to cull back-facing terrain. Back faces are not culled when the camera is underground or translucency is enabled.

Default Value: `true` 

#### [](#baseColor) baseColor : [Color](Color.html) 

[engine/Source/Scene/Globe.js 433](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L433) 

 Gets or sets the color of the globe when no imagery is available.

#### [](#cartographicLimitRectangle) cartographicLimitRectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/Globe.js 477](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L477) 

 A property specifying a [Rectangle](Rectangle.html) used to limit globe rendering to a cartographic area. Defaults to the maximum extent of cartographic coordinates.

Default Value: `[Rectangle.MAX_VALUE](Rectangle.html#.MAX%5FVALUE)` 

#### [](#clippingPlanes) clippingPlanes : [ClippingPlaneCollection](ClippingPlaneCollection.html) 

[engine/Source/Scene/Globe.js 447](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L447) 

 A property specifying a [ClippingPlaneCollection](ClippingPlaneCollection.html) used to selectively disable rendering on the outside of each plane.

#### [](#clippingPolygons) clippingPolygons : [ClippingPolygonCollection](ClippingPolygonCollection.html) 

[engine/Source/Scene/Globe.js 461](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L461) 

 A property specifying a [ClippingPolygonCollection](ClippingPolygonCollection.html) used to selectively disable rendering inside or outside a list of polygons.

#### [](#depthTestAgainstTerrain) depthTestAgainstTerrain : boolean 

[engine/Source/Scene/Globe.js 310](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L310) 

 True if primitives such as billboards, polylines, labels, etc. should be depth-tested against the terrain surface, or false if such primitives should always be drawn on top of terrain unless they're on the opposite side of the globe. The disadvantage of depth testing primitives against terrain is that slight numerical noise or terrain level-of-detail switched can sometimes make a primitive that should be on the surface disappear underneath it.

Default Value: `false` 

#### [](#dynamicAtmosphereLighting) dynamicAtmosphereLighting : boolean 

[engine/Source/Scene/Globe.js 179](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L179) 

 Enable dynamic lighting effects on atmosphere and fog. This only takes effect when `enableLighting` is `true`.

Default Value: `true` 

#### [](#dynamicAtmosphereLightingFromSun) dynamicAtmosphereLightingFromSun : boolean 

[engine/Source/Scene/Globe.js 189](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L189) 

 Whether dynamic atmosphere lighting uses the sun direction instead of the scene's light direction. This only takes effect when `enableLighting` and`dynamicAtmosphereLighting` are `true`.

Default Value: `false` 

#### [](#ellipsoid) ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Scene/Globe.js 382](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L382) 

 Gets an ellipsoid describing the shape of this globe.

#### [](#enableLighting) enableLighting : boolean 

[engine/Source/Scene/Globe.js 160](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L160) 

 Enable lighting the globe with the scene's light source.

Default Value: `false` 

#### [](#fillHighlightColor) fillHighlightColor : [Color](Color.html) 

[engine/Source/Scene/Globe.js 152](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L152) 

 The color to use to highlight terrain fill tiles. If undefined, fill tiles are not highlighted at all. The alpha value is used to alpha blend with the tile's actual color. Because terrain fill tiles do not represent the actual terrain surface, it may be useful in some applications to indicate visually that they are not to be trusted.

Default Value: `undefined` 

#### [](#imageryLayers) imageryLayers : [ImageryLayerCollection](ImageryLayerCollection.html) 

[engine/Source/Scene/Globe.js 392](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L392) 

 Gets the collection of image layers that will be rendered on this globe.

#### [](#imageryLayersUpdatedEvent) readonly imageryLayersUpdatedEvent : [Event](Event.html) 

[engine/Source/Scene/Globe.js 404](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L404) 

 Gets an event that's raised when an imagery layer is added, shown, hidden, moved, or removed.

#### [](#lambertDiffuseMultiplier) lambertDiffuseMultiplier : number 

[engine/Source/Scene/Globe.js 170](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L170) 

 A multiplier to adjust terrain lambert lighting. This number is multiplied by the result of `czm_getLambertDiffuse` in GlobeFS.glsl. This only takes effect when `enableLighting` is `true`.

Default Value: `0.9` 

#### [](#lightingFadeInDistance) lightingFadeInDistance : number 

[engine/Source/Scene/Globe.js 266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L266) 

 The distance where lighting resumes. This only takes effect when `enableLighting` or `showGroundAtmosphere` is `true`.

Default Value: `pi * ellipsoid.minimumRadius` 

#### [](#lightingFadeOutDistance) lightingFadeOutDistance : number 

[engine/Source/Scene/Globe.js 256](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L256) 

 The distance where everything becomes lit. This only takes effect when `enableLighting` or `showGroundAtmosphere` is `true`.

Default Value: `1/2 * pi * ellipsoid.minimumRadius` 

#### [](#loadingDescendantLimit) loadingDescendantLimit : number 

[engine/Source/Scene/Globe.js 123](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L123) 

 Gets or sets the number of loading descendant tiles that is considered "too many". If a tile has too many loading descendants, that tile will be loaded and rendered before any of its descendants are loaded and rendered. This means more feedback for the user that something is happening at the cost of a longer overall load time. Setting this to 0 will cause each tile level to be loaded successively, significantly increasing load time. Setting it to a large number (e.g. 1000) will minimize the number of tiles that are loaded but tend to make detail appear all at once after a long wait.

Default Value: `20` 

#### [](#material) material : [Material](Material.html)|undefined 

[engine/Source/Scene/Globe.js 557](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L557) 

 Gets or sets the material appearance of the Globe. This can be one of several built-in [Material](Material.html) objects or a custom material, scripted with[Fabric](https://github.com/CesiumGS/cesium/wiki/Fabric).

#### [](#maximumScreenSpaceError) maximumScreenSpaceError : number 

[engine/Source/Scene/Globe.js 99](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L99) 

 The maximum screen-space error used to drive level-of-detail refinement. Higher values will provide better performance but lower visual quality.

Default Value: `2` 

#### [](#nightFadeInDistance) nightFadeInDistance : number 

[engine/Source/Scene/Globe.js 286](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L286) 

 The distance where the darkness of night from the ground atmosphere fades in to an unlit ground atmosphere. This only takes effect when `showGroundAtmosphere`, `enableLighting`, and`dynamicAtmosphereLighting` are `true`.

Default Value: `5/2 * pi * ellipsoid.minimumRadius` 

#### [](#nightFadeOutDistance) nightFadeOutDistance : number 

[engine/Source/Scene/Globe.js 276](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L276) 

 The distance where the darkness of night from the ground atmosphere fades out to a lit ground atmosphere. This only takes effect when `showGroundAtmosphere`, `enableLighting`, and`dynamicAtmosphereLighting` are `true`.

Default Value: `1/2 * pi * ellipsoid.minimumRadius` 

#### [](#oceanNormalMapUrl) oceanNormalMapUrl : string 

[engine/Source/Scene/Globe.js 495](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L495) 

 The normal map to use for rendering waves in the ocean. Setting this property will only have an effect if the configured terrain provider includes a water mask.

Default Value: `buildModuleUrl('Assets/Textures/waterNormalsSmall.jpg')` 

#### [](#preloadAncestors) preloadAncestors : boolean 

[engine/Source/Scene/Globe.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L132) 

 Gets or sets a value indicating whether the ancestors of rendered tiles should be preloaded. Setting this to true optimizes the zoom-out experience and provides more detail in newly-exposed areas when panning. The down side is that it requires loading more tiles.

Default Value: `true` 

#### [](#preloadSiblings) preloadSiblings : boolean 

[engine/Source/Scene/Globe.js 142](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L142) 

 Gets or sets a value indicating whether the siblings of rendered tiles should be preloaded. Setting this to true causes tiles with the same parent as a rendered tile to be loaded, even if they are culled. Setting this to true may provide a better panning experience at the cost of loading more tiles.

Default Value: `false` 

#### [](#shadows) shadows : [ShadowMode](global.html#ShadowMode) 

[engine/Source/Scene/Globe.js 320](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L320) 

 Determines whether the globe casts or receives shadows from light sources. Setting the globe to cast shadows may impact performance since the terrain is rendered again from the light's perspective. Currently only terrain that is in view casts shadows. By default the globe does not cast shadows.

Default Value: `ShadowMode.RECEIVE_ONLY` 

#### [](#show) show : boolean 

[engine/Source/Scene/Globe.js 85](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L85) 

 Determines if the globe will be shown.

Default Value: `true` 

#### [](#showGroundAtmosphere) showGroundAtmosphere : boolean 

[engine/Source/Scene/Globe.js 197](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L197) 

 Enable the ground atmosphere, which is drawn over the globe when viewed from a distance between `lightingFadeInDistance` and `lightingFadeOutDistance`.

Default Value: `true when using the WGS84 ellipsoid, false otherwise` 

#### [](#showSkirts) showSkirts : boolean 

[engine/Source/Scene/Globe.js 353](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L353) 

 Whether to show terrain skirts. Terrain skirts are geometry extending downwards from a tile's edges used to hide seams between neighboring tiles. Skirts are always hidden when the camera is underground or translucency is enabled.

Default Value: `true` 

#### [](#showWaterEffect) showWaterEffect : boolean 

[engine/Source/Scene/Globe.js 297](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L297) 

 True if an animated wave effect should be shown in areas of the globe covered by water; otherwise, false. This property is ignored if the`terrainProvider` does not provide a water mask.

Default Value: `true` 

#### [](#terrainProvider) terrainProvider : [TerrainProvider](TerrainProvider.html) 

[engine/Source/Scene/Globe.js 512](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L512) 

 The terrain provider providing surface geometry for this globe.

#### [](#terrainProviderChanged) readonly terrainProviderChanged : [Event](Event.html) 

[engine/Source/Scene/Globe.js 533](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L533) 

 Gets an event that's raised when the terrain provider is changed

#### [](#tileCacheSize) tileCacheSize : number 

[engine/Source/Scene/Globe.js 110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L110) 

 The size of the terrain tile cache, expressed as a number of tiles. Any additional tiles beyond this number will be freed, as long as they aren't needed for rendering this frame. A larger number will consume more memory but will show detail faster when, for example, zooming out and then back in.

Default Value: `100` 

#### [](#tileLoadProgressEvent) tileLoadProgressEvent : [Event](Event.html) 

[engine/Source/Scene/Globe.js 545](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L545) 

 Gets an event that's raised when the length of the tile load queue has changed since the last render frame. When the load queue is empty, all terrain and imagery for the current view have been loaded. The event passes the new length of the tile load queue.

#### [](#tilesLoaded) readonly tilesLoaded : boolean 

[engine/Source/Scene/Globe.js 416](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L416) 

 Returns `true` when the tile load queue is empty, `false` otherwise. When the load queue is empty, all terrain and imagery for the current view have been loaded.

#### [](#translucency) translucency : [GlobeTranslucency](GlobeTranslucency.html) 

[engine/Source/Scene/Globe.js 632](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L632) 

 Properties for controlling globe translucency.

#### [](#undergroundColor) undergroundColor : [Color](Color.html) 

[engine/Source/Scene/Globe.js 581](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L581) 

 The color to render the back side of the globe when the camera is underground or the globe is translucent, blended with the globe color based on the camera's distance.  
  
To disable underground coloring, set `undergroundColor` to `undefined`.

Default Value: `[Color.BLACK](Color.html#.BLACK)` 

##### See:

* [Globe#undergroundColorAlphaByDistance](Globe.html#undergroundColorAlphaByDistance)

#### [](#undergroundColorAlphaByDistance) undergroundColorAlphaByDistance : [NearFarScalar](NearFarScalar.html) 

[engine/Source/Scene/Globe.js 607](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L607) 

 Gets or sets the near and far distance for blending [Globe#undergroundColor](Globe.html#undergroundColor) with the globe color. The alpha will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the alpha remains clamped to the nearest bound. If undefined, the underground color will not be blended with the globe color.  
  
When the camera is above the ellipsoid the distance is computed from the nearest point on the ellipsoid instead of the camera's position.

##### See:

* [Globe#undergroundColor](Globe.html#undergroundColor)

#### [](#vertexShadowDarkness) vertexShadowDarkness : number 

[engine/Source/Scene/Globe.js 373](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L373) 

 Determines the darkness of the vertex shadow. This only takes effect when `enableLighting` is `true`.

Default Value: `0.3` 

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/Globe.js 1127](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L1127) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
globe = globe && globe.destroy();
```

##### See:

* [Globe#isDestroyed](Globe.html#isDestroyed)

#### [](#getHeight) getHeight(cartographic) → number|undefined 

[engine/Source/Scene/Globe.js 839](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L839) 

 Get the height of the surface at a given cartographic.

| Name         | Type                              | Description                                    |
| ------------ | --------------------------------- | ---------------------------------------------- |
| cartographic | [Cartographic](Cartographic.html) | The cartographic for which to find the height. |

##### Returns:

 The height of the cartographic or undefined if it could not be found.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/Globe.js 1107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L1107) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

 True if this object was destroyed; otherwise, false.

##### See:

* [Globe#destroy](Globe.html#destroy)

#### [](#pick) pick(ray, scene, result) → [Cartesian3](Cartesian3.html)|undefined 

[engine/Source/Scene/Globe.js 811](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Globe.js#L811) 

 Find an intersection between a ray and the globe surface that was rendered. The ray must be given in world coordinates.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| ray    | [Ray](Ray.html)               | The ray to test for intersection.                   |
| scene  | [Scene](Scene.html)           | The scene.                                          |
| result | [Cartesian3](Cartesian3.html) | optional The object onto which to store the result. |

##### Returns:

 The intersection or `undefined` if none was found.

##### Example:

```javascript
// find intersection of ray through a pixel and the globe
const ray = viewer.camera.getPickRay(windowCoordinates);
const intersection = globe.pick(ray, scene);
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

