# [![](Images/CesiumLogo.png)](index.html) DebugAppearance 

#### [](#DebugAppearance) new Cesium.DebugAppearance(options) 

[engine/Source/Scene/DebugAppearance.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L35) 

 Visualizes a vertex attribute by displaying it as a color for debugging.

Components for well-known unit-length vectors, i.e., `normal`,`tangent`, and `bitangent`, are scaled and biased from \[-1.0, 1.0\] to (-1.0, 1.0).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description attributeName string  The name of the attribute to visualize. perInstanceAttribute boolean false optional Boolean that determines whether this attribute is a per-instance geometry attribute. glslDatatype string 'vec3' optional The GLSL datatype of the attribute. Supported datatypes are float, vec2, vec3, and vec4. vertexShaderSource string optional Optional GLSL vertex shader source to override the default vertex shader. fragmentShaderSource string optional Optional GLSL fragment shader source to override the default fragment shader. renderState object optional Optional render state to override the default render state. |

##### Throws:

* [DeveloperError](DeveloperError.html): options.glslDatatype must be float, vec2, vec3, or vec4.

##### Example:

```javascript
const primitive = new Cesium.Primitive({
  geometryInstances : // ...
  appearance : new Cesium.DebugAppearance({
    attributeName : 'normal'
  })
});
```

### Members

#### [](#attributeName) readonly attributeName : string 

[engine/Source/Scene/DebugAppearance.js 215](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L215) 

 The name of the attribute being visualized.

#### [](#closed) readonly closed : boolean 

[engine/Source/Scene/DebugAppearance.js 201](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L201) 

 When `true`, the geometry is expected to be closed.

Default Value: `false` 

#### [](#fragmentShaderSource) readonly fragmentShaderSource : string 

[engine/Source/Scene/DebugAppearance.js 171](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L171) 

 The GLSL source code for the fragment shader. The full fragment shader source is built procedurally taking into account the [DebugAppearance#material](DebugAppearance.html#material). Use [DebugAppearance#getFragmentShaderSource](DebugAppearance.html#getFragmentShaderSource) to get the full source.

#### [](#glslDatatype) readonly glslDatatype : string 

[engine/Source/Scene/DebugAppearance.js 229](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L229) 

 The GLSL datatype of the attribute being visualized.

#### [](#material) material : [Material](Material.html) 

[engine/Source/Scene/DebugAppearance.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L120) 

 This property is part of the [Appearance](Appearance.html) interface, but is not used by [DebugAppearance](DebugAppearance.html) since a fully custom fragment shader is used.

Default Value: `undefined` 

#### [](#renderState) readonly renderState : object 

[engine/Source/Scene/DebugAppearance.js 185](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L185) 

 The WebGL fixed-function state to use when rendering the geometry.

#### [](#translucent) translucent : boolean 

[engine/Source/Scene/DebugAppearance.js 129](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L129) 

 When `true`, the geometry is expected to appear translucent.

Default Value: `false` 

#### [](#vertexShaderSource) readonly vertexShaderSource : string 

[engine/Source/Scene/DebugAppearance.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L155) 

 The GLSL source code for the vertex shader.

### Methods

#### [](#getFragmentShaderSource) getFragmentShaderSource() → string 

[engine/Source/Scene/DebugAppearance.js 244](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L244) 

 Returns the full GLSL fragment shader source, which for [DebugAppearance](DebugAppearance.html) is just[DebugAppearance#fragmentShaderSource](DebugAppearance.html#fragmentShaderSource).

##### Returns:

 The full GLSL fragment shader source.

#### [](#getRenderState) getRenderState() → object 

[engine/Source/Scene/DebugAppearance.js 265](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L265) 

 Creates a render state. This is not the final render state instance; instead, it can contain a subset of render state properties identical to the render state created in the context.

##### Returns:

 The render state.

#### [](#isTranslucent) isTranslucent() → boolean 

[engine/Source/Scene/DebugAppearance.js 254](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/DebugAppearance.js#L254) 

 Determines if the geometry is translucent based on [DebugAppearance#translucent](DebugAppearance.html#translucent).

##### Returns:

`true` if the appearance is translucent.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

