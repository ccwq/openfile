# [![](Images/CesiumLogo.png)](index.html) Cesium3DTileset 

#### [](#Cesium3DTileset) new Cesium.Cesium3DTileset(options) 

[engine/Source/Scene/Cesium3DTileset.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L200) 

 A [3D Tiles tileset](https://github.com/CesiumGS/3d-tiles/tree/main/specification), used for streaming massive heterogeneous 3D geospatial datasets.

This object is normally not instantiated directly, use [Cesium3DTileset.fromUrl](Cesium3DTileset.html#.fromUrl).

| Name    | Type                                                                           | Description                                 |
| ------- | ------------------------------------------------------------------------------ | ------------------------------------------- |
| options | [Cesium3DTileset.ConstructorOptions](Cesium3DTileset.html#.ConstructorOptions) | An object describing initialization options |

##### Throws:

* [DeveloperError](DeveloperError.html): The tileset must be 3D Tiles version 0.0 or 1.0.

##### Examples:

```javascript
try {
  const tileset = await Cesium.Cesium3DTileset.fromUrl(
     "http://localhost:8002/tilesets/Seattle/tileset.json"
  );
  scene.primitives.add(tileset);
} catch (error) {
  console.error(`Error creating tileset: ${error}`);
}
```

```javascript
// Turn on camera collisions with the tileset.
try {
  const tileset = await Cesium.Cesium3DTileset.fromUrl(
     "http://localhost:8002/tilesets/Seattle/tileset.json",
     { enableCollision: true }
  );
  scene.primitives.add(tileset);
} catch (error) {
  console.error(`Error creating tileset: ${error}`);
}
```

```javascript
// Common setting for the skipLevelOfDetail optimization
const tileset = await Cesium.Cesium3DTileset.fromUrl(
  "http://localhost:8002/tilesets/Seattle/tileset.json", {
     skipLevelOfDetail: true,
     baseScreenSpaceError: 1024,
     skipScreenSpaceErrorFactor: 16,
     skipLevels: 1,
     immediatelyLoadDesiredLevelOfDetail: false,
     loadSiblings: false,
     cullWithChildrenBounds: true
});
scene.primitives.add(tileset);
```

```javascript
// Common settings for the dynamicScreenSpaceError optimization
const tileset = await Cesium.Cesium3DTileset.fromUrl(
  "http://localhost:8002/tilesets/Seattle/tileset.json", {
     dynamicScreenSpaceError: true,
     dynamicScreenSpaceErrorDensity: 2.0e-4,
     dynamicScreenSpaceErrorFactor: 24.0,
     dynamicScreenSpaceErrorHeightFalloff: 0.25
});
scene.primitives.add(tileset);
```

##### See:

* [3D Tiles specification](https://github.com/CesiumGS/3d-tiles/tree/main/specification)

### Members

#### [](#allTilesLoaded) allTilesLoaded : [Event](Event.html) 

[engine/Source/Scene/Cesium3DTileset.js 595](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L595) 

 The event fired to indicate that all tiles that meet the screen space error this frame are loaded. The tileset is completely loaded for this view.

This event is fired at the end of the frame after the scene is rendered.

Default Value: `new Event()` 

##### Example:

```javascript
tileset.allTilesLoaded.addEventListener(function() {
    console.log('All tiles are loaded');
});
```

##### See:

* [Cesium3DTileset#tilesLoaded](Cesium3DTileset.html#tilesLoaded)

#### [](#asset) readonly asset : object 

[engine/Source/Scene/Cesium3DTileset.js 1110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1110) 

 Gets the tileset's asset object property, which contains metadata about the tileset.

See the [asset schema reference](https://github.com/CesiumGS/3d-tiles/tree/main/specification#reference-asset)in the 3D Tiles spec for the full set of properties.

#### [](#backFaceCulling) backFaceCulling : boolean 

[engine/Source/Scene/Cesium3DTileset.js 856](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L856) 

 Whether to cull back-facing geometry. When true, back face culling is determined by the glTF material's doubleSided property; when false, back face culling is disabled.

Default Value: `true` 

#### [](#basePath) readonly deprecated basePath : string 

[engine/Source/Scene/Cesium3DTileset.js 1229](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1229) 

 The base path that non-absolute paths in tileset JSON file are relative to.

Deprecated: true 

#### [](#baseScreenSpaceError) baseScreenSpaceError : number 

[engine/Source/Scene/Cesium3DTileset.js 749](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L749) 

 The screen space error that must be reached before skipping levels of detail.

Only used when [Cesium3DTileset#skipLevelOfDetail](Cesium3DTileset.html#skipLevelOfDetail) is `true`.

Default Value: `1024` 

#### [](#boundingSphere) readonly boundingSphere : [BoundingSphere](BoundingSphere.html) 

[engine/Source/Scene/Cesium3DTileset.js 1601](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1601) 

 The tileset's bounding sphere.

##### Example:

```javascript
const tileset = await Cesium.Cesium3DTileset.fromUrl("http://localhost:8002/tilesets/Seattle/tileset.json");

viewer.scene.primitives.add(tileset);

// Set the camera to view the newly added tileset
viewer.camera.viewBoundingSphere(tileset.boundingSphere, new Cesium.HeadingPitchRange(0, -0.5, 0));
```

#### [](#cacheBytes) cacheBytes : number 

[engine/Source/Scene/Cesium3DTileset.js 1487](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1487) 

 The amount of GPU memory (in bytes) used to cache tiles. This memory usage is estimated from geometry, textures, and batch table textures of loaded tiles. For point clouds, this value also includes per-point metadata.

Tiles not in view are unloaded to enforce this.

If decreasing this value results in unloading tiles, the tiles are unloaded the next frame.

If tiles sized more than `cacheBytes` are needed to meet the desired screen space error, determined by [Cesium3DTileset#maximumScreenSpaceError](Cesium3DTileset.html#maximumScreenSpaceError), for the current view, then the memory usage of the tiles loaded will exceed`cacheBytes` by up to `maximumCacheOverflowBytes`. For example, if `cacheBytes` is 500000, but 600000 bytes of tiles are needed to meet the screen space error, then 600000 bytes of tiles may be loaded (if `maximumCacheOverflowBytes` is at least 100000). When these tiles go out of view, they will be unloaded.

Default Value: `536870912` 

##### See:

* [Cesium3DTileset#totalMemoryUsageInBytes](Cesium3DTileset.html#totalMemoryUsageInBytes)

#### [](#classificationType) readonly classificationType : [ClassificationType](global.html#ClassificationType) 

[engine/Source/Scene/Cesium3DTileset.js 1748](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1748) 

 Determines whether terrain, 3D Tiles, or both will be classified by this tileset.

This option is only applied to tilesets containing batched 3D models, glTF content, geometry data, or vector data. Even when undefined, vector and geometry data must render as classifications and will default to rendering on both terrain and other 3D Tiles tilesets.

When enabled for batched 3D model and glTF tilesets, there are a few requirements/limitations on the glTF:
* The glTF cannot contain morph targets, skins, or animations.
* The glTF cannot contain the `EXT_mesh_gpu_instancing` extension.
* Only meshes with TRIANGLES can be used to classify other assets.
* The meshes must be watertight.
* The `POSITION` semantic is required.
* If `_BATCHID`s and an index buffer are both present, all indices with the same batch id must occupy contiguous sections of the index buffer.
* If `_BATCHID`s are present with no index buffer, all positions with the same batch id must occupy contiguous sections of the position buffer.

Additionally, classification is not supported for points or instanced 3D models.

The 3D Tiles or terrain receiving the classification must be opaque.

Default Value: `undefined` 

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#clippingPlanes) clippingPlanes : [ClippingPlaneCollection](ClippingPlaneCollection.html) 

[engine/Source/Scene/Cesium3DTileset.js 1137](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1137) 

 The [ClippingPlaneCollection](ClippingPlaneCollection.html) used to selectively disable rendering the tileset.

#### [](#clippingPolygons) clippingPolygons : [ClippingPolygonCollection](ClippingPolygonCollection.html) 

[engine/Source/Scene/Cesium3DTileset.js 1153](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1153) 

 The [ClippingPolygonCollection](ClippingPolygonCollection.html) used to selectively disable rendering the tileset.

#### [](#colorBlendAmount) colorBlendAmount : number 

[engine/Source/Scene/Cesium3DTileset.js 546](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L546) 

 Defines the value used to linearly interpolate between the source color and feature color when the [Cesium3DTileset#colorBlendMode](Cesium3DTileset.html#colorBlendMode) is `MIX`. A value of 0.0 results in the source color while a value of 1.0 results in the feature color, with any value in-between resulting in a mix of the source color and feature color.

Default Value: `0.5` 

#### [](#colorBlendMode) colorBlendMode : [Cesium3DTileColorBlendMode](global.html#Cesium3DTileColorBlendMode) 

[engine/Source/Scene/Cesium3DTileset.js 536](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L536) 

 Defines how per-feature colors set from the Cesium API or declarative styling blend with the source colors from the original feature, e.g. glTF material or per-point color in the tile.

Default Value: `Cesium3DTileColorBlendMode.HIGHLIGHT` 

#### [](#cullRequestsWhileMoving) cullRequestsWhileMoving : boolean 

[engine/Source/Scene/Cesium3DTileset.js 308](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L308) 

 Optimization option. Don't request tiles that will likely be unused when they come back because of the camera's movement. This optimization only applies to stationary tilesets.

Default Value: `true` 

#### [](#cullRequestsWhileMovingMultiplier) cullRequestsWhileMovingMultiplier : number 

[engine/Source/Scene/Cesium3DTileset.js 320](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L320) 

 Optimization option. Multiplier used in culling requests while moving. Larger is more aggressive culling, smaller less aggressive culling.

Default Value: `60.0` 

#### [](#customShader) customShader : [CustomShader](CustomShader.html)|undefined 

[engine/Source/Scene/Cesium3DTileset.js 1306](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1306) 

 A custom shader to apply to all tiles in the tileset. Only used for contents that use [Model](Model.html). Using custom shaders with a[Cesium3DTileStyle](Cesium3DTileStyle.html) may lead to undefined behavior.

Default Value: `undefined` 

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#debugColorizeTiles) debugColorizeTiles : boolean 

[engine/Source/Scene/Cesium3DTileset.js 923](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L923) 

 This property is for debugging only; it is not optimized for production use.

When true, assigns a random color to each tile. This is useful for visualizing what features belong to what tiles, especially with additive refinement where features from parent tiles may be interleaved with features from child tiles.

Default Value: `false` 

#### [](#debugFreezeFrame) debugFreezeFrame : boolean 

[engine/Source/Scene/Cesium3DTileset.js 910](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L910) 

 This property is for debugging only; it is not optimized for production use.

Determines if only the tiles from last frame should be used for rendering. This effectively "freezes" the tileset to the previous frame so it is possible to zoom out and see what was rendered.

Default Value: `false` 

#### [](#debugShowBoundingVolume) debugShowBoundingVolume : boolean 

[engine/Source/Scene/Cesium3DTileset.js 960](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L960) 

 This property is for debugging only; it is not optimized for production use.

When true, renders the bounding volume for each visible tile. The bounding volume is white if the tile has a content bounding volume or is empty; otherwise, it is red. Tiles that don't meet the screen space error and are still refining to their descendants are yellow.

Default Value: `false` 

#### [](#debugShowContentBoundingVolume) debugShowContentBoundingVolume : boolean 

[engine/Source/Scene/Cesium3DTileset.js 975](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L975) 

 This property is for debugging only; it is not optimized for production use.

When true, renders the bounding volume for each visible tile's content. The bounding volume is blue if the tile has a content bounding volume; otherwise it is red.

Default Value: `false` 

#### [](#debugShowGeometricError) debugShowGeometricError : boolean 

[engine/Source/Scene/Cesium3DTileset.js 1012](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1012) 

 This property is for debugging only; it is not optimized for production use.

When true, draws labels to indicate the geometric error of each tile.

Default Value: `false` 

#### [](#debugShowMemoryUsage) debugShowMemoryUsage : boolean 

[engine/Source/Scene/Cesium3DTileset.js 1040](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1040) 

 This property is for debugging only; it is not optimized for production use.

When true, draws labels to indicate the geometry and texture memory usage of each tile.

Default Value: `false` 

#### [](#debugShowRenderingStatistics) debugShowRenderingStatistics : boolean 

[engine/Source/Scene/Cesium3DTileset.js 1026](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1026) 

 This property is for debugging only; it is not optimized for production use.

When true, draws labels to indicate the number of commands, points, triangles and features of each tile.

Default Value: `false` 

#### [](#debugShowUrl) debugShowUrl : boolean 

[engine/Source/Scene/Cesium3DTileset.js 1051](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1051) 

 This property is for debugging only; it is not optimized for production use.

When true, draws labels to indicate the url of each tile.

Default Value: `false` 

#### [](#debugShowViewerRequestVolume) debugShowViewerRequestVolume : boolean 

[engine/Source/Scene/Cesium3DTileset.js 989](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L989) 

 This property is for debugging only; it is not optimized for production use.

When true, renders the viewer request volume for each tile.

Default Value: `false` 

#### [](#debugWireframe) debugWireframe : boolean 

[engine/Source/Scene/Cesium3DTileset.js 939](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L939) 

 This property is for debugging only; it is not optimized for production use.

When true, renders each tile's content as a wireframe.

Default Value: `false` 

#### [](#dynamicScreenSpaceError) dynamicScreenSpaceError : boolean 

[engine/Source/Scene/Cesium3DTileset.js 398](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L398) 

 Optimization option. For street-level horizon views, use lower resolution tiles far from the camera. This reduces the amount of data loaded and improves tileset loading time with a slight drop in visual quality in the distance.

This optimization is strongest when the camera is close to the ground plane of the tileset and looking at the horizon. Furthermore, the results are more accurate for tightly fitting bounding volumes like box and region.

Default Value: `true` 

#### [](#dynamicScreenSpaceErrorDensity) dynamicScreenSpaceErrorDensity : number 

[engine/Source/Scene/Cesium3DTileset.js 464](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L464) 

 Similar to [Fog#density](Fog.html#density), this option controls the camera distance at which the [Cesium3DTileset#dynamicScreenSpaceError](Cesium3DTileset.html#dynamicScreenSpaceError)optimization applies. Larger values will cause tiles closer to the camera to be affected. This value must be non-negative.

This optimization works by rolling off the tile screen space error (SSE) with camera distance like a bell curve. This has the effect of selecting lower resolution tiles far from the camera. Near the camera, no adjustment is made. For tiles further away, the SSE is reduced by up to [Cesium3DTileset#dynamicScreenSpaceErrorFactor](Cesium3DTileset.html#dynamicScreenSpaceErrorFactor)(measured in pixels of error).

Increasing the density makes the bell curve narrower so tiles closer to the camera are affected. This is analagous to moving fog closer to the camera.

When the density is 0, the optimization will have no effect on the tileset.

Default Value: `2.0e-4` 

#### [](#dynamicScreenSpaceErrorFactor) dynamicScreenSpaceErrorFactor : number 

[engine/Source/Scene/Cesium3DTileset.js 485](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L485) 

 A parameter that controls the intensity of the [Cesium3DTileset#dynamicScreenSpaceError](Cesium3DTileset.html#dynamicScreenSpaceError) optimization for tiles on the horizon. Larger values cause lower resolution tiles to load, improving runtime performance at a slight reduction of visual quality. The value must be non-negative.

More specifically, this parameter represents the maximum adjustment to screen space error (SSE) in pixels for tiles far away from the camera. See [Cesium3DTileset#dynamicScreenSpaceErrorDensity](Cesium3DTileset.html#dynamicScreenSpaceErrorDensity) for more details about how this optimization works.

When the SSE factor is set to 0, the optimization will have no effect on the tileset.

Default Value: `24.0` 

#### [](#dynamicScreenSpaceErrorHeightFalloff) dynamicScreenSpaceErrorHeightFalloff : number 

[engine/Source/Scene/Cesium3DTileset.js 499](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L499) 

 A ratio of the tileset's height that determines "street level" for the [Cesium3DTileset#dynamicScreenSpaceError](Cesium3DTileset.html#dynamicScreenSpaceError)optimization. When the camera is below this height, the dynamic screen space error optimization will have the maximum effect, and it will roll off above this value. Valid values are between 0.0 and 1.0.

Default Value: `0.25` 

#### [](#ellipsoid) readonly ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Scene/Cesium3DTileset.js 1762](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1762) 

 Gets an ellipsoid describing the shape of the globe.

#### [](#enableCollision) enableCollision : boolean 

[engine/Source/Scene/Cesium3DTileset.js 895](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L895) 

 If `true`, allows collisions for camera collisions or picking. While this is `true` the camera will be prevented from going in or below the tileset surface if [ScreenSpaceCameraController#enableCollisionDetection](ScreenSpaceCameraController.html#enableCollisionDetection) is true. This can have performance implecations if the tileset contains tile with a larger number of vertices.

Default Value: `false` 

#### [](#environmentMapManager) readonly environmentMapManager : [DynamicEnvironmentMapManager](DynamicEnvironmentMapManager.html) 

[engine/Source/Scene/Cesium3DTileset.js 1881](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1881) 

 The properties for managing dynamic environment maps on this model. Affects lighting.

##### Example:

```javascript
// Change the ground color used for a tileset's environment map to a forest green
const environmentMapManager = tileset.environmentMapManager;
environmentMapManager.groundColor = Cesium.Color.fromCssColorString("#203b34");
```

#### [](#examineVectorLinesFunction) examineVectorLinesFunction : function 

[engine/Source/Scene/Cesium3DTileset.js 1060](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1060) 

 Function for examining vector lines as they are being streamed.

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#extensions) readonly extensions : object 

[engine/Source/Scene/Cesium3DTileset.js 1124](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1124) 

 Gets the tileset's extensions object property.

#### [](#extras) readonly extras : \* 

[engine/Source/Scene/Cesium3DTileset.js 1834](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1834) 

 Returns the `extras` property at the top-level of the tileset JSON, which contains application specific metadata. Returns `undefined` if `extras` does not exist.

##### See:

* [Extras in the 3D Tiles specification.](https://github.com/CesiumGS/3d-tiles/tree/main/specification#specifying-extensions-and-application-specific-extras)

#### [](#featureIdLabel) featureIdLabel : string 

[engine/Source/Scene/Cesium3DTileset.js 1960](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1960) 

 Label of the feature ID set to use for picking and styling.

For EXT\_mesh\_features, this is the feature ID's label property, or "featureId\_N" (where N is the index in the featureIds array) when not specified. EXT\_feature\_metadata did not have a label field, so such feature ID sets are always labeled "featureId\_N" where N is the index in the list of all feature Ids, where feature ID attributes are listed before feature ID textures.

If featureIdLabel is set to an integer N, it is converted to the string "featureId\_N" automatically. If both per-primitive and per-instance feature IDs are present, the instance feature IDs take priority.

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#foveatedConeSize) foveatedConeSize : number 

[engine/Source/Scene/Cesium3DTileset.js 1778](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1778) 

 Optimization option. Used when [Cesium3DTileset#foveatedScreenSpaceError](Cesium3DTileset.html#foveatedScreenSpaceError) is true to control the cone size that determines which tiles are deferred. Tiles that are inside this cone are loaded immediately. Tiles outside the cone are potentially deferred based on how far outside the cone they are and [Cesium3DTileset#foveatedInterpolationCallback](Cesium3DTileset.html#foveatedInterpolationCallback) and [Cesium3DTileset#foveatedMinimumScreenSpaceErrorRelaxation](Cesium3DTileset.html#foveatedMinimumScreenSpaceErrorRelaxation). Setting this to 0.0 means the cone will be the line formed by the camera position and its view direction. Setting this to 1.0 means the cone encompasses the entire field of view of the camera, essentially disabling the effect.

Default Value: `0.3` 

#### [](#foveatedInterpolationCallback) foveatedInterpolationCallback : [Cesium3DTileset.foveatedInterpolationCallback](Cesium3DTileset.html#.foveatedInterpolationCallback) 

[engine/Source/Scene/Cesium3DTileset.js 427](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L427) 

 Gets or sets a callback to control how much to raise the screen space error for tiles outside the foveated cone, interpolating between [Cesium3DTileset#foveatedMinimumScreenSpaceErrorRelaxation](Cesium3DTileset.html#foveatedMinimumScreenSpaceErrorRelaxation) and [Cesium3DTileset#maximumScreenSpaceError](Cesium3DTileset.html#maximumScreenSpaceError).

#### [](#foveatedMinimumScreenSpaceErrorRelaxation) foveatedMinimumScreenSpaceErrorRelaxation : number 

[engine/Source/Scene/Cesium3DTileset.js 1801](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1801) 

 Optimization option. Used when [Cesium3DTileset#foveatedScreenSpaceError](Cesium3DTileset.html#foveatedScreenSpaceError) is true to control the starting screen space error relaxation for tiles outside the foveated cone. The screen space error will be raised starting with this value up to [Cesium3DTileset#maximumScreenSpaceError](Cesium3DTileset.html#maximumScreenSpaceError) based on the provided [Cesium3DTileset#foveatedInterpolationCallback](Cesium3DTileset.html#foveatedInterpolationCallback).

Default Value: `0.0` 

#### [](#foveatedScreenSpaceError) foveatedScreenSpaceError : boolean 

[engine/Source/Scene/Cesium3DTileset.js 411](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L411) 

 Optimization option. Prioritize loading tiles in the center of the screen by temporarily raising the screen space error for tiles around the edge of the screen. Screen space error returns to normal once all the tiles in the center of the screen as determined by the [Cesium3DTileset#foveatedConeSize](Cesium3DTileset.html#foveatedConeSize) are loaded.

Default Value: `true` 

#### [](#foveatedTimeDelay) foveatedTimeDelay : number 

[engine/Source/Scene/Cesium3DTileset.js 441](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L441) 

 Optimization option. Used when [Cesium3DTileset#foveatedScreenSpaceError](Cesium3DTileset.html#foveatedScreenSpaceError) is true to control how long in seconds to wait after the camera stops moving before deferred tiles start loading in. This time delay prevents requesting tiles around the edges of the screen when the camera is moving. Setting this to 0.0 will immediately request all tiles in any given view.

Default Value: `0.2` 

#### [](#imageBasedLighting) imageBasedLighting : [ImageBasedLighting](ImageBasedLighting.html) 

[engine/Source/Scene/Cesium3DTileset.js 1847](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1847) 

 The properties for managing image-based lighting on this tileset.

#### [](#immediatelyLoadDesiredLevelOfDetail) immediatelyLoadDesiredLevelOfDetail : boolean 

[engine/Source/Scene/Cesium3DTileset.js 789](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L789) 

 When true, only tiles that meet the maximum screen space error will ever be downloaded. Skipping factors are ignored and just the desired tiles are loaded.

Only used when [Cesium3DTileset#skipLevelOfDetail](Cesium3DTileset.html#skipLevelOfDetail) is `true`.

Default Value: `false` 

#### [](#initialTilesLoaded) initialTilesLoaded : [Event](Event.html) 

[engine/Source/Scene/Cesium3DTileset.js 614](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L614) 

 The event fired to indicate that all tiles that meet the screen space error this frame are loaded. This event is fired once when all tiles in the initial view are loaded.

This event is fired at the end of the frame after the scene is rendered.

Default Value: `new Event()` 

##### Example:

```javascript
tileset.initialTilesLoaded.addEventListener(function() {
    console.log('Initial tiles are loaded');
});
```

##### See:

* [Cesium3DTileset#allTilesLoaded](Cesium3DTileset.html#allTilesLoaded)

#### [](#instanceFeatureIdLabel) instanceFeatureIdLabel : string 

[engine/Source/Scene/Cesium3DTileset.js 1992](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1992) 

 Label of the instance feature ID set used for picking and styling.

If instanceFeatureIdLabel is set to an integer N, it is converted to the string "instanceFeatureId\_N" automatically. If both per-primitive and per-instance feature IDs are present, the instance feature IDs take priority.

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#lightColor) lightColor : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/Cesium3DTileset.js 847](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L847) 

 The light color when shading models. When `undefined` the scene's light color is used instead.

For example, disabling additional light sources by setting`tileset.imageBasedLighting.imageBasedLightingFactor = new Cartesian2(0.0, 0.0)`will make the tileset much darker. Here, increasing the intensity of the light source will make the tileset brighter.

Default Value: `undefined` 

#### [](#loadProgress) loadProgress : [Event](Event.html) 

[engine/Source/Scene/Cesium3DTileset.js 576](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L576) 

 The event fired to indicate progress of loading new tiles. This event is fired when a new tile is requested, when a requested tile is finished downloading, and when a downloaded tile has been processed and is ready to render.

The number of pending tile requests, `numberOfPendingRequests`, and number of tiles processing, `numberOfTilesProcessing` are passed to the event listener.

This event is fired at the end of the frame after the scene is rendered.

Default Value: `new Event()` 

##### Example:

```javascript
tileset.loadProgress.addEventListener(function(numberOfPendingRequests, numberOfTilesProcessing) {
    if ((numberOfPendingRequests === 0) && (numberOfTilesProcessing === 0)) {
        console.log('Stopped loading');
        return;
    }

    console.log(`Loading: requests: ${numberOfPendingRequests}, processing: ${numberOfTilesProcessing}`);
});
```

#### [](#loadSiblings) loadSiblings : boolean 

[engine/Source/Scene/Cesium3DTileset.js 804](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L804) 

 Determines whether siblings of visible tiles are always downloaded during traversal. This may be useful for ensuring that tiles are already available when the viewer turns left/right.

Only used when [Cesium3DTileset#skipLevelOfDetail](Cesium3DTileset.html#skipLevelOfDetail) is `true`.

Default Value: `false` 

#### [](#maximumCacheOverflowBytes) maximumCacheOverflowBytes : number 

[engine/Source/Scene/Cesium3DTileset.js 1519](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1519) 

 The maximum additional amount of GPU memory (in bytes) that will be used to cache tiles.

If tiles sized more than `cacheBytes` plus `maximumCacheOverflowBytes`are needed to meet the desired screen space error, determined by[Cesium3DTileset#maximumScreenSpaceError](Cesium3DTileset.html#maximumScreenSpaceError) for the current view, then`Cesium3DTileset#memoryAdjustedScreenSpaceError` will be adjusted until the tiles required to meet the adjusted screen space error use less than `cacheBytes` plus `maximumCacheOverflowBytes`.

Default Value: `536870912` 

##### See:

* [Cesium3DTileset#totalMemoryUsageInBytes](Cesium3DTileset.html#totalMemoryUsageInBytes)

#### [](#maximumScreenSpaceError) maximumScreenSpaceError : number 

[engine/Source/Scene/Cesium3DTileset.js 1440](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1440) 

 The maximum screen space error used to drive level of detail refinement. This value helps determine when a tile refines to its descendants, and therefore plays a major role in balancing performance with visual quality.

A tile's screen space error is roughly equivalent to the number of pixels wide that would be drawn if a sphere with a radius equal to the tile's **geometric error** were rendered at the tile's position. If this value exceeds`maximumScreenSpaceError` the tile refines to its descendants.

Depending on the tileset, `maximumScreenSpaceError` may need to be tweaked to achieve the right balance. Higher values provide better performance but lower visual quality.

Default Value: `16` 

#### [](#modelMatrix) modelMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/Cesium3DTileset.js 1626](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1626) 

 A 4x4 transformation matrix that transforms the entire tileset.

Default Value: `Matrix4.IDENTITY` 

##### Example:

```javascript
// Adjust a tileset's height from the globe's surface.
const heightOffset = 20.0;
const boundingSphere = tileset.boundingSphere;
const cartographic = Cesium.Cartographic.fromCartesian(boundingSphere.center);
const surface = Cesium.Cartesian3.fromRadians(cartographic.longitude, cartographic.latitude, 0.0);
const offset = Cesium.Cartesian3.fromRadians(cartographic.longitude, cartographic.latitude, heightOffset);
const translation = Cesium.Cartesian3.subtract(offset, surface, new Cesium.Cartesian3());
tileset.modelMatrix = Cesium.Matrix4.fromTranslation(translation);
```

#### [](#outlineColor) outlineColor : [Color](Color.html) 

[engine/Source/Scene/Cesium3DTileset.js 876](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L876) 

 The color to use when rendering outlines.

Default Value: `Color.BLACK` 

#### [](#pointCloudShading) pointCloudShading : [PointCloudShading](PointCloudShading.html) 

[engine/Source/Scene/Cesium3DTileset.js 1559](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1559) 

 Options for controlling point size based on geometric error and eye dome lighting.

#### [](#preferLeaves) preferLeaves : boolean 

[engine/Source/Scene/Cesium3DTileset.js 343](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L343) 

 Optimization option. Prefer loading of leaves first.

Default Value: `false` 

#### [](#preloadFlightDestinations) preloadFlightDestinations : boolean 

[engine/Source/Scene/Cesium3DTileset.js 382](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L382) 

 Optimization option. Fetch tiles at the camera's flight destination while the camera is in flight.

Default Value: `true` 

#### [](#preloadWhenHidden) preloadWhenHidden : boolean 

[engine/Source/Scene/Cesium3DTileset.js 374](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L374) 

 Preload tiles when `tileset.show` is `false`. Loads tiles as if the tileset is visible but does not render them.

Default Value: `false` 

#### [](#progressiveResolutionHeightFraction) progressiveResolutionHeightFraction : number 

[engine/Source/Scene/Cesium3DTileset.js 331](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L331) 

 Optimization option. If between (0.0, 0.5\], tiles at or above the screen space error for the reduced screen resolution of `progressiveResolutionHeightFraction*screenHeight` will be prioritized first. This can help get a quick layer of tiles down while full resolution tiles continue to load.

Default Value: `0.3` 

#### [](#properties) readonly properties : object 

[engine/Source/Scene/Cesium3DTileset.js 1181](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1181) 

 Gets the tileset's properties dictionary object, which contains metadata about per-feature properties.

See the [properties schema reference](https://github.com/CesiumGS/3d-tiles/tree/main/specification#reference-properties)in the 3D Tiles spec for the full set of properties.

##### Example:

```javascript
console.log(`Maximum building height: ${tileset.properties.height.maximum}`);
console.log(`Minimum building height: ${tileset.properties.height.minimum}`);
```

##### See:

* [Cesium3DTileFeature#getProperty](Cesium3DTileFeature.html#getProperty)
* [Cesium3DTileFeature#setProperty](Cesium3DTileFeature.html#setProperty)

#### [](#resource) readonly resource : [Resource](Resource.html) 

[engine/Source/Scene/Cesium3DTileset.js 1214](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1214) 

 The resource used to fetch the tileset JSON file

#### [](#root) readonly root : [Cesium3DTile](Cesium3DTile.html) 

[engine/Source/Scene/Cesium3DTileset.js 1579](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1579) 

 The root tile.

#### [](#shadows) shadows : [ShadowMode](global.html#ShadowMode) 

[engine/Source/Scene/Cesium3DTileset.js 519](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L519) 

 Determines whether the tileset casts or receives shadows from light sources.

Enabling shadows has a performance impact. A tileset that casts shadows must be rendered twice, once from the camera and again from the light's point of view.

Shadows are rendered only when [Viewer#shadows](Viewer.html#shadows) is `true`.

Default Value: `ShadowMode.ENABLED` 

#### [](#show) show : boolean 

[engine/Source/Scene/Cesium3DTileset.js 527](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L527) 

 Determines if the tileset will be shown.

Default Value: `true` 

#### [](#showCreditsOnScreen) showCreditsOnScreen : boolean 

[engine/Source/Scene/Cesium3DTileset.js 1928](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1928) 

 Determines whether the credits of the tileset will be displayed on the screen

Default Value: `false` 

#### [](#showOutline) showOutline : boolean 

[engine/Source/Scene/Cesium3DTileset.js 868](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L868) 

 Whether to display the outline for models using the[CESIUM\_primitive\_outline](https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Vendor/CESIUM%5Fprimitive%5Foutline) extension. When true, outlines are displayed. When false, outlines are not displayed.

Default Value: `true` 

#### [](#skipLevelOfDetail) skipLevelOfDetail : boolean 

[engine/Source/Scene/Cesium3DTileset.js 736](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L736) 

 Optimization option. Determines if level of detail skipping should be applied during the traversal.

The common strategy for replacement-refinement traversal is to store all levels of the tree in memory and require all children to be loaded before the parent can refine. With this optimization levels of the tree can be skipped entirely and children can be rendered alongside their parents. The tileset requires significantly less memory when using this optimization.

Default Value: `false` 

#### [](#skipLevels) skipLevels : number 

[engine/Source/Scene/Cesium3DTileset.js 777](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L777) 

 Constant defining the minimum number of levels to skip when loading tiles. When it is 0, no levels are skipped. For example, if a tile is level 1, no tiles will be loaded unless they are at level greater than 2.

Only used when [Cesium3DTileset#skipLevelOfDetail](Cesium3DTileset.html#skipLevelOfDetail) is `true`.

Default Value: `1` 

#### [](#skipScreenSpaceErrorFactor) skipScreenSpaceErrorFactor : number 

[engine/Source/Scene/Cesium3DTileset.js 762](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L762) 

 Multiplier defining the minimum screen space error to skip. For example, if a tile has screen space error of 100, no tiles will be loaded unless they are leaves or have a screen space error `<= 100 / skipScreenSpaceErrorFactor`.

Only used when [Cesium3DTileset#skipLevelOfDetail](Cesium3DTileset.html#skipLevelOfDetail) is `true`.

Default Value: `16` 

#### [](#splitDirection) splitDirection : [SplitDirection](global.html#SplitDirection) 

[engine/Source/Scene/Cesium3DTileset.js 884](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L884) 

 The [SplitDirection](global.html#SplitDirection) to apply to this tileset.

Default Value: `[SplitDirection.NONE](global.html#SplitDirection#.NONE)` 

#### [](#style) style : [Cesium3DTileStyle](Cesium3DTileStyle.html)|undefined 

[engine/Source/Scene/Cesium3DTileset.js 1284](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1284) 

 The style, defined using the[3D Tiles Styling language](https://github.com/CesiumGS/3d-tiles/tree/main/specification/Styling), applied to each feature in the tileset.

Assign `undefined` to remove the style, which will restore the visual appearance of the tileset to its default when no style was applied.

The style is applied to a tile before the [Cesium3DTileset#tileVisible](Cesium3DTileset.html#tileVisible)event is raised, so code in `tileVisible` can manually set a feature's properties (e.g. color and show) after the style is applied. When a new style is assigned any manually set properties are overwritten.

Use an always "true" condition to specify the Color for all objects that are not overridden by pre-existing conditions. Otherwise, the default color Cesium.Color.White will be used. Similarly, use an always "true" condition to specify the show property for all objects that are not overridden by pre-existing conditions. Otherwise, the default show value true will be used.

Default Value: `undefined` 

##### Example:

```javascript
tileset.style = new Cesium.Cesium3DTileStyle({
   color : {
       conditions : [
           ['${Height} >= 100', 'color("purple", 0.5)'],
           ['${Height} >= 50', 'color("red")'],
           ['true', 'color("blue")']
       ]
   },
   show : '${Height} > 0',
   meta : {
       description : '"Building id ${id} has height ${Height}."'
   }
});
```

##### See:

* [3D Tiles Styling language](https://github.com/CesiumGS/3d-tiles/tree/main/specification/Styling)

#### [](#tileFailed) tileFailed : [Event](Event.html) 

[engine/Source/Scene/Cesium3DTileset.js 685](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L685) 

 The event fired to indicate that a tile's content failed to load.

If there are no event listeners, error messages will be logged to the console.

The error object passed to the listener contains two properties:
* `url`: the url of the failed tile.
* `message`: the error message.

If multiple contents are present, this event is raised once per inner content with errors.

Default Value: `new Event()` 

##### Example:

```javascript
tileset.tileFailed.addEventListener(function(error) {
    console.log(`An error occurred loading tile: ${error.url}`);
    console.log(`Error: ${error.message}`);
});
```

#### [](#tileLoad) tileLoad : [Event](Event.html) 

[engine/Source/Scene/Cesium3DTileset.js 635](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L635) 

 The event fired to indicate that a tile's content was loaded.

The loaded [Cesium3DTile](Cesium3DTile.html) is passed to the event listener.

This event is fired during the tileset traversal while the frame is being rendered so that updates to the tile take effect in the same frame. Do not create or modify Cesium entities or primitives during the event listener.

Default Value: `new Event()` 

##### Example:

```javascript
tileset.tileLoad.addEventListener(function(tile) {
    console.log('A tile was loaded.');
});
```

#### [](#tilesLoaded) readonly tilesLoaded : boolean 

[engine/Source/Scene/Cesium3DTileset.js 1200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1200) 

 When `true`, all tiles that meet the screen space error this frame are loaded. The tileset is completely loaded for this view.

Default Value: `false` 

##### See:

* [Cesium3DTileset#allTilesLoaded](Cesium3DTileset.html#allTilesLoaded)

#### [](#tileUnload) tileUnload : [Event](Event.html) 

[engine/Source/Scene/Cesium3DTileset.js 659](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L659) 

 The event fired to indicate that a tile's content was unloaded.

The unloaded [Cesium3DTile](Cesium3DTile.html) is passed to the event listener.

This event is fired immediately before the tile's content is unloaded while the frame is being rendered so that the event listener has access to the tile's content. Do not create or modify Cesium entities or primitives during the event listener.

Default Value: `new Event()` 

##### Example:

```javascript
tileset.tileUnload.addEventListener(function(tile) {
    console.log('A tile was unloaded from the cache.');
});
```

##### See:

* [Cesium3DTileset#cacheBytes](Cesium3DTileset.html#cacheBytes)
* [Cesium3DTileset#trimLoadedTiles](Cesium3DTileset.html#trimLoadedTiles)

#### [](#tileVisible) tileVisible : [Event](Event.html) 

[engine/Source/Scene/Cesium3DTileset.js 722](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L722) 

 This event fires once for each visible tile in a frame. This can be used to manually style a tileset.

The visible [Cesium3DTile](Cesium3DTile.html) is passed to the event listener.

This event is fired during the tileset traversal while the frame is being rendered so that updates to the tile take effect in the same frame. Do not create or modify Cesium entities or primitives during the event listener.

Default Value: `new Event()` 

##### Examples:

```javascript
tileset.tileVisible.addEventListener(function(tile) {
    if (tile.content instanceof Cesium.Model3DTileContent) {
        console.log('A 3D model tile is visible.');
    }
});
```

```javascript
// Apply a red style and then manually set random colors for every other feature when the tile becomes visible.
tileset.style = new Cesium.Cesium3DTileStyle({
    color : 'color("red")'
});
tileset.tileVisible.addEventListener(function(tile) {
    const content = tile.content;
    const featuresLength = content.featuresLength;
    for (let i = 0; i < featuresLength; i+=2) {
        content.getFeature(i).color = Cesium.Color.fromRandom();
    }
});
```

#### [](#timeSinceLoad) readonly timeSinceLoad : number 

[engine/Source/Scene/Cesium3DTileset.js 1643](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1643) 

 Returns the time, in milliseconds, since the tileset was loaded and first updated.

#### [](#totalMemoryUsageInBytes) readonly totalMemoryUsageInBytes : number 

[engine/Source/Scene/Cesium3DTileset.js 1660](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1660) 

 The total amount of GPU memory in bytes used by the tileset. This value is estimated from geometry, texture, batch table textures, and binary metadata of loaded tiles.

##### See:

* [Cesium3DTileset#cacheBytes](Cesium3DTileset.html#cacheBytes)

#### [](#vectorClassificationOnly) vectorClassificationOnly : boolean 

[engine/Source/Scene/Cesium3DTileset.js 1897](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1897) 

 Indicates that only the tileset's vector tiles should be used for classification.

Default Value: `false` 

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#vectorKeepDecodedPositions) vectorKeepDecodedPositions : boolean 

[engine/Source/Scene/Cesium3DTileset.js 1914](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L1914) 

 Whether vector tiles should keep decoded positions in memory. This is used with `Cesium3DTileFeature.getPolylinePositions`.

Default Value: `false` 

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

### Methods

#### [](#.fromIonAssetId) static Cesium.Cesium3DTileset.fromIonAssetId(assetId, options) → Promise.<[Cesium3DTileset](Cesium3DTileset.html)\> 

[engine/Source/Scene/Cesium3DTileset.js 2033](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L2033) 

 Creates a [3D Tiles tileset](https://github.com/CesiumGS/3d-tiles/tree/main/specification), used for streaming massive heterogeneous 3D geospatial datasets, from a Cesium ion asset ID.

| Name    | Type                                                                           | Description                                          |
| ------- | ------------------------------------------------------------------------------ | ---------------------------------------------------- |
| assetId | number                                                                         | The Cesium ion asset id.                             |
| options | [Cesium3DTileset.ConstructorOptions](Cesium3DTileset.html#.ConstructorOptions) | optional An object describing initialization options |

##### Returns:

##### Throws:

* [RuntimeError](RuntimeError.html): When the tileset asset version is not 0.0, 1.0, or 1.1, or when the tileset contains a required extension that is not supported.

##### Example:

```javascript
// Load a Cesium3DTileset with a Cesium ion asset ID of 124624234
try {
  const tileset = await Cesium.Cesium3DTileset.fromIonAssetId(124624234);
  scene.primitives.add(tileset);
} catch (error) {
  console.error(`Error creating tileset: ${error}`);
}
```

##### See:

* Cesium3DTileset#fromUrl

#### [](#.fromUrl) static Cesium.Cesium3DTileset.fromUrl(url, options) → Promise.<[Cesium3DTileset](Cesium3DTileset.html)\> 

[engine/Source/Scene/Cesium3DTileset.js 2090](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L2090) 

 Creates a [3D Tiles tileset](https://github.com/CesiumGS/3d-tiles/tree/main/specification), used for streaming massive heterogeneous 3D geospatial datasets.

| Name    | Type                                                                           | Description                                          |
| ------- | ------------------------------------------------------------------------------ | ---------------------------------------------------- |
| url     | [Resource](Resource.html)\|string                                              | The url to a tileset JSON file.                      |
| options | [Cesium3DTileset.ConstructorOptions](Cesium3DTileset.html#.ConstructorOptions) | optional An object describing initialization options |

##### Returns:

##### Throws:

* [RuntimeError](RuntimeError.html): When the tileset asset version is not 0.0, 1.0, or 1.1, or when the tileset contains a required extension that is not supported.

##### Examples:

```javascript
try {
  const tileset = await Cesium.Cesium3DTileset.fromUrl(
     "http://localhost:8002/tilesets/Seattle/tileset.json"
  );
  scene.primitives.add(tileset);
} catch (error) {
  console.error(`Error creating tileset: ${error}`);
}
```

```javascript
// Common setting for the skipLevelOfDetail optimization
const tileset = await Cesium.Cesium3DTileset.fromUrl(
  "http://localhost:8002/tilesets/Seattle/tileset.json", {
     skipLevelOfDetail: true,
     baseScreenSpaceError: 1024,
     skipScreenSpaceErrorFactor: 16,
     skipLevels: 1,
     immediatelyLoadDesiredLevelOfDetail: false,
     loadSiblings: false,
     cullWithChildrenBounds: true
});
scene.primitives.add(tileset);
```

```javascript
// Common settings for the dynamicScreenSpaceError optimization
const tileset = await Cesium.Cesium3DTileset.fromUrl(
  "http://localhost:8002/tilesets/Seattle/tileset.json", {
     dynamicScreenSpaceError: true,
     dynamicScreenSpaceErrorDensity: 2.0e-4,
     dynamicScreenSpaceErrorFactor: 24.0,
     dynamicScreenSpaceErrorHeightFalloff: 0.25
});
scene.primitives.add(tileset);
```

##### See:

* Cesium3DTileset#fromIonAssetId

#### [](#.loadJson) static Cesium.Cesium3DTileset.loadJson(tilesetUrl) → Promise.<object> 

[engine/Source/Scene/Cesium3DTileset.js 2176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L2176) 

 Provides a hook to override the method used to request the tileset json useful when fetching tilesets from remote servers

| Name       | Type                              | Description                            |
| ---------- | --------------------------------- | -------------------------------------- |
| tilesetUrl | [Resource](Resource.html)\|string | The url of the json file to be fetched |

##### Returns:

 A promise that resolves with the fetched json data

#### [](#destroy) destroy() 

[engine/Source/Scene/Cesium3DTileset.js 3516](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L3516) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
tileset = tileset && tileset.destroy();
```

##### See:

* [Cesium3DTileset#isDestroyed](Cesium3DTileset.html#isDestroyed)

#### [](#getHeight) getHeight(cartographic, scene) → number|undefined 

[engine/Source/Scene/Cesium3DTileset.js 3602](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L3602) 

 Get the height of the loaded surface at a given cartographic. This function will only take into account meshes for loaded tiles, not neccisarily the most detailed tiles available for a tileset. This function will always return undefined when sampling a point cloud.

| Name         | Type                              | Description                                    |
| ------------ | --------------------------------- | ---------------------------------------------- |
| cartographic | [Cartographic](Cartographic.html) | The cartographic for which to find the height. |
| scene        | [Scene](Scene.html)               | The scene where visualization is taking place. |

##### Returns:

 The height of the cartographic or undefined if it could not be found.

##### Example:

```javascript
const tileset = await Cesium.Cesium3DTileset.fromIonAssetId(124624234);
scene.primitives.add(tileset);

const height = tileset.getHeight(scene.camera.positionCartographic, scene);
```

#### [](#hasExtension) hasExtension(extensionName) → boolean 

[engine/Source/Scene/Cesium3DTileset.js 3479](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L3479) 

`true` if the tileset JSON file lists the extension in extensionsUsed; otherwise, `false`.

| Name          | Type   | Description                         |
| ------------- | ------ | ----------------------------------- |
| extensionName | string | The name of the extension to check. |

##### Returns:

`true` if the tileset JSON file lists the extension in extensionsUsed; otherwise, `false`.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/Cesium3DTileset.js 3497](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L3497) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [Cesium3DTileset#destroy](Cesium3DTileset.html#destroy)

#### [](#makeStyleDirty) makeStyleDirty() 

[engine/Source/Scene/Cesium3DTileset.js 2185](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L2185) 

 Marks the tileset's [Cesium3DTileset#style](Cesium3DTileset.html#style) as dirty, which forces all features to re-evaluate the style in the next frame each is visible.

#### [](#trimLoadedTiles) trimLoadedTiles() 

[engine/Source/Scene/Cesium3DTileset.js 3171](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L3171) 

 Unloads all tiles that weren't selected the previous frame. This can be used to explicitly manage the tile cache and reduce the total number of tiles loaded below[Cesium3DTileset#cacheBytes](Cesium3DTileset.html#cacheBytes).

Tile unloads occur at the next frame to keep all the WebGL delete calls within the render loop.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.Cesium3DTileset.ConstructorOptions

[engine/Source/Scene/Cesium3DTileset.js 66](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L66) 

 Initialization options for the Cesium3DTileset constructor

##### Properties:

| Name                                      | Type                                                                                                     | Attributes | Default                | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ----------------------------------------- | -------------------------------------------------------------------------------------------------------- | ---------- | ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| show                                      | boolean                                                                                                  | <optional> | true                   | Determines if the tileset will be shown.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| modelMatrix                               | [Matrix4](Matrix4.html)                                                                                  | <optional> | Matrix4.IDENTITY       | A 4x4 transformation matrix that transforms the tileset's root tile.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| modelUpAxis                               | [Axis](global.html#Axis)                                                                                 | <optional> | Axis.Y                 | Which axis is considered up when loading models for tile contents.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| modelForwardAxis                          | [Axis](global.html#Axis)                                                                                 | <optional> | Axis.X                 | Which axis is considered forward when loading models for tile contents.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| shadows                                   | [ShadowMode](global.html#ShadowMode)                                                                     | <optional> | ShadowMode.ENABLED     | Determines whether the tileset casts or receives shadows from light sources.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| maximumScreenSpaceError                   | number                                                                                                   | <optional> | 16                     | The maximum screen space error used to drive level of detail refinement.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| cacheBytes                                | number                                                                                                   | <optional> | 536870912              | The size (in bytes) to which the tile cache will be trimmed, if the cache contains tiles not needed for the current view.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| maximumCacheOverflowBytes                 | number                                                                                                   | <optional> | 536870912              | The maximum additional memory (in bytes) to allow for cache headroom, if more than [Cesium3DTileset#cacheBytes](Cesium3DTileset.html#cacheBytes) are needed for the current view.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| cullWithChildrenBounds                    | boolean                                                                                                  | <optional> | true                   | Optimization option. Whether to cull tiles using the union of their children bounding volumes.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| cullRequestsWhileMoving                   | boolean                                                                                                  | <optional> | true                   | Optimization option. Don't request tiles that will likely be unused when they come back because of the camera's movement. This optimization only applies to stationary tilesets.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| cullRequestsWhileMovingMultiplier         | number                                                                                                   | <optional> | 60.0                   | Optimization option. Multiplier used in culling requests while moving. Larger is more aggressive culling, smaller less aggressive culling.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| preloadWhenHidden                         | boolean                                                                                                  | <optional> | false                  | Preload tiles when tileset.show is false. Loads tiles as if the tileset is visible but does not render them.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| preloadFlightDestinations                 | boolean                                                                                                  | <optional> | true                   | Optimization option. Preload tiles at the camera's flight destination while the camera is in flight.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| preferLeaves                              | boolean                                                                                                  | <optional> | false                  | Optimization option. Prefer loading of leaves first.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| dynamicScreenSpaceError                   | boolean                                                                                                  | <optional> | true                   | Optimization option. For street-level horizon views, use lower resolution tiles far from the camera. This reduces the amount of data loaded and improves tileset loading time with a slight drop in visual quality in the distance.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| dynamicScreenSpaceErrorDensity            | number                                                                                                   | <optional> | 2.0e-4                 | Similar to [Fog#density](Fog.html#density), this option controls the camera distance at which the [Cesium3DTileset#dynamicScreenSpaceError](Cesium3DTileset.html#dynamicScreenSpaceError) optimization applies. Larger values will cause tiles closer to the camera to be affected.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| dynamicScreenSpaceErrorFactor             | number                                                                                                   | <optional> | 24.0                   | A parameter that controls the intensity of the [Cesium3DTileset#dynamicScreenSpaceError](Cesium3DTileset.html#dynamicScreenSpaceError) optimization for tiles on the horizon. Larger values cause lower resolution tiles to load, improving runtime performance at a slight reduction of visual quality.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| dynamicScreenSpaceErrorHeightFalloff      | number                                                                                                   | <optional> | 0.25                   | A ratio of the tileset's height that determines where "street level" camera views occur. When the camera is below this height, the [Cesium3DTileset#dynamicScreenSpaceError](Cesium3DTileset.html#dynamicScreenSpaceError) optimization will have the maximum effect, and it will roll off above this value.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| progressiveResolutionHeightFraction       | number                                                                                                   | <optional> | 0.3                    | Optimization option. If between (0.0, 0.5\], tiles at or above the screen space error for the reduced screen resolution of progressiveResolutionHeightFraction\*screenHeight will be prioritized first. This can help get a quick layer of tiles down while full resolution tiles continue to load.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| foveatedScreenSpaceError                  | boolean                                                                                                  | <optional> | true                   | Optimization option. Prioritize loading tiles in the center of the screen by temporarily raising the screen space error for tiles around the edge of the screen. Screen space error returns to normal once all the tiles in the center of the screen as determined by the [Cesium3DTileset#foveatedConeSize](Cesium3DTileset.html#foveatedConeSize) are loaded.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| foveatedConeSize                          | number                                                                                                   | <optional> | 0.1                    | Optimization option. Used when [Cesium3DTileset#foveatedScreenSpaceError](Cesium3DTileset.html#foveatedScreenSpaceError) is true to control the cone size that determines which tiles are deferred. Tiles that are inside this cone are loaded immediately. Tiles outside the cone are potentially deferred based on how far outside the cone they are and their screen space error. This is controlled by [Cesium3DTileset#foveatedInterpolationCallback](Cesium3DTileset.html#foveatedInterpolationCallback) and [Cesium3DTileset#foveatedMinimumScreenSpaceErrorRelaxation](Cesium3DTileset.html#foveatedMinimumScreenSpaceErrorRelaxation). Setting this to 0.0 means the cone will be the line formed by the camera position and its view direction. Setting this to 1.0 means the cone encompasses the entire field of view of the camera, disabling the effect. |
| foveatedMinimumScreenSpaceErrorRelaxation | number                                                                                                   | <optional> | 0.0                    | Optimization option. Used when [Cesium3DTileset#foveatedScreenSpaceError](Cesium3DTileset.html#foveatedScreenSpaceError) is true to control the starting screen space error relaxation for tiles outside the foveated cone. The screen space error will be raised starting with tileset value up to [Cesium3DTileset#maximumScreenSpaceError](Cesium3DTileset.html#maximumScreenSpaceError) based on the provided [Cesium3DTileset#foveatedInterpolationCallback](Cesium3DTileset.html#foveatedInterpolationCallback).                                                                                                                                                                                                                                                                                                                                                 |
| foveatedInterpolationCallback             | [Cesium3DTileset.foveatedInterpolationCallback](Cesium3DTileset.html#.foveatedInterpolationCallback)     | <optional> | Math.lerp              | Optimization option. Used when [Cesium3DTileset#foveatedScreenSpaceError](Cesium3DTileset.html#foveatedScreenSpaceError) is true to control how much to raise the screen space error for tiles outside the foveated cone, interpolating between [Cesium3DTileset#foveatedMinimumScreenSpaceErrorRelaxation](Cesium3DTileset.html#foveatedMinimumScreenSpaceErrorRelaxation) and [Cesium3DTileset#maximumScreenSpaceError](Cesium3DTileset.html#maximumScreenSpaceError)                                                                                                                                                                                                                                                                                                                                                                                                |
| foveatedTimeDelay                         | number                                                                                                   | <optional> | 0.2                    | Optimization option. Used when [Cesium3DTileset#foveatedScreenSpaceError](Cesium3DTileset.html#foveatedScreenSpaceError) is true to control how long in seconds to wait after the camera stops moving before deferred tiles start loading in. This time delay prevents requesting tiles around the edges of the screen when the camera is moving. Setting this to 0.0 will immediately request all tiles in any given view.                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| skipLevelOfDetail                         | boolean                                                                                                  | <optional> | false                  | Optimization option. Determines if level of detail skipping should be applied during the traversal.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| baseScreenSpaceError                      | number                                                                                                   | <optional> | 1024                   | When skipLevelOfDetail is true, the screen space error that must be reached before skipping levels of detail.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| skipScreenSpaceErrorFactor                | number                                                                                                   | <optional> | 16                     | When skipLevelOfDetail is true, a multiplier defining the minimum screen space error to skip. Used in conjunction with skipLevels to determine which tiles to load.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| skipLevels                                | number                                                                                                   | <optional> | 1                      | When skipLevelOfDetail is true, a constant defining the minimum number of levels to skip when loading tiles. When it is 0, no levels are skipped. Used in conjunction with skipScreenSpaceErrorFactor to determine which tiles to load.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| immediatelyLoadDesiredLevelOfDetail       | boolean                                                                                                  | <optional> | false                  | When skipLevelOfDetail is true, only tiles that meet the maximum screen space error will ever be downloaded. Skipping factors are ignored and just the desired tiles are loaded.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| loadSiblings                              | boolean                                                                                                  | <optional> | false                  | When skipLevelOfDetail is true, determines whether siblings of visible tiles are always downloaded during traversal.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| clippingPlanes                            | [ClippingPlaneCollection](ClippingPlaneCollection.html)                                                  | <optional> |                        | The [ClippingPlaneCollection](ClippingPlaneCollection.html) used to selectively disable rendering the tileset.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| clippingPolygons                          | [ClippingPolygonCollection](ClippingPolygonCollection.html)                                              | <optional> |                        | The [ClippingPolygonCollection](ClippingPolygonCollection.html) used to selectively disable rendering the tileset.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| classificationType                        | [ClassificationType](global.html#ClassificationType)                                                     | <optional> |                        | Determines whether terrain, 3D Tiles or both will be classified by this tileset. See [Cesium3DTileset#classificationType](Cesium3DTileset.html#classificationType) for details about restrictions and limitations.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| ellipsoid                                 | [Ellipsoid](Ellipsoid.html)                                                                              | <optional> | Ellipsoid.WGS84        | The ellipsoid determining the size and shape of the globe.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| pointCloudShading                         | object                                                                                                   | <optional> |                        | Options for constructing a [PointCloudShading](PointCloudShading.html) object to control point attenuation based on geometric error and lighting.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| lightColor                                | [Cartesian3](Cartesian3.html)                                                                            | <optional> |                        | The light color when shading models. When undefined the scene's light color is used instead.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| imageBasedLighting                        | [ImageBasedLighting](ImageBasedLighting.html)                                                            | <optional> |                        | The properties for managing image-based lighting for this tileset.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| environmentMapOptions                     | [DynamicEnvironmentMapManager.ConstructorOptions](DynamicEnvironmentMapManager.html#.ConstructorOptions) | <optional> |                        | The properties for managing dynamic environment maps on this tileset.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| backFaceCulling                           | boolean                                                                                                  | <optional> | true                   | Whether to cull back-facing geometry. When true, back face culling is determined by the glTF material's doubleSided property; when false, back face culling is disabled.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| enableShowOutline                         | boolean                                                                                                  | <optional> | true                   | Whether to enable outlines for models using the [CESIUM\_primitive\_outline](https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Vendor/CESIUM%5Fprimitive%5Foutline) extension. This can be set to false to avoid the additional processing of geometry at load time. When false, the showOutlines and outlineColor options are ignored.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| showOutline                               | boolean                                                                                                  | <optional> | true                   | Whether to display the outline for models using the [CESIUM\_primitive\_outline](https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Vendor/CESIUM%5Fprimitive%5Foutline) extension. When true, outlines are displayed. When false, outlines are not displayed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| outlineColor                              | [Color](Color.html)                                                                                      | <optional> | Color.BLACK            | The color to use when rendering outlines.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| vectorClassificationOnly                  | boolean                                                                                                  | <optional> | false                  | Indicates that only the tileset's vector tiles should be used for classification.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| vectorKeepDecodedPositions                | boolean                                                                                                  | <optional> | false                  | Whether vector tiles should keep decoded positions in memory. This is used with Cesium3DTileFeature.getPolylinePositions.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| featureIdLabel                            | string\|number                                                                                           | <optional> | "featureId\_0"         | Label of the feature ID set to use for picking and styling. For EXT\_mesh\_features, this is the feature ID's label property, or "featureId\_N" (where N is the index in the featureIds array) when not specified. EXT\_feature\_metadata did not have a label field, so such feature ID sets are always labeled "featureId\_N" where N is the index in the list of all feature Ids, where feature ID attributes are listed before feature ID textures. If featureIdLabel is an integer N, it is converted to the string "featureId\_N" automatically. If both per-primitive and per-instance feature IDs are present, the instance feature IDs take priority.                                                                                                                                                                                                         |
| instanceFeatureIdLabel                    | string\|number                                                                                           | <optional> | "instanceFeatureId\_0" | Label of the instance feature ID set used for picking and styling. If instanceFeatureIdLabel is set to an integer N, it is converted to the string "instanceFeatureId\_N" automatically. If both per-primitive and per-instance feature IDs are present, the instance feature IDs take priority.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| showCreditsOnScreen                       | boolean                                                                                                  | <optional> | false                  | Whether to display the credits of this tileset on screen.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| splitDirection                            | [SplitDirection](global.html#SplitDirection)                                                             | <optional> | SplitDirection.NONE    | The [SplitDirection](global.html#SplitDirection) split to apply to this tileset.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| enableCollision                           | boolean                                                                                                  | <optional> | false                  | When true, enables collisions for camera or CPU picking. While this is true the camera will be prevented from going below the tileset surface if [ScreenSpaceCameraController#enableCollisionDetection](ScreenSpaceCameraController.html#enableCollisionDetection) is true.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| projectTo2D                               | boolean                                                                                                  | <optional> | false                  | Whether to accurately project the tileset to 2D. If this is true, the tileset will be projected accurately to 2D, but it will use more memory to do so. If this is false, the tileset will use less memory and will still render in 2D / CV mode, but its projected positions may be inaccurate. This cannot be set after the tileset has been created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| enablePick                                | boolean                                                                                                  | <optional> | false                  | Whether to allow collision and CPU picking with pick when using WebGL 1\. If using WebGL 2 or above, this option will be ignored. If using WebGL 1 and this is true, the pick operation will work correctly, but it will use more memory to do so. If running with WebGL 1 and this is false, the model will use less memory, but pick will always return undefined. This cannot be set after the tileset has loaded.                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| debugHeatmapTilePropertyName              | string                                                                                                   | <optional> |                        | The tile variable to colorize as a heatmap. All rendered tiles will be colorized relative to each other's specified variable value.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| debugFreezeFrame                          | boolean                                                                                                  | <optional> | false                  | For debugging only. Determines if only the tiles from last frame should be used for rendering.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| debugColorizeTiles                        | boolean                                                                                                  | <optional> | false                  | For debugging only. When true, assigns a random color to each tile.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| enableDebugWireframe                      | boolean                                                                                                  | <optional> | false                  | For debugging only. This must be true for debugWireframe to work in WebGL1\. This cannot be set after the tileset has been created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| debugWireframe                            | boolean                                                                                                  | <optional> | false                  | For debugging only. When true, render's each tile's content as a wireframe.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| debugShowBoundingVolume                   | boolean                                                                                                  | <optional> | false                  | For debugging only. When true, renders the bounding volume for each tile.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| debugShowContentBoundingVolume            | boolean                                                                                                  | <optional> | false                  | For debugging only. When true, renders the bounding volume for each tile's content.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| debugShowViewerRequestVolume              | boolean                                                                                                  | <optional> | false                  | For debugging only. When true, renders the viewer request volume for each tile.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| debugShowGeometricError                   | boolean                                                                                                  | <optional> | false                  | For debugging only. When true, draws labels to indicate the geometric error of each tile.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| debugShowRenderingStatistics              | boolean                                                                                                  | <optional> | false                  | For debugging only. When true, draws labels to indicate the number of commands, points, triangles and features for each tile.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| debugShowMemoryUsage                      | boolean                                                                                                  | <optional> | false                  | For debugging only. When true, draws labels to indicate the texture and geometry memory in megabytes used by each tile.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| debugShowUrl                              | boolean                                                                                                  | <optional> | false                  | For debugging only. When true, draws labels to indicate the url of each tile.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |

#### [](#.foveatedInterpolationCallback) Cesium.Cesium3DTileset.foveatedInterpolationCallback(p, q, time) → number 

[engine/Source/Scene/Cesium3DTileset.js 3750](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileset.js#L3750) 

 Optimization option. Used as a callback when [Cesium3DTileset#foveatedScreenSpaceError](Cesium3DTileset.html#foveatedScreenSpaceError) is true to control how much to raise the screen space error for tiles outside the foveated cone, interpolating between [Cesium3DTileset#foveatedMinimumScreenSpaceErrorRelaxation](Cesium3DTileset.html#foveatedMinimumScreenSpaceErrorRelaxation) and [Cesium3DTileset#maximumScreenSpaceError](Cesium3DTileset.html#maximumScreenSpaceError).

| Name | Type   | Description                                                    |
| ---- | ------ | -------------------------------------------------------------- |
| p    | number | The start value to interpolate.                                |
| q    | number | The end value to interpolate.                                  |
| time | number | The time of interpolation generally in the range \[0.0, 1.0\]. |

##### Returns:

 The interpolated value.

Default Value: `Math.lerp` 

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

