# [![](Images/CesiumLogo.png)](index.html) OpenCageGeocoderService 

#### [](#OpenCageGeocoderService) new Cesium.OpenCageGeocoderService(url, apiKey, params) 

[engine/Source/Core/OpenCageGeocoderService.js 38](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OpenCageGeocoderService.js#L38) 

 Provides geocoding via a [OpenCage](https://opencagedata.com/) server.

| Name                    | Type                              | Description                                                                                                                                                                                                                     |
| ----------------------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| url                     | [Resource](Resource.html)\|string | The endpoint to the OpenCage server.                                                                                                                                                                                            |
| apiKey                  | string                            | The OpenCage API Key.                                                                                                                                                                                                           |
| params                  | object                            | optional An object with the following properties (See https://opencagedata.com/api#forward-opt): Name Type Description abbrv number optional When set to 1 we attempt to abbreviate and shorten the formatted string we return. |
| options.add\_request    | number                            | optional When set to 1 the various request parameters are added to the response for ease of debugging.                                                                                                                          |
| options.bounds          | string                            | optional Provides the geocoder with a hint to the region that the query resides in.                                                                                                                                             |
| options.countrycode     | string                            | optional Restricts the results to the specified country or countries (as defined by the ISO 3166-1 Alpha 2 standard).                                                                                                           |
| options.jsonp           | string                            | optional Wraps the returned JSON with a function name.                                                                                                                                                                          |
| options.language        | string                            | optional An IETF format language code.                                                                                                                                                                                          |
| options.limit           | number                            | optional The maximum number of results we should return.                                                                                                                                                                        |
| options.min\_confidence | number                            | optional An integer from 1-10\. Only results with at least this confidence will be returned.                                                                                                                                    |
| options.no\_annotations | number                            | optional When set to 1 results will not contain annotations.                                                                                                                                                                    |
| options.no\_dedupe      | number                            | optional When set to 1 results will not be deduplicated.                                                                                                                                                                        |
| options.no\_record      | number                            | optional When set to 1 the query contents are not logged.                                                                                                                                                                       |
| options.pretty          | number                            | optional When set to 1 results are 'pretty' printed for easier reading. Useful for debugging.                                                                                                                                   |
| options.proximity       | string                            | optional Provides the geocoder with a hint to bias results in favour of those closer to the specified location (For example: 41.40139,2.12870).                                                                                 |

##### Example:

```javascript
// Configure a Viewer to use the OpenCage Geocoder
const viewer = new Cesium.Viewer('cesiumContainer', {
  geocoder: new Cesium.OpenCageGeocoderService('https://api.opencagedata.com/geocode/v1/', '<API key>')
});
```

### Members

#### [](#credit) readonly credit : [Credit](Credit.html)|undefined 

[engine/Source/Core/OpenCageGeocoderService.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OpenCageGeocoderService.js#L88) 

 Gets the credit to display after a geocode is performed. Typically this is used to credit the geocoder service.

#### [](#params) readonly params : object 

[engine/Source/Core/OpenCageGeocoderService.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OpenCageGeocoderService.js#L76) 

 Optional params passed to OpenCage in order to customize geocoding

#### [](#url) readonly url : [Resource](Resource.html) 

[engine/Source/Core/OpenCageGeocoderService.js 65](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OpenCageGeocoderService.js#L65) 

 The Resource used to access the OpenCage endpoint.

### Methods

#### [](#geocode) geocode(query) → Promise.<Array.<[GeocoderService.Result](GeocoderService.html#.Result)\>> 

[engine/Source/Core/OpenCageGeocoderService.js 101](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OpenCageGeocoderService.js#L101) 

| Name  | Type   | Description                                  |
| ----- | ------ | -------------------------------------------- |
| query | string | The query to be sent to the geocoder service |

##### Returns:

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

