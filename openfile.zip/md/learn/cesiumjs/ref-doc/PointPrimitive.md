# [![](Images/CesiumLogo.png)](index.html) PointPrimitive 

#### [](#PointPrimitive) internal constructor new Cesium.PointPrimitive() 

[engine/Source/Scene/PointPrimitive.js 44](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L44) 

A point is created and its initial properties are set by calling [PointPrimitiveCollection#add](PointPrimitiveCollection.html#add). Do not call the constructor directly.

A graphical point positioned in the 3D scene, that is created and rendered using a [PointPrimitiveCollection](PointPrimitiveCollection.html).

##### Performance:

Reading a property, e.g., [PointPrimitive#show](PointPrimitive.html#show), is constant time. Assigning to a property is constant time but results in CPU to GPU traffic when `PointPrimitiveCollection#update` is called. The per-pointPrimitive traffic is the same regardless of how many properties were updated. If most pointPrimitives in a collection need to be updated, it may be more efficient to clear the collection with [PointPrimitiveCollection#removeAll](PointPrimitiveCollection.html#removeAll)and add new pointPrimitives instead of modifying each one.

##### Throws:

* [DeveloperError](DeveloperError.html): scaleByDistance.far must be greater than scaleByDistance.near
* [DeveloperError](DeveloperError.html): translucencyByDistance.far must be greater than translucencyByDistance.near
* [DeveloperError](DeveloperError.html): distanceDisplayCondition.far must be greater than distanceDisplayCondition.near

##### Demo:

* [Cesium Sandcastle Points Demo](https://sandcastle.cesium.com/index.html?src=Points.html)

##### See:

* [PointPrimitiveCollection](PointPrimitiveCollection.html)
* [PointPrimitiveCollection#add](PointPrimitiveCollection.html#add)

### Members

#### [](#color) color : [Color](Color.html) 

[engine/Source/Scene/PointPrimitive.js 335](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L335) 

 Gets or sets the inner color of the point. The red, green, blue, and alpha values are indicated by `value`'s `red`, `green`,`blue`, and `alpha` properties as shown in Example 1\. These components range from `0.0`(no intensity) to `1.0` (full intensity).

##### Examples:

```javascript
// Example 1. Assign yellow.
p.color = Cesium.Color.YELLOW;
```

```javascript
// Example 2. Make a pointPrimitive 50% translucent.
p.color = new Cesium.Color(1.0, 1.0, 1.0, 0.5);
```

#### [](#disableDepthTestDistance) disableDepthTestDistance : number 

[engine/Source/Scene/PointPrimitive.js 437](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L437) 

 Gets or sets the distance from the camera at which to disable the depth test to, for example, prevent clipping against terrain. When set to zero, the depth test is always applied. When set to Number.POSITIVE\_INFINITY, the depth test is never applied.

Default Value: `0.0` 

#### [](#distanceDisplayCondition) distanceDisplayCondition : [DistanceDisplayCondition](DistanceDisplayCondition.html) 

[engine/Source/Scene/PointPrimitive.js 408](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L408) 

 Gets or sets the condition specifying at what distance from the camera that this point will be displayed.

Default Value: `undefined` 

#### [](#id) id : \* 

[engine/Source/Scene/PointPrimitive.js 461](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L461) 

 Gets or sets the user-defined value returned when the point is picked.

#### [](#outlineColor) outlineColor : [Color](Color.html) 

[engine/Source/Scene/PointPrimitive.js 359](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L359) 

 Gets or sets the outline color of the point.

#### [](#outlineWidth) outlineWidth : number 

[engine/Source/Scene/PointPrimitive.js 384](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L384) 

 Gets or sets the outline width in pixels. This width adds to pixelSize, increasing the total size of the point.

#### [](#pixelSize) pixelSize : number 

[engine/Source/Scene/PointPrimitive.js 301](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L301) 

 Gets or sets the inner size of the point in pixels.

#### [](#position) position : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/PointPrimitive.js 185](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L185) 

 Gets or sets the Cartesian position of this point.

#### [](#scaleByDistance) scaleByDistance : [NearFarScalar](NearFarScalar.html) 

[engine/Source/Scene/PointPrimitive.js 229](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L229) 

 Gets or sets near and far scaling properties of a point based on the point's distance from the camera. A point's scale will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the point's scale remains clamped to the nearest bound. This scale multiplies the pixelSize and outlineWidth to affect the total size of the point. If undefined, scaleByDistance will be disabled.

##### Examples:

```javascript
// Example 1.
// Set a pointPrimitive's scaleByDistance to scale to 15 when the
// camera is 1500 meters from the pointPrimitive and disappear as
// the camera distance approaches 8.0e6 meters.
p.scaleByDistance = new Cesium.NearFarScalar(1.5e2, 15, 8.0e6, 0.0);
```

```javascript
// Example 2.
// disable scaling by distance
p.scaleByDistance = undefined;
```

#### [](#show) show : boolean 

[engine/Source/Scene/PointPrimitive.js 162](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L162) 

 Determines if this point will be shown. Use this to hide or show a point, instead of removing it and re-adding it to the collection.

#### [](#splitDirection) splitDirection : [SplitDirection](global.html#SplitDirection) 

[engine/Source/Scene/PointPrimitive.js 506](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L506) 

 The [SplitDirection](global.html#SplitDirection) to apply to this point.

Default Value: `[SplitDirection.NONE](global.html#SplitDirection#.NONE)` 

#### [](#translucencyByDistance) translucencyByDistance : [NearFarScalar](NearFarScalar.html) 

[engine/Source/Scene/PointPrimitive.js 272](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L272) 

 Gets or sets near and far translucency properties of a point based on the point's distance from the camera. A point's translucency will interpolate between the [NearFarScalar#nearValue](NearFarScalar.html#nearValue) and[NearFarScalar#farValue](NearFarScalar.html#farValue) while the camera distance falls within the lower and upper bounds of the specified [NearFarScalar#near](NearFarScalar.html#near) and [NearFarScalar#far](NearFarScalar.html#far). Outside of these ranges the point's translucency remains clamped to the nearest bound. If undefined, translucencyByDistance will be disabled.

##### Examples:

```javascript
// Example 1.
// Set a point's translucency to 1.0 when the
// camera is 1500 meters from the point and disappear as
// the camera distance approaches 8.0e6 meters.
p.translucencyByDistance = new Cesium.NearFarScalar(1.5e2, 1.0, 8.0e6, 0.0);
```

```javascript
// Example 2.
// disable translucency by distance
p.translucencyByDistance = undefined;
```

### Methods

#### [](#computeScreenSpacePosition) computeScreenSpacePosition(scene, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Scene/PointPrimitive.js 600](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L600) 

 Computes the screen-space position of the point's origin. The screen space origin is the top, left corner of the canvas; `x` increases from left to right, and `y` increases from top to bottom.

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| scene  | [Scene](Scene.html)           | The scene.                                          |
| result | [Cartesian2](Cartesian2.html) | optional The object onto which to store the result. |

##### Returns:

 The screen-space position of the point.

##### Throws:

* [DeveloperError](DeveloperError.html): PointPrimitive must be in a collection.

##### Example:

```javascript
console.log(p.computeScreenSpacePosition(scene).toString());
```

#### [](#equals) equals(other) → boolean 

[engine/Source/Scene/PointPrimitive.js 671](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/PointPrimitive.js#L671) 

 Determines if this point equals another point. Points are equal if all their properties are equal. Points in different collections can be equal.

| Name  | Type                                  | Description                                 |
| ----- | ------------------------------------- | ------------------------------------------- |
| other | [PointPrimitive](PointPrimitive.html) | optional The point to compare for equality. |

##### Returns:

`true` if the points are equal; otherwise, `false`.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

