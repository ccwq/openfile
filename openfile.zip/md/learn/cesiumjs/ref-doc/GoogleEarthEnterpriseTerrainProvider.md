# [![](Images/CesiumLogo.png)](index.html) GoogleEarthEnterpriseTerrainProvider 

#### [](#GoogleEarthEnterpriseTerrainProvider) new Cesium.GoogleEarthEnterpriseTerrainProvider(options) 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 99](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L99) 

To construct a GoogleEarthEnterpriseTerrainProvider, call [GoogleEarthEnterpriseTerrainProvider.fromMetadata](GoogleEarthEnterpriseTerrainProvider.html#.fromMetadata). Do not call the constructor directly.

Provides tiled terrain using the Google Earth Enterprise REST API.

| Name    | Type                                                                                                                     | Description                                          |
| ------- | ------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------- |
| options | [GoogleEarthEnterpriseTerrainProvider.ConstructorOptions](GoogleEarthEnterpriseTerrainProvider.html#.ConstructorOptions) | optional An object describing initialization options |

##### Example:

```javascript
const geeMetadata = await GoogleEarthEnterpriseMetadata.fromUrl("http://www.example.com");
const gee = Cesium.GoogleEarthEnterpriseTerrainProvider.fromMetadata(geeMetadata);
```

##### See:

* [GoogleEarthEnterpriseTerrainProvider.fromMetadata](GoogleEarthEnterpriseTerrainProvider.html#.fromMetadata)
* [GoogleEarthEnterpriseMetadata.fromUrl](GoogleEarthEnterpriseMetadata.html#.fromUrl)
* [GoogleEarthEnterpriseImageryProvider](GoogleEarthEnterpriseImageryProvider.html)
* [CesiumTerrainProvider](CesiumTerrainProvider.html)
* [Cross-Origin Resource Sharing](http://www.w3.org/TR/cors/)

### Members

#### [](#availability) readonly availability : [TileAvailability](TileAvailability.html) 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 228](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L228) 

 Gets an object that can be used to determine availability of terrain from this provider, such as at points and in rectangles. This property may be undefined if availability information is not available.

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 188](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L188) 

 Gets the credit to display when this terrain provider is active. Typically this is used to credit the source of the terrain.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 175](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L175) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasVertexNormals) readonly hasVertexNormals : boolean 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 214](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L214) 

 Gets a value indicating whether or not the requested tiles include vertex normals.

#### [](#hasWaterMask) readonly hasWaterMask : boolean 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 202](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L202) 

 Gets a value indicating whether or not the provider includes a water mask. The water mask indicates which areas of the globe are water rather than land, so they can be rendered as a reflective surface with animated waves.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 149](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L149) 

 Gets the proxy used by this provider.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 161](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L161) 

 Gets the tiling scheme used by this provider.

#### [](#url) readonly url : string 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 137](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L137) 

 Gets the name of the Google Earth Enterprise server url hosting the imagery.

### Methods

#### [](#.fromMetadata) static Cesium.GoogleEarthEnterpriseTerrainProvider.fromMetadata(metadata, options) → [GoogleEarthEnterpriseTerrainProvider](GoogleEarthEnterpriseTerrainProvider.html) 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 250](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L250) 

 Creates a GoogleEarthTerrainProvider from GoogleEarthEnterpriseMetadata

| Name     | Type                                                                                                                     | Description                                                                                                |
| -------- | ------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------- |
| metadata | [GoogleEarthEnterpriseMetadata](GoogleEarthEnterpriseMetadata.html)                                                      | A metadata object that can be used to share metadata requests with a GoogleEarthEnterpriseImageryProvider. |
| options  | [GoogleEarthEnterpriseTerrainProvider.ConstructorOptions](GoogleEarthEnterpriseTerrainProvider.html#.ConstructorOptions) | An object describing initialization options                                                                |

##### Returns:

##### Throws:

* [RuntimeError](RuntimeError.html): metadata does not specify terrain

##### Example:

```javascript
const geeMetadata = await GoogleEarthEnterpriseMetadata.fromUrl("http://www.example.com");
const gee = Cesium.GoogleEarthEnterpriseTerrainProvider.fromMetadata(geeMetadata);
```

##### See:

* [GoogleEarthEnterpriseMetadata.fromUrl](GoogleEarthEnterpriseMetadata.html#.fromUrl)

#### [](#getLevelMaximumGeometricError) getLevelMaximumGeometricError(level) → number 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 489](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L489) 

 Gets the maximum geometric error allowed in a tile at a given level.

| Name  | Type   | Description                                                  |
| ----- | ------ | ------------------------------------------------------------ |
| level | number | The tile level for which to get the maximum geometric error. |

##### Returns:

 The maximum geometric error.

#### [](#getTileDataAvailable) getTileDataAvailable(x, y, level) → boolean|undefined 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 502](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L502) 

 Determines whether data for a tile is available to be loaded.

| Name  | Type   | Description                                                 |
| ----- | ------ | ----------------------------------------------------------- |
| x     | number | The X coordinate of the tile for which to request geometry. |
| y     | number | The Y coordinate of the tile for which to request geometry. |
| level | number | The level of the tile for which to request geometry.        |

##### Returns:

 Undefined if not supported, otherwise true or false.

#### [](#loadTileDataAvailability) loadTileDataAvailability(x, y, level) → undefined 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 559](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L559) 

 Makes sure we load availability data for a tile

| Name  | Type   | Description                                                 |
| ----- | ------ | ----------------------------------------------------------- |
| x     | number | The X coordinate of the tile for which to request geometry. |
| y     | number | The Y coordinate of the tile for which to request geometry. |
| level | number | The level of the tile for which to request geometry.        |

##### Returns:

#### [](#requestTileGeometry) requestTileGeometry(x, y, level, request) → Promise.<[TerrainData](TerrainData.html)\>|undefined 

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 301](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L301) 

 Requests the geometry for a given tile. The result must include terrain data and may optionally include a water mask and an indication of which child tiles are available.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The X coordinate of the tile for which to request geometry.  |
| y       | number                  | The Y coordinate of the tile for which to request geometry.  |
| level   | number                  | The level of the tile for which to request geometry.         |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the requested geometry. If this method returns undefined instead of a promise, it is an indication that too many requests are already pending and the request will be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.GoogleEarthEnterpriseTerrainProvider.ConstructorOptions

[engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js 67](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/GoogleEarthEnterpriseTerrainProvider.js#L67) 

 Initialization options for GoogleEarthEnterpriseTerrainProvider constructor

##### Properties:

| Name      | Type                          | Attributes | Default           | Description                                                     |
| --------- | ----------------------------- | ---------- | ----------------- | --------------------------------------------------------------- |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | <optional> | Ellipsoid.default | The ellipsoid. If not specified, the default ellipsoid is used. |
| credit    | [Credit](Credit.html)\|string | <optional> |                   | A credit for the data source, which is displayed on the canvas. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

