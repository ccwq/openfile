# [![](Images/CesiumLogo.png)](index.html) EllipsoidTangentPlane 

#### [](#EllipsoidTangentPlane) new Cesium.EllipsoidTangentPlane(origin, ellipsoid) 

[engine/Source/Core/EllipsoidTangentPlane.js 29](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L29) 

 A plane tangent to the provided ellipsoid at the provided origin. If origin is not on the surface of the ellipsoid, it's surface projection will be used. If origin is at the center of the ellipsoid, an exception will be thrown.

| Name      | Type                          | Default           | Description                                                                |
| --------- | ----------------------------- | ----------------- | -------------------------------------------------------------------------- |
| origin    | [Cartesian3](Cartesian3.html) |                   | The point on the surface of the ellipsoid where the tangent plane touches. |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | Ellipsoid.default | optional The ellipsoid to use.                                             |

##### Throws:

* [DeveloperError](DeveloperError.html): origin must not be at the center of the ellipsoid.

### Members

#### [](#ellipsoid) ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/EllipsoidTangentPlane.js 67](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L67) 

 Gets the ellipsoid.

#### [](#origin) origin : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/EllipsoidTangentPlane.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L78) 

 Gets the origin.

#### [](#plane) readonly plane : [Plane](Plane.html) 

[engine/Source/Core/EllipsoidTangentPlane.js 90](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L90) 

 Gets the plane which is tangent to the ellipsoid.

#### [](#xAxis) readonly xAxis : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/EllipsoidTangentPlane.js 102](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L102) 

 Gets the local X-axis (east) of the tangent plane.

#### [](#yAxis) readonly yAxis : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/EllipsoidTangentPlane.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L114) 

 Gets the local Y-axis (north) of the tangent plane.

#### [](#zAxis) readonly zAxis : [Cartesian3](Cartesian3.html) 

[engine/Source/Core/EllipsoidTangentPlane.js 126](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L126) 

 Gets the local Z-axis (up) of the tangent plane.

### Methods

#### [](#.fromPoints) static Cesium.EllipsoidTangentPlane.fromPoints(cartesians, ellipsoid) → [EllipsoidTangentPlane](EllipsoidTangentPlane.html) 

[engine/Source/Core/EllipsoidTangentPlane.js 142](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L142) 

 Creates a new instance from the provided ellipsoid and the center point of the provided Cartesians.

| Name       | Type                                   | Default           | Description                                         |
| ---------- | -------------------------------------- | ----------------- | --------------------------------------------------- |
| cartesians | Array.<[Cartesian3](Cartesian3.html)\> |                   | The list of positions surrounding the center point. |
| ellipsoid  | [Ellipsoid](Ellipsoid.html)            | Ellipsoid.default | optional The ellipsoid to use.                      |

##### Returns:

 The new instance of EllipsoidTangentPlane.

#### [](#projectPointOntoEllipsoid) projectPointOntoEllipsoid(cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/EllipsoidTangentPlane.js 328](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L328) 

 Computes the projection of the provided 2D position onto the 3D ellipsoid.

| Name      | Type                          | Description                                       |
| --------- | ----------------------------- | ------------------------------------------------- |
| cartesian | [Cartesian2](Cartesian2.html) | The points to project.                            |
| result    | [Cartesian3](Cartesian3.html) | optional The Cartesian3 instance to store result. |

##### Returns:

 The modified result parameter or a new Cartesian3 instance if none was provided.

#### [](#projectPointOntoPlane) projectPointOntoPlane(cartesian, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/EllipsoidTangentPlane.js 161](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L161) 

 Computes the projection of the provided 3D position onto the 2D plane, radially outward from the `EllipsoidTangentPlane.ellipsoid` coordinate system origin.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The point to project.                               |
| result    | [Cartesian2](Cartesian2.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian2 instance if none was provided. Undefined if there is no intersection point

#### [](#projectPointsOntoEllipsoid) projectPointsOntoEllipsoid(cartesians, result) → Array.<[Cartesian3](Cartesian3.html)\> 

[engine/Source/Core/EllipsoidTangentPlane.js 362](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L362) 

 Computes the projection of the provided 2D positions onto the 3D ellipsoid.

| Name       | Type                                   | Description                                                             |
| ---------- | -------------------------------------- | ----------------------------------------------------------------------- |
| cartesians | Array.<[Cartesian2](Cartesian2.html)\> | The array of points to project.                                         |
| result     | Array.<[Cartesian3](Cartesian3.html)\> | optional The array of Cartesian3 instances onto which to store results. |

##### Returns:

 The modified result parameter or a new array of Cartesian3 instances if none was provided.

#### [](#projectPointsOntoPlane) projectPointsOntoPlane(cartesians, result) → Array.<[Cartesian2](Cartesian2.html)\> 

[engine/Source/Core/EllipsoidTangentPlane.js 216](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L216) 

 Computes the projection of the provided 3D positions onto the 2D plane (where possible), radially outward from the global origin. The resulting array may be shorter than the input array - if a single projection is impossible it will not be included.

| Name       | Type                                   | Description                                                             |
| ---------- | -------------------------------------- | ----------------------------------------------------------------------- |
| cartesians | Array.<[Cartesian3](Cartesian3.html)\> | The array of points to project.                                         |
| result     | Array.<[Cartesian2](Cartesian2.html)\> | optional The array of Cartesian2 instances onto which to store results. |

##### Returns:

 The modified result parameter or a new array of Cartesian2 instances if none was provided.

##### See:

* EllipsoidTangentPlane.projectPointOntoPlane

#### [](#projectPointsToNearestOnPlane) projectPointsToNearestOnPlane(cartesians, result) → Array.<[Cartesian2](Cartesian2.html)\> 

[engine/Source/Core/EllipsoidTangentPlane.js 300](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L300) 

 Computes the projection of the provided 3D positions onto the 2D plane, along the plane normal.

| Name       | Type                                   | Description                                                             |
| ---------- | -------------------------------------- | ----------------------------------------------------------------------- |
| cartesians | Array.<[Cartesian3](Cartesian3.html)\> | The array of points to project.                                         |
| result     | Array.<[Cartesian2](Cartesian2.html)\> | optional The array of Cartesian2 instances onto which to store results. |

##### Returns:

 The modified result parameter or a new array of Cartesian2 instances if none was provided. This will have the same length as `cartesians`.

##### See:

* EllipsoidTangentPlane.projectPointToNearestOnPlane

#### [](#projectPointToNearestOnPlane) projectPointToNearestOnPlane(cartesian, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/EllipsoidTangentPlane.js 248](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidTangentPlane.js#L248) 

 Computes the projection of the provided 3D position onto the 2D plane, along the plane normal.

| Name      | Type                          | Description                                         |
| --------- | ----------------------------- | --------------------------------------------------- |
| cartesian | [Cartesian3](Cartesian3.html) | The point to project.                               |
| result    | [Cartesian2](Cartesian2.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Cartesian2 instance if none was provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

