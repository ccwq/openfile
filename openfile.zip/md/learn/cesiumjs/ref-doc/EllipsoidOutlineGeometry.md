# [![](Images/CesiumLogo.png)](index.html) EllipsoidOutlineGeometry 

#### [](#EllipsoidOutlineGeometry) new Cesium.EllipsoidOutlineGeometry(options) 

[engine/Source/Core/EllipsoidOutlineGeometry.js 49](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidOutlineGeometry.js#L49) 

 A description of the outline of an ellipsoid centered at the origin.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description radii [Cartesian3](Cartesian3.html) Cartesian3(1.0, 1.0, 1.0) optional The radii of the ellipsoid in the x, y, and z directions. innerRadii [Cartesian3](Cartesian3.html) options.radii optional The inner radii of the ellipsoid in the x, y, and z directions. minimumClock number 0.0 optional The minimum angle lying in the xy-plane measured from the positive x-axis and toward the positive y-axis. maximumClock number 2\*PI optional The maximum angle lying in the xy-plane measured from the positive x-axis and toward the positive y-axis. minimumCone number 0.0 optional The minimum angle measured from the positive z-axis and toward the negative z-axis. maximumCone number PI optional The maximum angle measured from the positive z-axis and toward the negative z-axis. stackPartitions number 10 optional The count of stacks for the ellipsoid (1 greater than the number of parallel lines). slicePartitions number 8 optional The count of slices for the ellipsoid (Equal to the number of radial lines). subdivisions number 128 optional The number of points per line, determining the granularity of the curvature. |

##### Throws:

* [DeveloperError](DeveloperError.html): options.stackPartitions must be greater than or equal to one.
* [DeveloperError](DeveloperError.html): options.slicePartitions must be greater than or equal to zero.
* [DeveloperError](DeveloperError.html): options.subdivisions must be greater than or equal to zero.

##### Example:

```javascript
const ellipsoid = new Cesium.EllipsoidOutlineGeometry({
  radii : new Cesium.Cartesian3(1000000.0, 500000.0, 500000.0),
  stackPartitions: 6,
  slicePartitions: 5
});
const geometry = Cesium.EllipsoidOutlineGeometry.createGeometry(ellipsoid);
```

### Members

#### [](#.packedLength) static Cesium.EllipsoidOutlineGeometry.packedLength : number 

[engine/Source/Core/EllipsoidOutlineGeometry.js 101](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidOutlineGeometry.js#L101) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.EllipsoidOutlineGeometry.createGeometry(ellipsoidGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/EllipsoidOutlineGeometry.js 223](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidOutlineGeometry.js#L223) 

 Computes the geometric representation of an outline of an ellipsoid, including its vertices, indices, and a bounding sphere.

| Name              | Type                                                      | Description                             |
| ----------------- | --------------------------------------------------------- | --------------------------------------- |
| ellipsoidGeometry | [EllipsoidOutlineGeometry](EllipsoidOutlineGeometry.html) | A description of the ellipsoid outline. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.EllipsoidOutlineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/EllipsoidOutlineGeometry.js 112](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidOutlineGeometry.js#L112) 

 Stores the provided instance into the provided array.

| Name          | Type                                                      | Default | Description                                                               |
| ------------- | --------------------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [EllipsoidOutlineGeometry](EllipsoidOutlineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                            |         | The array to pack into.                                                   |
| startingIndex | number                                                    | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.EllipsoidOutlineGeometry.unpack(array, startingIndex, result) → [EllipsoidOutlineGeometry](EllipsoidOutlineGeometry.html) 

[engine/Source/Core/EllipsoidOutlineGeometry.js 165](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidOutlineGeometry.js#L165) 

 Retrieves an instance from a packed array.

| Name          | Type                                                      | Default | Description                                                |
| ------------- | --------------------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                            |         | The packed array.                                          |
| startingIndex | number                                                    | 0       | optional The starting index of the element to be unpacked. |
| result        | [EllipsoidOutlineGeometry](EllipsoidOutlineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new EllipsoidOutlineGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

