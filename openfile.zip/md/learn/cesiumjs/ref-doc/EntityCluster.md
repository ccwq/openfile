# [![](Images/CesiumLogo.png)](index.html) EntityCluster 

#### [](#EntityCluster) new Cesium.EntityCluster(options) 

[engine/Source/DataSources/EntityCluster.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCluster.js#L35) 

 Defines how screen space objects (billboards, points, labels) are clustered.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| options | object | optional An object with the following properties: Name Type Default Description enabled boolean false optional Whether or not to enable clustering. pixelRange number 80 optional The pixel range to extend the screen space bounding box. minimumClusterSize number 2 optional The minimum number of screen space objects that can be clustered. clusterBillboards boolean true optional Whether or not to cluster the billboards of an entity. clusterLabels boolean true optional Whether or not to cluster the labels of an entity. clusterPoints boolean true optional Whether or not to cluster the points of an entity. show boolean true optional Determines if the entities in the cluster will be shown. |

##### Demo:

* [Cesium Sandcastle Clustering Demo](https://sandcastle.cesium.com/index.html?src=Clustering.html)

### Members

#### [](#clusterBillboards) clusterBillboards : boolean 

[engine/Source/DataSources/EntityCluster.js 575](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCluster.js#L575) 

 Gets or sets whether clustering billboard entities is enabled.

#### [](#clusterEvent) clusterEvent : [Event](Event.html).<[EntityCluster.newClusterCallback](EntityCluster.html#.newClusterCallback)\> 

[engine/Source/DataSources/EntityCluster.js 565](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCluster.js#L565) 

 Gets the event that will be raised when a new cluster will be displayed. The signature of the event listener is [EntityCluster.newClusterCallback](EntityCluster.html#.newClusterCallback).

#### [](#clusterLabels) clusterLabels : boolean 

[engine/Source/DataSources/EntityCluster.js 590](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCluster.js#L590) 

 Gets or sets whether clustering labels entities is enabled.

#### [](#clusterPoints) clusterPoints : boolean 

[engine/Source/DataSources/EntityCluster.js 604](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCluster.js#L604) 

 Gets or sets whether clustering point entities is enabled.

#### [](#enabled) enabled : boolean 

[engine/Source/DataSources/EntityCluster.js 522](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCluster.js#L522) 

 Gets or sets whether clustering is enabled.

#### [](#minimumClusterSize) minimumClusterSize : number 

[engine/Source/DataSources/EntityCluster.js 550](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCluster.js#L550) 

 Gets or sets the minimum number of screen space objects that can be clustered.

#### [](#pixelRange) pixelRange : number 

[engine/Source/DataSources/EntityCluster.js 536](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCluster.js#L536) 

 Gets or sets the pixel range to extend the screen space bounding box.

#### [](#show) show : boolean 

[engine/Source/DataSources/EntityCluster.js 76](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCluster.js#L76) 

 Determines if entities in this collection will be shown.

Default Value: `true` 

### Methods

#### [](#destroy) destroy() 

[engine/Source/DataSources/EntityCluster.js 959](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCluster.js#L959) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.

Unlike other objects that use WebGL resources, this object can be reused. For example, if a data source is removed from a data source collection and added to another.

### Type Definitions

#### [](#.newClusterCallback) Cesium.EntityCluster.newClusterCallback(clusteredEntities, cluster) 

[engine/Source/DataSources/EntityCluster.js 1004](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EntityCluster.js#L1004) 

 A event listener function used to style clusters.

| Name              | Type                           | Description                                                                                                                                                                                                                                |
| ----------------- | ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| clusteredEntities | Array.<[Entity](Entity.html)\> | An array of the entities contained in the cluster.                                                                                                                                                                                         |
| cluster           | object                         | An object containing the Billboard, Label, and Point primitives that represent this cluster of entities. Name Type Description billboard [Billboard](Billboard.html) label [Label](Label.html) point [PointPrimitive](PointPrimitive.html) |

##### Example:

```javascript
// The default cluster values.
dataSource.clustering.clusterEvent.addEventListener(function(entities, cluster) {
    cluster.label.show = true;
    cluster.label.text = entities.length.toLocaleString();
});
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

