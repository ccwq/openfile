# [![](Images/CesiumLogo.png)](index.html) GltfGpmLocal 

#### [](#GltfGpmLocal) new Cesium.GltfGpmLocal(options) 

[engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js 52](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js#L52) 

 The GPM metadata for a Ground-Space Indirect implementation stored locally (i.e. a tile and/or leaf node). This reflects the root extension object of the [NGA\_gpm\_local](https://nsgreg.nga.mil/csmwg.jsp)glTF extension. When a model that contains this extension was loaded, then an object of this type can be obtained by calling \`\`\` const gltfGpmLocal = model.getExtension("NGA\_gpm\_local"); \`\`\` The storage type determines the presence of the optional properties:
* When the storage type is \`StorageType.Indirect\`, then the \`anchorPointsIndirect\` and \`intraTileCorrelationGroups\` are present.
* When the storage type is \`StorageType.Direct\`, then the \`anchorPointsDirect\` and \`covarianceDirect\` are present.

| Name    | Type                                                                     | Description                                 |
| ------- | ------------------------------------------------------------------------ | ------------------------------------------- |
| options | [GltfGpmLocal.ConstructorOptions](GltfGpmLocal.html#.ConstructorOptions) | An object describing initialization options |

##### Experimental

This feature is not final and is subject to change without Cesium's standard deprecation policy.

### Members

#### [](#anchorPointsDirect) readonly anchorPointsDirect : Array.<[AnchorPointDirect](AnchorPointDirect.html)\>|undefined 

[engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js 145](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js#L145) 

 Array of stored direct anchor points

#### [](#anchorPointsIndirect) readonly anchorPointsIndirect : Array.<[AnchorPointIndirect](AnchorPointIndirect.html)\>|undefined 

[engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js#L132) 

 Array of stored indirect anchor points

#### [](#covarianceDirect) readonly covarianceDirect : [Matrix3](Matrix3.html)|undefined 

[engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js 172](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js#L172) 

 The full covariance of anchor point parameters

#### [](#intraTileCorrelationGroups) readonly intraTileCorrelationGroups : Array.<[CorrelationGroup](CorrelationGroup.html)\>|undefined 

[engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js 159](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js#L159) 

 Metadata identifying parameters using same correlation modeling and associated correlation parameters

#### [](#storageType) readonly storageType : [StorageType](global.html#StorageType) 

[engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js 119](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js#L119) 

 Specifies if covariance storage is indirect or direct.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.GltfGpmLocal.ConstructorOptions

[engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js 6](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/Extensions/Gpm/GltfGpmLocal.js#L6) 

 Initialization options for the GltfGpmLocal constructor

##### Properties:

| Name                       | Type                                                                | Attributes | Description                                                                                                    |
| -------------------------- | ------------------------------------------------------------------- | ---------- | -------------------------------------------------------------------------------------------------------------- |
| storageType                | string                                                              |            | The storage type. This must be one of the \`StorageType\` constants, i.e. \`Direct\` or \`Indirect\`.          |
| anchorPointsIndirect       | Array.<[AnchorPointIndirect](AnchorPointIndirect.html)\>\|undefined | <optional> | The indirect anchor points. This must be present if and only if the storage type is \`Indirect\`.              |
| intraTileCorrelationGroups | Array.<[CorrelationGroup](CorrelationGroup.html)\>\|undefined       | <optional> | The intra-tile correlation groups. This must be present if and only if the storage type is \`Indirect\`.       |
| anchorPointsDirect         | Array.<[AnchorPointDirect](AnchorPointDirect.html)\>\|undefined     | <optional> | The direct anchor points. This must be present if and only if the storage type is \`Direct\`.                  |
| covarianceDirect           | [Matrix3](Matrix3.html)\|undefined                                  | <optional> | The covariance of anchor point parameters. This must be present if and only if the storage type is \`Direct\`. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

