# [![](Images/CesiumLogo.png)](index.html) CzmlDataSource 

#### [](#CzmlDataSource) new Cesium.CzmlDataSource(name) 

[engine/Source/DataSources/CzmlDataSource.js 4848](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4848) 

 A [DataSource](DataSource.html) which processes [CZML](https://github.com/AnalyticalGraphicsInc/czml-writer/wiki/CZML-Guide).

| Name | Type   | Description                                                                                                         |
| ---- | ------ | ------------------------------------------------------------------------------------------------------------------- |
| name | string | optional An optional name for the data source. This value will be overwritten if a loaded document contains a name. |

##### Demo:

* [Cesium Sandcastle CZML Demo](https://sandcastle.cesium.com/index.html?src=CZML.html)

### Members

#### [](#.updaters) static Cesium.CzmlDataSource.updaters : Array.<[CzmlDataSource.UpdaterFunction](CzmlDataSource.html#.UpdaterFunction)\> 

[engine/Source/DataSources/CzmlDataSource.js 5010](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L5010) 

 Gets the array of CZML processing functions.

#### [](#changedEvent) changedEvent : [Event](Event.html) 

[engine/Source/DataSources/CzmlDataSource.js 4923](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4923) 

 Gets an event that will be raised when the underlying data changes.

#### [](#clock) clock : [DataSourceClock](DataSourceClock.html) 

[engine/Source/DataSources/CzmlDataSource.js 4893](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4893) 

 Gets the clock settings defined by the loaded CZML. If no clock is explicitly defined in the CZML, the combined availability of all objects is returned. If only static data exists, this value is undefined.

#### [](#clustering) clustering : [EntityCluster](EntityCluster.html) 

[engine/Source/DataSources/CzmlDataSource.js 4968](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4968) 

 Gets or sets the clustering options for this data source. This object can be shared between multiple data sources.

#### [](#credit) credit : [Credit](Credit.html) 

[engine/Source/DataSources/CzmlDataSource.js 4986](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4986) 

 Gets the credit that will be displayed for the data source

#### [](#entities) entities : [EntityCollection](EntityCollection.html) 

[engine/Source/DataSources/CzmlDataSource.js 4903](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4903) 

 Gets the collection of [Entity](Entity.html) instances.

#### [](#errorEvent) errorEvent : [Event](Event.html) 

[engine/Source/DataSources/CzmlDataSource.js 4933](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4933) 

 Gets an event that will be raised if an error is encountered during processing.

#### [](#isLoading) isLoading : boolean 

[engine/Source/DataSources/CzmlDataSource.js 4913](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4913) 

 Gets a value indicating if the data source is currently loading data.

#### [](#loadingEvent) loadingEvent : [Event](Event.html) 

[engine/Source/DataSources/CzmlDataSource.js 4943](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4943) 

 Gets an event that will be raised when the data source either starts or stops loading.

#### [](#name) name : string 

[engine/Source/DataSources/CzmlDataSource.js 4881](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4881) 

 Gets a human-readable name for this instance.

#### [](#show) show : boolean 

[engine/Source/DataSources/CzmlDataSource.js 4953](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4953) 

 Gets whether or not this data source should be displayed.

### Methods

#### [](#.load) static Cesium.CzmlDataSource.load(czml, options) → Promise.<[CzmlDataSource](CzmlDataSource.html)\> 

[engine/Source/DataSources/CzmlDataSource.js 4871](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4871) 

 Creates a Promise to a new instance loaded with the provided CZML data.

| Name    | Type                                                           | Description                                         |
| ------- | -------------------------------------------------------------- | --------------------------------------------------- |
| czml    | [Resource](Resource.html)\|string|object                       | A url or CZML object to be processed.               |
| options | [CzmlDataSource.LoadOptions](CzmlDataSource.html#.LoadOptions) | optional An object specifying configuration options |

##### Returns:

 A promise that resolves to the new instance once the data is processed.

#### [](#.processMaterialPacketData) static Cesium.CzmlDataSource.processMaterialPacketData(object, propertyName, packetData, interval, sourceUri, entityCollection) 

[engine/Source/DataSources/CzmlDataSource.js 5137](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L5137) 

 A helper function used by custom CZML updater functions which creates or updates a [MaterialProperty](MaterialProperty.html) from a CZML packet.

| Name             | Type                                      | Description                                                |
| ---------------- | ----------------------------------------- | ---------------------------------------------------------- |
| object           | object                                    | The object on which the property will be added or updated. |
| propertyName     | string                                    | The name of the property on the object.                    |
| packetData       | object                                    | The CZML packet being processed.                           |
| interval         | [TimeInterval](TimeInterval.html)         | A constraining interval for which the data is valid.       |
| sourceUri        | string                                    | The originating uri of the data being processed.           |
| entityCollection | [EntityCollection](EntityCollection.html) | The collection being processsed.                           |

#### [](#.processPacketData) static Cesium.CzmlDataSource.processPacketData(type, object, propertyName, packetData, interval, sourceUri, entityCollection) 

[engine/Source/DataSources/CzmlDataSource.js 5109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L5109) 

 A helper function used by custom CZML updater functions which creates or updates a [Property](Property.html) from a CZML packet.

| Name             | Type                                      | Description                                                |
| ---------------- | ----------------------------------------- | ---------------------------------------------------------- |
| type             | function                                  | The constructor function for the property being processed. |
| object           | object                                    | The object on which the property will be added or updated. |
| propertyName     | string                                    | The name of the property on the object.                    |
| packetData       | object                                    | The CZML packet being processed.                           |
| interval         | [TimeInterval](TimeInterval.html)         | A constraining interval for which the data is valid.       |
| sourceUri        | string                                    | The originating uri of the data being processed.           |
| entityCollection | [EntityCollection](EntityCollection.html) | The collection being processsed.                           |

#### [](#.processPositionPacketData) static Cesium.CzmlDataSource.processPositionPacketData(object, propertyName, packetData, interval, sourceUri, entityCollection) 

[engine/Source/DataSources/CzmlDataSource.js 5123](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L5123) 

 A helper function used by custom CZML updater functions which creates or updates a [PositionProperty](PositionProperty.html) from a CZML packet.

| Name             | Type                                      | Description                                                |
| ---------------- | ----------------------------------------- | ---------------------------------------------------------- |
| object           | object                                    | The object on which the property will be added or updated. |
| propertyName     | string                                    | The name of the property on the object.                    |
| packetData       | object                                    | The CZML packet being processed.                           |
| interval         | [TimeInterval](TimeInterval.html)         | A constraining interval for which the data is valid.       |
| sourceUri        | string                                    | The originating uri of the data being processed.           |
| entityCollection | [EntityCollection](EntityCollection.html) | The collection being processsed.                           |

#### [](#load) load(czml, options) → Promise.<[CzmlDataSource](CzmlDataSource.html)\> 

[engine/Source/DataSources/CzmlDataSource.js 5079](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L5079) 

 Loads the provided url or CZML object, replacing any existing data.

| Name    | Type                                                           | Description                                         |
| ------- | -------------------------------------------------------------- | --------------------------------------------------- |
| czml    | [Resource](Resource.html)\|string|object                       | A url or CZML object to be processed.               |
| options | [CzmlDataSource.LoadOptions](CzmlDataSource.html#.LoadOptions) | optional An object specifying configuration options |

##### Returns:

 A promise that resolves to this instances once the data is processed.

#### [](#process) process(czml, options) → Promise.<[CzmlDataSource](CzmlDataSource.html)\> 

[engine/Source/DataSources/CzmlDataSource.js 5067](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L5067) 

 Processes the provided url or CZML object without clearing any existing data.

| Name    | Type                                                           | Description                                         |
| ------- | -------------------------------------------------------------- | --------------------------------------------------- |
| czml    | [Resource](Resource.html)\|string|object                       | A url or CZML object to be processed.               |
| options | [CzmlDataSource.LoadOptions](CzmlDataSource.html#.LoadOptions) | optional An object specifying configuration options |

##### Returns:

 A promise that resolves to this instances once the data is processed.

#### [](#update) update(time) → boolean 

[engine/Source/DataSources/CzmlDataSource.js 5092](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L5092) 

 Updates the data source to the provided time. This function is optional and is not required to be implemented. It is provided for data sources which retrieve data based on the current animation time or scene state. If implemented, update will be called by [DataSourceDisplay](DataSourceDisplay.html) once a frame.

| Name | Type                          | Description          |
| ---- | ----------------------------- | -------------------- |
| time | [JulianDate](JulianDate.html) | The simulation time. |

##### Returns:

 True if this data source is ready to be displayed at the provided time, false otherwise.

### Type Definitions

#### [](#.LoadOptions) Cesium.CzmlDataSource.LoadOptions

[engine/Source/DataSources/CzmlDataSource.js 4830](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4830) 

 Initialization options for the `load` method.

##### Properties:

| Name      | Type                              | Attributes | Description                                                     |
| --------- | --------------------------------- | ---------- | --------------------------------------------------------------- |
| sourceUri | [Resource](Resource.html)\|string | <optional> | Overrides the url to use for resolving relative links.          |
| credit    | [Credit](Credit.html)\|string     | <optional> | A credit for the data source, which is displayed on the canvas. |

#### [](#.UpdaterFunction) Cesium.CzmlDataSource.UpdaterFunction(entity, packet, entityCollection, sourceUri) 

[engine/Source/DataSources/CzmlDataSource.js 4993](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/CzmlDataSource.js#L4993) 

| Name             | Type                                      | Description |
| ---------------- | ----------------------------------------- | ----------- |
| entity           | [Entity](Entity.html)                     |             |
| packet           | object                                    |             |
| entityCollection | [EntityCollection](EntityCollection.html) |             |
| sourceUri        | string                                    |             |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

