# [![](Images/CesiumLogo.png)](index.html) ImageryLayer 

#### [](#ImageryLayer) new Cesium.ImageryLayer(imageryProvider, options) 

[engine/Source/Scene/ImageryLayer.js 159](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L159) 

 An imagery layer that displays tiled image data from a single imagery provider on a [Globe](Globe.html).

| Name            | Type                                                                     | Description                                          |
| --------------- | ------------------------------------------------------------------------ | ---------------------------------------------------- |
| imageryProvider | [ImageryProvider](ImageryProvider.html)                                  | optional The imagery provider to use.                |
| options         | [ImageryLayer.ConstructorOptions](ImageryLayer.html#.ConstructorOptions) | optional An object describing initialization options |

##### Examples:

```javascript
// Add an OpenStreetMaps layer
const imageryLayer = new Cesium.ImageryLayer(new Cesium.OpenStreetMapImageryProvider({
  url: "https://tile.openstreetmap.org/"
}));
scene.imageryLayers.add(imageryLayer);
```

```javascript
// Add Cesium ion's default world imagery layer
const imageryLayer = Cesium.ImageryLayer.fromWorldImagery();
scene.imageryLayers.add(imageryLayer);
```

```javascript
// Add a new transparent layer from Cesium ion
const imageryLayer = Cesium.ImageryLayer.fromProviderAsync(Cesium.IonImageryProvider.fromAssetId(3812));
imageryLayer.alpha = 0.5;
scene.imageryLayers.add(imageryLayer);
```

##### See:

* [ImageryLayer.fromProviderAsync](ImageryLayer.html#.fromProviderAsync)
* [ImageryLayer.fromWorldImagery](ImageryLayer.html#.fromWorldImagery)

### Members

#### [](#.DEFAULT%5FAPPLY%5FCOLOR%5FTO%5FALPHA%5FTHRESHOLD) static Cesium.ImageryLayer.DEFAULT\_APPLY\_COLOR\_TO\_ALPHA\_THRESHOLD : number 

[engine/Source/Scene/ImageryLayer.js 508](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L508) 

 This value is used as the default threshold for color-to-alpha if one is not provided during construction or by the imagery provider.

Default Value: `0.004` 

#### [](#.DEFAULT%5FBRIGHTNESS) static Cesium.ImageryLayer.DEFAULT\_BRIGHTNESS : number 

[engine/Source/Scene/ImageryLayer.js 448](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L448) 

 This value is used as the default brightness for the imagery layer if one is not provided during construction or by the imagery provider. This value does not modify the brightness of the imagery.

Default Value: `1.0` 

#### [](#.DEFAULT%5FCONTRAST) static Cesium.ImageryLayer.DEFAULT\_CONTRAST : number 

[engine/Source/Scene/ImageryLayer.js 455](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L455) 

 This value is used as the default contrast for the imagery layer if one is not provided during construction or by the imagery provider. This value does not modify the contrast of the imagery.

Default Value: `1.0` 

#### [](#.DEFAULT%5FGAMMA) static Cesium.ImageryLayer.DEFAULT\_GAMMA : number 

[engine/Source/Scene/ImageryLayer.js 476](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L476) 

 This value is used as the default gamma for the imagery layer if one is not provided during construction or by the imagery provider. This value does not modify the gamma of the imagery.

Default Value: `1.0` 

#### [](#.DEFAULT%5FHUE) static Cesium.ImageryLayer.DEFAULT\_HUE : number 

[engine/Source/Scene/ImageryLayer.js 462](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L462) 

 This value is used as the default hue for the imagery layer if one is not provided during construction or by the imagery provider. This value does not modify the hue of the imagery.

Default Value: `0.0` 

#### [](#.DEFAULT%5FMAGNIFICATION%5FFILTER) static Cesium.ImageryLayer.DEFAULT\_MAGNIFICATION\_FILTER : [TextureMagnificationFilter](global.html#TextureMagnificationFilter) 

[engine/Source/Scene/ImageryLayer.js 500](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L500) 

 This value is used as the default texture magnification filter for the imagery layer if one is not provided during construction or by the imagery provider.

Default Value: `TextureMagnificationFilter.LINEAR` 

#### [](#.DEFAULT%5FMINIFICATION%5FFILTER) static Cesium.ImageryLayer.DEFAULT\_MINIFICATION\_FILTER : [TextureMinificationFilter](global.html#TextureMinificationFilter) 

[engine/Source/Scene/ImageryLayer.js 492](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L492) 

 This value is used as the default texture minification filter for the imagery layer if one is not provided during construction or by the imagery provider.

Default Value: `TextureMinificationFilter.LINEAR` 

#### [](#.DEFAULT%5FSATURATION) static Cesium.ImageryLayer.DEFAULT\_SATURATION : number 

[engine/Source/Scene/ImageryLayer.js 469](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L469) 

 This value is used as the default saturation for the imagery layer if one is not provided during construction or by the imagery provider. This value does not modify the saturation of the imagery.

Default Value: `1.0` 

#### [](#.DEFAULT%5FSPLIT) static Cesium.ImageryLayer.DEFAULT\_SPLIT : [SplitDirection](global.html#SplitDirection) 

[engine/Source/Scene/ImageryLayer.js 484](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L484) 

 This value is used as the default split for the imagery layer if one is not provided during construction or by the imagery provider.

Default Value: `SplitDirection.NONE` 

#### [](#alpha) alpha : number 

[engine/Source/Scene/ImageryLayer.js 175](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L175) 

 The alpha blending value of this layer, with 0.0 representing fully transparent and 1.0 representing fully opaque.

Default Value: `1.0` 

#### [](#brightness) brightness : number 

[engine/Source/Scene/ImageryLayer.js 211](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L211) 

 The brightness of this layer. 1.0 uses the unmodified imagery color. Less than 1.0 makes the imagery darker while greater than 1.0 makes it brighter.

Default Value: `[ImageryLayer.DEFAULT_BRIGHTNESS](ImageryLayer.html#.DEFAULT%5FBRIGHTNESS)` 

#### [](#colorToAlpha) colorToAlpha : [Color](Color.html) 

[engine/Source/Scene/ImageryLayer.js 363](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L363) 

 Color value that should be set to transparent.

#### [](#colorToAlphaThreshold) colorToAlphaThreshold : number 

[engine/Source/Scene/ImageryLayer.js 370](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L370) 

 Normalized (0-1) threshold for color-to-alpha.

#### [](#contrast) contrast : number 

[engine/Source/Scene/ImageryLayer.js 226](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L226) 

 The contrast of this layer. 1.0 uses the unmodified imagery color. Less than 1.0 reduces the contrast while greater than 1.0 increases it.

Default Value: `[ImageryLayer.DEFAULT_CONTRAST](ImageryLayer.html#.DEFAULT%5FCONTRAST)` 

#### [](#cutoutRectangle) cutoutRectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/ImageryLayer.js 356](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L356) 

 Rectangle cutout in this layer of imagery.

#### [](#dayAlpha) dayAlpha : number 

[engine/Source/Scene/ImageryLayer.js 199](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L199) 

 The alpha blending value of this layer on the day side of the globe, with 0.0 representing fully transparent and 1.0 representing fully opaque. This only takes effect when [Globe#enableLighting](Globe.html#enableLighting) is `true`.

Default Value: `1.0` 

#### [](#gamma) gamma : number 

[engine/Source/Scene/ImageryLayer.js 266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L266) 

 The gamma correction to apply to this layer. 1.0 uses the unmodified imagery color.

Default Value: `[ImageryLayer.DEFAULT_GAMMA](ImageryLayer.html#.DEFAULT%5FGAMMA)` 

#### [](#hue) hue : number 

[engine/Source/Scene/ImageryLayer.js 240](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L240) 

 The hue of this layer in radians. 0.0 uses the unmodified imagery color.

Default Value: `[ImageryLayer.DEFAULT_HUE](ImageryLayer.html#.DEFAULT%5FHUE)` 

#### [](#imageryProvider) readonly imageryProvider : [ImageryProvider](ImageryProvider.html) 

[engine/Source/Scene/ImageryLayer.js 383](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L383) 

 Gets the imagery provider for this layer. This should not be called before [ImageryLayer#ready](ImageryLayer.html#ready) returns true.

#### [](#magnificationFilter) magnificationFilter : [TextureMagnificationFilter](global.html#TextureMagnificationFilter) 

[engine/Source/Scene/ImageryLayer.js 312](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L312) 

 The [TextureMagnificationFilter](global.html#TextureMagnificationFilter) to apply to this layer. Possible values are [TextureMagnificationFilter.LINEAR](global.html#TextureMagnificationFilter#.LINEAR) (the default) and [TextureMagnificationFilter.NEAREST](global.html#TextureMagnificationFilter#.NEAREST). To take effect, this property must be set immediately after adding the imagery layer. Once a texture is loaded it won't be possible to change the texture filter used.

Default Value: `[ImageryLayer.DEFAULT_MAGNIFICATION_FILTER](ImageryLayer.html#.DEFAULT%5FMAGNIFICATION%5FFILTER)` 

#### [](#minificationFilter) minificationFilter : [TextureMinificationFilter](global.html#TextureMinificationFilter) 

[engine/Source/Scene/ImageryLayer.js 293](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L293) 

 The [TextureMinificationFilter](global.html#TextureMinificationFilter) to apply to this layer. Possible values are [TextureMinificationFilter.LINEAR](global.html#TextureMinificationFilter#.LINEAR) (the default) and [TextureMinificationFilter.NEAREST](global.html#TextureMinificationFilter#.NEAREST). To take effect, this property must be set immediately after adding the imagery layer. Once a texture is loaded it won't be possible to change the texture filter used.

Default Value: `[ImageryLayer.DEFAULT_MINIFICATION_FILTER](ImageryLayer.html#.DEFAULT%5FMINIFICATION%5FFILTER)` 

#### [](#nightAlpha) nightAlpha : number 

[engine/Source/Scene/ImageryLayer.js 187](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L187) 

 The alpha blending value of this layer on the night side of the globe, with 0.0 representing fully transparent and 1.0 representing fully opaque. This only takes effect when [Globe#enableLighting](Globe.html#enableLighting) is `true`.

Default Value: `1.0` 

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/ImageryLayer.js 395](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L395) 

 Returns true when the terrain provider has been successfully created. Otherwise, returns false.

#### [](#readyEvent) readonly readyEvent : [Event](Event.html).<[ImageryLayer.ReadyEventCallback](ImageryLayer.html#.ReadyEventCallback)\> 

[engine/Source/Scene/ImageryLayer.js 422](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L422) 

 Gets an event that is raised when the imagery provider has been successfully created. Event listeners are passed the created instance of [ImageryProvider](ImageryProvider.html).

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/ImageryLayer.js 435](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L435) 

 Gets the rectangle of this layer. If this rectangle is smaller than the rectangle of the[ImageryProvider](ImageryProvider.html), only a portion of the imagery provider is shown.

#### [](#saturation) saturation : number 

[engine/Source/Scene/ImageryLayer.js 252](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L252) 

 The saturation of this layer. 1.0 uses the unmodified imagery color. Less than 1.0 reduces the saturation while greater than 1.0 increases it.

Default Value: `[ImageryLayer.DEFAULT_SATURATION](ImageryLayer.html#.DEFAULT%5FSATURATION)` 

#### [](#show) show : boolean 

[engine/Source/Scene/ImageryLayer.js 326](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L326) 

 Determines if this layer is shown.

Default Value: `true` 

#### [](#splitDirection) splitDirection : [SplitDirection](global.html#SplitDirection) 

[engine/Source/Scene/ImageryLayer.js 277](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L277) 

 The [SplitDirection](global.html#SplitDirection) to apply to this layer.

Default Value: `[ImageryLayer.DEFAULT_SPLIT](ImageryLayer.html#.DEFAULT%5FSPLIT)` 

### Methods

#### [](#.fromProviderAsync) static Cesium.ImageryLayer.fromProviderAsync(imageryProviderPromise, options) → [ImageryLayer](ImageryLayer.html) 

[engine/Source/Scene/ImageryLayer.js 549](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L549) 

 Create a new imagery layer from an asynchronous imagery provider. The layer will handle any asynchronous loads or errors, and begin rendering the imagery layer once ready.

| Name                   | Type                                                                     | Description                                          |
| ---------------------- | ------------------------------------------------------------------------ | ---------------------------------------------------- |
| imageryProviderPromise | Promise.<[ImageryProvider](ImageryProvider.html)\>                       | A promise which resolves to a imagery provider       |
| options                | [ImageryLayer.ConstructorOptions](ImageryLayer.html#.ConstructorOptions) | optional An object describing initialization options |

##### Returns:

 The created imagery layer.

##### Examples:

```javascript
// Create a new base layer
const viewer = new Cesium.Viewer("cesiumContainer", {
  baseLayer: Cesium.ImageryLayer.fromProviderAsync(Cesium.IonImageryProvider.fromAssetId(3812));
});
```

```javascript
// Add a new transparent layer
const imageryLayer = Cesium.ImageryLayer.fromProviderAsync(Cesium.IonImageryProvider.fromAssetId(3812));
imageryLayer.alpha = 0.5;
viewer.imageryLayers.add(imageryLayer);
```

```javascript
// Handle loading events
const imageryLayer = Cesium.ImageryLayer.fromProviderAsync(Cesium.IonImageryProvider.fromAssetId(3812));
viewer.imageryLayers.add(imageryLayer);

imageryLayer.readyEvent.addEventListener(provider => {
  imageryLayer.provider.errorEvent.addEventListener(error => {
    alert(`Encountered an error while loading imagery tiles! ${error}`);
  });
});

imageryLayer.errorEvent.addEventListener(error => {
  alert(`Encountered an error while creating an imagery layer! ${error}`);
});
```

##### See:

* ImageryLayer.errorEvent
* ImageryLayer.readyEvent
* ImageryLayer.provider
* [ImageryLayer.fromWorldImagery](ImageryLayer.html#.fromWorldImagery)

#### [](#.fromWorldImagery) static Cesium.ImageryLayer.fromWorldImagery(options) → [ImageryLayer](ImageryLayer.html) 

[engine/Source/Scene/ImageryLayer.js 606](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L606) 

 Create a new imagery layer for ion's default global base imagery layer, currently Bing Maps. The layer will handle any asynchronous loads or errors, and begin rendering the imagery layer once ready.

| Name    | Type                                                                                             | Description                                 |
| ------- | ------------------------------------------------------------------------------------------------ | ------------------------------------------- |
| options | [ImageryLayer.WorldImageryConstructorOptions](ImageryLayer.html#.WorldImageryConstructorOptions) | An object describing initialization options |

##### Returns:

 The created imagery layer. \* @example // Create a new base layer const viewer = new Cesium.Viewer("cesiumContainer", { baseLayer: Cesium.ImageryLayer.fromWorldImagery(); });

##### Examples:

```javascript
// Add a new transparent layer
const imageryLayer = Cesium.ImageryLayer.fromWorldImagery();
imageryLayer.alpha = 0.5;
viewer.imageryLayers.add(imageryLayer);
```

```javascript
// Handle loading events
const imageryLayer = Cesium.ImageryLayer.fromWorldImagery();
viewer.imageryLayers.add(imageryLayer);

imageryLayer.readyEvent.addEventListener(provider => {
  imageryLayer.provider.errorEvent.addEventListener(error => {
    alert(`Encountered an error while loading imagery tiles! ${error}`);
  });
});

imageryLayer.errorEvent.addEventListener(error => {
  alert(`Encountered an error while creating an imagery layer! ${error}`);
});
```

##### See:

* ImageryLayer.errorEvent
* ImageryLayer.readyEvent
* ImageryLayer.provider

#### [](#destroy) destroy() 

[engine/Source/Scene/ImageryLayer.js 660](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L660) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
imageryLayer = imageryLayer && imageryLayer.destroy();
```

##### See:

* [ImageryLayer#isDestroyed](ImageryLayer.html#isDestroyed)

#### [](#getImageryRectangle) getImageryRectangle() → [Rectangle](Rectangle.html) 

[engine/Source/Scene/ImageryLayer.js 683](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L683) 

 Computes the intersection of this layer's rectangle with the imagery provider's availability rectangle, producing the overall bounds of imagery that can be produced by this layer.

##### Returns:

 A rectangle which defines the overall bounds of imagery that can be produced by this layer.

##### Example:

```javascript
// Zoom to an imagery layer.
const imageryRectangle = imageryLayer.getImageryRectangle();
scene.camera.flyTo({
    destination: rectangle
});
```

#### [](#isBaseLayer) isBaseLayer() → boolean 

[engine/Source/Scene/ImageryLayer.js 626](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L626) 

 Gets a value indicating whether this layer is the base layer in the[ImageryLayerCollection](ImageryLayerCollection.html). The base layer is the one that underlies all others. It is special in that it is treated as if it has global rectangle, even if it actually does not, by stretching the texels at the edges over the entire globe.

##### Returns:

 true if this is the base layer; otherwise, false.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/ImageryLayer.js 640](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L640) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

 True if this object was destroyed; otherwise, false.

##### See:

* [ImageryLayer#destroy](ImageryLayer.html#destroy)

### Type Definitions

#### [](#.ConstructorOptions) Cesium.ImageryLayer.ConstructorOptions

[engine/Source/Scene/ImageryLayer.js 42](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L42) 

 Initialization options for the ImageryLayer constructor.

##### Properties:

| Name                  | Type                                                                 | Attributes | Default                           | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| --------------------- | -------------------------------------------------------------------- | ---------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| rectangle             | [Rectangle](Rectangle.html)                                          | <optional> | imageryProvider.rectangle         | The rectangle of the layer. This rectangle can limit the visible portion of the imagery provider.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| alpha                 | number\|function                                                     | <optional> | 1.0                               | The alpha blending value of this layer, from 0.0 to 1.0\. This can either be a simple number or a function with the signaturefunction(frameState, layer, x, y, level). The function is passed the current frame state, this layer, and the x, y, and level coordinates of the imagery tile for which the alpha is required, and it is expected to return the alpha value to use for the tile.                                                                                                                                                                                        |
| nightAlpha            | number\|function                                                     | <optional> | 1.0                               | The alpha blending value of this layer on the night side of the globe, from 0.0 to 1.0\. This can either be a simple number or a function with the signaturefunction(frameState, layer, x, y, level). The function is passed the current frame state, this layer, and the x, y, and level coordinates of the imagery tile for which the alpha is required, and it is expected to return the alpha value to use for the tile. This only takes effect when enableLighting is true.                                                                                                     |
| dayAlpha              | number\|function                                                     | <optional> | 1.0                               | The alpha blending value of this layer on the day side of the globe, from 0.0 to 1.0\. This can either be a simple number or a function with the signaturefunction(frameState, layer, x, y, level). The function is passed the current frame state, this layer, and the x, y, and level coordinates of the imagery tile for which the alpha is required, and it is expected to return the alpha value to use for the tile. This only takes effect when enableLighting is true.                                                                                                       |
| brightness            | number\|function                                                     | <optional> | 1.0                               | The brightness of this layer. 1.0 uses the unmodified imagery color. Less than 1.0 makes the imagery darker while greater than 1.0 makes it brighter. This can either be a simple number or a function with the signaturefunction(frameState, layer, x, y, level). The function is passed the current frame state, this layer, and the x, y, and level coordinates of the imagery tile for which the brightness is required, and it is expected to return the brightness value to use for the tile. The function is executed for every frame and for every tile, so it must be fast. |
| contrast              | number\|function                                                     | <optional> | 1.0                               | The contrast of this layer. 1.0 uses the unmodified imagery color. Less than 1.0 reduces the contrast while greater than 1.0 increases it. This can either be a simple number or a function with the signaturefunction(frameState, layer, x, y, level). The function is passed the current frame state, this layer, and the x, y, and level coordinates of the imagery tile for which the contrast is required, and it is expected to return the contrast value to use for the tile. The function is executed for every frame and for every tile, so it must be fast.                |
| hue                   | number\|function                                                     | <optional> | 0.0                               | The hue of this layer. 0.0 uses the unmodified imagery color. This can either be a simple number or a function with the signaturefunction(frameState, layer, x, y, level). The function is passed the current frame state, this layer, and the x, y, and level coordinates of the imagery tile for which the hue is required, and it is expected to return the contrast value to use for the tile. The function is executed for every frame and for every tile, so it must be fast.                                                                                                  |
| saturation            | number\|function                                                     | <optional> | 1.0                               | The saturation of this layer. 1.0 uses the unmodified imagery color. Less than 1.0 reduces the saturation while greater than 1.0 increases it. This can either be a simple number or a function with the signaturefunction(frameState, layer, x, y, level). The function is passed the current frame state, this layer, and the x, y, and level coordinates of the imagery tile for which the saturation is required, and it is expected to return the contrast value to use for the tile. The function is executed for every frame and for every tile, so it must be fast.          |
| gamma                 | number\|function                                                     | <optional> | 1.0                               | The gamma correction to apply to this layer. 1.0 uses the unmodified imagery color. This can either be a simple number or a function with the signaturefunction(frameState, layer, x, y, level). The function is passed the current frame state, this layer, and the x, y, and level coordinates of the imagery tile for which the gamma is required, and it is expected to return the gamma value to use for the tile. The function is executed for every frame and for every tile, so it must be fast.                                                                             |
| splitDirection        | [SplitDirection](global.html#SplitDirection)\|function               | <optional> | SplitDirection.NONE               | The [SplitDirection](global.html#SplitDirection) split to apply to this layer.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| minificationFilter    | [TextureMinificationFilter](global.html#TextureMinificationFilter)   | <optional> | TextureMinificationFilter.LINEAR  | The texture minification filter to apply to this layer. Possible values are TextureMinificationFilter.LINEAR andTextureMinificationFilter.NEAREST.                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| magnificationFilter   | [TextureMagnificationFilter](global.html#TextureMagnificationFilter) | <optional> | TextureMagnificationFilter.LINEAR | The texture minification filter to apply to this layer. Possible values are TextureMagnificationFilter.LINEAR andTextureMagnificationFilter.NEAREST.                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| show                  | boolean                                                              | <optional> | true                              | True if the layer is shown; otherwise, false.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| maximumAnisotropy     | number                                                               | <optional> | maximum supported                 | The maximum anisotropy level to use for texture filtering. If this parameter is not specified, the maximum anisotropy supported by the WebGL stack will be used. Larger values make the imagery look better in horizon views.                                                                                                                                                                                                                                                                                                                                                        |
| minimumTerrainLevel   | number                                                               | <optional> |                                   | The minimum terrain level-of-detail at which to show this imagery layer, or undefined to show it at all levels. Level zero is the least-detailed level.                                                                                                                                                                                                                                                                                                                                                                                                                              |
| maximumTerrainLevel   | number                                                               | <optional> |                                   | The maximum terrain level-of-detail at which to show this imagery layer, or undefined to show it at all levels. Level zero is the least-detailed level.                                                                                                                                                                                                                                                                                                                                                                                                                              |
| cutoutRectangle       | [Rectangle](Rectangle.html)                                          | <optional> |                                   | Cartographic rectangle for cutting out a portion of this ImageryLayer.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| colorToAlpha          | [Color](Color.html)                                                  | <optional> |                                   | Color to be used as alpha.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| colorToAlphaThreshold | number                                                               | <optional> | 0.004                             | Threshold for color-to-alpha.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |

#### [](#.ErrorEventCallback) Cesium.ImageryLayer.ErrorEventCallback(err) 

[engine/Source/Scene/ImageryLayer.js 1747](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L1747) 

 A function that is called when an error occurs.

##### This:

* [ImageryLayer](ImageryLayer.html)

| Name | Type  | Description                                              |
| ---- | ----- | -------------------------------------------------------- |
| err  | Error | An object holding details about the error that occurred. |

#### [](#.ReadyEventCallback) Cesium.ImageryLayer.ReadyEventCallback(provider) 

[engine/Source/Scene/ImageryLayer.js 1755](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L1755) 

 A function that is called when the provider has been created

##### This:

* [ImageryLayer](ImageryLayer.html)

| Name     | Type                                    | Description                   |
| -------- | --------------------------------------- | ----------------------------- |
| provider | [ImageryProvider](ImageryProvider.html) | The created imagery provider. |

#### [](#.WorldImageryConstructorOptions) Cesium.ImageryLayer.WorldImageryConstructorOptions

[engine/Source/Scene/ImageryLayer.js 561](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayer.js#L561) 

 Initialization options for ImageryLayer.fromWorldImagery

##### Properties:

| Name          | Type                                                     | Attributes | Default              | Description                                                                                     |
| ------------- | -------------------------------------------------------- | ---------- | -------------------- | ----------------------------------------------------------------------------------------------- |
| options.style | [IonWorldImageryStyle](global.html#IonWorldImageryStyle) | <optional> | IonWorldImageryStyle | The style of base imagery, only AERIAL, AERIAL\_WITH\_LABELS, and ROAD are currently supported. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

