# [![](Images/CesiumLogo.png)](index.html) BoxOutlineGeometry 

#### [](#BoxOutlineGeometry) new Cesium.BoxOutlineGeometry(options) 

[engine/Source/Core/BoxOutlineGeometry.js 37](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxOutlineGeometry.js#L37) 

 A description of the outline of a cube centered at the origin.

| Name    | Type   | Description                                                                                                                                                                                                                               |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description minimum [Cartesian3](Cartesian3.html)  The minimum x, y, and z coordinates of the box. maximum [Cartesian3](Cartesian3.html)  The maximum x, y, and z coordinates of the box. |

##### Example:

```javascript
const box = new Cesium.BoxOutlineGeometry({
  maximum : new Cesium.Cartesian3(250000.0, 250000.0, 250000.0),
  minimum : new Cesium.Cartesian3(-250000.0, -250000.0, -250000.0)
});
const geometry = Cesium.BoxOutlineGeometry.createGeometry(box);
```

##### See:

* [BoxOutlineGeometry.fromDimensions](BoxOutlineGeometry.html#.fromDimensions)
* [BoxOutlineGeometry.createGeometry](BoxOutlineGeometry.html#.createGeometry)
* [Packable](Packable.html)

### Members

#### [](#.packedLength) static Cesium.BoxOutlineGeometry.packedLength : number 

[engine/Source/Core/BoxOutlineGeometry.js 135](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxOutlineGeometry.js#L135) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.BoxOutlineGeometry.createGeometry(boxGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/BoxOutlineGeometry.js 215](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxOutlineGeometry.js#L215) 

 Computes the geometric representation of an outline of a box, including its vertices, indices, and a bounding sphere.

| Name        | Type                                          | Description                       |
| ----------- | --------------------------------------------- | --------------------------------- |
| boxGeometry | [BoxOutlineGeometry](BoxOutlineGeometry.html) | A description of the box outline. |

##### Returns:

 The computed vertices and indices.

#### [](#.fromAxisAlignedBoundingBox) static Cesium.BoxOutlineGeometry.fromAxisAlignedBoundingBox(boundingBox) → [BoxOutlineGeometry](BoxOutlineGeometry.html) 

[engine/Source/Core/BoxOutlineGeometry.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxOutlineGeometry.js#L120) 

 Creates an outline of a cube from the dimensions of an AxisAlignedBoundingBox.

| Name        | Type                                                  | Description                                  |
| ----------- | ----------------------------------------------------- | -------------------------------------------- |
| boundingBox | [AxisAlignedBoundingBox](AxisAlignedBoundingBox.html) | A description of the AxisAlignedBoundingBox. |

##### Returns:

##### Example:

```javascript
const aabb = Cesium.AxisAlignedBoundingBox.fromPoints(Cesium.Cartesian3.fromDegreesArray([
     -72.0, 40.0,
     -70.0, 35.0,
     -75.0, 30.0,
     -70.0, 30.0,
     -68.0, 40.0
]));
const box = Cesium.BoxOutlineGeometry.fromAxisAlignedBoundingBox(aabb);

 
```

##### See:

* [BoxOutlineGeometry.createGeometry](BoxOutlineGeometry.html#.createGeometry)

#### [](#.fromDimensions) static Cesium.BoxOutlineGeometry.fromDimensions(options) → [BoxOutlineGeometry](BoxOutlineGeometry.html) 

[engine/Source/Core/BoxOutlineGeometry.js 80](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxOutlineGeometry.js#L80) 

 Creates an outline of a cube centered at the origin given its dimensions.

| Name    | Type   | Description                                                                                                                                                                                                          |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description dimensions [Cartesian3](Cartesian3.html)  The width, depth, and height of the box stored in the x, y, and z coordinates of the Cartesian3, respectively. |

##### Returns:

##### Throws:

* [DeveloperError](DeveloperError.html): All dimensions components must be greater than or equal to zero.

##### Example:

```javascript
const box = Cesium.BoxOutlineGeometry.fromDimensions({
  dimensions : new Cesium.Cartesian3(500000.0, 500000.0, 500000.0)
});
const geometry = Cesium.BoxOutlineGeometry.createGeometry(box);
```

##### See:

* [BoxOutlineGeometry.createGeometry](BoxOutlineGeometry.html#.createGeometry)

#### [](#.pack) static Cesium.BoxOutlineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/BoxOutlineGeometry.js 146](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxOutlineGeometry.js#L146) 

 Stores the provided instance into the provided array.

| Name          | Type                                          | Default | Description                                                               |
| ------------- | --------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [BoxOutlineGeometry](BoxOutlineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                |         | The array to pack into.                                                   |
| startingIndex | number                                        | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.BoxOutlineGeometry.unpack(array, startingIndex, result) → [BoxOutlineGeometry](BoxOutlineGeometry.html) 

[engine/Source/Core/BoxOutlineGeometry.js 180](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/BoxOutlineGeometry.js#L180) 

 Retrieves an instance from a packed array.

| Name          | Type                                          | Default | Description                                                |
| ------------- | --------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                |         | The packed array.                                          |
| startingIndex | number                                        | 0       | optional The starting index of the element to be unpacked. |
| result        | [BoxOutlineGeometry](BoxOutlineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new BoxOutlineGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

