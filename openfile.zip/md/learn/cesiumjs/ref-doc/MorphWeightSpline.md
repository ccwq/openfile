# [![](Images/CesiumLogo.png)](index.html) MorphWeightSpline 

#### [](#MorphWeightSpline) new Cesium.MorphWeightSpline(options) 

[engine/Source/Core/MorphWeightSpline.js 42](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/MorphWeightSpline.js#L42) 

 A spline that linearly interpolates over an array of weight values used by morph targets.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description times Array.<number>  An array of strictly increasing, unit-less, floating-point times at each point. The values are in no way connected to the clock time. They are the parameterization for the curve. weights Array.<number>  The array of floating-point control weights given. The weights are ordered such that all weights for the targets are given in chronological order and order in which they appear in the glTF from which the morph targets come. This means for 2 targets, weights = \[w(0,0), w(0,1), w(1,0), w(1,1) ...\] where i and j in w(i,j) are the time indices and target indices, respectively. |

##### Throws:

* [DeveloperError](DeveloperError.html): weights.length must be greater than or equal to 2.
* [DeveloperError](DeveloperError.html): times.length must be a factor of weights.length.

##### Example:

```javascript
const times = [ 0.0, 1.5, 3.0, 4.5, 6.0 ];
const weights = [0.0, 1.0, 0.25, 0.75, 0.5, 0.5, 0.75, 0.25, 1.0, 0.0]; //Two targets
const spline = new Cesium.WeightSpline({
    times : times,
    weights : weights
});

const p0 = spline.evaluate(times[0]);
```

##### See:

* [ConstantSpline](ConstantSpline.html)
* [SteppedSpline](SteppedSpline.html)
* [LinearSpline](LinearSpline.html)
* [HermiteSpline](HermiteSpline.html)
* [CatmullRomSpline](CatmullRomSpline.html)
* [QuaternionSpline](QuaternionSpline.html)

### Methods

#### [](#clampTime) clampTime(time) → number 

[engine/Source/Core/MorphWeightSpline.js 127](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/MorphWeightSpline.js#L127) 

 Clamps the given time to the period covered by the spline.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The time, clamped to the animation period.

#### [](#evaluate) evaluate(time, result) → Array.<number> 

[engine/Source/Core/MorphWeightSpline.js 140](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/MorphWeightSpline.js#L140) 

 Evaluates the curve at a given time.

| Name   | Type           | Description                                         |
| ------ | -------------- | --------------------------------------------------- |
| time   | number         | The time at which to evaluate the curve.            |
| result | Array.<number> | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance of the point on the curve at the given time.

##### Throws:

* [DeveloperError](DeveloperError.html): time must be in the range `[t0, tn]`, where `t0` is the first element in the array `times` and `tn` is the last element in the array `times`.

#### [](#findTimeInterval) findTimeInterval(time) → number 

[engine/Source/Core/MorphWeightSpline.js 108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/MorphWeightSpline.js#L108) 

 Finds an index `i` in `times` such that the parameter`time` is in the interval `[times[i], times[i + 1]]`.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The index for the element at the start of the interval.

##### Throws:

* [DeveloperError](DeveloperError.html): time must be in the range `[t0, tn]`, where `t0` is the first element in the array `times` and `tn` is the last element in the array `times`.

#### [](#wrapTime) wrapTime(time) → number 

[engine/Source/Core/MorphWeightSpline.js 118](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/MorphWeightSpline.js#L118) 

 Wraps the given time to the period covered by the spline.

| Name | Type   | Description |
| ---- | ------ | ----------- |
| time | number | The time.   |

##### Returns:

 The time, wrapped around to the updated animation.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

