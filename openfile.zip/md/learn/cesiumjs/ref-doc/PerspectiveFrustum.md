# [![](Images/CesiumLogo.png)](index.html) PerspectiveFrustum 

#### [](#PerspectiveFrustum) new Cesium.PerspectiveFrustum(options) 

[engine/Source/Core/PerspectiveFrustum.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L35) 

 The viewing frustum is defined by 6 planes. Each plane is represented by a [Cartesian4](Cartesian4.html) object, where the x, y, and z components define the unit vector normal to the plane, and the w component is the distance of the plane from the origin/camera position.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional An object with the following properties: Name Type Default Description fov number optional The angle of the field of view (FOV), in radians. aspectRatio number optional The aspect ratio of the frustum's width to it's height. near number 1.0 optional The distance of the near plane. far number 500000000.0 optional The distance of the far plane. xOffset number 0.0 optional The offset in the x direction. yOffset number 0.0 optional The offset in the y direction. |

##### Example:

```javascript
const frustum = new Cesium.PerspectiveFrustum({
    fov : Cesium.Math.PI_OVER_THREE,
    aspectRatio : canvas.clientWidth / canvas.clientHeight
    near : 1.0,
    far : 1000.0
});
```

##### See:

* [PerspectiveOffCenterFrustum](PerspectiveOffCenterFrustum.html)

### Members

#### [](#.packedLength) static Cesium.PerspectiveFrustum.packedLength : number 

[engine/Source/Core/PerspectiveFrustum.js 98](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L98) 

 The number of elements used to pack the object into an array.

#### [](#aspectRatio) aspectRatio : number|undefined 

[engine/Source/Core/PerspectiveFrustum.js 58](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L58) 

 The aspect ratio of the frustum's width to it's height.

Default Value: `undefined` 

#### [](#far) far : number 

[engine/Source/Core/PerspectiveFrustum.js 74](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L74) 

 The distance of the far plane.

Default Value: `500000000.0` 

#### [](#fov) fov : number|undefined 

[engine/Source/Core/PerspectiveFrustum.js 47](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L47) 

 The angle of the field of view (FOV), in radians. This angle will be used as the horizontal FOV if the width is greater than the height, otherwise it will be the vertical FOV.

Default Value: `undefined` 

#### [](#fovy) readonly fovy : number|undefined 

[engine/Source/Core/PerspectiveFrustum.js 266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L266) 

 Gets the angle of the vertical field of view, in radians.

Default Value: `undefined` 

#### [](#infiniteProjectionMatrix) readonly infiniteProjectionMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Core/PerspectiveFrustum.js 252](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L252) 

 The perspective projection matrix computed from the view frustum with an infinite far plane.

##### See:

* [PerspectiveFrustum#projectionMatrix](PerspectiveFrustum.html#projectionMatrix)

#### [](#near) near : number 

[engine/Source/Core/PerspectiveFrustum.js 66](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L66) 

 The distance of the near plane.

Default Value: `1.0` 

#### [](#projectionMatrix) readonly projectionMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Core/PerspectiveFrustum.js 237](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L237) 

 Gets the perspective projection matrix computed from the view frustum. If necessary, the projection matrix will be recomputed.

##### See:

* PerspectiveOffCenterFrustum#projectionMatrix.
* [PerspectiveFrustum#infiniteProjectionMatrix](PerspectiveFrustum.html#infiniteProjectionMatrix)

#### [](#xOffset) xOffset : number 

[engine/Source/Core/PerspectiveFrustum.js 82](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L82) 

 Offsets the frustum in the x direction.

Default Value: `0.0` 

#### [](#yOffset) yOffset : number 

[engine/Source/Core/PerspectiveFrustum.js 90](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L90) 

 Offsets the frustum in the y direction.

Default Value: `0.0` 

### Methods

#### [](#.pack) static Cesium.PerspectiveFrustum.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/PerspectiveFrustum.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L109) 

 Stores the provided instance into the provided array.

| Name          | Type                                          | Default | Description                                                               |
| ------------- | --------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [PerspectiveFrustum](PerspectiveFrustum.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                |         | The array to pack into.                                                   |
| startingIndex | number                                        | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.PerspectiveFrustum.unpack(array, startingIndex, result) → [PerspectiveFrustum](PerspectiveFrustum.html) 

[engine/Source/Core/PerspectiveFrustum.js 135](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L135) 

 Retrieves an instance from a packed array.

| Name          | Type                                          | Default | Description                                                |
| ------------- | --------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                |         | The packed array.                                          |
| startingIndex | number                                        | 0       | optional The starting index of the element to be unpacked. |
| result        | [PerspectiveFrustum](PerspectiveFrustum.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new PerspectiveFrustum instance if one was not provided.

#### [](#clone) clone(result) → [PerspectiveFrustum](PerspectiveFrustum.html) 

[engine/Source/Core/PerspectiveFrustum.js 374](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L374) 

 Returns a duplicate of a PerspectiveFrustum instance.

| Name   | Type                                          | Description                                         |
| ------ | --------------------------------------------- | --------------------------------------------------- |
| result | [PerspectiveFrustum](PerspectiveFrustum.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new PerspectiveFrustum instance if one was not provided.

#### [](#computeCullingVolume) computeCullingVolume(position, direction, up) → [CullingVolume](CullingVolume.html) 

[engine/Source/Core/PerspectiveFrustum.js 312](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L312) 

 Creates a culling volume for this frustum.

| Name      | Type                          | Description         |
| --------- | ----------------------------- | ------------------- |
| position  | [Cartesian3](Cartesian3.html) | The eye position.   |
| direction | [Cartesian3](Cartesian3.html) | The view direction. |
| up        | [Cartesian3](Cartesian3.html) | The up direction.   |

##### Returns:

 A culling volume at the given position and orientation.

##### Example:

```javascript
// Check if a bounding volume intersects the frustum.
const cullingVolume = frustum.computeCullingVolume(cameraPosition, cameraDirection, cameraUp);
const intersect = cullingVolume.computeVisibility(boundingVolume);
```

#### [](#equals) equals(other) → boolean 

[engine/Source/Core/PerspectiveFrustum.js 402](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L402) 

 Compares the provided PerspectiveFrustum componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                          | Description                                      |
| ----- | --------------------------------------------- | ------------------------------------------------ |
| other | [PerspectiveFrustum](PerspectiveFrustum.html) | optional The right hand side PerspectiveFrustum. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(other, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/PerspectiveFrustum.js 427](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L427) 

 Compares the provided PerspectiveFrustum componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                                          | Default         | Description                                                          |
| --------------- | --------------------------------------------- | --------------- | -------------------------------------------------------------------- |
| other           | [PerspectiveFrustum](PerspectiveFrustum.html) |                 | The right hand side PerspectiveFrustum.                              |
| relativeEpsilon | number                                        |                 | The relative epsilon tolerance to use for equality testing.          |
| absoluteEpsilon | number                                        | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if this and other are within the provided epsilon, `false` otherwise.

#### [](#getPixelDimensions) getPixelDimensions(drawingBufferWidth, drawingBufferHeight, distance, pixelRatio, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/PerspectiveFrustum.js 351](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/PerspectiveFrustum.js#L351) 

 Returns the pixel's width and height in meters.

| Name                | Type                          | Description                                              |
| ------------------- | ----------------------------- | -------------------------------------------------------- |
| drawingBufferWidth  | number                        | The width of the drawing buffer.                         |
| drawingBufferHeight | number                        | The height of the drawing buffer.                        |
| distance            | number                        | The distance to the near plane in meters.                |
| pixelRatio          | number                        | The scaling factor from pixel space to coordinate space. |
| result              | [Cartesian2](Cartesian2.html) | The object onto which to store the result.               |

##### Returns:

 The modified result parameter or a new instance of [Cartesian2](Cartesian2.html) with the pixel's width and height in the x and y properties, respectively.

##### Throws:

* [DeveloperError](DeveloperError.html): drawingBufferWidth must be greater than zero.
* [DeveloperError](DeveloperError.html): drawingBufferHeight must be greater than zero.
* [DeveloperError](DeveloperError.html): pixelRatio must be greater than zero.

##### Examples:

```javascript
// Example 1
// Get the width and height of a pixel.
const pixelSize = camera.frustum.getPixelDimensions(scene.drawingBufferWidth, scene.drawingBufferHeight, 1.0, scene.pixelRatio, new Cesium.Cartesian2());
```

```javascript
// Example 2
// Get the width and height of a pixel if the near plane was set to 'distance'.
// For example, get the size of a pixel of an image on a billboard.
const position = camera.position;
const direction = camera.direction;
const toCenter = Cesium.Cartesian3.subtract(primitive.boundingVolume.center, position, new Cesium.Cartesian3());      // vector from camera to a primitive
const toCenterProj = Cesium.Cartesian3.multiplyByScalar(direction, Cesium.Cartesian3.dot(direction, toCenter), new Cesium.Cartesian3()); // project vector onto camera direction vector
const distance = Cesium.Cartesian3.magnitude(toCenterProj);
const pixelSize = camera.frustum.getPixelDimensions(scene.drawingBufferWidth, scene.drawingBufferHeight, distance, scene.pixelRatio, new Cesium.Cartesian2());
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

