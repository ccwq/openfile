# [![](Images/CesiumLogo.png)](index.html) Matrix4 

#### [](#Matrix4) new Cesium.Matrix4(column0Row0, column1Row0, column2Row0, column3Row0, column0Row1, column1Row1, column2Row1, column3Row1, column0Row2, column1Row2, column2Row2, column3Row2, column0Row3, column1Row3, column2Row3, column3Row3) 

[engine/Source/Core/Matrix4.js 56](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L56) 

 A 4x4 matrix, indexable as a column-major order array. Constructor parameters are in row-major order for code readability.

| Name        | Type   | Default | Description                             |
| ----------- | ------ | ------- | --------------------------------------- |
| column0Row0 | number | 0.0     | optional The value for column 0, row 0. |
| column1Row0 | number | 0.0     | optional The value for column 1, row 0. |
| column2Row0 | number | 0.0     | optional The value for column 2, row 0. |
| column3Row0 | number | 0.0     | optional The value for column 3, row 0. |
| column0Row1 | number | 0.0     | optional The value for column 0, row 1. |
| column1Row1 | number | 0.0     | optional The value for column 1, row 1. |
| column2Row1 | number | 0.0     | optional The value for column 2, row 1. |
| column3Row1 | number | 0.0     | optional The value for column 3, row 1. |
| column0Row2 | number | 0.0     | optional The value for column 0, row 2. |
| column1Row2 | number | 0.0     | optional The value for column 1, row 2. |
| column2Row2 | number | 0.0     | optional The value for column 2, row 2. |
| column3Row2 | number | 0.0     | optional The value for column 3, row 2. |
| column0Row3 | number | 0.0     | optional The value for column 0, row 3. |
| column1Row3 | number | 0.0     | optional The value for column 1, row 3. |
| column2Row3 | number | 0.0     | optional The value for column 2, row 3. |
| column3Row3 | number | 0.0     | optional The value for column 3, row 3. |

##### See:

* [Matrix4.fromArray](Matrix4.html#.fromArray)
* [Matrix4.fromColumnMajorArray](Matrix4.html#.fromColumnMajorArray)
* [Matrix4.fromRowMajorArray](Matrix4.html#.fromRowMajorArray)
* [Matrix4.fromRotationTranslation](Matrix4.html#.fromRotationTranslation)
* [Matrix4.fromTranslationQuaternionRotationScale](Matrix4.html#.fromTranslationQuaternionRotationScale)
* [Matrix4.fromTranslationRotationScale](Matrix4.html#.fromTranslationRotationScale)
* [Matrix4.fromTranslation](Matrix4.html#.fromTranslation)
* [Matrix4.fromScale](Matrix4.html#.fromScale)
* [Matrix4.fromUniformScale](Matrix4.html#.fromUniformScale)
* [Matrix4.fromRotation](Matrix4.html#.fromRotation)
* [Matrix4.fromCamera](Matrix4.html#.fromCamera)
* [Matrix4.computePerspectiveFieldOfView](Matrix4.html#.computePerspectiveFieldOfView)
* [Matrix4.computeOrthographicOffCenter](Matrix4.html#.computeOrthographicOffCenter)
* [Matrix4.computePerspectiveOffCenter](Matrix4.html#.computePerspectiveOffCenter)
* [Matrix4.computeInfinitePerspectiveOffCenter](Matrix4.html#.computeInfinitePerspectiveOffCenter)
* [Matrix4.computeViewportTransformation](Matrix4.html#.computeViewportTransformation)
* [Matrix4.computeView](Matrix4.html#.computeView)
* [Matrix2](Matrix2.html)
* [Matrix3](Matrix3.html)
* [Packable](Packable.html)

### Members

#### [](#length) length : number 

[engine/Source/Core/Matrix4.js 3154](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3154) 

 Gets the number of items in the collection.

#### [](#.COLUMN0ROW0) static constant Cesium.Matrix4.COLUMN0ROW0 : number 

[engine/Source/Core/Matrix4.js 3025](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3025) 

 The index into Matrix4 for column 0, row 0.

#### [](#.COLUMN0ROW1) static constant Cesium.Matrix4.COLUMN0ROW1 : number 

[engine/Source/Core/Matrix4.js 3033](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3033) 

 The index into Matrix4 for column 0, row 1.

#### [](#.COLUMN0ROW2) static constant Cesium.Matrix4.COLUMN0ROW2 : number 

[engine/Source/Core/Matrix4.js 3041](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3041) 

 The index into Matrix4 for column 0, row 2.

#### [](#.COLUMN0ROW3) static constant Cesium.Matrix4.COLUMN0ROW3 : number 

[engine/Source/Core/Matrix4.js 3049](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3049) 

 The index into Matrix4 for column 0, row 3.

#### [](#.COLUMN1ROW0) static constant Cesium.Matrix4.COLUMN1ROW0 : number 

[engine/Source/Core/Matrix4.js 3057](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3057) 

 The index into Matrix4 for column 1, row 0.

#### [](#.COLUMN1ROW1) static constant Cesium.Matrix4.COLUMN1ROW1 : number 

[engine/Source/Core/Matrix4.js 3065](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3065) 

 The index into Matrix4 for column 1, row 1.

#### [](#.COLUMN1ROW2) static constant Cesium.Matrix4.COLUMN1ROW2 : number 

[engine/Source/Core/Matrix4.js 3073](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3073) 

 The index into Matrix4 for column 1, row 2.

#### [](#.COLUMN1ROW3) static constant Cesium.Matrix4.COLUMN1ROW3 : number 

[engine/Source/Core/Matrix4.js 3081](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3081) 

 The index into Matrix4 for column 1, row 3.

#### [](#.COLUMN2ROW0) static constant Cesium.Matrix4.COLUMN2ROW0 : number 

[engine/Source/Core/Matrix4.js 3089](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3089) 

 The index into Matrix4 for column 2, row 0.

#### [](#.COLUMN2ROW1) static constant Cesium.Matrix4.COLUMN2ROW1 : number 

[engine/Source/Core/Matrix4.js 3097](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3097) 

 The index into Matrix4 for column 2, row 1.

#### [](#.COLUMN2ROW2) static constant Cesium.Matrix4.COLUMN2ROW2 : number 

[engine/Source/Core/Matrix4.js 3105](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3105) 

 The index into Matrix4 for column 2, row 2.

#### [](#.COLUMN2ROW3) static constant Cesium.Matrix4.COLUMN2ROW3 : number 

[engine/Source/Core/Matrix4.js 3113](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3113) 

 The index into Matrix4 for column 2, row 3.

#### [](#.COLUMN3ROW0) static constant Cesium.Matrix4.COLUMN3ROW0 : number 

[engine/Source/Core/Matrix4.js 3121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3121) 

 The index into Matrix4 for column 3, row 0.

#### [](#.COLUMN3ROW1) static constant Cesium.Matrix4.COLUMN3ROW1 : number 

[engine/Source/Core/Matrix4.js 3129](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3129) 

 The index into Matrix4 for column 3, row 1.

#### [](#.COLUMN3ROW2) static constant Cesium.Matrix4.COLUMN3ROW2 : number 

[engine/Source/Core/Matrix4.js 3137](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3137) 

 The index into Matrix4 for column 3, row 2.

#### [](#.COLUMN3ROW3) static constant Cesium.Matrix4.COLUMN3ROW3 : number 

[engine/Source/Core/Matrix4.js 3145](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3145) 

 The index into Matrix4 for column 3, row 3.

#### [](#.IDENTITY) static constant Cesium.Matrix4.IDENTITY : [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2971](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2971) 

 An immutable Matrix4 instance initialized to the identity matrix.

#### [](#.packedLength) static Cesium.Matrix4.packedLength : number 

[engine/Source/Core/Matrix4.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L96) 

 The number of elements used to pack the object into an array.

#### [](#.ZERO) static constant Cesium.Matrix4.ZERO : [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2998](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2998) 

 An immutable Matrix4 instance initialized to the zero matrix.

### Methods

#### [](#clone) clone(result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 3167](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3167) 

 Duplicates the provided Matrix4 instance.

| Name   | Type                    | Description                                         |
| ------ | ----------------------- | --------------------------------------------------- |
| result | [Matrix4](Matrix4.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Matrix4 instance if one was not provided.

#### [](#equals) equals(right) → boolean 

[engine/Source/Core/Matrix4.js 3178](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3178) 

 Compares this matrix to the provided matrix componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                    | Description                          |
| ----- | ----------------------- | ------------------------------------ |
| right | [Matrix4](Matrix4.html) | optional The right hand side matrix. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(right, epsilon) → boolean 

[engine/Source/Core/Matrix4.js 3215](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3215) 

 Compares this matrix to the provided matrix componentwise and returns`true` if they are within the provided epsilon,`false` otherwise.

| Name    | Type                    | Default | Description                                       |
| ------- | ----------------------- | ------- | ------------------------------------------------- |
| right   | [Matrix4](Matrix4.html) |         | optional The right hand side matrix.              |
| epsilon | number                  | 0       | optional The epsilon to use for equality testing. |

##### Returns:

`true` if they are within the provided epsilon, `false` otherwise.

#### [](#toString) toString() → string 

[engine/Source/Core/Matrix4.js 3225](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L3225) 

 Computes a string representing this Matrix with each row being on a separate line and in the format '(column0, column1, column2, column3)'.

##### Returns:

 A string representing the provided Matrix with each row being on a separate line and in the format '(column0, column1, column2, column3)'.

#### [](#.abs) static Cesium.Matrix4.abs(matrix, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2462](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2462) 

 Computes a matrix, which contains the absolute (unsigned) values of the provided matrix's elements.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html) | The matrix with signed elements.           |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.add) static Cesium.Matrix4.add(left, right, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1820](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1820) 

 Computes the sum of two matrices.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| left   | [Matrix4](Matrix4.html) | The first matrix.                          |
| right  | [Matrix4](Matrix4.html) | The second matrix.                         |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.clone) static Cesium.Matrix4.clone(matrix, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 243](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L243) 

 Duplicates a Matrix4 instance.

| Name   | Type                    | Description                                         |
| ------ | ----------------------- | --------------------------------------------------- |
| matrix | [Matrix4](Matrix4.html) | The matrix to duplicate.                            |
| result | [Matrix4](Matrix4.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Matrix4 instance if one was not provided. (Returns undefined if matrix is undefined)

#### [](#.computeInfinitePerspectiveOffCenter) static Cesium.Matrix4.computeInfinitePerspectiveOffCenter(left, right, bottom, top, near, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1004](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1004) 

 Computes a Matrix4 instance representing an infinite off center perspective transformation.

| Name   | Type                    | Description                                                           |
| ------ | ----------------------- | --------------------------------------------------------------------- |
| left   | number                  | The number of meters to the left of the camera that will be in view.  |
| right  | number                  | The number of meters to the right of the camera that will be in view. |
| bottom | number                  | The number of meters below of the camera that will be in view.        |
| top    | number                  | The number of meters above of the camera that will be in view.        |
| near   | number                  | The distance to the near plane in meters.                             |
| result | [Matrix4](Matrix4.html) | The object in which the result will be stored.                        |

##### Returns:

 The modified result parameter.

#### [](#.computeOrthographicOffCenter) static Cesium.Matrix4.computeOrthographicOffCenter(left, right, bottom, top, near, far, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 886](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L886) 

 Computes a Matrix4 instance representing an orthographic transformation matrix.

| Name   | Type                    | Description                                                           |
| ------ | ----------------------- | --------------------------------------------------------------------- |
| left   | number                  | The number of meters to the left of the camera that will be in view.  |
| right  | number                  | The number of meters to the right of the camera that will be in view. |
| bottom | number                  | The number of meters below of the camera that will be in view.        |
| top    | number                  | The number of meters above of the camera that will be in view.        |
| near   | number                  | The distance to the near plane in meters.                             |
| far    | number                  | The distance to the far plane in meters.                              |
| result | [Matrix4](Matrix4.html) | The object in which the result will be stored.                        |

##### Returns:

 The modified result parameter.

#### [](#.computePerspectiveFieldOfView) static Cesium.Matrix4.computePerspectiveFieldOfView(fovY, aspectRatio, near, far, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 833](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L833) 

 Computes a Matrix4 instance representing a perspective transformation matrix.

| Name        | Type                    | Description                                    |
| ----------- | ----------------------- | ---------------------------------------------- |
| fovY        | number                  | The field of view along the Y axis in radians. |
| aspectRatio | number                  | The aspect ratio.                              |
| near        | number                  | The distance to the near plane in meters.      |
| far         | number                  | The distance to the far plane in meters.       |
| result      | [Matrix4](Matrix4.html) | The object in which the result will be stored. |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): fovY must be in (0, PI\].
* [DeveloperError](DeveloperError.html): aspectRatio must be greater than zero.
* [DeveloperError](DeveloperError.html): near must be greater than zero.
* [DeveloperError](DeveloperError.html): far must be greater than zero.

#### [](#.computePerspectiveOffCenter) static Cesium.Matrix4.computePerspectiveOffCenter(left, right, bottom, top, near, far, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 947](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L947) 

 Computes a Matrix4 instance representing an off center perspective transformation.

| Name   | Type                    | Description                                                           |
| ------ | ----------------------- | --------------------------------------------------------------------- |
| left   | number                  | The number of meters to the left of the camera that will be in view.  |
| right  | number                  | The number of meters to the right of the camera that will be in view. |
| bottom | number                  | The number of meters below the camera that will be in view.           |
| top    | number                  | The number of meters above the camera that will be in view.           |
| near   | number                  | The distance to the near plane in meters.                             |
| far    | number                  | The distance to the far plane in meters.                              |
| result | [Matrix4](Matrix4.html) | The object in which the result will be stored.                        |

##### Returns:

 The modified result parameter.

#### [](#.computeView) static Cesium.Matrix4.computeView(position, direction, up, right, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1126](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1126) 

 Computes a Matrix4 instance that transforms from world space to view space.

| Name      | Type                          | Description                                    |
| --------- | ----------------------------- | ---------------------------------------------- |
| position  | [Cartesian3](Cartesian3.html) | The position of the camera.                    |
| direction | [Cartesian3](Cartesian3.html) | The forward direction.                         |
| up        | [Cartesian3](Cartesian3.html) | The up direction.                              |
| right     | [Cartesian3](Cartesian3.html) | The right direction.                           |
| result    | [Matrix4](Matrix4.html)       | The object in which the result will be stored. |

##### Returns:

 The modified result parameter.

#### [](#.computeViewportTransformation) static Cesium.Matrix4.computeViewportTransformation(viewport, nearDepthRange, farDepthRange, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1066](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1066) 

 Computes a Matrix4 instance that transforms from normalized device coordinates to window coordinates.

| Name           | Type                    | Default                                         | Description                                             |
| -------------- | ----------------------- | ----------------------------------------------- | ------------------------------------------------------- |
| viewport       | object                  | { x : 0.0, y : 0.0, width : 0.0, height : 0.0 } | optional The viewport's corners as shown in Example 1.  |
| nearDepthRange | number                  | 0.0                                             | optional The near plane distance in window coordinates. |
| farDepthRange  | number                  | 1.0                                             | optional The far plane distance in window coordinates.  |
| result         | [Matrix4](Matrix4.html) |                                                 | optional The object in which the result will be stored. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
// Create viewport transformation using an explicit viewport and depth range.
const m = Cesium.Matrix4.computeViewportTransformation({
    x : 0.0,
    y : 0.0,
    width : 1024.0,
    height : 768.0
}, 0.0, 1.0, new Cesium.Matrix4());
```

#### [](#.equals) static Cesium.Matrix4.equals(left, right) → boolean 

[engine/Source/Core/Matrix4.js 2517](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2517) 

 Compares the provided matrices componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                    | Description                 |
| ----- | ----------------------- | --------------------------- |
| left  | [Matrix4](Matrix4.html) | optional The first matrix.  |
| right | [Matrix4](Matrix4.html) | optional The second matrix. |

##### Returns:

`true` if left and right are equal, `false` otherwise.

##### Example:

```javascript
//compares two Matrix4 instances

// a = [10.0, 14.0, 18.0, 22.0]
//     [11.0, 15.0, 19.0, 23.0]
//     [12.0, 16.0, 20.0, 24.0]
//     [13.0, 17.0, 21.0, 25.0]

// b = [10.0, 14.0, 18.0, 22.0]
//     [11.0, 15.0, 19.0, 23.0]
//     [12.0, 16.0, 20.0, 24.0]
//     [13.0, 17.0, 21.0, 25.0]

if(Cesium.Matrix4.equals(a,b)) {
     console.log("Both matrices are equal");
} else {
     console.log("They are not equal");
}

//Prints "Both matrices are equal" on the console
```

#### [](#.equalsEpsilon) static Cesium.Matrix4.equalsEpsilon(left, right, epsilon) → boolean 

[engine/Source/Core/Matrix4.js 2579](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2579) 

 Compares the provided matrices componentwise and returns`true` if they are within the provided epsilon,`false` otherwise.

| Name    | Type                    | Default | Description                                       |
| ------- | ----------------------- | ------- | ------------------------------------------------- |
| left    | [Matrix4](Matrix4.html) |         | optional The first matrix.                        |
| right   | [Matrix4](Matrix4.html) |         | optional The second matrix.                       |
| epsilon | number                  | 0       | optional The epsilon to use for equality testing. |

##### Returns:

`true` if left and right are within the provided epsilon, `false` otherwise.

##### Example:

```javascript
//compares two Matrix4 instances

// a = [10.5, 14.5, 18.5, 22.5]
//     [11.5, 15.5, 19.5, 23.5]
//     [12.5, 16.5, 20.5, 24.5]
//     [13.5, 17.5, 21.5, 25.5]

// b = [10.0, 14.0, 18.0, 22.0]
//     [11.0, 15.0, 19.0, 23.0]
//     [12.0, 16.0, 20.0, 24.0]
//     [13.0, 17.0, 21.0, 25.0]

if(Cesium.Matrix4.equalsEpsilon(a,b,0.1)){
     console.log("Difference between both the matrices is less than 0.1");
} else {
     console.log("Difference between both the matrices is not less than 0.1");
}

//Prints "Difference between both the matrices is not less than 0.1" on the console
```

#### [](#.fromArray) static Cesium.Matrix4.fromArray(array, startingIndex, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 309](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L309) 

 Creates a Matrix4 from 16 consecutive elements in an array.

| Name          | Type                    | Default | Description                                                                                                                  |
| ------------- | ----------------------- | ------- | ---------------------------------------------------------------------------------------------------------------------------- |
| array         | Array.<number>          |         | The array whose 16 consecutive elements correspond to the positions of the matrix. Assumes column-major order.               |
| startingIndex | number                  | 0       | optional The offset into the array of the first element, which corresponds to first column first row position in the matrix. |
| result        | [Matrix4](Matrix4.html) |         | optional The object onto which to store the result.                                                                          |

##### Returns:

 The modified result parameter or a new Matrix4 instance if one was not provided.

##### Example:

```javascript
// Create the Matrix4:
// [1.0, 2.0, 3.0, 4.0]
// [1.0, 2.0, 3.0, 4.0]
// [1.0, 2.0, 3.0, 4.0]
// [1.0, 2.0, 3.0, 4.0]

const v = [1.0, 1.0, 1.0, 1.0, 2.0, 2.0, 2.0, 2.0, 3.0, 3.0, 3.0, 3.0, 4.0, 4.0, 4.0, 4.0];
const m = Cesium.Matrix4.fromArray(v);

// Create same Matrix4 with using an offset into an array
const v2 = [0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 2.0, 2.0, 2.0, 2.0, 3.0, 3.0, 3.0, 3.0, 4.0, 4.0, 4.0, 4.0];
const m2 = Cesium.Matrix4.fromArray(v2, 2);
```

#### [](#.fromCamera) static Cesium.Matrix4.fromCamera(camera, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 723](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L723) 

 Computes a Matrix4 instance from a Camera.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| camera | [Camera](Camera.html)   | The camera to use.                                                                                   |
| result | [Matrix4](Matrix4.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix4 instance if one was not provided.

#### [](#.fromColumnMajorArray) static Cesium.Matrix4.fromColumnMajorArray(values, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 318](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L318) 

 Computes a Matrix4 instance from a column-major order array.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| values | Array.<number>          | The column-major order array.                                                                        |
| result | [Matrix4](Matrix4.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix4 instance if one was not provided.

#### [](#.fromRotation) static Cesium.Matrix4.fromRotation(rotation, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 681](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L681) 

 Creates a rotation matrix.

| Name     | Type                    | Description                                                                                          |
| -------- | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| rotation | [Matrix3](Matrix3.html) | The rotation matrix.                                                                                 |
| result   | [Matrix4](Matrix4.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix4 instance if one was not provided.

#### [](#.fromRotationTranslation) static Cesium.Matrix4.fromRotationTranslation(rotation, translation, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 387](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L387) 

 Computes a Matrix4 instance from a Matrix3 representing the rotation and a Cartesian3 representing the translation.

| Name        | Type                          | Default         | Description                                                                                          |
| ----------- | ----------------------------- | --------------- | ---------------------------------------------------------------------------------------------------- |
| rotation    | [Matrix3](Matrix3.html)       |                 | The upper left portion of the matrix representing the rotation.                                      |
| translation | [Cartesian3](Cartesian3.html) | Cartesian3.ZERO | optional The upper right portion of the matrix representing the translation.                         |
| result      | [Matrix4](Matrix4.html)       |                 | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix4 instance if one was not provided.

#### [](#.fromRowMajorArray) static Cesium.Matrix4.fromRowMajorArray(values, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 334](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L334) 

 Computes a Matrix4 instance from a row-major order array. The resulting matrix will be in column-major order.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| values | Array.<number>          | The row-major order array.                                                                           |
| result | [Matrix4](Matrix4.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix4 instance if one was not provided.

#### [](#.fromScale) static Cesium.Matrix4.fromScale(scale, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 569](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L569) 

 Computes a Matrix4 instance representing a non-uniform scale.

| Name   | Type                          | Description                                                                                          |
| ------ | ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| scale  | [Cartesian3](Cartesian3.html) | The x, y, and z scale factors.                                                                       |
| result | [Matrix4](Matrix4.html)       | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix4 instance if one was not provided.

##### Example:

```javascript
// Creates
//   [7.0, 0.0, 0.0, 0.0]
//   [0.0, 8.0, 0.0, 0.0]
//   [0.0, 0.0, 9.0, 0.0]
//   [0.0, 0.0, 0.0, 1.0]
const m = Cesium.Matrix4.fromScale(new Cesium.Cartesian3(7.0, 8.0, 9.0));
```

#### [](#.fromTranslation) static Cesium.Matrix4.fromTranslation(translation, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 546](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L546) 

 Creates a Matrix4 instance from a Cartesian3 representing the translation.

| Name        | Type                          | Description                                                                                          |
| ----------- | ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| translation | [Cartesian3](Cartesian3.html) | The upper right portion of the matrix representing the translation.                                  |
| result      | [Matrix4](Matrix4.html)       | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix4 instance if one was not provided.

##### See:

* [Matrix4.multiplyByTranslation](Matrix4.html#.multiplyByTranslation)

#### [](#.fromTranslationQuaternionRotationScale) static Cesium.Matrix4.fromTranslationQuaternionRotationScale(translation, rotation, scale, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 451](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L451) 

 Computes a Matrix4 instance from a translation, rotation, and scale (TRS) representation with the rotation represented as a quaternion.

| Name        | Type                          | Description                                                                                          |
| ----------- | ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| translation | [Cartesian3](Cartesian3.html) | The translation transformation.                                                                      |
| rotation    | [Quaternion](Quaternion.html) | The rotation transformation.                                                                         |
| scale       | [Cartesian3](Cartesian3.html) | The non-uniform scale transformation.                                                                |
| result      | [Matrix4](Matrix4.html)       | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix4 instance if one was not provided.

##### Example:

```javascript
const result = Cesium.Matrix4.fromTranslationQuaternionRotationScale(
  new Cesium.Cartesian3(1.0, 2.0, 3.0), // translation
  Cesium.Quaternion.IDENTITY,           // rotation
  new Cesium.Cartesian3(7.0, 8.0, 9.0), // scale
  result);
```

#### [](#.fromTranslationRotationScale) static Cesium.Matrix4.fromTranslationRotationScale(translationRotationScale, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 521](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L521) 

 Creates a Matrix4 instance from a [TranslationRotationScale](TranslationRotationScale.html) instance.

| Name                     | Type                                                      | Description                                                                                          |
| ------------------------ | --------------------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| translationRotationScale | [TranslationRotationScale](TranslationRotationScale.html) | The instance.                                                                                        |
| result                   | [Matrix4](Matrix4.html)                                   | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix4 instance if one was not provided.

#### [](#.fromUniformScale) static Cesium.Matrix4.fromUniformScale(scale, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 629](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L629) 

 Computes a Matrix4 instance representing a uniform scale.

| Name   | Type                    | Description                                                                                          |
| ------ | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| scale  | number                  | The uniform scale factor.                                                                            |
| result | [Matrix4](Matrix4.html) | optional The object in which the result will be stored, if undefined a new instance will be created. |

##### Returns:

 The modified result parameter, or a new Matrix4 instance if one was not provided.

##### Example:

```javascript
// Creates
//   [2.0, 0.0, 0.0, 0.0]
//   [0.0, 2.0, 0.0, 0.0]
//   [0.0, 0.0, 2.0, 0.0]
//   [0.0, 0.0, 0.0, 1.0]
const m = Cesium.Matrix4.fromUniformScale(2.0);
```

#### [](#.getColumn) static Cesium.Matrix4.getColumn(matrix, index, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Matrix4.js 1272](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1272) 

 Retrieves a copy of the matrix column at the provided index as a Cartesian4 instance.

| Name   | Type                          | Description                                     |
| ------ | ----------------------------- | ----------------------------------------------- |
| matrix | [Matrix4](Matrix4.html)       | The matrix to use.                              |
| index  | number                        | The zero-based index of the column to retrieve. |
| result | [Cartesian4](Cartesian4.html) | The object onto which to store the result.      |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0, 1, 2, or 3.

##### Examples:

```javascript
//returns a Cartesian4 instance with values from the specified column
// m = [10.0, 11.0, 12.0, 13.0]
//     [14.0, 15.0, 16.0, 17.0]
//     [18.0, 19.0, 20.0, 21.0]
//     [22.0, 23.0, 24.0, 25.0]

//Example 1: Creates an instance of Cartesian
const a = Cesium.Matrix4.getColumn(m, 2, new Cesium.Cartesian4());
```

```javascript
//Example 2: Sets values for Cartesian instance
const a = new Cesium.Cartesian4();
Cesium.Matrix4.getColumn(m, 2, a);

// a.x = 12.0; a.y = 16.0; a.z = 20.0; a.w = 24.0;
```

#### [](#.getElementIndex) static Cesium.Matrix4.getElementIndex(row, column) → number 

[engine/Source/Core/Matrix4.js 1233](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1233) 

 Computes the array index of the element at the provided row and column.

| Name   | Type   | Description                         |
| ------ | ------ | ----------------------------------- |
| row    | number | The zero-based index of the row.    |
| column | number | The zero-based index of the column. |

##### Returns:

 The index of the element at the provided row and column.

##### Throws:

* [DeveloperError](DeveloperError.html): row must be 0, 1, 2, or 3.
* [DeveloperError](DeveloperError.html): column must be 0, 1, 2, or 3.

##### Example:

```javascript
const myMatrix = new Cesium.Matrix4();
const column1Row0Index = Cesium.Matrix4.getElementIndex(1, 0);
const column1Row0 = myMatrix[column1Row0Index];
myMatrix[column1Row0Index] = 10.0;
```

#### [](#.getMatrix3) static Cesium.Matrix4.getMatrix3(matrix, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix4.js 2646](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2646) 

 Gets the upper left 3x3 matrix of the provided matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html) | The matrix to use.                         |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
// returns a Matrix3 instance from a Matrix4 instance

// m = [10.0, 14.0, 18.0, 22.0]
//     [11.0, 15.0, 19.0, 23.0]
//     [12.0, 16.0, 20.0, 24.0]
//     [13.0, 17.0, 21.0, 25.0]

const b = new Cesium.Matrix3();
Cesium.Matrix4.getMatrix3(m,b);

// b = [10.0, 14.0, 18.0]
//     [11.0, 15.0, 19.0]
//     [12.0, 16.0, 20.0]
```

#### [](#.getMaximumScale) static Cesium.Matrix4.getMaximumScale(matrix) → number 

[engine/Source/Core/Matrix4.js 1624](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1624) 

 Computes the maximum scale assuming the matrix is an affine transformation. The maximum scale is the maximum length of the column vectors in the upper-left 3x3 matrix.

| Name   | Type                    | Description |
| ------ | ----------------------- | ----------- |
| matrix | [Matrix4](Matrix4.html) | The matrix. |

##### Returns:

 The maximum scale.

#### [](#.getRotation) static Cesium.Matrix4.getRotation(matrix, result) → [Matrix3](Matrix3.html) 

[engine/Source/Core/Matrix4.js 1685](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1685) 

 Extracts the rotation matrix assuming the matrix is an affine transformation.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html) | The matrix.                                |
| result | [Matrix3](Matrix3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix4.setRotation](Matrix4.html#.setRotation)
* [Matrix4.fromRotation](Matrix4.html#.fromRotation)

#### [](#.getRow) static Cesium.Matrix4.getRow(matrix, index, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Matrix4.js 1368](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1368) 

 Retrieves a copy of the matrix row at the provided index as a Cartesian4 instance.

| Name   | Type                          | Description                                  |
| ------ | ----------------------------- | -------------------------------------------- |
| matrix | [Matrix4](Matrix4.html)       | The matrix to use.                           |
| index  | number                        | The zero-based index of the row to retrieve. |
| result | [Cartesian4](Cartesian4.html) | The object onto which to store the result.   |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0, 1, 2, or 3.

##### Examples:

```javascript
//returns a Cartesian4 instance with values from the specified column
// m = [10.0, 11.0, 12.0, 13.0]
//     [14.0, 15.0, 16.0, 17.0]
//     [18.0, 19.0, 20.0, 21.0]
//     [22.0, 23.0, 24.0, 25.0]

//Example 1: Returns an instance of Cartesian
const a = Cesium.Matrix4.getRow(m, 2, new Cesium.Cartesian4());
```

```javascript
//Example 2: Sets values for a Cartesian instance
const a = new Cesium.Cartesian4();
Cesium.Matrix4.getRow(m, 2, a);

// a.x = 18.0; a.y = 19.0; a.z = 20.0; a.w = 21.0;
```

#### [](#.getScale) static Cesium.Matrix4.getScale(matrix, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Matrix4.js 1596](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1596) 

 Extracts the non-uniform scale assuming the matrix is an affine transformation.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html)       | The matrix.                                |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter

##### See:

* [Matrix4.multiplyByScale](Matrix4.html#.multiplyByScale)
* [Matrix4.multiplyByUniformScale](Matrix4.html#.multiplyByUniformScale)
* [Matrix4.fromScale](Matrix4.html#.fromScale)
* [Matrix4.fromUniformScale](Matrix4.html#.fromUniformScale)
* [Matrix4.setScale](Matrix4.html#.setScale)
* [Matrix4.setUniformScale](Matrix4.html#.setUniformScale)

#### [](#.getTranslation) static Cesium.Matrix4.getTranslation(matrix, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Matrix4.js 2612](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2612) 

 Gets the translation portion of the provided matrix, assuming the matrix is an affine transformation matrix.

| Name   | Type                          | Description                                |
| ------ | ----------------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html)       | The matrix to use.                         |
| result | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.inverse) static Cesium.Matrix4.inverse(matrix, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2681](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2681) 

 Computes the inverse of the provided matrix using Cramers Rule. If the determinant is zero, the matrix can not be inverted, and an exception is thrown. If the matrix is a proper rigid transformation, it is more efficient to invert it with [Matrix4.inverseTransformation](Matrix4.html#.inverseTransformation).

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html) | The matrix to invert.                      |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Throws:

* [RuntimeError](RuntimeError.html): matrix is not invertible because its determinate is zero.

#### [](#.inverseTransformation) static Cesium.Matrix4.inverseTransformation(matrix, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2895](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2895) 

 Computes the inverse of the provided matrix assuming it is a proper rigid matrix, where the upper left 3x3 elements are a rotation matrix, and the upper three elements in the fourth column are the translation. The bottom row is assumed to be \[0, 0, 0, 1\]. The matrix is not verified to be in the proper form. This method is faster than computing the inverse for a general 4x4 matrix using [Matrix4.inverse](Matrix4.html#.inverse).

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html) | The matrix to invert.                      |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.inverseTranspose) static Cesium.Matrix4.inverseTranspose(matrix, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2953](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2953) 

 Computes the inverse transpose of a matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html) | The matrix to transpose and invert.        |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiply) static Cesium.Matrix4.multiply(left, right, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1716](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1716) 

 Computes the product of two matrices.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| left   | [Matrix4](Matrix4.html) | The first matrix.                          |
| right  | [Matrix4](Matrix4.html) | The second matrix.                         |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiplyByMatrix3) static Cesium.Matrix4.multiplyByMatrix3(matrix, rotation, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1984](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1984) 

 Multiplies a transformation matrix (with a bottom row of `[0.0, 0.0, 0.0, 1.0]`) by a 3x3 rotation matrix. This is an optimization for `Matrix4.multiply(m, Matrix4.fromRotationTranslation(rotation), m);` with less allocations and arithmetic operations.

| Name     | Type                    | Description                                     |
| -------- | ----------------------- | ----------------------------------------------- |
| matrix   | [Matrix4](Matrix4.html) | The matrix on the left-hand side.               |
| rotation | [Matrix3](Matrix3.html) | The 3x3 rotation matrix on the right-hand side. |
| result   | [Matrix4](Matrix4.html) | The object onto which to store the result.      |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
// Instead of Cesium.Matrix4.multiply(m, Cesium.Matrix4.fromRotationTranslation(rotation), m);
Cesium.Matrix4.multiplyByMatrix3(m, rotation, m);
```

#### [](#.multiplyByPoint) static Cesium.Matrix4.multiplyByPoint(matrix, cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Matrix4.js 2284](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2284) 

 Computes the product of a matrix and a [Cartesian3](Cartesian3.html). This is equivalent to calling [Matrix4.multiplyByVector](Matrix4.html#.multiplyByVector)with a [Cartesian4](Cartesian4.html) with a `w` component of 1, but returns a [Cartesian3](Cartesian3.html) instead of a [Cartesian4](Cartesian4.html).

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| matrix    | [Matrix4](Matrix4.html)       | The matrix.                                |
| cartesian | [Cartesian3](Cartesian3.html) | The point.                                 |
| result    | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
const p = new Cesium.Cartesian3(1.0, 2.0, 3.0);
const result = Cesium.Matrix4.multiplyByPoint(matrix, p, new Cesium.Cartesian3());
```

#### [](#.multiplyByPointAsVector) static Cesium.Matrix4.multiplyByPointAsVector(matrix, cartesian, result) → [Cartesian3](Cartesian3.html) 

[engine/Source/Core/Matrix4.js 2250](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2250) 

 Computes the product of a matrix and a [Cartesian3](Cartesian3.html). This is equivalent to calling [Matrix4.multiplyByVector](Matrix4.html#.multiplyByVector)with a [Cartesian4](Cartesian4.html) with a `w` component of zero.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| matrix    | [Matrix4](Matrix4.html)       | The matrix.                                |
| cartesian | [Cartesian3](Cartesian3.html) | The point.                                 |
| result    | [Cartesian3](Cartesian3.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
const p = new Cesium.Cartesian3(1.0, 2.0, 3.0);
const result = Cesium.Matrix4.multiplyByPointAsVector(matrix, p, new Cesium.Cartesian3());
// A shortcut for
//   Cartesian3 p = ...
//   Cesium.Matrix4.multiplyByVector(matrix, new Cesium.Cartesian4(p.x, p.y, p.z, 0.0), result);
```

#### [](#.multiplyByScalar) static Cesium.Matrix4.multiplyByScalar(matrix, scalar, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2328](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2328) 

 Computes the product of a matrix and a scalar.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html) | The matrix.                                |
| scalar | number                  | The number to multiply by.                 |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
//create a Matrix4 instance which is a scaled version of the supplied Matrix4
// m = [10.0, 11.0, 12.0, 13.0]
//     [14.0, 15.0, 16.0, 17.0]
//     [18.0, 19.0, 20.0, 21.0]
//     [22.0, 23.0, 24.0, 25.0]

const a = Cesium.Matrix4.multiplyByScalar(m, -2, new Cesium.Matrix4());

// m remains the same
// a = [-20.0, -22.0, -24.0, -26.0]
//     [-28.0, -30.0, -32.0, -34.0]
//     [-36.0, -38.0, -40.0, -42.0]
//     [-44.0, -46.0, -48.0, -50.0]
```

#### [](#.multiplyByScale) static Cesium.Matrix4.multiplyByScale(matrix, scale, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2114) 

 Multiplies an affine transformation matrix (with a bottom row of `[0.0, 0.0, 0.0, 1.0]`) by an implicit non-uniform scale matrix. This is an optimization for `Matrix4.multiply(m, Matrix4.fromUniformScale(scale), m);`, where`m` must be an affine matrix. This function performs fewer allocations and arithmetic operations.

| Name   | Type                          | Description                                   |
| ------ | ----------------------------- | --------------------------------------------- |
| matrix | [Matrix4](Matrix4.html)       | The affine matrix on the left-hand side.      |
| scale  | [Cartesian3](Cartesian3.html) | The non-uniform scale on the right-hand side. |
| result | [Matrix4](Matrix4.html)       | The object onto which to store the result.    |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
// Instead of Cesium.Matrix4.multiply(m, Cesium.Matrix4.fromScale(scale), m);
Cesium.Matrix4.multiplyByScale(m, scale, m);
```

##### See:

* [Matrix4.multiplyByUniformScale](Matrix4.html#.multiplyByUniformScale)
* [Matrix4.fromScale](Matrix4.html#.fromScale)
* [Matrix4.fromUniformScale](Matrix4.html#.fromUniformScale)
* [Matrix4.setScale](Matrix4.html#.setScale)
* [Matrix4.setUniformScale](Matrix4.html#.setUniformScale)
* [Matrix4.getScale](Matrix4.html#.getScale)

#### [](#.multiplyByTranslation) static Cesium.Matrix4.multiplyByTranslation(matrix, translation, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2056](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2056) 

 Multiplies a transformation matrix (with a bottom row of `[0.0, 0.0, 0.0, 1.0]`) by an implicit translation matrix defined by a [Cartesian3](Cartesian3.html). This is an optimization for `Matrix4.multiply(m, Matrix4.fromTranslation(position), m);` with less allocations and arithmetic operations.

| Name        | Type                          | Description                                |
| ----------- | ----------------------------- | ------------------------------------------ |
| matrix      | [Matrix4](Matrix4.html)       | The matrix on the left-hand side.          |
| translation | [Cartesian3](Cartesian3.html) | The translation on the right-hand side.    |
| result      | [Matrix4](Matrix4.html)       | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
// Instead of Cesium.Matrix4.multiply(m, Cesium.Matrix4.fromTranslation(position), m);
Cesium.Matrix4.multiplyByTranslation(m, position, m);
```

#### [](#.multiplyByUniformScale) static Cesium.Matrix4.multiplyByUniformScale(matrix, scale, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2172](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2172) 

 Computes the product of a matrix times a uniform scale, as if the scale were a scale matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html) | The matrix on the left-hand side.          |
| scale  | number                  | The uniform scale on the right-hand side.  |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
// Instead of Cesium.Matrix4.multiply(m, Cesium.Matrix4.fromUniformScale(scale), m);
Cesium.Matrix4.multiplyByUniformScale(m, scale, m);
```

##### See:

* [Matrix4.multiplyByScale](Matrix4.html#.multiplyByScale)
* [Matrix4.fromScale](Matrix4.html#.fromScale)
* [Matrix4.fromUniformScale](Matrix4.html#.fromUniformScale)
* [Matrix4.setScale](Matrix4.html#.setScale)
* [Matrix4.setUniformScale](Matrix4.html#.setUniformScale)
* [Matrix4.getScale](Matrix4.html#.getScale)

#### [](#.multiplyByVector) static Cesium.Matrix4.multiplyByVector(matrix, cartesian, result) → [Cartesian4](Cartesian4.html) 

[engine/Source/Core/Matrix4.js 2210](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2210) 

 Computes the product of a matrix and a column vector.

| Name      | Type                          | Description                                |
| --------- | ----------------------------- | ------------------------------------------ |
| matrix    | [Matrix4](Matrix4.html)       | The matrix.                                |
| cartesian | [Cartesian4](Cartesian4.html) | The vector.                                |
| result    | [Cartesian4](Cartesian4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.multiplyTransformation) static Cesium.Matrix4.multiplyTransformation(left, right, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1899](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1899) 

 Computes the product of two matrices assuming the matrices are affine transformation matrices, where the upper left 3x3 elements are any matrix, and the upper three elements in the fourth column are the translation. The bottom row is assumed to be \[0, 0, 0, 1\]. The matrix is not verified to be in the proper form. This method is faster than computing the product for general 4x4 matrices using [Matrix4.multiply](Matrix4.html#.multiply).

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| left   | [Matrix4](Matrix4.html) | The first matrix.                          |
| right  | [Matrix4](Matrix4.html) | The second matrix.                         |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
const m1 = new Cesium.Matrix4(1.0, 6.0, 7.0, 0.0, 2.0, 5.0, 8.0, 0.0, 3.0, 4.0, 9.0, 0.0, 0.0, 0.0, 0.0, 1.0);
const m2 = Cesium.Transforms.eastNorthUpToFixedFrame(new Cesium.Cartesian3(1.0, 1.0, 1.0));
const m3 = Cesium.Matrix4.multiplyTransformation(m1, m2, new Cesium.Matrix4());
```

#### [](#.negate) static Cesium.Matrix4.negate(matrix, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2376](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2376) 

 Computes a negated copy of the provided matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html) | The matrix to negate.                      |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
//create a new Matrix4 instance which is a negation of a Matrix4
// m = [10.0, 11.0, 12.0, 13.0]
//     [14.0, 15.0, 16.0, 17.0]
//     [18.0, 19.0, 20.0, 21.0]
//     [22.0, 23.0, 24.0, 25.0]

const a = Cesium.Matrix4.negate(m, new Cesium.Matrix4());

// m remains the same
// a = [-10.0, -11.0, -12.0, -13.0]
//     [-14.0, -15.0, -16.0, -17.0]
//     [-18.0, -19.0, -20.0, -21.0]
//     [-22.0, -23.0, -24.0, -25.0]
```

#### [](#.pack) static Cesium.Matrix4.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/Matrix4.js 107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L107) 

 Stores the provided instance into the provided array.

| Name          | Type                    | Default | Description                                                               |
| ------------- | ----------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [Matrix4](Matrix4.html) |         | The value to pack.                                                        |
| array         | Array.<number>          |         | The array to pack into.                                                   |
| startingIndex | number                  | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.packArray) static Cesium.Matrix4.packArray(array, result) → Array.<number> 

[engine/Source/Core/Matrix4.js 181](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L181) 

 Flattens an array of Matrix4s into an array of components. The components are stored in column-major order.

| Name   | Type                             | Description                                                                                                                                                                                                                                                               |
| ------ | -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| array  | Array.<[Matrix4](Matrix4.html)\> | The array of matrices to pack.                                                                                                                                                                                                                                            |
| result | Array.<number>                   | optional The array onto which to store the result. If this is a typed array, it must have array.length \* 16 components, else a [DeveloperError](DeveloperError.html) will be thrown. If it is a regular array, it will be resized to have (array.length \* 16) elements. |

##### Returns:

 The packed array.

#### [](#.setColumn) static Cesium.Matrix4.setColumn(matrix, index, cartesian, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1321](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1321) 

 Computes a new matrix that replaces the specified column in the provided matrix with the provided Cartesian4 instance.

| Name      | Type                          | Description                                                          |
| --------- | ----------------------------- | -------------------------------------------------------------------- |
| matrix    | [Matrix4](Matrix4.html)       | The matrix to use.                                                   |
| index     | number                        | The zero-based index of the column to set.                           |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian whose values will be assigned to the specified column. |
| result    | [Matrix4](Matrix4.html)       | The object onto which to store the result.                           |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0, 1, 2, or 3.

##### Example:

```javascript
//creates a new Matrix4 instance with new column values from the Cartesian4 instance
// m = [10.0, 11.0, 12.0, 13.0]
//     [14.0, 15.0, 16.0, 17.0]
//     [18.0, 19.0, 20.0, 21.0]
//     [22.0, 23.0, 24.0, 25.0]

const a = Cesium.Matrix4.setColumn(m, 2, new Cesium.Cartesian4(99.0, 98.0, 97.0, 96.0), new Cesium.Matrix4());

// m remains the same
// a = [10.0, 11.0, 99.0, 13.0]
//     [14.0, 15.0, 98.0, 17.0]
//     [18.0, 19.0, 97.0, 21.0]
//     [22.0, 23.0, 96.0, 25.0]
```

#### [](#.setRotation) static Cesium.Matrix4.setRotation(matrix, rotation, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1642](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1642) 

 Sets the rotation assuming the matrix is an affine transformation.

| Name     | Type                    | Description                                |
| -------- | ----------------------- | ------------------------------------------ |
| matrix   | [Matrix4](Matrix4.html) | The matrix.                                |
| rotation | [Matrix3](Matrix3.html) | The rotation matrix.                       |
| result   | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix4.fromRotation](Matrix4.html#.fromRotation)
* [Matrix4.getRotation](Matrix4.html#.getRotation)

#### [](#.setRow) static Cesium.Matrix4.setRow(matrix, index, cartesian, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1416](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1416) 

 Computes a new matrix that replaces the specified row in the provided matrix with the provided Cartesian4 instance.

| Name      | Type                          | Description                                                       |
| --------- | ----------------------------- | ----------------------------------------------------------------- |
| matrix    | [Matrix4](Matrix4.html)       | The matrix to use.                                                |
| index     | number                        | The zero-based index of the row to set.                           |
| cartesian | [Cartesian4](Cartesian4.html) | The Cartesian whose values will be assigned to the specified row. |
| result    | [Matrix4](Matrix4.html)       | The object onto which to store the result.                        |

##### Returns:

 The modified result parameter.

##### Throws:

* [DeveloperError](DeveloperError.html): index must be 0, 1, 2, or 3.

##### Example:

```javascript
//create a new Matrix4 instance with new row values from the Cartesian4 instance
// m = [10.0, 11.0, 12.0, 13.0]
//     [14.0, 15.0, 16.0, 17.0]
//     [18.0, 19.0, 20.0, 21.0]
//     [22.0, 23.0, 24.0, 25.0]

const a = Cesium.Matrix4.setRow(m, 2, new Cesium.Cartesian4(99.0, 98.0, 97.0, 96.0), new Cesium.Matrix4());

// m remains the same
// a = [10.0, 11.0, 12.0, 13.0]
//     [14.0, 15.0, 16.0, 17.0]
//     [99.0, 98.0, 97.0, 96.0]
//     [22.0, 23.0, 24.0, 25.0]
```

#### [](#.setScale) static Cesium.Matrix4.setScale(matrix, scale, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1492](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1492) 

 Computes a new matrix that replaces the scale with the provided scale. This assumes the matrix is an affine transformation.

| Name   | Type                          | Description                                               |
| ------ | ----------------------------- | --------------------------------------------------------- |
| matrix | [Matrix4](Matrix4.html)       | The matrix to use.                                        |
| scale  | [Cartesian3](Cartesian3.html) | The scale that replaces the scale of the provided matrix. |
| result | [Matrix4](Matrix4.html)       | The object onto which to store the result.                |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix4.setUniformScale](Matrix4.html#.setUniformScale)
* [Matrix4.fromScale](Matrix4.html#.fromScale)
* [Matrix4.fromUniformScale](Matrix4.html#.fromUniformScale)
* [Matrix4.multiplyByScale](Matrix4.html#.multiplyByScale)
* [Matrix4.multiplyByUniformScale](Matrix4.html#.multiplyByUniformScale)
* [Matrix4.getScale](Matrix4.html#.getScale)

#### [](#.setTranslation) static Cesium.Matrix4.setTranslation(matrix, translation, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1444](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1444) 

 Computes a new matrix that replaces the translation in the rightmost column of the provided matrix with the provided translation. This assumes the matrix is an affine transformation.

| Name        | Type                          | Description                                                           |
| ----------- | ----------------------------- | --------------------------------------------------------------------- |
| matrix      | [Matrix4](Matrix4.html)       | The matrix to use.                                                    |
| translation | [Cartesian3](Cartesian3.html) | The translation that replaces the translation of the provided matrix. |
| result      | [Matrix4](Matrix4.html)       | The object onto which to store the result.                            |

##### Returns:

 The modified result parameter.

#### [](#.setUniformScale) static Cesium.Matrix4.setUniformScale(matrix, scale, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1545](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1545) 

 Computes a new matrix that replaces the scale with the provided uniform scale. This assumes the matrix is an affine transformation.

| Name   | Type                    | Description                                                       |
| ------ | ----------------------- | ----------------------------------------------------------------- |
| matrix | [Matrix4](Matrix4.html) | The matrix to use.                                                |
| scale  | number                  | The uniform scale that replaces the scale of the provided matrix. |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result.                        |

##### Returns:

 The modified result parameter.

##### See:

* [Matrix4.setScale](Matrix4.html#.setScale)
* [Matrix4.fromScale](Matrix4.html#.fromScale)
* [Matrix4.fromUniformScale](Matrix4.html#.fromUniformScale)
* [Matrix4.multiplyByScale](Matrix4.html#.multiplyByScale)
* [Matrix4.multiplyByUniformScale](Matrix4.html#.multiplyByUniformScale)
* [Matrix4.getScale](Matrix4.html#.getScale)

#### [](#.subtract) static Cesium.Matrix4.subtract(left, right, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 1854](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1854) 

 Computes the difference of two matrices.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| left   | [Matrix4](Matrix4.html) | The first matrix.                          |
| right  | [Matrix4](Matrix4.html) | The second matrix.                         |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

#### [](#.toArray) static Cesium.Matrix4.toArray(matrix, result) → Array.<number> 

[engine/Source/Core/Matrix4.js 1173](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L1173) 

 Computes an Array from the provided Matrix4 instance. The array will be in column-major order.

| Name   | Type                    | Description                                        |
| ------ | ----------------------- | -------------------------------------------------- |
| matrix | [Matrix4](Matrix4.html) | The matrix to use..                                |
| result | Array.<number>          | optional The Array onto which to store the result. |

##### Returns:

 The modified Array parameter or a new Array instance if one was not provided.

##### Example:

```javascript
//create an array from an instance of Matrix4
// m = [10.0, 14.0, 18.0, 22.0]
//     [11.0, 15.0, 19.0, 23.0]
//     [12.0, 16.0, 20.0, 24.0]
//     [13.0, 17.0, 21.0, 25.0]
const a = Cesium.Matrix4.toArray(m);

// m remains the same
//creates a = [10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 24.0, 25.0]
```

#### [](#.transpose) static Cesium.Matrix4.transpose(matrix, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 2423](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L2423) 

 Computes the transpose of the provided matrix.

| Name   | Type                    | Description                                |
| ------ | ----------------------- | ------------------------------------------ |
| matrix | [Matrix4](Matrix4.html) | The matrix to transpose.                   |
| result | [Matrix4](Matrix4.html) | The object onto which to store the result. |

##### Returns:

 The modified result parameter.

##### Example:

```javascript
//returns transpose of a Matrix4
// m = [10.0, 11.0, 12.0, 13.0]
//     [14.0, 15.0, 16.0, 17.0]
//     [18.0, 19.0, 20.0, 21.0]
//     [22.0, 23.0, 24.0, 25.0]

const a = Cesium.Matrix4.transpose(m, new Cesium.Matrix4());

// m remains the same
// a = [10.0, 14.0, 18.0, 22.0]
//     [11.0, 15.0, 19.0, 23.0]
//     [12.0, 16.0, 20.0, 24.0]
//     [13.0, 17.0, 21.0, 25.0]
```

#### [](#.unpack) static Cesium.Matrix4.unpack(array, startingIndex, result) → [Matrix4](Matrix4.html) 

[engine/Source/Core/Matrix4.js 143](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L143) 

 Retrieves an instance from a packed array.

| Name          | Type                    | Default | Description                                                |
| ------------- | ----------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>          |         | The packed array.                                          |
| startingIndex | number                  | 0       | optional The starting index of the element to be unpacked. |
| result        | [Matrix4](Matrix4.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new Matrix4 instance if one was not provided.

#### [](#.unpackArray) static Cesium.Matrix4.unpackArray(array, result) → Array.<[Matrix4](Matrix4.html)\> 

[engine/Source/Core/Matrix4.js 213](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/Matrix4.js#L213) 

 Unpacks an array of column-major matrix components into an array of Matrix4s.

| Name   | Type                             | Description                                        |
| ------ | -------------------------------- | -------------------------------------------------- |
| array  | Array.<number>                   | The array of components to unpack.                 |
| result | Array.<[Matrix4](Matrix4.html)\> | optional The array onto which to store the result. |

##### Returns:

 The unpacked array.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

