# [![](Images/CesiumLogo.png)](index.html) Cesium3DTileContent 

#### [](#Cesium3DTileContent) new Cesium.Cesium3DTileContent() 

[engine/Source/Scene/Cesium3DTileContent.js 16](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L16) 

 The content of a tile in a [Cesium3DTileset](Cesium3DTileset.html).

Derived classes of this interface provide access to individual features in the tile. Access derived objects through [Cesium3DTile#content](Cesium3DTile.html#content).

This type describes an interface and is not intended to be instantiated directly.

### Members

#### [](#batchTableByteLength) readonly batchTableByteLength : number 

[engine/Source/Scene/Cesium3DTileContent.js 124](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L124) 

 Gets the amount of memory used by the batch table textures and any binary metadata properties not accounted for in geometryByteLength or texturesByteLength

#### [](#featuresLength) readonly featuresLength : number 

[engine/Source/Scene/Cesium3DTileContent.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L41) 

 Gets the number of features in the tile.

#### [](#geometryByteLength) readonly geometryByteLength : number 

[engine/Source/Scene/Cesium3DTileContent.js 92](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L92) 

 Gets the tile's geometry memory in bytes.

#### [](#innerContents) readonly innerContents : Array 

[engine/Source/Scene/Cesium3DTileContent.js 141](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L141) 

 Gets the array of [Cesium3DTileContent](Cesium3DTileContent.html) objects for contents that contain other contents, such as composite tiles. The inner contents may in turn have inner contents, such as a composite tile that contains a composite tile.

##### See:

* [Composite specification](https://github.com/CesiumGS/3d-tiles/tree/main/specification/TileFormats/Composite)

#### [](#pointsLength) readonly pointsLength : number 

[engine/Source/Scene/Cesium3DTileContent.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L62) 

 Gets the number of points in the tile.

Only applicable for tiles with Point Cloud content. This is different than [Cesium3DTileContent#featuresLength](Cesium3DTileContent.html#featuresLength) which equals the number of groups of points as distinguished by the `BATCH_ID` feature table semantic.

##### See:

* <https://github.com/CesiumGS/3d-tiles/tree/main/specification/TileFormats/PointCloud#batched-points>

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/Cesium3DTileContent.js 156](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L156) 

 Returns true when the tile's content is ready to render; otherwise false

#### [](#texturesByteLength) readonly texturesByteLength : number 

[engine/Source/Scene/Cesium3DTileContent.js 107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L107) 

 Gets the tile's texture memory in bytes.

#### [](#tile) readonly tile : [Cesium3DTile](Cesium3DTile.html) 

[engine/Source/Scene/Cesium3DTileContent.js 186](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L186) 

 Gets the tile containing this content.

#### [](#tileset) readonly tileset : [Cesium3DTileset](Cesium3DTileset.html) 

[engine/Source/Scene/Cesium3DTileContent.js 171](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L171) 

 Gets the tileset for this tile.

#### [](#trianglesLength) readonly trianglesLength : number 

[engine/Source/Scene/Cesium3DTileContent.js 77](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L77) 

 Gets the number of triangles in the tile.

#### [](#url) readonly url : string 

[engine/Source/Scene/Cesium3DTileContent.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L200) 

 Gets the url of the tile's content.

### Methods

#### [](#getFeature) getFeature(batchId) → [Cesium3DTileFeature](Cesium3DTileFeature.html) 

[engine/Source/Scene/Cesium3DTileContent.js 300](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L300) 

 Returns the [Cesium3DTileFeature](Cesium3DTileFeature.html) object for the feature with the given `batchId`. This object is used to get and modify the feature's properties.

Features in a tile are ordered by `batchId`, an index used to retrieve their metadata from the batch table.

| Name    | Type   | Description                  |
| ------- | ------ | ---------------------------- |
| batchId | number | The batchId for the feature. |

##### Returns:

 The corresponding [Cesium3DTileFeature](Cesium3DTileFeature.html) object.

##### Throws:

* [DeveloperError](DeveloperError.html): batchId must be between zero and [Cesium3DTileContent#featuresLength](Cesium3DTileContent.html#featuresLength) \- 1.

##### See:

* <https://github.com/CesiumGS/3d-tiles/tree/main/specification/TileFormats/BatchTable>.

#### [](#hasProperty) hasProperty(batchId, name) → boolean 

[engine/Source/Scene/Cesium3DTileContent.js 281](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Cesium3DTileContent.js#L281) 

 Returns whether the feature has this property.

| Name    | Type   | Description                              |
| ------- | ------ | ---------------------------------------- |
| batchId | number | The batchId for the feature.             |
| name    | string | The case-sensitive name of the property. |

##### Returns:

`true` if the feature has this property; otherwise, `false`.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

