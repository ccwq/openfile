# [![](Images/CesiumLogo.png)](index.html) CylinderGeometry 

#### [](#CylinderGeometry) new Cesium.CylinderGeometry(options) 

[engine/Source/Core/CylinderGeometry.js 50](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CylinderGeometry.js#L50) 

 A description of a cylinder.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description length number  The length of the cylinder. topRadius number  The radius of the top of the cylinder. bottomRadius number  The radius of the bottom of the cylinder. slices number 128 optional The number of edges around the perimeter of the cylinder. vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. |

##### Throws:

* [DeveloperError](DeveloperError.html): options.slices must be greater than or equal to 3.

##### Example:

```javascript
// create cylinder geometry
const cylinder = new Cesium.CylinderGeometry({
    length: 200000,
    topRadius: 80000,
    bottomRadius: 200000,
});
const geometry = Cesium.CylinderGeometry.createGeometry(cylinder);
```

##### See:

* [CylinderGeometry.createGeometry](CylinderGeometry.html#.createGeometry)

### Members

#### [](#.packedLength) static Cesium.CylinderGeometry.packedLength : number 

[engine/Source/Core/CylinderGeometry.js 97](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CylinderGeometry.js#L97) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.CylinderGeometry.createGeometry(cylinderGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/CylinderGeometry.js 199](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CylinderGeometry.js#L199) 

 Computes the geometric representation of a cylinder, including its vertices, indices, and a bounding sphere.

| Name             | Type                                      | Description                    |
| ---------------- | ----------------------------------------- | ------------------------------ |
| cylinderGeometry | [CylinderGeometry](CylinderGeometry.html) | A description of the cylinder. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.CylinderGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/CylinderGeometry.js 108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CylinderGeometry.js#L108) 

 Stores the provided instance into the provided array.

| Name          | Type                                      | Default | Description                                                               |
| ------------- | ----------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [CylinderGeometry](CylinderGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                            |         | The array to pack into.                                                   |
| startingIndex | number                                    | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.CylinderGeometry.unpack(array, startingIndex, result) → [CylinderGeometry](CylinderGeometry.html) 

[engine/Source/Core/CylinderGeometry.js 150](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CylinderGeometry.js#L150) 

 Retrieves an instance from a packed array.

| Name          | Type                                      | Default | Description                                                |
| ------------- | ----------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                            |         | The packed array.                                          |
| startingIndex | number                                    | 0       | optional The starting index of the element to be unpacked. |
| result        | [CylinderGeometry](CylinderGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new CylinderGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

