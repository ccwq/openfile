# [![](Images/CesiumLogo.png)](index.html) WallGraphics 

#### [](#WallGraphics) new Cesium.WallGraphics(options) 

[engine/Source/DataSources/WallGraphics.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L39) 

 Describes a two dimensional wall defined as a line strip and optional maximum and minimum heights. The wall conforms to the curvature of the globe and can be placed along the surface or at altitude.

| Name    | Type                                                                     | Description                                       |
| ------- | ------------------------------------------------------------------------ | ------------------------------------------------- |
| options | [WallGraphics.ConstructorOptions](WallGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle Wall Demo](https://sandcastle.cesium.com/index.html?src=Wall.html)

##### See:

* [Entity](Entity.html)

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/WallGraphics.js 77](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L77) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/WallGraphics.js 179](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L179) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this wall will be displayed.

#### [](#fill) fill : [Property](Property.html)|undefined 

[engine/Source/DataSources/WallGraphics.js 128](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L128) 

 Gets or sets the boolean Property specifying whether the wall is filled with the provided material.

Default Value: `true` 

#### [](#granularity) granularity : [Property](Property.html)|undefined 

[engine/Source/DataSources/WallGraphics.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L120) 

 Gets or sets the numeric Property specifying the angular distance between points on the wall.

Default Value: `{CesiumMath.RADIANS_PER_DEGREE}` 

#### [](#material) material : [MaterialProperty](MaterialProperty.html) 

[engine/Source/DataSources/WallGraphics.js 136](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L136) 

 Gets or sets the Property specifying the material used to fill the wall.

Default Value: `Color.WHITE` 

#### [](#maximumHeights) maximumHeights : [Property](Property.html)|undefined 

[engine/Source/DataSources/WallGraphics.js 112](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L112) 

 Gets or sets the Property specifying an array of heights to be used for the top of the wall instead of the height of each position. If defined, the array must be the same length as `Wall#positions`.

#### [](#minimumHeights) minimumHeights : [Property](Property.html)|undefined 

[engine/Source/DataSources/WallGraphics.js 104](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L104) 

 Gets or sets the Property specifying an array of heights to be used for the bottom of the wall instead of the surface of the globe. If defined, the array must be the same length as `Wall#positions`.

#### [](#outline) outline : [Property](Property.html)|undefined 

[engine/Source/DataSources/WallGraphics.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L144) 

 Gets or sets the Property specifying whether the wall is outlined.

Default Value: `false` 

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/WallGraphics.js 152](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L152) 

 Gets or sets the Property specifying the [Color](Color.html) of the outline.

Default Value: `Color.BLACK` 

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/WallGraphics.js 163](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L163) 

 Gets or sets the numeric Property specifying the width of the outline.

Note: This property will be ignored on all major browsers on Windows platforms. For details, see (@link https://github.com/CesiumGS/cesium/issues/40}.

Default Value: `1.0` 

#### [](#positions) positions : [Property](Property.html)|undefined 

[engine/Source/DataSources/WallGraphics.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L96) 

 Gets or sets the Property specifying the array of [Cartesian3](Cartesian3.html) positions which define the top of the wall.

#### [](#shadows) shadows : [Property](Property.html)|undefined 

[engine/Source/DataSources/WallGraphics.js 172](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L172) 

 Get or sets the enum Property specifying whether the wall casts or receives shadows from light sources.

Default Value: `ShadowMode.DISABLED` 

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/WallGraphics.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L89) 

 Gets or sets the boolean Property specifying the visibility of the wall.

Default Value: `true` 

### Methods

#### [](#clone) clone(result) → [WallGraphics](WallGraphics.html) 

[engine/Source/DataSources/WallGraphics.js 190](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L190) 

 Duplicates this instance.

| Name   | Type                              | Description                                         |
| ------ | --------------------------------- | --------------------------------------------------- |
| result | [WallGraphics](WallGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/WallGraphics.js 215](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L215) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                              | Description                               |
| ------ | --------------------------------- | ----------------------------------------- |
| source | [WallGraphics](WallGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.WallGraphics.ConstructorOptions

[engine/Source/DataSources/WallGraphics.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/WallGraphics.js#L8) 

 Initialization options for the WallGraphics constructor

##### Properties:

| Name                     | Type                                                                                 | Attributes | Default                          | Description                                                                                                          |
| ------------------------ | ------------------------------------------------------------------------------------ | ---------- | -------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| show                     | [Property](Property.html)\|boolean                                                   | <optional> | true                             | A boolean Property specifying the visibility of the wall.                                                            |
| positions                | [Property](Property.html)\|Array.<[Cartesian3](Cartesian3.html)\>                    | <optional> |                                  | A Property specifying the array of [Cartesian3](Cartesian3.html) positions which define the top of the wall.         |
| minimumHeights           | [Property](Property.html)\|Array.<number>                                            | <optional> |                                  | A Property specifying an array of heights to be used for the bottom of the wall instead of the globe surface.        |
| maximumHeights           | [Property](Property.html)\|Array.<number>                                            | <optional> |                                  | A Property specifying an array of heights to be used for the top of the wall instead of the height of each position. |
| granularity              | [Property](Property.html)\|number                                                    | <optional> | Cesium.Math.RADIANS\_PER\_DEGREE | A numeric Property specifying the angular distance between each latitude and longitude point.                        |
| fill                     | [Property](Property.html)\|boolean                                                   | <optional> | true                             | A boolean Property specifying whether the wall is filled with the provided material.                                 |
| material                 | [MaterialProperty](MaterialProperty.html)\|[Color](Color.html)                       | <optional> | Color.WHITE                      | A Property specifying the material used to fill the wall.                                                            |
| outline                  | [Property](Property.html)\|boolean                                                   | <optional> | false                            | A boolean Property specifying whether the wall is outlined.                                                          |
| outlineColor             | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.BLACK                      | A Property specifying the [Color](Color.html) of the outline.                                                        |
| outlineWidth             | [Property](Property.html)\|number                                                    | <optional> | 1.0                              | A numeric Property specifying the width of the outline.                                                              |
| shadows                  | [Property](Property.html)\|[ShadowMode](global.html#ShadowMode)                      | <optional> | ShadowMode.DISABLED              | An enum Property specifying whether the wall casts or receives shadows from light sources.                           |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                                  | A Property specifying at what distance from the camera that this wall will be displayed.                             |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

