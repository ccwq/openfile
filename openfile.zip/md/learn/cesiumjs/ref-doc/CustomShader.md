# [![](Images/CesiumLogo.png)](index.html) CustomShader 

#### [](#CustomShader) new Cesium.CustomShader(options) 

[engine/Source/Scene/Model/CustomShader.js 122](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L122) 

 A user defined GLSL shader used with [Model](Model.html) as well as [Cesium3DTileset](Cesium3DTileset.html).

If texture uniforms are used, additional resource management must be done:

* The `update` function must be called each frame. When a custom shader is passed to a [Model](Model.html) or a[Cesium3DTileset](Cesium3DTileset.html), this step is handled automaticaly
* [CustomShader#destroy](CustomShader.html#destroy) must be called when the custom shader is no longer needed to clean up GPU resources properly. The application is responsible for calling this method.

See the [Custom Shader Guide](https://github.com/CesiumGS/cesium/tree/main/Documentation/CustomShaderGuide) for more detailed documentation.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | An object with the following options Name Type Default Description mode [CustomShaderMode](global.html#CustomShaderMode) CustomShaderMode.MODIFY\_MATERIAL optional The custom shader mode, which determines how the custom shader code is inserted into the fragment shader. lightingModel [LightingModel](global.html#LightingModel) optional The lighting model (e.g. PBR or unlit). If present, this overrides the default lighting for the model. translucencyMode [CustomShaderTranslucencyMode](global.html#CustomShaderTranslucencyMode) CustomShaderTranslucencyMode.INHERIT optional The translucency mode, which determines how the custom shader will be applied. If the value is CustomShaderTransulcencyMode.OPAQUE or CustomShaderTransulcencyMode.TRANSLUCENT, the custom shader will override settings from the model's material. If the value is CustomShaderTransulcencyMode.INHERIT, the custom shader will render as either opaque or translucent depending on the primitive's material settings. uniforms Object.<string, [UniformSpecifier](global.html#UniformSpecifier)\> optional A dictionary for user-defined uniforms. The key is the uniform name that will appear in the GLSL code. The value is an object that describes the uniform type and initial value varyings Object.<string, [VaryingType](global.html#VaryingType)\> optional A dictionary for declaring additional GLSL varyings used in the shader. The key is the varying name that will appear in the GLSL code. The value is the data type of the varying. For each varying, the declaration will be added to the top of the shader automatically. The caller is responsible for assigning a value in the vertex shader and using the value in the fragment shader. vertexShaderText string optional The custom vertex shader as a string of GLSL code. It must include a GLSL function called vertexMain. See the example for the expected signature. If not specified, the custom vertex shader step will be skipped in the computed vertex shader. fragmentShaderText string optional The custom fragment shader as a string of GLSL code. It must include a GLSL function called fragmentMain. See the example for the expected signature. If not specified, the custom fragment shader step will be skipped in the computed fragment shader. |

##### Example:

```javascript
const customShader = new CustomShader({
  uniforms: {
    u_colorIndex: {
      type: Cesium.UniformType.FLOAT,
      value: 1.0
    },
    u_normalMap: {
      type: Cesium.UniformType.SAMPLER_2D,
      value: new Cesium.TextureUniform({
        url: "http://example.com/normal.png"
      })
    }
  },
  varyings: {
    v_selectedColor: Cesium.VaryingType.VEC3
  },
  vertexShaderText: `
  void vertexMain(VertexInput vsInput, inout czm_modelVertexOutput vsOutput) {
    v_selectedColor = mix(vsInput.attributes.color_0, vsInput.attributes.color_1, u_colorIndex);
    vsOutput.positionMC += 0.1 * vsInput.attributes.normal;
  }
  `,
  fragmentShaderText: `
  void fragmentMain(FragmentInput fsInput, inout czm_modelMaterial material) {
    material.normal = texture(u_normalMap, fsInput.attributes.texCoord_0);
    material.diffuse = v_selectedColor;
  }
  `
});
```

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

### Members

#### [](#fragmentShaderText) readonly fragmentShaderText : string 

[engine/Source/Scene/Model/CustomShader.js 169](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L169) 

 The user-defined GLSL code for the fragment shader

#### [](#lightingModel) readonly lightingModel : [LightingModel](global.html#LightingModel) 

[engine/Source/Scene/Model/CustomShader.js 140](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L140) 

 The lighting model to use when using the custom shader. This is used by `CustomShaderPipelineStage` 

#### [](#mode) readonly mode : [CustomShaderMode](global.html#CustomShaderMode) 

[engine/Source/Scene/Model/CustomShader.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L132) 

 A value determining how the custom shader interacts with the overall fragment shader. This is used by `CustomShaderPipelineStage` 

#### [](#translucencyMode) readonly translucencyMode : [CustomShaderTranslucencyMode](global.html#CustomShaderTranslucencyMode) 

[engine/Source/Scene/Model/CustomShader.js 181](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L181) 

 The translucency mode, which determines how the custom shader will be applied. If the value is CustomShaderTransulcencyMode.OPAQUE or CustomShaderTransulcencyMode.TRANSLUCENT, the custom shader will override settings from the model's material. If the value isCustomShaderTransulcencyMode.INHERIT, the custom shader will render as either opaque or translucent depending on the primitive's material settings.

Default Value: `CustomShaderTranslucencyMode.INHERIT` 

#### [](#uniforms) readonly uniforms : Object.<string, [UniformSpecifier](global.html#UniformSpecifier)\> 

[engine/Source/Scene/Model/CustomShader.js 147](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L147) 

 Additional uniforms as declared by the user.

#### [](#varyings) readonly varyings : Object.<string, [VaryingType](global.html#VaryingType)\> 

[engine/Source/Scene/Model/CustomShader.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L155) 

 Additional varyings as declared by the user. This is used by `CustomShaderPipelineStage` 

#### [](#vertexShaderText) readonly vertexShaderText : string 

[engine/Source/Scene/Model/CustomShader.js 162](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L162) 

 The user-defined GLSL code for the vertex shader

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/Model/CustomShader.js 466](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L466) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
customShader = customShader && customShader.destroy();
```

##### See:

* [CustomShader#isDestroyed](CustomShader.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/Model/CustomShader.js 447](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L447) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

 True if this object was destroyed; otherwise, false.

##### See:

* [CustomShader#destroy](CustomShader.html#destroy)

#### [](#setUniform) setUniform(uniformName, value) 

[engine/Source/Scene/Model/CustomShader.js 410](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/CustomShader.js#L410) 

 Update the value of a uniform declared in the shader

| Name        | Type                                                                                                                                                                                                                                                     | Description                                                                                   |
| ----------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| uniformName | string                                                                                                                                                                                                                                                   | The GLSL name of the uniform. This must match one of the uniforms declared in the constructor |
| value       | boolean\|number|[Cartesian2](Cartesian2.html)|[Cartesian3](Cartesian3.html)|[Cartesian4](Cartesian4.html)|[Matrix2](Matrix2.html)|[Matrix3](Matrix3.html)|[Matrix4](Matrix4.html)|string|[Resource](Resource.html)|[TextureUniform](TextureUniform.html) | The new value of the uniform.                                                                 |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

