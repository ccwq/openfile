# [![](Images/CesiumLogo.png)](index.html) BoxGraphics 

#### [](#BoxGraphics) new Cesium.BoxGraphics(options) 

[engine/Source/DataSources/BoxGraphics.js 36](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L36) 

 Describes a box. The center position and orientation are determined by the containing [Entity](Entity.html).

| Name    | Type                                                                   | Description                                       |
| ------- | ---------------------------------------------------------------------- | ------------------------------------------------- |
| options | [BoxGraphics.ConstructorOptions](BoxGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle Box Demo](https://sandcastle.cesium.com/index.html?src=Box.html)

### Members

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/BoxGraphics.js 69](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L69) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#dimensions) dimensions : [Property](Property.html)|undefined 

[engine/Source/DataSources/BoxGraphics.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L88) 

 Gets or sets [Cartesian3](Cartesian3.html) Property property specifying the length, width, and height of the box.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/BoxGraphics.js 155](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L155) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this box will be displayed.

#### [](#fill) fill : [Property](Property.html)|undefined 

[engine/Source/DataSources/BoxGraphics.js 104](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L104) 

 Gets or sets the boolean Property specifying whether the box is filled with the provided material.

Default Value: `true` 

#### [](#heightReference) heightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/BoxGraphics.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L96) 

 Gets or sets the Property specifying the [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#material) material : [MaterialProperty](MaterialProperty.html)|undefined 

[engine/Source/DataSources/BoxGraphics.js 112](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L112) 

 Gets or sets the material used to fill the box.

Default Value: `Color.WHITE` 

#### [](#outline) outline : [Property](Property.html)|undefined 

[engine/Source/DataSources/BoxGraphics.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L120) 

 Gets or sets the Property specifying whether the box is outlined.

Default Value: `false` 

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/BoxGraphics.js 128](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L128) 

 Gets or sets the Property specifying the [Color](Color.html) of the outline.

Default Value: `Color.BLACK` 

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/BoxGraphics.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L139) 

 Gets or sets the numeric Property specifying the width of the outline.

Note: This property will be ignored on all major browsers on Windows platforms. For details, see (@link https://github.com/CesiumGS/cesium/issues/40}.

Default Value: `1.0` 

#### [](#shadows) shadows : [Property](Property.html)|undefined 

[engine/Source/DataSources/BoxGraphics.js 148](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L148) 

 Get or sets the enum Property specifying whether the box casts or receives shadows from light sources.

Default Value: `ShadowMode.DISABLED` 

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/BoxGraphics.js 81](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L81) 

 Gets or sets the boolean Property specifying the visibility of the box.

Default Value: `true` 

### Methods

#### [](#clone) clone(result) → [BoxGraphics](BoxGraphics.html) 

[engine/Source/DataSources/BoxGraphics.js 166](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L166) 

 Duplicates this instance.

| Name   | Type                            | Description                                         |
| ------ | ------------------------------- | --------------------------------------------------- |
| result | [BoxGraphics](BoxGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/BoxGraphics.js 189](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L189) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                            | Description                               |
| ------ | ------------------------------- | ----------------------------------------- |
| source | [BoxGraphics](BoxGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.BoxGraphics.ConstructorOptions

[engine/Source/DataSources/BoxGraphics.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/BoxGraphics.js#L8) 

 Initialization options for the BoxGraphics constructor

##### Properties:

| Name                     | Type                                                                                 | Attributes | Default              | Description                                                                                   |
| ------------------------ | ------------------------------------------------------------------------------------ | ---------- | -------------------- | --------------------------------------------------------------------------------------------- |
| show                     | [Property](Property.html)\|boolean                                                   | <optional> | true                 | A boolean Property specifying the visibility of the box.                                      |
| dimensions               | [Property](Property.html)\|[Cartesian3](Cartesian3.html)                             | <optional> |                      | A [Cartesian3](Cartesian3.html) Property specifying the length, width, and height of the box. |
| heightReference          | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE | A Property specifying what the height from the entity position is relative to.                |
| fill                     | [Property](Property.html)\|boolean                                                   | <optional> | true                 | A boolean Property specifying whether the box is filled with the provided material.           |
| material                 | [MaterialProperty](MaterialProperty.html)\|[Color](Color.html)                       | <optional> | Color.WHITE          | A Property specifying the material used to fill the box.                                      |
| outline                  | [Property](Property.html)\|boolean                                                   | <optional> | false                | A boolean Property specifying whether the box is outlined.                                    |
| outlineColor             | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.BLACK          | A Property specifying the [Color](Color.html) of the outline.                                 |
| outlineWidth             | [Property](Property.html)\|number                                                    | <optional> | 1.0                  | A numeric Property specifying the width of the outline.                                       |
| shadows                  | [Property](Property.html)\|[ShadowMode](global.html#ShadowMode)                      | <optional> | ShadowMode.DISABLED  | An enum Property specifying whether the box casts or receives shadows from light sources.     |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                      | A Property specifying at what distance from the camera that this box will be displayed.       |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

