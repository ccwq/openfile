# [![](Images/CesiumLogo.png)](index.html) GridImageryProvider 

#### [](#GridImageryProvider) new Cesium.GridImageryProvider(options) 

[engine/Source/Scene/GridImageryProvider.js 39](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L39) 

 An [ImageryProvider](ImageryProvider.html) that draws a wireframe grid on every tile with controllable background and glow. May be useful for custom rendering effects or debugging terrain.

| Name    | Type                                                                                   | Description                              |
| ------- | -------------------------------------------------------------------------------------- | ---------------------------------------- |
| options | [GridImageryProvider.ConstructorOptions](GridImageryProvider.html#.ConstructorOptions) | Object describing initialization options |

### Members

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/GridImageryProvider.js 197](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L197) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/GridImageryProvider.js 184](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L184) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/GridImageryProvider.js 213](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L213) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. When this property is false, memory usage and texture upload time are reduced.

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/GridImageryProvider.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L120) 

 Gets the maximum level-of-detail that can be requested.

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/GridImageryProvider.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L132) 

 Gets the minimum level-of-detail that can be requested.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/GridImageryProvider.js 84](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L84) 

 Gets the proxy used by this provider.

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/GridImageryProvider.js 156](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L156) 

 Gets the rectangle, in radians, of the imagery provided by this instance.

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/GridImageryProvider.js 170](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L170) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/GridImageryProvider.js 108](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L108) 

 Gets the height of each tile, in pixels.

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/GridImageryProvider.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L96) 

 Gets the width of each tile, in pixels.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/GridImageryProvider.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L144) 

 Gets the tiling scheme used by this provider.

### Methods

#### [](#%5FcreateGridCanvas) \_createGridCanvas() 

[engine/Source/Scene/GridImageryProvider.js 241](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L241) 

 Render a grid into a canvas with background and glow

#### [](#%5FdrawGrid) \_drawGrid() 

[engine/Source/Scene/GridImageryProvider.js 223](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L223) 

 Draws a grid of lines into a canvas.

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/GridImageryProvider.js 288](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L288) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → undefined 

[engine/Source/Scene/GridImageryProvider.js 316](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L316) 

 Picking features is not currently supported by this imagery provider, so this function simply returns undefined.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 Undefined since picking is not supported.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<HTMLCanvasElement> 

[engine/Source/Scene/GridImageryProvider.js 301](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L301) 

 Requests the image for a given tile.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 The resolved image as a Canvas DOM object.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.GridImageryProvider.ConstructorOptions

[engine/Source/Scene/GridImageryProvider.js 11](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GridImageryProvider.js#L11) 

 Initialization options for the GridImageryProvider constructor

##### Properties:

| Name            | Type                              | Attributes | Default                      | Description                                                                                                                                                                                     |
| --------------- | --------------------------------- | ---------- | ---------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| tilingScheme    | [TilingScheme](TilingScheme.html) | <optional> | new GeographicTilingScheme() | The tiling scheme for which to draw tiles.                                                                                                                                                      |
| ellipsoid       | [Ellipsoid](Ellipsoid.html)       | <optional> | Ellipsoid.default            | The ellipsoid. If the tilingScheme is specified, this parameter is ignored and the tiling scheme's ellipsoid is used instead. If neither parameter is specified, the default ellipsoid is used. |
| cells           | number                            | <optional> | 8                            | The number of grids cells.                                                                                                                                                                      |
| color           | [Color](Color.html)               | <optional> | Color(1.0, 1.0, 1.0, 0.4)    | The color to draw grid lines.                                                                                                                                                                   |
| glowColor       | [Color](Color.html)               | <optional> | Color(0.0, 1.0, 0.0, 0.05)   | The color to draw glow for grid lines.                                                                                                                                                          |
| glowWidth       | number                            | <optional> | 6                            | The width of lines used for rendering the line glow effect.                                                                                                                                     |
| backgroundColor | [Color](Color.html)               | <optional> | Color(0.0, 0.5, 0.0, 0.2)    | Background fill color.                                                                                                                                                                          |
| tileWidth       | number                            | <optional> | 256                          | The width of the tile for level-of-detail selection purposes.                                                                                                                                   |
| tileHeight      | number                            | <optional> | 256                          | The height of the tile for level-of-detail selection purposes.                                                                                                                                  |
| canvasSize      | number                            | <optional> | 256                          | The size of the canvas used for rendering.                                                                                                                                                      |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

