# [![](Images/CesiumLogo.png)](index.html) CloudCollection 

#### [](#CloudCollection) new Cesium.CloudCollection(options) 

[engine/Source/Scene/CloudCollection.js 106](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L106) 

 A renderable collection of clouds in the 3D scene.  
  
![](Images/CumulusCloud.png)  
Example cumulus clouds
  
  
Clouds are added and removed from the collection using [CloudCollection#add](CloudCollection.html#add)and [CloudCollection#remove](CloudCollection.html#remove).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description show boolean true optional Whether to display the clouds. noiseDetail number 16.0 optional Desired amount of detail in the noise texture. noiseOffset number Cartesian3.ZERO optional Desired translation of data in noise texture. debugBillboards boolean false optional For debugging only. Determines if the billboards are rendered with an opaque color. debugEllipsoids boolean false optional For debugging only. Determines if the clouds will be rendered as opaque ellipsoids. |

##### Example:

```javascript
// Create a cloud collection with two cumulus clouds
const clouds = scene.primitives.add(new Cesium.CloudCollection());
clouds.add({
  position : new Cesium.Cartesian3(1.0, 2.0, 3.0),
  maximumSize: new Cesium.Cartesian3(20.0, 12.0, 8.0)
});
clouds.add({
  position : new Cesium.Cartesian3(4.0, 5.0, 6.0),
  maximumSize: new Cesium.Cartesian3(15.0, 9.0, 9.0),
  slice: 0.5
});
```

##### Demo:

* [Cesium Sandcastle Clouds Demo](https://sandcastle.cesium.com/index.html?src=Clouds.html)
* [Cesium Sandcastle Cloud Parameters Demo](https://sandcastle.cesium.com/index.html?src=Cloud%2520Parameters.html)

##### See:

* [CloudCollection#add](CloudCollection.html#add)
* [CloudCollection#remove](CloudCollection.html#remove)
* [CumulusCloud](CumulusCloud.html)

### Members

#### [](#debugBillboards) debugBillboards : boolean 

[engine/Source/Scene/CloudCollection.js 215](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L215) 

 This property is for debugging only; it is not for production use nor is it optimized.

Renders the billboards with one opaque color for the sake of debugging.

Default Value: `false` 

#### [](#debugEllipsoids) debugEllipsoids : boolean 

[engine/Source/Scene/CloudCollection.js 229](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L229) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the clouds as opaque, monochrome ellipsoids for the sake of debugging. If `debugBillboards` is also true, then the ellipsoids will draw on top of the billboards.

Default Value: `false` 

#### [](#length) length : number 

[engine/Source/Scene/CloudCollection.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L249) 

 Returns the number of clouds in this collection.

#### [](#noiseDetail) noiseDetail : number 

[engine/Source/Scene/CloudCollection.js 146](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L146) 

Controls the amount of detail captured in the precomputed noise texture used to render the cumulus clouds. In order for the texture to be tileable, this must be a power of two. For best results, set this to be a power of two between `8.0` and `32.0` (inclusive).

| clouds.noiseDetail = 8.0; ![](Images/CloudCollection.noiseDetail8.png) | clouds.noiseDetail = 32.0; ![](Images/CloudCollection.noiseDetail32.png) |
| ---------------------------------------------------------------------- | ------------------------------------------------------------------------ |

Default Value: `16.0` 

#### [](#noiseOffset) noiseOffset : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/CloudCollection.js 170](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L170) 

Applies a translation to noise texture coordinates to generate different data. This can be modified if the default noise does not generate good-looking clouds.

| default ![](Images/CloudCollection.noiseOffsetdefault.png) | clouds.noiseOffset = new Cesium.Cartesian3(10, 20, 10); ![](Images/CloudCollection.noiseOffsetx10y20z10.png) |
| ---------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |

Default Value: `Cartesian3.ZERO` 

#### [](#show) show : boolean 

[engine/Source/Scene/CloudCollection.js 201](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L201) 

 Determines if billboards in this collection will be shown.

Default Value: `true` 

### Methods

#### [](#add) add(options) → [CumulusCloud](CumulusCloud.html) 

[engine/Source/Scene/CloudCollection.js 300](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L300) 

 Creates and adds a cloud with the specified initial properties to the collection. The added cloud is returned so it can be modified or removed from the collection later.

##### Performance:

Calling `add` is expected constant time. However, the collection's vertex buffer is rewritten - an `O(n)` operation that also incurs CPU to GPU overhead. For best performance, add as many clouds as possible before calling `update`.

| Name    | Type   | Description                                                                  |
| ------- | ------ | ---------------------------------------------------------------------------- |
| options | object | optional A template describing the cloud's properties as shown in Example 1. |

##### Returns:

 The cloud that was added to the collection.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Examples:

```javascript
// Example 1:  Add a cumulus cloud, specifying all the default values.
const c = clouds.add({
  show : true,
  position : Cesium.Cartesian3.ZERO,
  scale : new Cesium.Cartesian2(20.0, 12.0),
  maximumSize: new Cesium.Cartesian3(20.0, 12.0, 12.0),
  slice: -1.0,
  cloudType : CloudType.CUMULUS
});
```

```javascript
// Example 2:  Specify only the cloud's cartographic position.
const c = clouds.add({
  position : Cesium.Cartesian3.fromDegrees(longitude, latitude, height)
});
```

##### See:

* [CloudCollection#remove](CloudCollection.html#remove)
* [CloudCollection#removeAll](CloudCollection.html#removeAll)

#### [](#contains) contains(cloud) → boolean 

[engine/Source/Scene/CloudCollection.js 410](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L410) 

 Check whether this collection contains a given cloud.

| Name  | Type                              | Description                      |
| ----- | --------------------------------- | -------------------------------- |
| cloud | [CumulusCloud](CumulusCloud.html) | optional The cloud to check for. |

##### Returns:

 true if this collection contains the cloud, false otherwise.

##### See:

* [CloudCollection#get](CloudCollection.html#get)

#### [](#destroy) destroy() 

[engine/Source/Scene/CloudCollection.js 1033](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L1033) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
clouds = clouds && clouds.destroy();
```

##### See:

* [CloudCollection#isDestroyed](CloudCollection.html#isDestroyed)

#### [](#get) get(index) → [CumulusCloud](CumulusCloud.html) 

[engine/Source/Scene/CloudCollection.js 440](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L440) 

 Returns the cloud in the collection at the specified index. Indices are zero-based and increase as clouds are added. Removing a cloud shifts all clouds after it to the left, changing their indices. This function is commonly used with[CloudCollection#length](CloudCollection.html#length) to iterate over all the clouds in the collection.

##### Performance:

Expected constant time. If clouds were removed from the collection and`CloudCollection#update` was not called, an implicit `O(n)`operation is performed.

| Name  | Type   | Description                        |
| ----- | ------ | ---------------------------------- |
| index | number | The zero-based index of the cloud. |

##### Returns:

 The cloud at the specified index.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
// Toggle the show property of every cloud in the collection
const len = clouds.length;
for (let i = 0; i < len; ++i) {
  const c = clouds.get(i);
  c.show = !c.show;
}
```

##### See:

* [CloudCollection#length](CloudCollection.html#length)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/CloudCollection.js 1013](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L1013) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [CloudCollection#destroy](CloudCollection.html#destroy)

#### [](#remove) remove(cloud) → boolean 

[engine/Source/Scene/CloudCollection.js 337](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L337) 

 Removes a cloud from the collection.

| Name  | Type                              | Description          |
| ----- | --------------------------------- | -------------------- |
| cloud | [CumulusCloud](CumulusCloud.html) | The cloud to remove. |

##### Returns:

`true` if the cloud was removed; `false` if the cloud was not found in the collection.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
const c = clouds.add(...);
clouds.remove(c);  // Returns true
```

##### See:

* [CloudCollection#add](CloudCollection.html#add)
* [CloudCollection#removeAll](CloudCollection.html#removeAll)
* [CumulusCloud#show](CumulusCloud.html#show)

#### [](#removeAll) removeAll() 

[engine/Source/Scene/CloudCollection.js 365](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/CloudCollection.js#L365) 

 Removes all clouds from the collection.

##### Performance:

`O(n)`. It is more efficient to remove all the clouds from a collection and then add new ones than to create a new collection entirely.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
clouds.add(...);
clouds.add(...);
clouds.removeAll();
```

##### See:

* [CloudCollection#add](CloudCollection.html#add)
* [CloudCollection#remove](CloudCollection.html#remove)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

