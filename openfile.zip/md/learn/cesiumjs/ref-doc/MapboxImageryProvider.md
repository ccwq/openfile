# [![](Images/CesiumLogo.png)](index.html) MapboxImageryProvider 

#### [](#MapboxImageryProvider) new Cesium.MapboxImageryProvider(options) 

[engine/Source/Scene/MapboxImageryProvider.js 49](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L49) 

 Provides tiled imagery hosted by Mapbox.

| Name    | Type                                                                                       | Description                              |
| ------- | ------------------------------------------------------------------------------------------ | ---------------------------------------- |
| options | [MapboxImageryProvider.ConstructorOptions](MapboxImageryProvider.html#.ConstructorOptions) | Object describing initialization options |

##### Example:

```javascript
// Mapbox tile provider
const mapbox = new Cesium.MapboxImageryProvider({
    mapId: 'mapbox.mapbox-terrain-v2',
    accessToken: 'thisIsMyAccessToken'
});
```

##### See:

* <https://docs.mapbox.com/api/maps/raster-tiles/>
* <https://docs.mapbox.com/api/accounts/tokens/>

### Members

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/MapboxImageryProvider.js 245](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L245) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/MapboxImageryProvider.js 232](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L232) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error.. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/MapboxImageryProvider.js 273](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L273) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. When this property is false, memory usage and texture upload time are reduced.

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/MapboxImageryProvider.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L176) 

 Gets the maximum level-of-detail that can be requested.

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/MapboxImageryProvider.js 192](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L192) 

 Gets the minimum level-of-detail that can be requested. Generally, a minimum level should only be used when the rectangle of the imagery is small enough that the number of tiles at the minimum level is small. An imagery provider with more than a few tiles at the minimum level will lead to rendering problems.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/MapboxImageryProvider.js 257](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L257) 

 Gets the proxy used by this provider.

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/MapboxImageryProvider.js 140](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L140) 

 Gets the rectangle, in radians, of the imagery provided by the instance.

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/MapboxImageryProvider.js 218](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L218) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/MapboxImageryProvider.js 164](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L164) 

 Gets the height of each tile, in pixels.

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/MapboxImageryProvider.js 152](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L152) 

 Gets the width of each tile, in pixels.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/MapboxImageryProvider.js 204](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L204) 

 Gets the tiling scheme used by the provider.

#### [](#url) readonly url : string 

[engine/Source/Scene/MapboxImageryProvider.js 128](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L128) 

 Gets the URL of the Mapbox server.

### Methods

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/MapboxImageryProvider.js 288](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L288) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → Promise.<Array.<[ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html)\>>|undefined 

[engine/Source/Scene/MapboxImageryProvider.js 320](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L320) 

 Asynchronously determines what features, if any, are located at a given longitude and latitude within a tile. This function is optional, so it may not exist on all ImageryProviders.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 A promise for the picked features that will resolve when the asynchronous picking completes. The resolved value is an array of [ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html) instances. The array may be empty if no features are found at the given location. It may also be undefined if picking is not supported.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<[ImageryTypes](global.html#ImageryTypes)\>|undefined 

[engine/Source/Scene/MapboxImageryProvider.js 302](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L302) 

 Requests the image for a given tile.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 A promise for the image that will resolve when the image is available, or undefined if there are too many active requests to the server, and the request should be retried later.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.MapboxImageryProvider.ConstructorOptions

[engine/Source/Scene/MapboxImageryProvider.js 13](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/MapboxImageryProvider.js#L13) 

 Initialization options for the MapboxImageryProvider constructor

##### Properties:

| Name         | Type                          | Attributes | Default                      | Description                                                                                                                                                                                                                            |
| ------------ | ----------------------------- | ---------- | ---------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| url          | string                        | <optional> | 'https://api.mapbox.com/v4/' | The Mapbox server url.                                                                                                                                                                                                                 |
| mapId        | string                        |            |                              | The Mapbox Map ID.                                                                                                                                                                                                                     |
| accessToken  | string                        |            |                              | The public access token for the imagery.                                                                                                                                                                                               |
| format       | string                        | <optional> | 'png'                        | The format of the image request.                                                                                                                                                                                                       |
| ellipsoid    | [Ellipsoid](Ellipsoid.html)   | <optional> | Ellipsoid.default            | The ellipsoid. If not specified, the default ellipsoid is used.                                                                                                                                                                        |
| minimumLevel | number                        | <optional> | 0                            | The minimum level-of-detail supported by the imagery provider. Take care when specifying this that the number of tiles at the minimum level is small, such as four or less. A larger number is likely to result in rendering problems. |
| maximumLevel | number                        | <optional> |                              | The maximum level-of-detail supported by the imagery provider, or undefined if there is no limit.                                                                                                                                      |
| rectangle    | [Rectangle](Rectangle.html)   | <optional> | Rectangle.MAX\_VALUE         | The rectangle, in radians, covered by the image.                                                                                                                                                                                       |
| credit       | [Credit](Credit.html)\|string | <optional> |                              | A credit for the data source, which is displayed on the canvas.                                                                                                                                                                        |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

