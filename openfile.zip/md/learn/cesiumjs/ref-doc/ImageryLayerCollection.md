# [![](Images/CesiumLogo.png)](index.html) ImageryLayerCollection 

#### [](#ImageryLayerCollection) new Cesium.ImageryLayerCollection() 

[engine/Source/Scene/ImageryLayerCollection.js 19](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L19) 

 An ordered collection of imagery layers.

##### Demo:

* [Cesium Sandcastle Imagery Adjustment Demo](https://sandcastle.cesium.com/index.html?src=Imagery%2520Adjustment.html)
* [Cesium Sandcastle Imagery Manipulation Demo](https://sandcastle.cesium.com/index.html?src=Imagery%2520Layers%2520Manipulation.html)

### Members

#### [](#layerAdded) layerAdded : [Event](Event.html) 

[engine/Source/Scene/ImageryLayerCollection.js 28](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L28) 

 An event that is raised when a layer is added to the collection. Event handlers are passed the layer that was added and the index at which it was added.

Default Value: `Event()` 

#### [](#layerMoved) layerMoved : [Event](Event.html) 

[engine/Source/Scene/ImageryLayerCollection.js 44](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L44) 

 An event that is raised when a layer changes position in the collection. Event handlers are passed the layer that was moved, its new index after the move, and its old index prior to the move.

Default Value: `Event()` 

#### [](#layerRemoved) layerRemoved : [Event](Event.html) 

[engine/Source/Scene/ImageryLayerCollection.js 36](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L36) 

 An event that is raised when a layer is removed from the collection. Event handlers are passed the layer that was removed and the index from which it was removed.

Default Value: `Event()` 

#### [](#layerShownOrHidden) layerShownOrHidden : [Event](Event.html) 

[engine/Source/Scene/ImageryLayerCollection.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L55) 

 An event that is raised when a layer is shown or hidden by setting the[ImageryLayer#show](ImageryLayer.html#show) property. Event handlers are passed a reference to this layer, the index of the layer in the collection, and a flag that is true if the layer is now shown or false if it is now hidden.

Default Value: `Event()` 

#### [](#length) length : number 

[engine/Source/Scene/ImageryLayerCollection.js 64](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L64) 

 Gets the number of layers in this collection.

### Methods

#### [](#add) add(layer, index) 

[engine/Source/Scene/ImageryLayerCollection.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L88) 

 Adds a layer to the collection.

| Name  | Type                              | Description                                                                                                |
| ----- | --------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| layer | [ImageryLayer](ImageryLayer.html) | the layer to add.                                                                                          |
| index | number                            | optional the index to add the layer at. If omitted, the layer will be added on top of all existing layers. |

##### Throws:

* [DeveloperError](DeveloperError.html): index, if supplied, must be greater than or equal to zero and less than or equal to the number of the layers.

##### Examples:

```javascript
const imageryLayer = Cesium.ImageryLayer.fromWorldImagery();
scene.imageryLayers.add(imageryLayer);
```

```javascript
const imageryLayer = Cesium.ImageryLayer.fromProviderAsync(Cesium.IonImageryProvider.fromAssetId(3812));
scene.imageryLayers.add(imageryLayer);
```

#### [](#addImageryProvider) addImageryProvider(imageryProvider, index) → [ImageryLayer](ImageryLayer.html) 

[engine/Source/Scene/ImageryLayerCollection.js 137](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L137) 

 Creates a new layer using the given ImageryProvider and adds it to the collection.

| Name            | Type                                    | Description                                                                                             |
| --------------- | --------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| imageryProvider | [ImageryProvider](ImageryProvider.html) | the imagery provider to create a new layer for.                                                         |
| index           | number                                  | optional the index to add the layer at. If omitted, the layer will added on top of all existing layers. |

##### Returns:

 The newly created layer.

##### Example:

```javascript
try {
   const provider = await Cesium.IonImageryProvider.fromAssetId(3812);
   scene.imageryLayers.addImageryProvider(provider);
} catch (error) {
  console.log(`There was an error creating the imagery layer. ${error}`)
}
```

#### [](#contains) contains(layer) → boolean 

[engine/Source/Scene/ImageryLayerCollection.js 209](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L209) 

 Checks to see if the collection contains a given layer.

| Name  | Type                              | Description             |
| ----- | --------------------------------- | ----------------------- |
| layer | [ImageryLayer](ImageryLayer.html) | the layer to check for. |

##### Returns:

 true if the collection contains the layer, false otherwise.

#### [](#destroy) destroy() 

[engine/Source/Scene/ImageryLayerCollection.js 604](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L604) 

 Destroys the WebGL resources held by all layers in this collection. Explicitly destroying this object allows for deterministic release of WebGL resources, instead of relying on the garbage collector.  
  
Once this object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
layerCollection = layerCollection && layerCollection.destroy();
```

##### See:

* [ImageryLayerCollection#isDestroyed](ImageryLayerCollection.html#isDestroyed)

#### [](#get) get(index) → [ImageryLayer](ImageryLayer.html) 

[engine/Source/Scene/ImageryLayerCollection.js 231](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L231) 

 Gets a layer by index from the collection.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| index | number | the index to retrieve. |

##### Returns:

 The imagery layer at the given index.

#### [](#indexOf) indexOf(layer) → number 

[engine/Source/Scene/ImageryLayerCollection.js 220](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L220) 

 Determines the index of a given layer in the collection.

| Name  | Type                              | Description                     |
| ----- | --------------------------------- | ------------------------------- |
| layer | [ImageryLayer](ImageryLayer.html) | The layer to find the index of. |

##### Returns:

 The index of the layer in the collection, or -1 if the layer does not exist in the collection.

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/ImageryLayerCollection.js 583](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L583) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

 true if this object was destroyed; otherwise, false.

##### See:

* [ImageryLayerCollection#destroy](ImageryLayerCollection.html#destroy)

#### [](#lower) lower(layer) 

[engine/Source/Scene/ImageryLayerCollection.js 298](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L298) 

 Lowers a layer down one position in the collection.

| Name  | Type                              | Description        |
| ----- | --------------------------------- | ------------------ |
| layer | [ImageryLayer](ImageryLayer.html) | the layer to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): layer is not in this collection.
* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

#### [](#lowerToBottom) lowerToBottom(layer) 

[engine/Source/Scene/ImageryLayerCollection.js 332](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L332) 

 Lowers a layer to the bottom of the collection.

| Name  | Type                              | Description        |
| ----- | --------------------------------- | ------------------ |
| layer | [ImageryLayer](ImageryLayer.html) | the layer to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): layer is not in this collection.
* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

#### [](#pickImageryLayerFeatures) pickImageryLayerFeatures(ray, scene) → Promise.<Array.<[ImageryLayerFeatureInfo](ImageryLayerFeatureInfo.html)\>>|undefined 

[engine/Source/Scene/ImageryLayerCollection.js 483](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L483) 

 Asynchronously determines the imagery layer features that are intersected by a pick ray. The intersected imagery layer features are found by invoking [ImageryProvider#pickFeatures](ImageryProvider.html#pickFeatures) for each imagery layer tile intersected by the pick ray. To compute a pick ray from a location on the screen, use `Camera.getPickRay`.

| Name  | Type                | Description                       |
| ----- | ------------------- | --------------------------------- |
| ray   | [Ray](Ray.html)     | The ray to test for intersection. |
| scene | [Scene](Scene.html) | The scene.                        |

##### Returns:

 A promise that resolves to an array of features intersected by the pick ray. If it can be quickly determined that no features are intersected (for example, because no active imagery providers support [ImageryProvider#pickFeatures](ImageryProvider.html#pickFeatures) or because the pick ray does not intersect the surface), this function will return undefined.

##### Example:

```javascript
const pickRay = viewer.camera.getPickRay(windowPosition);
const featuresPromise = viewer.imageryLayers.pickImageryLayerFeatures(pickRay, viewer.scene);
if (!Cesium.defined(featuresPromise)) {
    console.log('No features picked.');
} else {
    Promise.resolve(featuresPromise).then(function(features) {
        // This function is called asynchronously when the list if picked features is available.
        console.log(`Number of features: ${features.length}`);
        if (features.length > 0) {
            console.log(`First feature name: ${features[0].name}`);
        }
    });
}
```

#### [](#pickImageryLayers) pickImageryLayers(ray, scene) → Array.<[ImageryLayer](ImageryLayer.html)\>|undefined 

[engine/Source/Scene/ImageryLayerCollection.js 432](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L432) 

 Determines the imagery layers that are intersected by a pick ray. To compute a pick ray from a location on the screen, use `Camera.getPickRay`.

| Name  | Type                | Description                       |
| ----- | ------------------- | --------------------------------- |
| ray   | [Ray](Ray.html)     | The ray to test for intersection. |
| scene | [Scene](Scene.html) | The scene.                        |

##### Returns:

 An array that includes all of the layers that are intersected by a given pick ray. Undefined if no layers are selected.

#### [](#raise) raise(layer) 

[engine/Source/Scene/ImageryLayerCollection.js 285](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L285) 

 Raises a layer up one position in the collection.

| Name  | Type                              | Description        |
| ----- | --------------------------------- | ------------------ |
| layer | [ImageryLayer](ImageryLayer.html) | the layer to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): layer is not in this collection.
* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

#### [](#raiseToTop) raiseToTop(layer) 

[engine/Source/Scene/ImageryLayerCollection.js 311](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L311) 

 Raises a layer to the top of the collection.

| Name  | Type                              | Description        |
| ----- | --------------------------------- | ------------------ |
| layer | [ImageryLayer](ImageryLayer.html) | the layer to move. |

##### Throws:

* [DeveloperError](DeveloperError.html): layer is not in this collection.
* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

#### [](#remove) remove(layer, destroy) → boolean 

[engine/Source/Scene/ImageryLayerCollection.js 160](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L160) 

 Removes a layer from this collection, if present.

| Name    | Type                              | Default | Description                                                          |
| ------- | --------------------------------- | ------- | -------------------------------------------------------------------- |
| layer   | [ImageryLayer](ImageryLayer.html) |         | The layer to remove.                                                 |
| destroy | boolean                           | true    | optional whether to destroy the layers in addition to removing them. |

##### Returns:

 true if the layer was in the collection and was removed, false if the layer was not in the collection.

#### [](#removeAll) removeAll(destroy) 

[engine/Source/Scene/ImageryLayerCollection.js 186](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/ImageryLayerCollection.js#L186) 

 Removes all layers from this collection.

| Name    | Type    | Default | Description                                                          |
| ------- | ------- | ------- | -------------------------------------------------------------------- |
| destroy | boolean | true    | optional whether to destroy the layers in addition to removing them. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

