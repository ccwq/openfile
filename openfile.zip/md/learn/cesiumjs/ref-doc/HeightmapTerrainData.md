# [![](Images/CesiumLogo.png)](index.html) HeightmapTerrainData 

#### [](#HeightmapTerrainData) new Cesium.HeightmapTerrainData(options) 

[engine/Source/Core/HeightmapTerrainData.js 96](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeightmapTerrainData.js#L96) 

 Terrain data for a single tile where the terrain data is represented as a heightmap. A heightmap is a rectangular array of heights in row-major order from north to south and west to east.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description buffer Int8Array\|Uint8Array|Int16Array|Uint16Array|Int32Array|Uint32Array|Float32Array|Float64Array  The buffer containing height data. width number  The width (longitude direction) of the heightmap, in samples. height number  The height (latitude direction) of the heightmap, in samples. childTileMask number 15 optional A bit mask indicating which of this tile's four children exist. If a child's bit is set, geometry will be requested for that tile as well when it is needed. If the bit is cleared, the child tile is not requested and geometry is instead upsampled from the parent. The bit values are as follows: Bit PositionBit ValueChild Tile 01Southwest 12Southeast 24Northwest 38Northeast waterMask Uint8Array optional The water mask included in this terrain data, if any. A water mask is a square Uint8Array or image where a value of 255 indicates water and a value of 0 indicates land. Values in between 0 and 255 are allowed as well to smoothly blend between land and water. structure object optional An object describing the structure of the height data. Name Type Default Description heightScale number 1.0 optional The factor by which to multiply height samples in order to obtain the height above the heightOffset, in meters. The heightOffset is added to the resulting height after multiplying by the scale. heightOffset number 0.0 optional The offset to add to the scaled height to obtain the final height in meters. The offset is added after the height sample is multiplied by the heightScale. elementsPerHeight number 1 optional The number of elements in the buffer that make up a single height sample. This is usually 1, indicating that each element is a separate height sample. If it is greater than 1, that number of elements together form the height sample, which is computed according to the structure.elementMultiplier and structure.isBigEndian properties. stride number 1 optional The number of elements to skip to get from the first element of one height to the first element of the next height. elementMultiplier number 256.0 optional The multiplier used to compute the height value when the stride property is greater than 1\. For example, if the stride is 4 and the strideMultiplier is 256, the height is computed as follows: \`height = buffer\[index\] + buffer\[index + 1\] \* 256 + buffer\[index + 2\] \* 256 \* 256 + buffer\[index + 3\] \* 256 \* 256 \* 256\` This is assuming that the isBigEndian property is false. If it is true, the order of the elements is reversed. isBigEndian boolean false optional Indicates endianness of the elements in the buffer when the stride property is greater than 1\. If this property is false, the first element is the low-order element. If it is true, the first element is the high-order element. lowestEncodedHeight number optional The lowest value that can be stored in the height buffer. Any heights that are lower than this value after encoding with the \`heightScale\` and \`heightOffset\` are clamped to this value. For example, if the height buffer is a \`Uint16Array\`, this value should be 0 because a \`Uint16Array\` cannot store negative numbers. If this parameter is not specified, no minimum value is enforced. highestEncodedHeight number optional The highest value that can be stored in the height buffer. Any heights that are higher than this value after encoding with the \`heightScale\` and \`heightOffset\` are clamped to this value. For example, if the height buffer is a \`Uint16Array\`, this value should be \`256 \* 256 - 1\` or 65535 because a \`Uint16Array\` cannot store numbers larger than 65535\. If this parameter is not specified, no maximum value is enforced. encoding [HeightmapEncoding](global.html#HeightmapEncoding) HeightmapEncoding.NONE optional The encoding that is used on the buffer. createdByUpsampling boolean false optional True if this instance was created by upsampling another instance; otherwise, false. |

##### Example:

```javascript
const buffer = ...
const heightBuffer = new Uint16Array(buffer, 0, that._heightmapWidth * that._heightmapWidth);
const childTileMask = new Uint8Array(buffer, heightBuffer.byteLength, 1)[0];
const waterMask = new Uint8Array(buffer, heightBuffer.byteLength + 1, buffer.byteLength - heightBuffer.byteLength - 1);
const terrainData = new Cesium.HeightmapTerrainData({
  buffer : heightBuffer,
  width : 65,
  height : 65,
  childTileMask : childTileMask,
  waterMask : waterMask
});
```

##### See:

* [TerrainData](TerrainData.html)
* [QuantizedMeshTerrainData](QuantizedMeshTerrainData.html)
* [GoogleEarthEnterpriseTerrainData](GoogleEarthEnterpriseTerrainData.html)

### Members

#### [](#credits) credits : Array.<[Credit](Credit.html)\> 

[engine/Source/Core/HeightmapTerrainData.js 161](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeightmapTerrainData.js#L161) 

 An array of credits for this tile.

#### [](#waterMask) waterMask : Uint8Array|HTMLImageElement|HTMLCanvasElement 

[engine/Source/Core/HeightmapTerrainData.js 173](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeightmapTerrainData.js#L173) 

 The water mask included in this terrain data, if any. A water mask is a square Uint8Array or image where a value of 255 indicates water and a value of 0 indicates land. Values in between 0 and 255 are allowed as well to smoothly blend between land and water.

### Methods

#### [](#interpolateHeight) interpolateHeight(rectangle, longitude, latitude) → number 

[engine/Source/Core/HeightmapTerrainData.js 436](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeightmapTerrainData.js#L436) 

 Computes the terrain height at a specified longitude and latitude.

| Name      | Type                        | Description                                 |
| --------- | --------------------------- | ------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html) | The rectangle covered by this terrain data. |
| longitude | number                      | The longitude in radians.                   |
| latitude  | number                      | The latitude in radians.                    |

##### Returns:

 The terrain height at the specified position. If the position is outside the rectangle, this method will extrapolate the height, which is likely to be wildly incorrect for positions far outside the rectangle.

#### [](#isChildAvailable) isChildAvailable(thisX, thisY, childX, childY) → boolean 

[engine/Source/Core/HeightmapTerrainData.js 657](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeightmapTerrainData.js#L657) 

 Determines if a given child tile is available, based on the`HeightmapTerrainData.childTileMask`. The given child tile coordinates are assumed to be one of the four children of this tile. If non-child tile coordinates are given, the availability of the southeast child tile is returned.

| Name   | Type   | Description                                                        |
| ------ | ------ | ------------------------------------------------------------------ |
| thisX  | number | The tile X coordinate of this (the parent) tile.                   |
| thisY  | number | The tile Y coordinate of this (the parent) tile.                   |
| childX | number | The tile X coordinate of the child tile to check for availability. |
| childY | number | The tile Y coordinate of the child tile to check for availability. |

##### Returns:

 True if the child tile is available; otherwise, false.

#### [](#upsample) upsample(tilingScheme, thisX, thisY, thisLevel, descendantX, descendantY, descendantLevel) → Promise.<[HeightmapTerrainData](HeightmapTerrainData.html)\>|undefined 

[engine/Source/Core/HeightmapTerrainData.js 510](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeightmapTerrainData.js#L510) 

 Upsamples this terrain data for use by a descendant tile. The resulting instance will contain a subset of the height samples in this instance, interpolated if necessary.

| Name            | Type                              | Description                                                                                   |
| --------------- | --------------------------------- | --------------------------------------------------------------------------------------------- |
| tilingScheme    | [TilingScheme](TilingScheme.html) | The tiling scheme of this terrain data.                                                       |
| thisX           | number                            | The X coordinate of this tile in the tiling scheme.                                           |
| thisY           | number                            | The Y coordinate of this tile in the tiling scheme.                                           |
| thisLevel       | number                            | The level of this tile in the tiling scheme.                                                  |
| descendantX     | number                            | The X coordinate within the tiling scheme of the descendant tile for which we are upsampling. |
| descendantY     | number                            | The Y coordinate within the tiling scheme of the descendant tile for which we are upsampling. |
| descendantLevel | number                            | The level within the tiling scheme of the descendant tile for which we are upsampling.        |

##### Returns:

 A promise for upsampled heightmap terrain data for the descendant tile, or undefined if the mesh is unavailable.

#### [](#wasCreatedByUpsampling) wasCreatedByUpsampling() → boolean 

[engine/Source/Core/HeightmapTerrainData.js 697](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/HeightmapTerrainData.js#L697) 

 Gets a value indicating whether or not this terrain data was created by upsampling lower resolution terrain data. If this value is false, the data was obtained from some other source, such as by downloading it from a remote server. This method should return true for instances returned from a call to [HeightmapTerrainData#upsample](HeightmapTerrainData.html#upsample).

##### Returns:

 True if this instance was created by upsampling; otherwise, false.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

