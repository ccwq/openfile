# [![](Images/CesiumLogo.png)](index.html) WallGeometry 

#### [](#WallGeometry) new Cesium.WallGeometry(options) 

[engine/Source/Core/WallGeometry.js 64](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallGeometry.js#L64) 

 A description of a wall, which is similar to a KML line string. A wall is defined by a series of points, which extrude down to the ground. Optionally, they can extrude downwards to a specified height.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of Cartesian objects, which are the points of the wall. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The distance, in radians, between each latitude and longitude. Determines the number of positions in the buffer. maximumHeights Array.<number> optional An array parallel to positions that give the maximum height of the wall at positions. If undefined, the height of each position in used. minimumHeights Array.<number> optional An array parallel to positions that give the minimum height of the wall at positions. If undefined, the height at each position is 0.0. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid for coordinate manipulation vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. |

##### Throws:

* [DeveloperError](DeveloperError.html): positions length must be greater than or equal to 2.
* [DeveloperError](DeveloperError.html): positions and maximumHeights must have the same length.
* [DeveloperError](DeveloperError.html): positions and minimumHeights must have the same length.

##### Example:

```javascript
// create a wall that spans from ground level to 10000 meters
const wall = new Cesium.WallGeometry({
  positions : Cesium.Cartesian3.fromDegreesArrayHeights([
    19.0, 47.0, 10000.0,
    19.0, 48.0, 10000.0,
    20.0, 48.0, 10000.0,
    20.0, 47.0, 10000.0,
    19.0, 47.0, 10000.0
  ])
});
const geometry = Cesium.WallGeometry.createGeometry(wall);
```

##### Demo:

* [Cesium Sandcastle Wall Demo](https://sandcastle.cesium.com/index.html?src=Wall.html)

##### See:

* WallGeometry#createGeometry
* WallGeometry#fromConstantHeight

### Members

#### [](#packedLength) packedLength : number 

[engine/Source/Core/WallGeometry.js 120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallGeometry.js#L120) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.WallGeometry.createGeometry(wallGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/WallGeometry.js 355](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallGeometry.js#L355) 

 Computes the geometric representation of a wall, including its vertices, indices, and a bounding sphere.

| Name         | Type                              | Description                |
| ------------ | --------------------------------- | -------------------------- |
| wallGeometry | [WallGeometry](WallGeometry.html) | A description of the wall. |

##### Returns:

 The computed vertices and indices.

#### [](#.fromConstantHeights) static Cesium.WallGeometry.fromConstantHeights(options) → [WallGeometry](WallGeometry.html) 

[engine/Source/Core/WallGeometry.js 305](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallGeometry.js#L305) 

 A description of a wall, which is similar to a KML line string. A wall is defined by a series of points, which extrude down to the ground. Optionally, they can extrude downwards to a specified height.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of Cartesian objects, which are the points of the wall. maximumHeight number optional A constant that defines the maximum height of the wall at positions. If undefined, the height of each position in used. minimumHeight number optional A constant that defines the minimum height of the wall at positions. If undefined, the height at each position is 0.0. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid for coordinate manipulation vertexFormat [VertexFormat](VertexFormat.html) VertexFormat.DEFAULT optional The vertex attributes to be computed. |

##### Returns:

##### Example:

```javascript
// create a wall that spans from 10000 meters to 20000 meters
const wall = Cesium.WallGeometry.fromConstantHeights({
  positions : Cesium.Cartesian3.fromDegreesArray([
    19.0, 47.0,
    19.0, 48.0,
    20.0, 48.0,
    20.0, 47.0,
    19.0, 47.0,
  ]),
  minimumHeight : 20000.0,
  maximumHeight : 10000.0
});
const geometry = Cesium.WallGeometry.createGeometry(wall);
```

##### See:

* WallGeometry#createGeometry

#### [](#.pack) static Cesium.WallGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/WallGeometry.js 133](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallGeometry.js#L133) 

 Stores the provided instance into the provided array.

| Name          | Type                              | Default | Description                                                               |
| ------------- | --------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [WallGeometry](WallGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                    |         | The array to pack into.                                                   |
| startingIndex | number                            | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.WallGeometry.unpack(array, startingIndex, result) → [WallGeometry](WallGeometry.html) 

[engine/Source/Core/WallGeometry.js 205](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WallGeometry.js#L205) 

 Retrieves an instance from a packed array.

| Name          | Type                              | Default | Description                                                |
| ------------- | --------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                    |         | The packed array.                                          |
| startingIndex | number                            | 0       | optional The starting index of the element to be unpacked. |
| result        | [WallGeometry](WallGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new WallGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

