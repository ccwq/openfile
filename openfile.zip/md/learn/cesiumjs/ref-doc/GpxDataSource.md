# [![](Images/CesiumLogo.png)](index.html) GpxDataSource 

#### [](#GpxDataSource) new Cesium.GpxDataSource() 

[engine/Source/DataSources/GpxDataSource.js 750](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L750) 

 A [DataSource](DataSource.html) which processes the GPS Exchange Format (GPX).

##### Example:

```javascript
const viewer = new Cesium.Viewer('cesiumContainer');
viewer.dataSources.add(Cesium.GpxDataSource.load('../../SampleData/track.gpx'));
```

##### Demo:

* <http://sandcastle.cesium.com/index.html?src=GPX.html>

##### See:

* [Topografix GPX Standard](http://www.topografix.com/gpx.asp)
* [Topografix GPX Documentation](http://www.topografix.com/gpx/1/1/)

### Members

#### [](#changedEvent) changedEvent : [Event](Event.html) 

[engine/Source/DataSources/GpxDataSource.js 860](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L860) 

 Gets an event that will be raised when the underlying data changes.

#### [](#clock) clock : [DataSourceClock](DataSourceClock.html) 

[engine/Source/DataSources/GpxDataSource.js 830](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L830) 

 Gets the clock settings defined by the loaded GPX. This represents the total availability interval for all time-dynamic data. If the GPX does not contain time-dynamic data, this value is undefined.

#### [](#clustering) clustering : [EntityCluster](EntityCluster.html) 

[engine/Source/DataSources/GpxDataSource.js 905](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L905) 

 Gets or sets the clustering options for this data source. This object can be shared between multiple data sources.

#### [](#creator) creator : string 

[engine/Source/DataSources/GpxDataSource.js 808](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L808) 

 Gets the creator of the GPX document.

#### [](#entities) entities : [EntityCollection](EntityCollection.html) 

[engine/Source/DataSources/GpxDataSource.js 840](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L840) 

 Gets the collection of [Entity](Entity.html) instances.

#### [](#errorEvent) errorEvent : [Event](Event.html) 

[engine/Source/DataSources/GpxDataSource.js 870](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L870) 

 Gets an event that will be raised if an error is encountered during processing.

#### [](#isLoading) isLoading : boolean 

[engine/Source/DataSources/GpxDataSource.js 850](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L850) 

 Gets a value indicating if the data source is currently loading data.

#### [](#loadingEvent) loadingEvent : [Event](Event.html) 

[engine/Source/DataSources/GpxDataSource.js 880](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L880) 

 Gets an event that will be raised when the data source either starts or stops loading.

#### [](#metadata) metadata : object 

[engine/Source/DataSources/GpxDataSource.js 818](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L818) 

 Gets an object containing metadata about the GPX file.

#### [](#name) name : string 

[engine/Source/DataSources/GpxDataSource.js 788](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L788) 

 Gets a human-readable name for this instance. This will be automatically be set to the GPX document name on load.

#### [](#show) show : boolean 

[engine/Source/DataSources/GpxDataSource.js 890](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L890) 

 Gets whether or not this data source should be displayed.

#### [](#version) version : string 

[engine/Source/DataSources/GpxDataSource.js 798](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L798) 

 Gets the version of the GPX Schema in use.

### Methods

#### [](#.load) static Cesium.GpxDataSource.load(data, options) → Promise.<[GpxDataSource](GpxDataSource.html)\> 

[engine/Source/DataSources/GpxDataSource.js 777](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L777) 

 Creates a Promise to a new instance loaded with the provided GPX data.

| Name    | Type                  | Description                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ------- | --------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| data    | string\|Document|Blob | A url, parsed GPX document, or Blob containing binary GPX data.                                                                                                                                                                                                                                                                                                                                                                     |
| options | object                | optional An object with the following properties: Name Type Description clampToGround boolean optional True if the symbols should be rendered at the same height as the terrain waypointImage string optional Image to use for waypoint billboards. trackImage string optional Image to use for track billboards. trackColor string optional Color to use for track lines. routeColor string optional Color to use for route lines. |

##### Returns:

 A promise that will resolve to a new GpxDataSource instance once the gpx is loaded.

#### [](#load) load(data, options) → Promise.<[GpxDataSource](GpxDataSource.html)\> 

[engine/Source/DataSources/GpxDataSource.js 945](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L945) 

 Asynchronously loads the provided GPX data, replacing any existing data.

| Name    | Type                  | Description                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ------- | --------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| data    | string\|Document|Blob | A url, parsed GPX document, or Blob containing binary GPX data or a parsed GPX document.                                                                                                                                                                                                                                                                                                                                            |
| options | object                | optional An object with the following properties: Name Type Description clampToGround boolean optional True if the symbols should be rendered at the same height as the terrain waypointImage string optional Image to use for waypoint billboards. trackImage string optional Image to use for track billboards. trackColor string optional Color to use for track lines. routeColor string optional Color to use for route lines. |

##### Returns:

 A promise that will resolve to this instances once the GPX is loaded.

#### [](#update) update(time) → boolean 

[engine/Source/DataSources/GpxDataSource.js 929](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/GpxDataSource.js#L929) 

 Updates the data source to the provided time. This function is optional and is not required to be implemented. It is provided for data sources which retrieve data based on the current animation time or scene state. If implemented, update will be called by [DataSourceDisplay](DataSourceDisplay.html) once a frame.

| Name | Type                          | Description          |
| ---- | ----------------------------- | -------------------- |
| time | [JulianDate](JulianDate.html) | The simulation time. |

##### Returns:

 True if this data source is ready to be displayed at the provided time, false otherwise.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

