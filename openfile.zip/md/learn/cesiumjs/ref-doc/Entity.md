# [![](Images/CesiumLogo.png)](index.html) Entity 

#### [](#Entity) new Cesium.Entity(options) 

[engine/Source/DataSources/Entity.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L114) 

 Entity instances aggregate multiple forms of visualization into a single high-level object. They can be created manually and added to [Viewer#entities](Viewer.html#entities) or be produced by data sources, such as [CzmlDataSource](CzmlDataSource.html) and [GeoJsonDataSource](GeoJsonDataSource.html).

| Name    | Type                                                         | Description                                       |
| ------- | ------------------------------------------------------------ | ------------------------------------------------- |
| options | [Entity.ConstructorOptions](Entity.html#.ConstructorOptions) | optional Object describing initialization options |

##### See:

* [Creating Entities](https://cesium.com/learn/cesiumjs-learn/cesiumjs-creating-entities/)

### Members

#### [](#availability) availability : [TimeIntervalCollection](TimeIntervalCollection.html)|undefined 

[engine/Source/DataSources/Entity.js 243](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L243) 

 The availability, if any, associated with this object. If availability is undefined, it is assumed that this object's other properties will return valid data for any provided time. If availability exists, the objects other properties will only provide valid data if queried within the given interval.

#### [](#billboard) billboard : [BillboardGraphics](BillboardGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 379](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L379) 

 Gets or sets the billboard.

#### [](#box) box : [BoxGraphics](BoxGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 385](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L385) 

 Gets or sets the box.

#### [](#corridor) corridor : [CorridorGraphics](CorridorGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 391](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L391) 

 Gets or sets the corridor.

#### [](#cylinder) cylinder : [CylinderGraphics](CylinderGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 397](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L397) 

 Gets or sets the cylinder.

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/Entity.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L261) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#description) description : [Property](Property.html)|undefined 

[engine/Source/DataSources/Entity.js 403](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L403) 

 Gets or sets the description.

#### [](#ellipse) ellipse : [EllipseGraphics](EllipseGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 409](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L409) 

 Gets or sets the ellipse.

#### [](#ellipsoid) ellipsoid : [EllipsoidGraphics](EllipsoidGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 415](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L415) 

 Gets or sets the ellipsoid.

#### [](#entityCollection) entityCollection : [EntityCollection](EntityCollection.html) 

[engine/Source/DataSources/Entity.js 208](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L208) 

 Gets or sets the entity collection that this entity belongs to.

#### [](#id) id : string 

[engine/Source/DataSources/Entity.js 249](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L249) 

 Gets the unique ID associated with this object.

#### [](#isShowing) isShowing : boolean 

[engine/Source/DataSources/Entity.js 319](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L319) 

 Gets whether this entity is being displayed, taking into account the visibility of any ancestor entities.

#### [](#label) label : [LabelGraphics](LabelGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 421](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L421) 

 Gets or sets the label.

#### [](#model) model : [ModelGraphics](ModelGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 427](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L427) 

 Gets or sets the model.

#### [](#name) name : string|undefined 

[engine/Source/DataSources/Entity.js 272](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L272) 

 Gets or sets the name of the object. The name is intended for end-user consumption and does not need to be unique.

#### [](#orientation) orientation : [Property](Property.html)|undefined 

[engine/Source/DataSources/Entity.js 440](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L440) 

 Gets or sets the orientation in respect to Earth-fixed-Earth-centered (ECEF). Defaults to east-north-up at entity position.

#### [](#parent) parent : [Entity](Entity.html)|undefined 

[engine/Source/DataSources/Entity.js 333](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L333) 

 Gets or sets the parent object.

#### [](#path) path : [PathGraphics](PathGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 446](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L446) 

 Gets or sets the path.

#### [](#plane) plane : [PlaneGraphics](PlaneGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 452](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L452) 

 Gets or sets the plane.

#### [](#point) point : [PointGraphics](PointGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 458](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L458) 

 Gets or sets the point graphic.

#### [](#polygon) polygon : [PolygonGraphics](PolygonGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 464](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L464) 

 Gets or sets the polygon.

#### [](#polyline) polyline : [PolylineGraphics](PolylineGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 470](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L470) 

 Gets or sets the polyline.

#### [](#polylineVolume) polylineVolume : [PolylineVolumeGraphics](PolylineVolumeGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 476](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L476) 

 Gets or sets the polyline volume.

#### [](#position) position : [PositionProperty](PositionProperty.html)|undefined 

[engine/Source/DataSources/Entity.js 491](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L491) 

 Gets or sets the position.

#### [](#properties) properties : [PropertyBag](PropertyBag.html)|undefined 

[engine/Source/DataSources/Entity.js 485](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L485) 

 Gets or sets the bag of arbitrary properties associated with this entity.

#### [](#propertyNames) propertyNames : Array.<string> 

[engine/Source/DataSources/Entity.js 369](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L369) 

 Gets the names of all properties registered on this instance.

#### [](#rectangle) rectangle : [RectangleGraphics](RectangleGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 497](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L497) 

 Gets or sets the rectangle.

#### [](#show) show : boolean 

[engine/Source/DataSources/Entity.js 279](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L279) 

 Gets or sets whether this entity should be displayed. When set to true, the entity is only displayed if the parent entity's show property is also true.

#### [](#tileset) tileset : [Cesium3DTilesetGraphics](Cesium3DTilesetGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 433](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L433) 

 Gets or sets the tileset.

#### [](#trackingReferenceFrame) trackingReferenceFrame : [TrackingReferenceFrame](global.html#TrackingReferenceFrame) 

[engine/Source/DataSources/Entity.js 312](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L312) 

 Gets or sets the entity's tracking reference frame.

##### Demo:

* [Cesium Sandcastle Entity tracking Demo](https://sandcastle.cesium.com/index.html?src=Entity%20tracking.html)

#### [](#viewFrom) viewFrom : [Property](Property.html)|undefined 

[engine/Source/DataSources/Entity.js 505](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L505) 

 Gets or sets the suggested initial offset when tracking this object. The offset is typically defined in the east-north-up reference frame, but may be another frame depending on the object's velocity.

#### [](#wall) wall : [WallGraphics](WallGraphics.html)|undefined 

[engine/Source/DataSources/Entity.js 511](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L511) 

 Gets or sets the wall.

### Methods

#### [](#.supportsMaterialsforEntitiesOnTerrain) static Cesium.Entity.supportsMaterialsforEntitiesOnTerrain(scene) → boolean 

[engine/Source/DataSources/Entity.js 776](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L776) 

 Checks if the given Scene supports materials besides Color on Entities draped on terrain or 3D Tiles. If this feature is not supported, Entities with non-color materials but no \`height\` will instead be rendered as if height is 0.

| Name  | Type                | Description        |
| ----- | ------------------- | ------------------ |
| scene | [Scene](Scene.html) | The current scene. |

##### Returns:

 Whether or not the current scene supports materials for entities on terrain.

#### [](#.supportsPolylinesOnTerrain) static Cesium.Entity.supportsPolylinesOnTerrain(scene) → boolean 

[engine/Source/DataSources/Entity.js 788](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L788) 

 Checks if the given Scene supports polylines clamped to terrain or 3D Tiles. If this feature is not supported, Entities with PolylineGraphics will be rendered with vertices at the provided heights and using the \`arcType\` parameter instead of clamped to the ground.

| Name  | Type                | Description        |
| ----- | ------------------- | ------------------ |
| scene | [Scene](Scene.html) | The current scene. |

##### Returns:

 Whether or not the current scene supports polylines on terrain or 3D TIles.

#### [](#addProperty) addProperty(propertyName) 

[engine/Source/DataSources/Entity.js 556](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L556) 

 Adds a property to this object. Once a property is added, it can be observed with [Entity#definitionChanged](Entity.html#definitionChanged) and composited with [CompositeEntityCollection](CompositeEntityCollection.html) 

| Name         | Type   | Description                      |
| ------------ | ------ | -------------------------------- |
| propertyName | string | The name of the property to add. |

##### Throws:

* [DeveloperError](DeveloperError.html): "propertyName" is a reserved property name.
* [DeveloperError](DeveloperError.html): "propertyName" is already a registered property.

#### [](#computeModelMatrix) computeModelMatrix(time, result) → [Matrix4](Matrix4.html) 

[engine/Source/DataSources/Entity.js 682](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L682) 

 Computes the model matrix for the entity's transform at specified time. Returns undefined if position is undefined

| Name   | Type                          | Description                                         |
| ------ | ----------------------------- | --------------------------------------------------- |
| time   | [JulianDate](JulianDate.html) | The time to retrieve model matrix for.              |
| result | [Matrix4](Matrix4.html)       | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new Matrix4 instance if one was not provided. Result is undefined if position is undefined.

#### [](#isAvailable) isAvailable(time) → boolean 

[engine/Source/DataSources/Entity.js 535](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L535) 

 Given a time, returns true if this object should have data during that time.

| Name | Type                          | Description                         |
| ---- | ----------------------------- | ----------------------------------- |
| time | [JulianDate](JulianDate.html) | The time to check availability for. |

##### Returns:

 true if the object should have data during the provided time, false otherwise.

#### [](#merge) merge(source) 

[engine/Source/DataSources/Entity.js 612](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L612) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                  | Description                               |
| ------ | --------------------- | ----------------------------------------- |
| source | [Entity](Entity.html) | The object to be merged into this object. |

#### [](#removeProperty) removeProperty(propertyName) 

[engine/Source/DataSources/Entity.js 589](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L589) 

 Removed a property previously added with addProperty.

| Name         | Type   | Description                         |
| ------------ | ------ | ----------------------------------- |
| propertyName | string | The name of the property to remove. |

##### Throws:

* [DeveloperError](DeveloperError.html): "propertyName" is a reserved property name.
* [DeveloperError](DeveloperError.html): "propertyName" is not a registered property.

### Type Definitions

#### [](#.ConstructorOptions) Cesium.Entity.ConstructorOptions

[engine/Source/DataSources/Entity.js 68](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/Entity.js#L68) 

 Initialization options for the Entity constructor

##### Properties:

| Name                   | Type                                                                                                                                                    | Attributes | Default                                      | Description                                                                                                                                                                                                                                                                                                                                  |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------- | -------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| id                     | string                                                                                                                                                  | <optional> |                                              | A unique identifier for this object. If none is provided, a GUID is generated.                                                                                                                                                                                                                                                               |
| name                   | string                                                                                                                                                  | <optional> |                                              | A human readable name to display to users. It does not have to be unique.                                                                                                                                                                                                                                                                    |
| availability           | [TimeIntervalCollection](TimeIntervalCollection.html)                                                                                                   | <optional> |                                              | The availability, if any, associated with this object.                                                                                                                                                                                                                                                                                       |
| show                   | boolean                                                                                                                                                 | <optional> |                                              | A boolean value indicating if the entity and its children are displayed.                                                                                                                                                                                                                                                                     |
| trackingReferenceFrame | [TrackingReferenceFrame](global.html#TrackingReferenceFrame)                                                                                            | <optional> | TrackingReferenceFrame.AUTODETECT            | The reference frame used when this entity is being tracked.  If undefined, reference frame is determined based on entity velocity: near-surface slow moving entities are tracked using the local east-north-up reference frame, whereas fast moving entities such as satellites are tracked using VVLH (Vehicle Velocity, Local Horizontal). |
| description            | [Property](Property.html)\|string                                                                                                                       | <optional> |                                              | A string Property specifying an HTML description for this entity.                                                                                                                                                                                                                                                                            |
| position               | [PositionProperty](PositionProperty.html)\|[Cartesian3](Cartesian3.html)|[CallbackPositionProperty](CallbackPositionProperty.html)                      | <optional> |                                              | A Property specifying the entity position.                                                                                                                                                                                                                                                                                                   |
| orientation            | [Property](Property.html)\|[Quaternion](Quaternion.html)                                                                                                | <optional> | Transforms.eastNorthUpToFixedFrame(position) | A Property specifying the entity orientation in respect to Earth-fixed-Earth-centered (ECEF). If undefined, east-north-up at entity position is used.                                                                                                                                                                                        |
| viewFrom               | [Property](Property.html)\|[Cartesian3](Cartesian3.html)                                                                                                | <optional> |                                              | A suggested initial offset for viewing this object.                                                                                                                                                                                                                                                                                          |
| parent                 | [Entity](Entity.html)                                                                                                                                   | <optional> |                                              | A parent entity to associate with this entity.                                                                                                                                                                                                                                                                                               |
| billboard              | [BillboardGraphics](BillboardGraphics.html)\|[BillboardGraphics.ConstructorOptions](BillboardGraphics.html#.ConstructorOptions)                         | <optional> |                                              | A billboard to associate with this entity.                                                                                                                                                                                                                                                                                                   |
| box                    | [BoxGraphics](BoxGraphics.html)\|[BoxGraphics.ConstructorOptions](BoxGraphics.html#.ConstructorOptions)                                                 | <optional> |                                              | A box to associate with this entity.                                                                                                                                                                                                                                                                                                         |
| corridor               | [CorridorGraphics](CorridorGraphics.html)\|[CorridorGraphics.ConstructorOptions](CorridorGraphics.html#.ConstructorOptions)                             | <optional> |                                              | A corridor to associate with this entity.                                                                                                                                                                                                                                                                                                    |
| cylinder               | [CylinderGraphics](CylinderGraphics.html)\|[CylinderGraphics.ConstructorOptions](CylinderGraphics.html#.ConstructorOptions)                             | <optional> |                                              | A cylinder to associate with this entity.                                                                                                                                                                                                                                                                                                    |
| ellipse                | [EllipseGraphics](EllipseGraphics.html)\|[EllipseGraphics.ConstructorOptions](EllipseGraphics.html#.ConstructorOptions)                                 | <optional> |                                              | A ellipse to associate with this entity.                                                                                                                                                                                                                                                                                                     |
| ellipsoid              | [EllipsoidGraphics](EllipsoidGraphics.html)\|[EllipsoidGraphics.ConstructorOptions](EllipsoidGraphics.html#.ConstructorOptions)                         | <optional> |                                              | A ellipsoid to associate with this entity.                                                                                                                                                                                                                                                                                                   |
| label                  | [LabelGraphics](LabelGraphics.html)\|[LabelGraphics.ConstructorOptions](LabelGraphics.html#.ConstructorOptions)                                         | <optional> |                                              | A options.label to associate with this entity.                                                                                                                                                                                                                                                                                               |
| model                  | [ModelGraphics](ModelGraphics.html)\|[ModelGraphics.ConstructorOptions](ModelGraphics.html#.ConstructorOptions)                                         | <optional> |                                              | A model to associate with this entity.                                                                                                                                                                                                                                                                                                       |
| tileset                | [Cesium3DTilesetGraphics](Cesium3DTilesetGraphics.html)\|[Cesium3DTilesetGraphics.ConstructorOptions](Cesium3DTilesetGraphics.html#.ConstructorOptions) | <optional> |                                              | A 3D Tiles tileset to associate with this entity.                                                                                                                                                                                                                                                                                            |
| path                   | [PathGraphics](PathGraphics.html)\|[PathGraphics.ConstructorOptions](PathGraphics.html#.ConstructorOptions)                                             | <optional> |                                              | A path to associate with this entity.                                                                                                                                                                                                                                                                                                        |
| plane                  | [PlaneGraphics](PlaneGraphics.html)\|[PlaneGraphics.ConstructorOptions](PlaneGraphics.html#.ConstructorOptions)                                         | <optional> |                                              | A plane to associate with this entity.                                                                                                                                                                                                                                                                                                       |
| point                  | [PointGraphics](PointGraphics.html)\|[PointGraphics.ConstructorOptions](PointGraphics.html#.ConstructorOptions)                                         | <optional> |                                              | A point to associate with this entity.                                                                                                                                                                                                                                                                                                       |
| polygon                | [PolygonGraphics](PolygonGraphics.html)\|[PolygonGraphics.ConstructorOptions](PolygonGraphics.html#.ConstructorOptions)                                 | <optional> |                                              | A polygon to associate with this entity.                                                                                                                                                                                                                                                                                                     |
| polyline               | [PolylineGraphics](PolylineGraphics.html)\|[PolylineGraphics.ConstructorOptions](PolylineGraphics.html#.ConstructorOptions)                             | <optional> |                                              | A polyline to associate with this entity.                                                                                                                                                                                                                                                                                                    |
| properties             | [PropertyBag](PropertyBag.html)\|Object.<string, \*>                                                                                                    | <optional> |                                              | Arbitrary properties to associate with this entity.                                                                                                                                                                                                                                                                                          |
| polylineVolume         | [PolylineVolumeGraphics](PolylineVolumeGraphics.html)\|[PolylineVolumeGraphics.ConstructorOptions](PolylineVolumeGraphics.html#.ConstructorOptions)     | <optional> |                                              | A polylineVolume to associate with this entity.                                                                                                                                                                                                                                                                                              |
| rectangle              | [RectangleGraphics](RectangleGraphics.html)\|[RectangleGraphics.ConstructorOptions](RectangleGraphics.html#.ConstructorOptions)                         | <optional> |                                              | A rectangle to associate with this entity.                                                                                                                                                                                                                                                                                                   |
| wall                   | [WallGraphics](WallGraphics.html)\|[WallGraphics.ConstructorOptions](WallGraphics.html#.ConstructorOptions)                                             | <optional> |                                              | A wall to associate with this entity.                                                                                                                                                                                                                                                                                                        |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

