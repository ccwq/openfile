# [![](Images/CesiumLogo.png)](index.html) TileProviderError 

#### [](#TileProviderError) new Cesium.TileProviderError(provider, message, x, y, level, timesRetried, error) 

[engine/Source/Core/TileProviderError.js 22](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L22) 

 Provides details about an error that occurred in an [ImageryProvider](ImageryProvider.html) or a [TerrainProvider](TerrainProvider.html).

| Name         | Type                                                                             | Default | Description                                                                                                                       |
| ------------ | -------------------------------------------------------------------------------- | ------- | --------------------------------------------------------------------------------------------------------------------------------- |
| provider     | [ImageryProvider](ImageryProvider.html)\|[TerrainProvider](TerrainProvider.html) |         | The imagery or terrain provider that experienced the error.                                                                       |
| message      | string                                                                           |         | A message describing the error.                                                                                                   |
| x            | number                                                                           |         | optional The X coordinate of the tile that experienced the error, or undefined if the error is not specific to a particular tile. |
| y            | number                                                                           |         | optional The Y coordinate of the tile that experienced the error, or undefined if the error is not specific to a particular tile. |
| level        | number                                                                           |         | optional The level of the tile that experienced the error, or undefined if the error is not specific to a particular tile.        |
| timesRetried | number                                                                           | 0       | optional The number of times this operation has been retried.                                                                     |
| error        | Error                                                                            |         | optional The error or exception that occurred, if any.                                                                            |

### Members

#### [](#error) error : Error 

[engine/Source/Core/TileProviderError.js 84](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L84) 

 The error or exception that occurred, if any.

#### [](#level) level : number 

[engine/Source/Core/TileProviderError.js 62](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L62) 

 The level-of-detail of the tile that experienced the error. If the error is not specific to a particular tile, this property will be undefined.

#### [](#message) message : string 

[engine/Source/Core/TileProviderError.js 41](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L41) 

 The message describing the error.

#### [](#provider) provider : [ImageryProvider](ImageryProvider.html)|[TerrainProvider](TerrainProvider.html) 

[engine/Source/Core/TileProviderError.js 35](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L35) 

 The [ImageryProvider](ImageryProvider.html) or [TerrainProvider](TerrainProvider.html) that experienced the error.

#### [](#retry) retry : boolean 

[engine/Source/Core/TileProviderError.js 78](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L78) 

 True if the failed operation should be retried; otherwise, false. The imagery or terrain provider will set the initial value of this property before raising the event, but any listeners can change it. The value after the last listener is invoked will be acted upon.

Default Value: `false` 

#### [](#timesRetried) timesRetried : number 

[engine/Source/Core/TileProviderError.js 69](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L69) 

 The number of times this operation has been retried.

Default Value: `0` 

#### [](#x) x : number 

[engine/Source/Core/TileProviderError.js 48](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L48) 

 The X coordinate of the tile that experienced the error. If the error is not specific to a particular tile, this property will be undefined.

#### [](#y) y : number 

[engine/Source/Core/TileProviderError.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L55) 

 The Y coordinate of the tile that experienced the error. If the error is not specific to a particular tile, this property will be undefined.

### Methods

#### [](#.reportError) static Cesium.TileProviderError.reportError(previousError, provider, event, message, x, y, level, errorDetails) → [TileProviderError](TileProviderError.html) 

[engine/Source/Core/TileProviderError.js 109](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L109) 

 Reports an error in an [ImageryProvider](ImageryProvider.html) or [TerrainProvider](TerrainProvider.html) by raising an event if it has any listeners, or by logging the error to the console if the event has no listeners. This method also tracks the number of times the operation has been retried.

| Name          | Type                                                                             | Description                                                                                                                                              |
| ------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| previousError | [TileProviderError](TileProviderError.html)                                      | The error instance returned by this function the last time it was called for this error, or undefined if this is the first time this error has occurred. |
| provider      | [ImageryProvider](ImageryProvider.html)\|[TerrainProvider](TerrainProvider.html) | optional The imagery or terrain provider that encountered the error.                                                                                     |
| event         | [Event](Event.html)                                                              | optional The event to raise to inform listeners of the error.                                                                                            |
| message       | string                                                                           | optional The message describing the error.                                                                                                               |
| x             | number                                                                           | optional The X coordinate of the tile that experienced the error, or undefined if the error is not specific to a particular tile.                        |
| y             | number                                                                           | optional The Y coordinate of the tile that experienced the error, or undefined if the error is not specific to a particular tile.                        |
| level         | number                                                                           | optional The level-of-detail of the tile that experienced the error, or undefined if the error is not specific to a particular tile.                     |
| errorDetails  | Error                                                                            | optional The error or exception that occurred, if any.                                                                                                   |

##### Returns:

 The error instance that was passed to the event listeners and that should be passed to this function the next time it is called for the same error in order to track retry counts.

#### [](#.reportSuccess) static Cesium.TileProviderError.reportSuccess(previousError) 

[engine/Source/Core/TileProviderError.js 161](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L161) 

 Reports success of an operation by resetting the retry count of a previous error, if any. This way, if the error occurs again in the future, the listeners will be informed that it has not yet been retried.

| Name          | Type                                        | Description                                                                                 |
| ------------- | ------------------------------------------- | ------------------------------------------------------------------------------------------- |
| previousError | [TileProviderError](TileProviderError.html) | The previous error, or undefined if this operation has not previously resulted in an error. |

### Type Definitions

#### [](#.RetryFunction) Cesium.TileProviderError.RetryFunction() 

[engine/Source/Core/TileProviderError.js 167](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TileProviderError.js#L167) 

 A function that will be called to retry the operation.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

