# [![](Images/CesiumLogo.png)](index.html) QuantizedMeshTerrainData 

#### [](#QuantizedMeshTerrainData) new Cesium.QuantizedMeshTerrainData(options) 

[engine/Source/Core/QuantizedMeshTerrainData.js 94](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuantizedMeshTerrainData.js#L94) 

 Terrain data for a single tile where the terrain data is represented as a quantized mesh. A quantized mesh consists of three vertex attributes, longitude, latitude, and height. All attributes are expressed as 16-bit values in the range 0 to 32767\. Longitude and latitude are zero at the southwest corner of the tile and 32767 at the northeast corner. Height is zero at the minimum height in the tile and 32767 at the maximum height in the tile.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description quantizedVertices Uint16Array  The buffer containing the quantized mesh. indices Uint16Array\|Uint32Array  The indices specifying how the quantized vertices are linked together into triangles. Each three indices specifies one triangle. minimumHeight number  The minimum terrain height within the tile, in meters above the ellipsoid. maximumHeight number  The maximum terrain height within the tile, in meters above the ellipsoid. boundingSphere [BoundingSphere](BoundingSphere.html)  A sphere bounding all of the vertices in the mesh. orientedBoundingBox [OrientedBoundingBox](OrientedBoundingBox.html) optional An OrientedBoundingBox bounding all of the vertices in the mesh. horizonOcclusionPoint [Cartesian3](Cartesian3.html)  The horizon occlusion point of the mesh. If this point is below the horizon, the entire tile is assumed to be below the horizon as well. The point is expressed in ellipsoid-scaled coordinates. westIndices Array.<number>  The indices of the vertices on the western edge of the tile. southIndices Array.<number>  The indices of the vertices on the southern edge of the tile. eastIndices Array.<number>  The indices of the vertices on the eastern edge of the tile. northIndices Array.<number>  The indices of the vertices on the northern edge of the tile. westSkirtHeight number  The height of the skirt to add on the western edge of the tile. southSkirtHeight number  The height of the skirt to add on the southern edge of the tile. eastSkirtHeight number  The height of the skirt to add on the eastern edge of the tile. northSkirtHeight number  The height of the skirt to add on the northern edge of the tile. childTileMask number 15 optional A bit mask indicating which of this tile's four children exist. If a child's bit is set, geometry will be requested for that tile as well when it is needed. If the bit is cleared, the child tile is not requested and geometry is instead upsampled from the parent. The bit values are as follows: Bit PositionBit ValueChild Tile 01Southwest 12Southeast 24Northwest 38Northeast createdByUpsampling boolean false optional True if this instance was created by upsampling another instance; otherwise, false. encodedNormals Uint8Array optional The buffer containing per vertex normals, encoded using 'oct' encoding waterMask Uint8Array optional The buffer containing the watermask. credits Array.<[Credit](Credit.html)\> optional Array of credits for this tile. |

##### Example:

```javascript
const data = new Cesium.QuantizedMeshTerrainData({
    minimumHeight : -100,
    maximumHeight : 2101,
    quantizedVertices : new Uint16Array([// order is SW NW SE NE
                                         // longitude
                                         0, 0, 32767, 32767,
                                         // latitude
                                         0, 32767, 0, 32767,
                                         // heights
                                         16384, 0, 32767, 16384]),
    indices : new Uint16Array([0, 3, 1,
                               0, 2, 3]),
    boundingSphere : new Cesium.BoundingSphere(new Cesium.Cartesian3(1.0, 2.0, 3.0), 10000),
    orientedBoundingBox : new Cesium.OrientedBoundingBox(new Cesium.Cartesian3(1.0, 2.0, 3.0), Cesium.Matrix3.fromRotationX(Cesium.Math.PI, new Cesium.Matrix3())),
    horizonOcclusionPoint : new Cesium.Cartesian3(3.0, 2.0, 1.0),
    westIndices : [0, 1],
    southIndices : [0, 1],
    eastIndices : [2, 3],
    northIndices : [1, 3],
    westSkirtHeight : 1.0,
    southSkirtHeight : 1.0,
    eastSkirtHeight : 1.0,
    northSkirtHeight : 1.0
});
```

##### See:

* [TerrainData](TerrainData.html)
* [HeightmapTerrainData](HeightmapTerrainData.html)
* [GoogleEarthEnterpriseTerrainData](GoogleEarthEnterpriseTerrainData.html)

### Members

#### [](#credits) credits : Array.<[Credit](Credit.html)\> 

[engine/Source/Core/QuantizedMeshTerrainData.js 216](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuantizedMeshTerrainData.js#L216) 

 An array of credits for this tile.

#### [](#waterMask) waterMask : Uint8Array|HTMLImageElement|HTMLCanvasElement 

[engine/Source/Core/QuantizedMeshTerrainData.js 228](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuantizedMeshTerrainData.js#L228) 

 The water mask included in this terrain data, if any. A water mask is a rectangular Uint8Array or image where a value of 255 indicates water and a value of 0 indicates land. Values in between 0 and 255 are allowed as well to smoothly blend between land and water.

### Methods

#### [](#interpolateHeight) interpolateHeight(rectangle, longitude, latitude) → number 

[engine/Source/Core/QuantizedMeshTerrainData.js 571](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuantizedMeshTerrainData.js#L571) 

 Computes the terrain height at a specified longitude and latitude.

| Name      | Type                        | Description                                 |
| --------- | --------------------------- | ------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html) | The rectangle covered by this terrain data. |
| longitude | number                      | The longitude in radians.                   |
| latitude  | number                      | The latitude in radians.                    |

##### Returns:

 The terrain height at the specified position. The position is clamped to the rectangle, so expect incorrect results for positions far outside the rectangle.

#### [](#isChildAvailable) isChildAvailable(thisX, thisY, childX, childY) → boolean 

[engine/Source/Core/QuantizedMeshTerrainData.js 729](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuantizedMeshTerrainData.js#L729) 

 Determines if a given child tile is available, based on the`HeightmapTerrainData.childTileMask`. The given child tile coordinates are assumed to be one of the four children of this tile. If non-child tile coordinates are given, the availability of the southeast child tile is returned.

| Name   | Type   | Description                                                        |
| ------ | ------ | ------------------------------------------------------------------ |
| thisX  | number | The tile X coordinate of this (the parent) tile.                   |
| thisY  | number | The tile Y coordinate of this (the parent) tile.                   |
| childX | number | The tile X coordinate of the child tile to check for availability. |
| childY | number | The tile Y coordinate of the child tile to check for availability. |

##### Returns:

 True if the child tile is available; otherwise, false.

#### [](#upsample) upsample(tilingScheme, thisX, thisY, thisLevel, descendantX, descendantY, descendantLevel) → Promise.<[QuantizedMeshTerrainData](QuantizedMeshTerrainData.html)\>|undefined 

[engine/Source/Core/QuantizedMeshTerrainData.js 431](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuantizedMeshTerrainData.js#L431) 

 Upsamples this terrain data for use by a descendant tile. The resulting instance will contain a subset of the vertices in this instance, interpolated if necessary.

| Name            | Type                              | Description                                                                                   |
| --------------- | --------------------------------- | --------------------------------------------------------------------------------------------- |
| tilingScheme    | [TilingScheme](TilingScheme.html) | The tiling scheme of this terrain data.                                                       |
| thisX           | number                            | The X coordinate of this tile in the tiling scheme.                                           |
| thisY           | number                            | The Y coordinate of this tile in the tiling scheme.                                           |
| thisLevel       | number                            | The level of this tile in the tiling scheme.                                                  |
| descendantX     | number                            | The X coordinate within the tiling scheme of the descendant tile for which we are upsampling. |
| descendantY     | number                            | The Y coordinate within the tiling scheme of the descendant tile for which we are upsampling. |
| descendantLevel | number                            | The level within the tiling scheme of the descendant tile for which we are upsampling.        |

##### Returns:

 A promise for upsampled heightmap terrain data for the descendant tile, or undefined if too many asynchronous upsample operations are in progress and the request has been deferred.

#### [](#wasCreatedByUpsampling) wasCreatedByUpsampling() → boolean 

[engine/Source/Core/QuantizedMeshTerrainData.js 769](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/QuantizedMeshTerrainData.js#L769) 

 Gets a value indicating whether or not this terrain data was created by upsampling lower resolution terrain data. If this value is false, the data was obtained from some other source, such as by downloading it from a remote server. This method should return true for instances returned from a call to [HeightmapTerrainData#upsample](HeightmapTerrainData.html#upsample).

##### Returns:

 True if this instance was created by upsampling; otherwise, false.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

