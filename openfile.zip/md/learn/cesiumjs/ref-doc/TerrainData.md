# [![](Images/CesiumLogo.png)](index.html) TerrainData 

#### [](#TerrainData) new Cesium.TerrainData() 

[engine/Source/Core/TerrainData.js 14](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TerrainData.js#L14) 

 Terrain data for a single tile. This type describes an interface and is not intended to be instantiated directly.

##### See:

* [HeightmapTerrainData](HeightmapTerrainData.html)
* [QuantizedMeshTerrainData](QuantizedMeshTerrainData.html)
* [GoogleEarthEnterpriseTerrainData](GoogleEarthEnterpriseTerrainData.html)

### Members

#### [](#credits) credits : Array.<[Credit](Credit.html)\> 

[engine/Source/Core/TerrainData.js 24](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TerrainData.js#L24) 

 An array of credits for this tile.

#### [](#waterMask) waterMask : Uint8Array|HTMLImageElement|HTMLCanvasElement 

[engine/Source/Core/TerrainData.js 34](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TerrainData.js#L34) 

 The water mask included in this terrain data, if any. A water mask is a rectangular Uint8Array or image where a value of 255 indicates water and a value of 0 indicates land. Values in between 0 and 255 are allowed as well to smoothly blend between land and water.

### Methods

#### [](#interpolateHeight) interpolateHeight(rectangle, longitude, latitude) → number 

[engine/Source/Core/TerrainData.js 50](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TerrainData.js#L50) 

 Computes the terrain height at a specified longitude and latitude.

| Name      | Type                        | Description                                 |
| --------- | --------------------------- | ------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html) | The rectangle covered by this terrain data. |
| longitude | number                      | The longitude in radians.                   |
| latitude  | number                      | The latitude in radians.                    |

##### Returns:

 The terrain height at the specified position. If the position is outside the rectangle, this method will extrapolate the height, which is likely to be wildly incorrect for positions far outside the rectangle.

#### [](#isChildAvailable) isChildAvailable(thisX, thisY, childX, childY) → boolean 

[engine/Source/Core/TerrainData.js 66](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TerrainData.js#L66) 

 Determines if a given child tile is available, based on the`TerrainData#childTileMask`. The given child tile coordinates are assumed to be one of the four children of this tile. If non-child tile coordinates are given, the availability of the southeast child tile is returned.

| Name   | Type   | Description                                                        |
| ------ | ------ | ------------------------------------------------------------------ |
| thisX  | number | The tile X coordinate of this (the parent) tile.                   |
| thisY  | number | The tile Y coordinate of this (the parent) tile.                   |
| childX | number | The tile X coordinate of the child tile to check for availability. |
| childY | number | The tile Y coordinate of the child tile to check for availability. |

##### Returns:

 True if the child tile is available; otherwise, false.

#### [](#upsample) upsample(tilingScheme, thisX, thisY, thisLevel, descendantX, descendantY, descendantLevel) → Promise.<[TerrainData](TerrainData.html)\>|undefined 

[engine/Source/Core/TerrainData.js 103](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TerrainData.js#L103) 

 Upsamples this terrain data for use by a descendant tile.

| Name            | Type                              | Description                                                                                   |
| --------------- | --------------------------------- | --------------------------------------------------------------------------------------------- |
| tilingScheme    | [TilingScheme](TilingScheme.html) | The tiling scheme of this terrain data.                                                       |
| thisX           | number                            | The X coordinate of this tile in the tiling scheme.                                           |
| thisY           | number                            | The Y coordinate of this tile in the tiling scheme.                                           |
| thisLevel       | number                            | The level of this tile in the tiling scheme.                                                  |
| descendantX     | number                            | The X coordinate within the tiling scheme of the descendant tile for which we are upsampling. |
| descendantY     | number                            | The Y coordinate within the tiling scheme of the descendant tile for which we are upsampling. |
| descendantLevel | number                            | The level within the tiling scheme of the descendant tile for which we are upsampling.        |

##### Returns:

 A promise for upsampled terrain data for the descendant tile, or undefined if too many asynchronous upsample operations are in progress and the request has been deferred.

#### [](#wasCreatedByUpsampling) wasCreatedByUpsampling() → boolean 

[engine/Source/Core/TerrainData.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/TerrainData.js#L114) 

 Gets a value indicating whether or not this terrain data was created by upsampling lower resolution terrain data. If this value is false, the data was obtained from some other source, such as by downloading it from a remote server. This method should return true for instances returned from a call to [TerrainData#upsample](TerrainData.html#upsample).

##### Returns:

 True if this instance was created by upsampling; otherwise, false.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

