# [![](Images/CesiumLogo.png)](index.html) ScreenSpaceEventHandler 

#### [](#ScreenSpaceEventHandler) new Cesium.ScreenSpaceEventHandler(element) 

[engine/Source/Core/ScreenSpaceEventHandler.js 982](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L982) 

 Handles user input events. Custom functions can be added to be executed on when the user enters input.

| Name    | Type              | Default  | Description                            |
| ------- | ----------------- | -------- | -------------------------------------- |
| element | HTMLCanvasElement | document | optional The element to add events to. |

### Members

#### [](#.mouseEmulationIgnoreMilliseconds) static Cesium.ScreenSpaceEventHandler.mouseEmulationIgnoreMilliseconds : number 

[engine/Source/Core/ScreenSpaceEventHandler.js 1132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L1132) 

 The amount of time, in milliseconds, that mouse events will be disabled after receiving any touch events, such that any emulated mouse events will be ignored.

Default Value: `800` 

#### [](#.touchHoldDelayMilliseconds) static Cesium.ScreenSpaceEventHandler.touchHoldDelayMilliseconds : number 

[engine/Source/Core/ScreenSpaceEventHandler.js 1140](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L1140) 

 The amount of time, in milliseconds, before a touch on the screen becomes a touch and hold.

Default Value: `1500` 

### Methods

#### [](#destroy) destroy() 

[engine/Source/Core/ScreenSpaceEventHandler.js 1120](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L1120) 

 Removes listeners held by this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
handler = handler && handler.destroy();
```

##### See:

* [ScreenSpaceEventHandler#isDestroyed](ScreenSpaceEventHandler.html#isDestroyed)

#### [](#getInputAction) getInputAction(type, modifier) → [ScreenSpaceEventHandler.PositionedEventCallback](ScreenSpaceEventHandler.html#.PositionedEventCallback)|[ScreenSpaceEventHandler.MotionEventCallback](ScreenSpaceEventHandler.html#.MotionEventCallback)|[ScreenSpaceEventHandler.WheelEventCallback](ScreenSpaceEventHandler.html#.WheelEventCallback)|[ScreenSpaceEventHandler.TwoPointEventCallback](ScreenSpaceEventHandler.html#.TwoPointEventCallback)|[ScreenSpaceEventHandler.TwoPointMotionEventCallback](ScreenSpaceEventHandler.html#.TwoPointMotionEventCallback) 

[engine/Source/Core/ScreenSpaceEventHandler.js 1056](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L1056) 

 Returns the function to be executed on an input event.

| Name     | Type                                                       | Description                                                                |
| -------- | ---------------------------------------------------------- | -------------------------------------------------------------------------- |
| type     | [ScreenSpaceEventType](global.html#ScreenSpaceEventType)   | The ScreenSpaceEventType of input event.                                   |
| modifier | [KeyboardEventModifier](global.html#KeyboardEventModifier) | optional A KeyboardEventModifier key that is held when a typeevent occurs. |

##### Returns:

 The function to be executed on an input event.

##### See:

* [ScreenSpaceEventHandler#setInputAction](ScreenSpaceEventHandler.html#setInputAction)
* [ScreenSpaceEventHandler#removeInputAction](ScreenSpaceEventHandler.html#removeInputAction)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Core/ScreenSpaceEventHandler.js 1101](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L1101) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [ScreenSpaceEventHandler#destroy](ScreenSpaceEventHandler.html#destroy)

#### [](#removeInputAction) removeInputAction(type, modifier) 

[engine/Source/Core/ScreenSpaceEventHandler.js 1077](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L1077) 

 Removes the function to be executed on an input event.

| Name     | Type                                                       | Description                                                                |
| -------- | ---------------------------------------------------------- | -------------------------------------------------------------------------- |
| type     | [ScreenSpaceEventType](global.html#ScreenSpaceEventType)   | The ScreenSpaceEventType of input event.                                   |
| modifier | [KeyboardEventModifier](global.html#KeyboardEventModifier) | optional A KeyboardEventModifier key that is held when a typeevent occurs. |

##### See:

* [ScreenSpaceEventHandler#getInputAction](ScreenSpaceEventHandler.html#getInputAction)
* [ScreenSpaceEventHandler#setInputAction](ScreenSpaceEventHandler.html#setInputAction)

#### [](#setInputAction) setInputAction(action, type, modifier) 

[engine/Source/Core/ScreenSpaceEventHandler.js 1026](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L1026) 

 Set a function to be executed on an input event.

| Name     | Type                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | Description                                                                |
| -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------- |
| action   | [ScreenSpaceEventHandler.PositionedEventCallback](ScreenSpaceEventHandler.html#.PositionedEventCallback)\|[ScreenSpaceEventHandler.MotionEventCallback](ScreenSpaceEventHandler.html#.MotionEventCallback)|[ScreenSpaceEventHandler.WheelEventCallback](ScreenSpaceEventHandler.html#.WheelEventCallback)|[ScreenSpaceEventHandler.TwoPointEventCallback](ScreenSpaceEventHandler.html#.TwoPointEventCallback)|[ScreenSpaceEventHandler.TwoPointMotionEventCallback](ScreenSpaceEventHandler.html#.TwoPointMotionEventCallback) | Function to be executed when the input event occurs.                       |
| type     | [ScreenSpaceEventType](global.html#ScreenSpaceEventType)                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | The ScreenSpaceEventType of input event.                                   |
| modifier | [KeyboardEventModifier](global.html#KeyboardEventModifier)                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | optional A KeyboardEventModifier key that is held when a typeevent occurs. |

##### See:

* [ScreenSpaceEventHandler#getInputAction](ScreenSpaceEventHandler.html#getInputAction)
* [ScreenSpaceEventHandler#removeInputAction](ScreenSpaceEventHandler.html#removeInputAction)

### Type Definitions

#### [](#.MotionEvent) Cesium.ScreenSpaceEventHandler.MotionEvent

[engine/Source/Core/ScreenSpaceEventHandler.js 911](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L911) 

 An Event that starts at one position and ends at another.

##### Properties:

| Name          | Type                          | Description |
| ------------- | ----------------------------- | ----------- |
| startPosition | [Cartesian2](Cartesian2.html) |             |
| endPosition   | [Cartesian2](Cartesian2.html) |             |

#### [](#.MotionEventCallback) Cesium.ScreenSpaceEventHandler.MotionEventCallback(event) 

[engine/Source/Core/ScreenSpaceEventHandler.js 920](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L920) 

| Name  | Type                                                                             | Description                            |
| ----- | -------------------------------------------------------------------------------- | -------------------------------------- |
| event | [ScreenSpaceEventHandler.MotionEvent](ScreenSpaceEventHandler.html#.MotionEvent) | The event which triggered the listener |

#### [](#.PositionedEvent) Cesium.ScreenSpaceEventHandler.PositionedEvent

[engine/Source/Core/ScreenSpaceEventHandler.js 895](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L895) 

 An Event that occurs at a single position on screen.

##### Properties:

| Name     | Type                          | Description |
| -------- | ----------------------------- | ----------- |
| position | [Cartesian2](Cartesian2.html) |             |

#### [](#.PositionedEventCallback) Cesium.ScreenSpaceEventHandler.PositionedEventCallback(event) 

[engine/Source/Core/ScreenSpaceEventHandler.js 903](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L903) 

| Name  | Type                                                                                     | Description                            |
| ----- | ---------------------------------------------------------------------------------------- | -------------------------------------- |
| event | [ScreenSpaceEventHandler.PositionedEvent](ScreenSpaceEventHandler.html#.PositionedEvent) | The event which triggered the listener |

#### [](#.TwoPointEvent) Cesium.ScreenSpaceEventHandler.TwoPointEvent

[engine/Source/Core/ScreenSpaceEventHandler.js 928](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L928) 

 An Event that occurs at a two positions on screen.

##### Properties:

| Name      | Type                          | Description |
| --------- | ----------------------------- | ----------- |
| position1 | [Cartesian2](Cartesian2.html) |             |
| position2 | [Cartesian2](Cartesian2.html) |             |

#### [](#.TwoPointEventCallback) Cesium.ScreenSpaceEventHandler.TwoPointEventCallback(event) 

[engine/Source/Core/ScreenSpaceEventHandler.js 937](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L937) 

| Name  | Type                                                                                 | Description                            |
| ----- | ------------------------------------------------------------------------------------ | -------------------------------------- |
| event | [ScreenSpaceEventHandler.TwoPointEvent](ScreenSpaceEventHandler.html#.TwoPointEvent) | The event which triggered the listener |

#### [](#.TwoPointMotionEvent) Cesium.ScreenSpaceEventHandler.TwoPointMotionEvent

[engine/Source/Core/ScreenSpaceEventHandler.js 945](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L945) 

 An Event that starts at a two positions on screen and moves to two other positions.

##### Properties:

| Name              | Type                          | Description |
| ----------------- | ----------------------------- | ----------- |
| position1         | [Cartesian2](Cartesian2.html) |             |
| position2         | [Cartesian2](Cartesian2.html) |             |
| previousPosition1 | [Cartesian2](Cartesian2.html) |             |
| previousPosition2 | [Cartesian2](Cartesian2.html) |             |

#### [](#.TwoPointMotionEventCallback) Cesium.ScreenSpaceEventHandler.TwoPointMotionEventCallback(event) 

[engine/Source/Core/ScreenSpaceEventHandler.js 956](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L956) 

| Name  | Type                                                                                             | Description                            |
| ----- | ------------------------------------------------------------------------------------------------ | -------------------------------------- |
| event | [ScreenSpaceEventHandler.TwoPointMotionEvent](ScreenSpaceEventHandler.html#.TwoPointMotionEvent) | The event which triggered the listener |

#### [](#.WheelEventCallback) Cesium.ScreenSpaceEventHandler.WheelEventCallback(delta) 

[engine/Source/Core/ScreenSpaceEventHandler.js 964](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/ScreenSpaceEventHandler.js#L964) 

| Name  | Type   | Description                           |
| ----- | ------ | ------------------------------------- |
| delta | number | The amount that the mouse wheel moved |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

