# [![](Images/CesiumLogo.png)](index.html) I3SNode 

#### [](#I3SNode) internal constructor new Cesium.I3SNode() 

[engine/Source/Scene/I3SNode.js 37](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L37) 

 This class implements an I3S Node. In CesiumJS each I3SNode creates a Cesium3DTile.

Do not construct this directly, instead access tiles through [I3SLayer](I3SLayer.html).

### Members

#### [](#children) readonly children : Array.<[I3SNode](I3SNode.html)\> 

[engine/Source/Scene/I3SNode.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L121) 

 Gets the children nodes.

#### [](#data) readonly data : object 

[engine/Source/Scene/I3SNode.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L176) 

 Gets the I3S data for this object.

#### [](#featureData) readonly featureData : Array.<[I3SFeature](I3SFeature.html)\> 

[engine/Source/Scene/I3SNode.js 143](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L143) 

 Gets the collection of features.

#### [](#fields) readonly fields : Array.<[I3SField](I3SField.html)\> 

[engine/Source/Scene/I3SNode.js 154](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L154) 

 Gets the collection of fields.

#### [](#geometryData) readonly geometryData : Array.<[I3SGeometry](I3SGeometry.html)\> 

[engine/Source/Scene/I3SNode.js 132](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L132) 

 Gets the collection of geometries.

#### [](#layer) readonly layer : [I3SLayer](I3SLayer.html) 

[engine/Source/Scene/I3SNode.js 99](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L99) 

 Gets the parent layer.

#### [](#parent) readonly parent : [I3SNode](I3SNode.html)|undefined 

[engine/Source/Scene/I3SNode.js 110](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L110) 

 Gets the parent node.

#### [](#resource) readonly resource : [Resource](Resource.html) 

[engine/Source/Scene/I3SNode.js 88](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L88) 

 Gets the resource for the node.

#### [](#tile) readonly tile : [Cesium3DTile](Cesium3DTile.html) 

[engine/Source/Scene/I3SNode.js 165](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L165) 

 Gets the Cesium3DTile for this node.

### Methods

#### [](#getFieldsForFeature) getFieldsForFeature(featureIndex) → object 

[engine/Source/Scene/I3SNode.js 320](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L320) 

 Returns the fields for a given feature

| Name         | Type   | Description                                          |
| ------------ | ------ | ---------------------------------------------------- |
| featureIndex | number | Index of the feature whose attributes we want to get |

##### Returns:

 Object containing field names and their values

#### [](#getFieldsForPickedPosition) getFieldsForPickedPosition(pickedPosition) → object 

[engine/Source/Scene/I3SNode.js 292](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L292) 

 Returns the fields for a given picked position

| Name           | Type                          | Description         |
| -------------- | ----------------------------- | ------------------- |
| pickedPosition | [Cartesian3](Cartesian3.html) | The picked position |

##### Returns:

 Object containing field names and their values

#### [](#loadField) loadField(name) → Promise.<void> 

[engine/Source/Scene/I3SNode.js 264](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L264) 

 Loads the node field.

| Name | Type   | Description    |
| ---- | ------ | -------------- |
| name | string | The field name |

##### Returns:

 A promise that is resolved when the I3S Node field is loaded

#### [](#loadFields) loadFields() → Promise.<void> 

[engine/Source/Scene/I3SNode.js 239](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L239) 

 Loads the node fields.

##### Returns:

 A promise that is resolved when the I3S Node fields are loaded

### Type Definitions

#### [](#.AttributeFilter) Cesium.I3SNode.AttributeFilter

[engine/Source/Scene/I3SNode.js 19](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/I3SNode.js#L19) 

 A filter given by an attribute name and values. The 3D feature object should be hidden if its value for the attribute name is not specified in the collection of values.

##### Properties:

| Name   | Type                           | Description               |
| ------ | ------------------------------ | ------------------------- |
| name   | string                         | The name of the attribute |
| values | Array.<string>\|Array.<number> | The collection of values  |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

