# [![](Images/CesiumLogo.png)](index.html) GroundPrimitive 

#### [](#GroundPrimitive) new Cesium.GroundPrimitive(options) 

[engine/Source/Scene/GroundPrimitive.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L114) 

 A ground primitive represents geometry draped over terrain or 3D Tiles in the [Scene](Scene.html).

A primitive combines geometry instances with an [Appearance](Appearance.html) that describes the full shading, including[Material](Material.html) and `RenderState`. Roughly, the geometry instance defines the structure and placement, and the appearance defines the visual characteristics. Decoupling geometry and appearance allows us to mix and match most of them and add a new geometry or appearance independently of each other.

Support for the WEBGL\_depth\_texture extension is required to use GeometryInstances with different PerInstanceColors or materials besides PerInstanceColorAppearance.

Textured GroundPrimitives were designed for notional patterns and are not meant for precisely mapping textures to terrain - for that use case, use [SingleTileImageryProvider](SingleTileImageryProvider.html).

For correct rendering, this feature requires the EXT\_frag\_depth WebGL extension. For hardware that do not support this extension, there will be rendering artifacts for some viewing angles.

Valid geometries are [CircleGeometry](CircleGeometry.html), [CorridorGeometry](CorridorGeometry.html), [EllipseGeometry](EllipseGeometry.html), [PolygonGeometry](PolygonGeometry.html), and [RectangleGeometry](RectangleGeometry.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description geometryInstances Array\|[GeometryInstance](GeometryInstance.html) optional The geometry instances to render. appearance [Appearance](Appearance.html) optional The appearance used to render the primitive. Defaults to a flat PerInstanceColorAppearance when GeometryInstances have a color attribute. show boolean true optional Determines if this primitive will be shown. vertexCacheOptimize boolean false optional When true, geometry vertices are optimized for the pre and post-vertex-shader caches. interleave boolean false optional When true, geometry vertex attributes are interleaved, which can slightly improve rendering performance but increases load time. compressVertices boolean true optional When true, the geometry vertices are compressed, which will save memory. releaseGeometryInstances boolean true optional When true, the primitive does not keep a reference to the input geometryInstances to save memory. allowPicking boolean true optional When true, each geometry instance will only be pickable with [Scene#pick](Scene.html#pick). When false, GPU memory is saved. asynchronous boolean true optional Determines if the primitive will be created asynchronously or block until ready. If false initializeTerrainHeights() must be called first. classificationType [ClassificationType](global.html#ClassificationType) ClassificationType.BOTH optional Determines whether terrain, 3D Tiles or both will be classified. debugShowBoundingVolume boolean false optional For debugging only. Determines if this primitive's commands' bounding spheres are shown. debugShowShadowVolume boolean false optional For debugging only. Determines if the shadow volume for each geometry in the primitive is drawn. Must be true on creation for the volumes to be created before the geometry is released or options.releaseGeometryInstance must be false. |

##### Example:

```javascript
// Example 1: Create primitive with a single instance
const rectangleInstance = new Cesium.GeometryInstance({
  geometry : new Cesium.RectangleGeometry({
    rectangle : Cesium.Rectangle.fromDegrees(-140.0, 30.0, -100.0, 40.0)
  }),
  id : 'rectangle',
  attributes : {
    color : new Cesium.ColorGeometryInstanceAttribute(0.0, 1.0, 1.0, 0.5)
  }
});
scene.primitives.add(new Cesium.GroundPrimitive({
  geometryInstances : rectangleInstance
}));

// Example 2: Batch instances
const color = new Cesium.ColorGeometryInstanceAttribute(0.0, 1.0, 1.0, 0.5); // Both instances must have the same color.
const rectangleInstance = new Cesium.GeometryInstance({
  geometry : new Cesium.RectangleGeometry({
    rectangle : Cesium.Rectangle.fromDegrees(-140.0, 30.0, -100.0, 40.0)
  }),
  id : 'rectangle',
  attributes : {
    color : color
  }
});
const ellipseInstance = new Cesium.GeometryInstance({
    geometry : new Cesium.EllipseGeometry({
        center : Cesium.Cartesian3.fromDegrees(-105.0, 40.0),
        semiMinorAxis : 300000.0,
        semiMajorAxis : 400000.0
    }),
    id : 'ellipse',
    attributes : {
        color : color
    }
});
scene.primitives.add(new Cesium.GroundPrimitive({
  geometryInstances : [rectangleInstance, ellipseInstance]
}));
```

##### See:

* [Primitive](Primitive.html)
* [ClassificationPrimitive](ClassificationPrimitive.html)
* [GeometryInstance](GeometryInstance.html)
* [Appearance](Appearance.html)

### Members

#### [](#allowPicking) readonly allowPicking : boolean 

[engine/Source/Scene/GroundPrimitive.js 309](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L309) 

 When `true`, each geometry instance will only be pickable with [Scene#pick](Scene.html#pick). When `false`, GPU memory is saved.

Default Value: `true` 

#### [](#appearance) appearance : [Appearance](Appearance.html) 

[engine/Source/Scene/GroundPrimitive.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L144) 

 The [Appearance](Appearance.html) used to shade this primitive. Each geometry instance is shaded with the same appearance. Some appearances, like[PerInstanceColorAppearance](PerInstanceColorAppearance.html) allow giving each instance unique properties.

Default Value: `undefined` 

#### [](#asynchronous) readonly asynchronous : boolean 

[engine/Source/Scene/GroundPrimitive.js 325](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L325) 

 Determines if the geometry instances will be created and batched on a web worker.

Default Value: `true` 

#### [](#classificationType) classificationType : [ClassificationType](global.html#ClassificationType) 

[engine/Source/Scene/GroundPrimitive.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L176) 

 Determines whether terrain, 3D Tiles or both will be classified.

Default Value: `ClassificationType.BOTH` 

#### [](#compressVertices) readonly compressVertices : boolean 

[engine/Source/Scene/GroundPrimitive.js 341](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L341) 

 When `true`, geometry vertices are compressed, which will save memory.

Default Value: `true` 

#### [](#debugShowBoundingVolume) debugShowBoundingVolume : boolean 

[engine/Source/Scene/GroundPrimitive.js 190](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L190) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the bounding sphere for each draw command in the primitive.

Default Value: `false` 

#### [](#debugShowShadowVolume) debugShowShadowVolume : boolean 

[engine/Source/Scene/GroundPrimitive.js 205](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L205) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the shadow volume for each geometry in the primitive.

Default Value: `false` 

#### [](#geometryInstances) readonly geometryInstances : Array|[GeometryInstance](GeometryInstance.html) 

[engine/Source/Scene/GroundPrimitive.js 159](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L159) 

 The geometry instances rendered with this primitive. This may be `undefined` if `options.releaseGeometryInstances`is `true` when the primitive is constructed.

Changing this property after the primitive is rendered has no effect.

Default Value: `undefined` 

#### [](#interleave) readonly interleave : boolean 

[engine/Source/Scene/GroundPrimitive.js 277](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L277) 

 Determines if geometry vertex attributes are interleaved, which can slightly improve rendering performance.

Default Value: `false` 

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/GroundPrimitive.js 357](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L357) 

 Determines if the primitive is complete and ready to render. If this property is true, the primitive will be rendered the next time that [GroundPrimitive#update](GroundPrimitive.html#update)is called.

#### [](#releaseGeometryInstances) readonly releaseGeometryInstances : boolean 

[engine/Source/Scene/GroundPrimitive.js 293](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L293) 

 When `true`, the primitive does not keep a reference to the input `geometryInstances` to save memory.

Default Value: `true` 

#### [](#show) show : boolean 

[engine/Source/Scene/GroundPrimitive.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L168) 

 Determines if the primitive will be shown. This affects all geometry instances in the primitive.

Default Value: `true` 

#### [](#vertexCacheOptimize) readonly vertexCacheOptimize : boolean 

[engine/Source/Scene/GroundPrimitive.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L261) 

 When `true`, geometry vertices are optimized for the pre and post-vertex-shader caches.

Default Value: `true` 

### Methods

#### [](#.initializeTerrainHeights) static Cesium.GroundPrimitive.initializeTerrainHeights() → Promise.<void> 

[engine/Source/Scene/GroundPrimitive.js 682](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L682) 

 Initializes the minimum and maximum terrain heights. This only needs to be called if you are creating the GroundPrimitive synchronously.

##### Returns:

 A promise that will resolve once the terrain heights have been loaded.

#### [](#.isSupported) static Cesium.GroundPrimitive.isSupported(scene) → boolean 

[engine/Source/Scene/GroundPrimitive.js 371](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L371) 

 Determines if GroundPrimitive rendering is supported.

| Name  | Type                | Description |
| ----- | ------------------- | ----------- |
| scene | [Scene](Scene.html) | The scene.  |

##### Returns:

`true` if GroundPrimitives are supported; otherwise, returns `false` 

#### [](#.supportsMaterials) static Cesium.GroundPrimitive.supportsMaterials(scene) → boolean 

[engine/Source/Scene/GroundPrimitive.js 1004](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L1004) 

 Checks if the given Scene supports materials on GroundPrimitives. Materials on GroundPrimitives require support for the WEBGL\_depth\_texture extension.

| Name  | Type                | Description        |
| ----- | ------------------- | ------------------ |
| scene | [Scene](Scene.html) | The current scene. |

##### Returns:

 Whether or not the current scene supports materials on GroundPrimitives.

#### [](#destroy) destroy() 

[engine/Source/Scene/GroundPrimitive.js 981](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L981) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.

Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
e = e && e.destroy();
```

##### See:

* [GroundPrimitive#isDestroyed](GroundPrimitive.html#isDestroyed)

#### [](#getGeometryInstanceAttributes) getGeometryInstanceAttributes(id) → object 

[engine/Source/Scene/GroundPrimitive.js 939](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L939) 

 Returns the modifiable per-instance attributes for a [GeometryInstance](GeometryInstance.html).

| Name | Type | Description                                              |
| ---- | ---- | -------------------------------------------------------- |
| id   | \*   | The id of the [GeometryInstance](GeometryInstance.html). |

##### Returns:

 The typed array in the attribute's format or undefined if the is no instance with id.

##### Throws:

* [DeveloperError](DeveloperError.html): must call update before calling getGeometryInstanceAttributes.

##### Example:

```javascript
const attributes = primitive.getGeometryInstanceAttributes('an id');
attributes.color = Cesium.ColorGeometryInstanceAttribute.toValue(Cesium.Color.AQUA);
attributes.show = Cesium.ShowGeometryInstanceAttribute.toValue(true);
```

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/GroundPrimitive.js 961](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L961) 

 Returns true if this object was destroyed; otherwise, false.

If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [GroundPrimitive#destroy](GroundPrimitive.html#destroy)

#### [](#update) update() 

[engine/Source/Scene/GroundPrimitive.js 698](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/GroundPrimitive.js#L698) 

 Called when [Viewer](Viewer.html) or [CesiumWidget](CesiumWidget.html) render the scene to get the draw commands needed to render this primitive.

Do not call this function directly. This is documented just to list the exceptions that may be propagated when the scene is rendered:

##### Throws:

* [DeveloperError](DeveloperError.html): For synchronous GroundPrimitive, you must call GroundPrimitive.initializeTerrainHeights() and wait for the returned promise to resolve.
* [DeveloperError](DeveloperError.html): All instance geometries must have the same primitiveType.
* [DeveloperError](DeveloperError.html): Appearance and material have a uniform with the same name.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

