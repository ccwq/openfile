# [![](Images/CesiumLogo.png)](index.html) ModelFeature 

#### [](#ModelFeature) new Cesium.ModelFeature(options) 

[engine/Source/Scene/Model/ModelFeature.js 33](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelFeature.js#L33) 

 A feature of a [Model](Model.html).

Provides access to a feature's properties stored in the model's feature table.

Modifications to a `ModelFeature` object have the lifetime of the model.

Do not construct this directly. Access it through picking using [Scene#pick](Scene.html#pick).

| Name    | Type   | Description                                                                                                                                                                                 |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Description model [Model](Model.html)  The model the feature belongs to. featureId number  The unique integral identifier for this feature. |

##### Example:

```javascript
// On mouse over, display all the properties for a feature in the console log.
handler.setInputAction(function(movement) {
    const feature = scene.pick(movement.endPosition);
    if (feature instanceof Cesium.ModelFeature) {
        console.log(feature);
    }
}, Cesium.ScreenSpaceEventType.MOUSE_MOVE);
```

### Members

#### [](#color) color : [Color](Color.html) 

[engine/Source/Scene/Model/ModelFeature.js 75](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelFeature.js#L75) 

 Gets or sets the highlight color multiplied with the feature's color. When this is white, the feature's color is not changed. This is set for all features when a style's color is evaluated.

Default Value: `[Color.WHITE](Color.html#.WHITE)` 

#### [](#featureId) readonly featureId : number 

[engine/Source/Scene/Model/ModelFeature.js 131](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelFeature.js#L131) 

 Get the feature ID associated with this feature. For 3D Tiles 1.0, the batch ID is returned. For EXT\_mesh\_features, this is the feature ID from the selected feature ID set.

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#show) show : boolean 

[engine/Source/Scene/Model/ModelFeature.js 55](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelFeature.js#L55) 

 Gets or sets if the feature will be shown. This is set for all features when a style's show is evaluated.

Default Value: `true` 

### Methods

#### [](#getProperty) getProperty(name) → \* 

[engine/Source/Scene/Model/ModelFeature.js 163](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelFeature.js#L163) 

 Returns a copy of the value of the feature's property with the given name.

| Name | Type   | Description                              |
| ---- | ------ | ---------------------------------------- |
| name | string | The case-sensitive name of the property. |

##### Returns:

 The value of the property or `undefined` if the feature does not have this property.

##### Example:

```javascript
// Display all the properties for a feature in the console log.
const propertyIds = feature.getPropertyIds();
const length = propertyIds.length;
for (let i = 0; i < length; ++i) {
    const propertyId = propertyIds[i];
    console.log(propertyId + ': ' + feature.getProperty(propertyId));
}
```

#### [](#getPropertyIds) getPropertyIds(results) → Array.<string> 

[engine/Source/Scene/Model/ModelFeature.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelFeature.js#L200) 

 Returns an array of property IDs for the feature.

| Name    | Type           | Description                                        |
| ------- | -------------- | -------------------------------------------------- |
| results | Array.<string> | optional An array into which to store the results. |

##### Returns:

 The IDs of the feature's properties.

#### [](#getPropertyInherited) getPropertyInherited(name) → \* 

[engine/Source/Scene/Model/ModelFeature.js 186](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelFeature.js#L186) 

 Returns a copy of the feature's property with the given name, examining all the metadata from the EXT\_structural\_metadata and legacy EXT\_feature\_metadata glTF extensions. Metadata is checked against name from most specific to most general and the first match is returned. Metadata is checked in this order:
1. structural metadata property by semantic
2. structural metadata property by property ID

See the [EXT\_structural\_metadata Extension](https://github.com/CesiumGS/glTF/tree/3d-tiles-next/extensions/2.0/Vendor/EXT%5Fstructural%5Fmetadata) as well as the previous [EXT\_feature\_metadata Extension](https://github.com/CesiumGS/glTF/tree/3d-tiles-next/extensions/2.0/Vendor/EXT%5Ffeature%5Fmetadata) for glTF.

| Name | Type   | Description                                                                                                            |
| ---- | ------ | ---------------------------------------------------------------------------------------------------------------------- |
| name | string | The semantic or property ID of the feature. Semantics are checked before property IDs in each granularity of metadata. |

##### Returns:

 The value of the property or `undefined` if the feature does not have this property.

##### Experimental

This feature is using part of the 3D Tiles spec that is not final and is subject to change without Cesium's standard deprecation policy.

#### [](#hasProperty) hasProperty(name) → boolean 

[engine/Source/Scene/Model/ModelFeature.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelFeature.js#L144) 

 Returns whether the feature contains this property.

| Name | Type   | Description                              |
| ---- | ------ | ---------------------------------------- |
| name | string | The case-sensitive name of the property. |

##### Returns:

 Whether the feature contains this property.

#### [](#setProperty) setProperty(name, value) → boolean 

[engine/Source/Scene/Model/ModelFeature.js 225](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Model/ModelFeature.js#L225) 

 Sets the value of the feature's property with the given name.

| Name  | Type   | Description                                    |
| ----- | ------ | ---------------------------------------------- |
| name  | string | The case-sensitive name of the property.       |
| value | \*     | The value of the property that will be copied. |

##### Returns:

`true` if the property was set, `false` otherwise.

##### Throws:

* [DeveloperError](DeveloperError.html): Inherited batch table hierarchy property is read only.

##### Examples:

```javascript
const height = feature.getProperty('Height'); // e.g., the height of a building
```

```javascript
const name = 'clicked';
if (feature.getProperty(name)) {
    console.log('already clicked');
} else {
    feature.setProperty(name, true);
    console.log('first click');
}
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

