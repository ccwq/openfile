# [![](Images/CesiumLogo.png)](index.html) BillboardCollection 

#### [](#BillboardCollection) new Cesium.BillboardCollection(options) 

[engine/Source/Scene/BillboardCollection.js 145](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L145) 

 A renderable collection of billboards. Billboards are viewport-aligned images positioned in the 3D scene.  
  
![](Images/Billboard.png)  
Example billboards
  
  
Billboards are added and removed from the collection using [BillboardCollection#add](BillboardCollection.html#add)and [BillboardCollection#remove](BillboardCollection.html#remove). Billboards in a collection automatically share textures for images with the same identifier.

##### Performance:

For best performance, prefer a few collections, each with many billboards, to many collections with only a few billboards each. Organize collections so that billboards with the same update frequency are in the same collection, i.e., billboards that do not change should be in one collection; billboards that change every frame should be in another collection; and so on.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description modelMatrix [Matrix4](Matrix4.html) Matrix4.IDENTITY optional The 4x4 transformation matrix that transforms each billboard from model to world coordinates. debugShowBoundingVolume boolean false optional For debugging only. Determines if this primitive's commands' bounding spheres are shown. scene [Scene](Scene.html) optional Must be passed in for billboards that use the height reference property or will be depth tested against the globe. blendOption [BlendOption](global.html#BlendOption) BlendOption.OPAQUE\_AND\_TRANSLUCENT optional The billboard blending option. The default is used for rendering both opaque and translucent billboards. However, if either all of the billboards are completely opaque or all are completely translucent, setting the technique to BlendOption.OPAQUE or BlendOption.TRANSLUCENT can improve performance by up to 2x. show boolean true optional Determines if the billboards in the collection will be shown. |

##### Example:

```javascript
// Create a billboard collection with two billboards
const billboards = scene.primitives.add(new Cesium.BillboardCollection());
billboards.add({
  position : new Cesium.Cartesian3(1.0, 2.0, 3.0),
  image : 'url/to/image'
});
billboards.add({
  position : new Cesium.Cartesian3(4.0, 5.0, 6.0),
  image : 'url/to/another/image'
});
```

##### Demo:

* [Cesium Sandcastle Billboard Demo](https://sandcastle.cesium.com/index.html?src=Billboards.html)

##### See:

* [BillboardCollection#add](BillboardCollection.html#add)
* [BillboardCollection#remove](BillboardCollection.html#remove)
* [Billboard](Billboard.html)
* [LabelCollection](LabelCollection.html)

### Members

#### [](#blendOption) blendOption : [BlendOption](global.html#BlendOption) 

[engine/Source/Scene/BillboardCollection.js 299](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L299) 

 The billboard blending option. The default is used for rendering both opaque and translucent billboards. However, if either all of the billboards are completely opaque or all are completely translucent, setting the technique to BlendOption.OPAQUE or BlendOption.TRANSLUCENT can improve performance by up to 2x.

Default Value: `BlendOption.OPAQUE_AND_TRANSLUCENT` 

#### [](#debugShowBoundingVolume) debugShowBoundingVolume : boolean 

[engine/Source/Scene/BillboardCollection.js 271](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L271) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the bounding sphere for each draw command in the primitive.

Default Value: `false` 

#### [](#debugShowTextureAtlas) debugShowTextureAtlas : boolean 

[engine/Source/Scene/BillboardCollection.js 286](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L286) 

 This property is for debugging only; it is not for production use nor is it optimized.

Draws the texture atlas for this BillboardCollection as a fullscreen quad.

Default Value: `false` 

#### [](#length) readonly length : number 

[engine/Source/Scene/BillboardCollection.js 365](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L365) 

 Returns the number of billboards in this collection. This is commonly used with[BillboardCollection#get](BillboardCollection.html#get) to iterate over all the billboards in the collection.

#### [](#modelMatrix) modelMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/BillboardCollection.js 256](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L256) 

 The 4x4 transformation matrix that transforms each billboard in this collection from model to world coordinates. When this is the identity matrix, the billboards are drawn in world coordinates, i.e., Earth's WGS84 coordinates. Local reference frames can be used by providing a different transformation matrix, like that returned by [Transforms.eastNorthUpToFixedFrame](Transforms.html#.eastNorthUpToFixedFrame).

Default Value: `[Matrix4.IDENTITY](Matrix4.html#.IDENTITY)` 

##### Example:

```javascript
const center = Cesium.Cartesian3.fromDegrees(-75.59777, 40.03883);
billboards.modelMatrix = Cesium.Transforms.eastNorthUpToFixedFrame(center);
billboards.add({
  image : 'url/to/image',
  position : new Cesium.Cartesian3(0.0, 0.0, 0.0) // center
});
billboards.add({
  image : 'url/to/image',
  position : new Cesium.Cartesian3(1000000.0, 0.0, 0.0) // east
});
billboards.add({
  image : 'url/to/image',
  position : new Cesium.Cartesian3(0.0, 1000000.0, 0.0) // north
});
billboards.add({
  image : 'url/to/image',
  position : new Cesium.Cartesian3(0.0, 0.0, 1000000.0) // up
});
```

##### See:

* [Transforms.eastNorthUpToFixedFrame](Transforms.html#.eastNorthUpToFixedFrame)

#### [](#show) show : boolean 

[engine/Source/Scene/BillboardCollection.js 222](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L222) 

 Determines if billboards in this collection will be shown.

Default Value: `true` 

### Methods

#### [](#add) add(options) → [Billboard](Billboard.html) 

[engine/Source/Scene/BillboardCollection.js 526](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L526) 

 Creates and adds a billboard with the specified initial properties to the collection. The added billboard is returned so it can be modified or removed from the collection later.

##### Performance:

Calling `add` is expected constant time. However, the collection's vertex buffer is rewritten - an `O(n)` operation that also incurs CPU to GPU overhead. For best performance, add as many billboards as possible before calling `update`.

| Name    | Type                                                               | Description                                                                      |
| ------- | ------------------------------------------------------------------ | -------------------------------------------------------------------------------- |
| options | [Billboard.ConstructorOptions](Billboard.html#.ConstructorOptions) | optional A template describing the billboard's properties as shown in Example 1. |

##### Returns:

 The billboard that was added to the collection.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Examples:

```javascript
// Example 1:  Add a billboard, specifying all the default values.
const b = billboards.add({
  show : true,
  position : Cesium.Cartesian3.ZERO,
  pixelOffset : Cesium.Cartesian2.ZERO,
  eyeOffset : Cesium.Cartesian3.ZERO,
  heightReference : Cesium.HeightReference.NONE,
  horizontalOrigin : Cesium.HorizontalOrigin.CENTER,
  verticalOrigin : Cesium.VerticalOrigin.CENTER,
  scale : 1.0,
  image : 'url/to/image',
  imageSubRegion : undefined,
  color : Cesium.Color.WHITE,
  id : undefined,
  rotation : 0.0,
  alignedAxis : Cesium.Cartesian3.ZERO,
  width : undefined,
  height : undefined,
  scaleByDistance : undefined,
  translucencyByDistance : undefined,
  pixelOffsetScaleByDistance : undefined,
  sizeInMeters : false,
  distanceDisplayCondition : undefined
});
```

```javascript
// Example 2:  Specify only the billboard's cartographic position.
const b = billboards.add({
  position : Cesium.Cartesian3.fromDegrees(longitude, latitude, height)
});
```

##### See:

* [BillboardCollection#remove](BillboardCollection.html#remove)
* [BillboardCollection#removeAll](BillboardCollection.html#removeAll)

#### [](#contains) contains(billboard) → boolean 

[engine/Source/Scene/BillboardCollection.js 636](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L636) 

 Check whether this collection contains a given billboard.

| Name      | Type                        | Description                          |
| --------- | --------------------------- | ------------------------------------ |
| billboard | [Billboard](Billboard.html) | optional The billboard to check for. |

##### Returns:

 true if this collection contains the billboard, false otherwise.

##### See:

* [BillboardCollection#get](BillboardCollection.html#get)

#### [](#destroy) destroy() 

[engine/Source/Scene/BillboardCollection.js 2377](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L2377) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
billboards = billboards && billboards.destroy();
```

##### See:

* [BillboardCollection#isDestroyed](BillboardCollection.html#isDestroyed)

#### [](#get) get(index) → [Billboard](Billboard.html) 

[engine/Source/Scene/BillboardCollection.js 667](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L667) 

 Returns the billboard in the collection at the specified index. Indices are zero-based and increase as billboards are added. Removing a billboard shifts all billboards after it to the left, changing their indices. This function is commonly used with[BillboardCollection#length](BillboardCollection.html#length) to iterate over all the billboards in the collection.

##### Performance:

Expected constant time. If billboards were removed from the collection and[BillboardCollection#update](BillboardCollection.html#update) was not called, an implicit `O(n)`operation is performed.

| Name  | Type   | Description                            |
| ----- | ------ | -------------------------------------- |
| index | number | The zero-based index of the billboard. |

##### Returns:

 The billboard at the specified index.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
// Toggle the show property of every billboard in the collection
const len = billboards.length;
for (let i = 0; i < len; ++i) {
  const b = billboards.get(i);
  b.show = !b.show;
}
```

##### See:

* [BillboardCollection#length](BillboardCollection.html#length)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/BillboardCollection.js 2357](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L2357) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [BillboardCollection#destroy](BillboardCollection.html#destroy)

#### [](#remove) remove(billboard) → boolean 

[engine/Source/Scene/BillboardCollection.js 559](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L559) 

 Removes a billboard from the collection.

##### Performance:

Calling `remove` is expected constant time. However, the collection's vertex buffer is rewritten - an `O(n)` operation that also incurs CPU to GPU overhead. For best performance, remove as many billboards as possible before calling `update`. If you intend to temporarily hide a billboard, it is usually more efficient to call[Billboard#show](Billboard.html#show) instead of removing and re-adding the billboard.

| Name      | Type                        | Description              |
| --------- | --------------------------- | ------------------------ |
| billboard | [Billboard](Billboard.html) | The billboard to remove. |

##### Returns:

`true` if the billboard was removed; `false` if the billboard was not found in the collection.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
const b = billboards.add(...);
billboards.remove(b);  // Returns true
```

##### See:

* [BillboardCollection#add](BillboardCollection.html#add)
* [BillboardCollection#removeAll](BillboardCollection.html#removeAll)
* [Billboard#show](Billboard.html#show)

#### [](#removeAll) removeAll() 

[engine/Source/Scene/BillboardCollection.js 588](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L588) 

 Removes all billboards from the collection.

##### Performance:

`O(n)`. It is more efficient to remove all the billboards from a collection and then add new ones than to create a new collection entirely.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
billboards.add(...);
billboards.add(...);
billboards.removeAll();
```

##### See:

* [BillboardCollection#add](BillboardCollection.html#add)
* [BillboardCollection#remove](BillboardCollection.html#remove)

#### [](#update) update() 

[engine/Source/Scene/BillboardCollection.js 1776](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/BillboardCollection.js#L1776) 

 Called when [Viewer](Viewer.html) or [CesiumWidget](CesiumWidget.html) render the scene to get the draw commands needed to render this primitive.

Do not call this function directly. This is documented just to list the exceptions that may be propagated when the scene is rendered:

##### Throws:

* [RuntimeError](RuntimeError.html): image with id must be in the atlas.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

