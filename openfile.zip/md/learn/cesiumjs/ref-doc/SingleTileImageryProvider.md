# [![](Images/CesiumLogo.png)](index.html) SingleTileImageryProvider 

#### [](#SingleTileImageryProvider) new Cesium.SingleTileImageryProvider(options) 

[engine/Source/Scene/SingleTileImageryProvider.js 45](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L45) 

 Provides a single, top-level imagery tile. The single image is assumed to be in the Geographic projection (i.e. WGS84 / EPSG:4326), and will be rendered using a [GeographicTilingScheme](GeographicTilingScheme.html).

| Name    | Type                                                                                               | Description                              |
| ------- | -------------------------------------------------------------------------------------------------- | ---------------------------------------- |
| options | [SingleTileImageryProvider.ConstructorOptions](SingleTileImageryProvider.html#.ConstructorOptions) | Object describing initialization options |

##### See:

* [ArcGisMapServerImageryProvider](ArcGisMapServerImageryProvider.html)
* [BingMapsImageryProvider](BingMapsImageryProvider.html)
* [GoogleEarthEnterpriseMapsProvider](GoogleEarthEnterpriseMapsProvider.html)
* [OpenStreetMapImageryProvider](OpenStreetMapImageryProvider.html)
* [TileMapServiceImageryProvider](TileMapServiceImageryProvider.html)
* [WebMapServiceImageryProvider](WebMapServiceImageryProvider.html)
* [WebMapTileServiceImageryProvider](WebMapTileServiceImageryProvider.html)
* [UrlTemplateImageryProvider](UrlTemplateImageryProvider.html)

### Members

#### [](#credit) readonly credit : [Credit](Credit.html) 

[engine/Source/Scene/SingleTileImageryProvider.js 227](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L227) 

 Gets the credit to display when this imagery provider is active. Typically this is used to credit the source of the imagery.

#### [](#errorEvent) readonly errorEvent : [Event](Event.html) 

[engine/Source/Scene/SingleTileImageryProvider.js 214](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L214) 

 Gets an event that is raised when the imagery provider encounters an asynchronous error. By subscribing to the event, you will be notified of the error and can potentially recover from it. Event listeners are passed an instance of [TileProviderError](TileProviderError.html).

#### [](#hasAlphaChannel) readonly hasAlphaChannel : boolean 

[engine/Source/Scene/SingleTileImageryProvider.js 243](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L243) 

 Gets a value indicating whether or not the images provided by this imagery provider include an alpha channel. If this property is false, an alpha channel, if present, will be ignored. If this property is true, any images without an alpha channel will be treated as if their alpha is 1.0 everywhere. When this property is false, memory usage and texture upload time are reduced.

#### [](#maximumLevel) readonly maximumLevel : number|undefined 

[engine/Source/Scene/SingleTileImageryProvider.js 150](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L150) 

 Gets the maximum level-of-detail that can be requested.

#### [](#minimumLevel) readonly minimumLevel : number 

[engine/Source/Scene/SingleTileImageryProvider.js 162](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L162) 

 Gets the minimum level-of-detail that can be requested.

#### [](#proxy) readonly proxy : [Proxy](Proxy.html) 

[engine/Source/Scene/SingleTileImageryProvider.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L114) 

 Gets the proxy used by this provider.

#### [](#rectangle) readonly rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Scene/SingleTileImageryProvider.js 186](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L186) 

 Gets the rectangle, in radians, of the imagery provided by this instance.

#### [](#tileDiscardPolicy) readonly tileDiscardPolicy : [TileDiscardPolicy](TileDiscardPolicy.html) 

[engine/Source/Scene/SingleTileImageryProvider.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L200) 

 Gets the tile discard policy. If not undefined, the discard policy is responsible for filtering out "missing" tiles via its shouldDiscardImage function. If this function returns undefined, no tiles are filtered.

#### [](#tileHeight) readonly tileHeight : number 

[engine/Source/Scene/SingleTileImageryProvider.js 138](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L138) 

 Gets the height of each tile, in pixels.

#### [](#tileWidth) readonly tileWidth : number 

[engine/Source/Scene/SingleTileImageryProvider.js 126](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L126) 

 Gets the width of each tile, in pixels.

#### [](#tilingScheme) readonly tilingScheme : [TilingScheme](TilingScheme.html) 

[engine/Source/Scene/SingleTileImageryProvider.js 174](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L174) 

 Gets the tiling scheme used by this provider.

#### [](#url) readonly url : string 

[engine/Source/Scene/SingleTileImageryProvider.js 102](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L102) 

 Gets the URL of the single, top-level imagery tile.

### Methods

#### [](#.fromUrl) static Cesium.SingleTileImageryProvider.fromUrl(url, options) → Promise.<[SingleTileImageryProvider](SingleTileImageryProvider.html)\> 

[engine/Source/Scene/SingleTileImageryProvider.js 304](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L304) 

 Creates a provider for a single, top-level imagery tile. The single image is assumed to use a

| Name    | Type                                                                                       | Description                                        |
| ------- | ------------------------------------------------------------------------------------------ | -------------------------------------------------- |
| url     | [Resource](Resource.html)\|String                                                          | The url for the tile                               |
| options | [SingleTileImageryProvider.fromUrlOptions](SingleTileImageryProvider.html#.fromUrlOptions) | optional Object describing initialization options. |

##### Returns:

 The resolved SingleTileImageryProvider.

##### Example:

```javascript
const provider = await SingleTileImageryProvider.fromUrl("https://yoururl.com/image.png");
```

#### [](#getTileCredits) getTileCredits(x, y, level) → Array.<[Credit](Credit.html)\> 

[engine/Source/Scene/SingleTileImageryProvider.js 331](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L331) 

 Gets the credits to be displayed when a given tile is displayed.

| Name  | Type   | Description            |
| ----- | ------ | ---------------------- |
| x     | number | The tile X coordinate. |
| y     | number | The tile Y coordinate. |
| level | number | The tile level;        |

##### Returns:

 The credits to be displayed when the tile is displayed.

#### [](#pickFeatures) pickFeatures(x, y, level, longitude, latitude) → undefined 

[engine/Source/Scene/SingleTileImageryProvider.js 371](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L371) 

 Picking features is not currently supported by this imagery provider, so this function simply returns undefined.

| Name      | Type   | Description                              |
| --------- | ------ | ---------------------------------------- |
| x         | number | The tile X coordinate.                   |
| y         | number | The tile Y coordinate.                   |
| level     | number | The tile level.                          |
| longitude | number | The longitude at which to pick features. |
| latitude  | number | The latitude at which to pick features.  |

##### Returns:

 Undefined since picking is not supported.

#### [](#requestImage) requestImage(x, y, level, request) → Promise.<[ImageryTypes](global.html#ImageryTypes)\>|undefined 

[engine/Source/Scene/SingleTileImageryProvider.js 344](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L344) 

 Requests the image for a given tile.

| Name    | Type                    | Description                                                  |
| ------- | ----------------------- | ------------------------------------------------------------ |
| x       | number                  | The tile X coordinate.                                       |
| y       | number                  | The tile Y coordinate.                                       |
| level   | number                  | The tile level.                                              |
| request | [Request](Request.html) | optional The request object. Intended for internal use only. |

##### Returns:

 The resolved image

### Type Definitions

#### [](#.ConstructorOptions) Cesium.SingleTileImageryProvider.ConstructorOptions

[engine/Source/Scene/SingleTileImageryProvider.js 13](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L13) 

 Initialization options for the SingleTileImageryProvider constructor

##### Properties:

| Name       | Type                              | Attributes | Default              | Description                                                     |
| ---------- | --------------------------------- | ---------- | -------------------- | --------------------------------------------------------------- |
| url        | [Resource](Resource.html)\|string |            |                      | The url for the tile.                                           |
| tileWidth  | number                            | <optional> |                      | The width of the tile, in pixels.                               |
| tileHeight | number                            | <optional> |                      | The height of the tile, in pixels.                              |
| rectangle  | [Rectangle](Rectangle.html)       | <optional> | Rectangle.MAX\_VALUE | The rectangle, in radians, covered by the image.                |
| credit     | [Credit](Credit.html)\|string     | <optional> |                      | A credit for the data source, which is displayed on the canvas. |
| ellipsoid  | [Ellipsoid](Ellipsoid.html)       | <optional> |                      | The ellipsoid. If not specified, the WGS84 ellipsoid is used.   |

#### [](#.fromUrlOptions) Cesium.SingleTileImageryProvider.fromUrlOptions

[engine/Source/Scene/SingleTileImageryProvider.js 285](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/SingleTileImageryProvider.js#L285) 

 Initialization options for the SingleTileImageryProvider constructor when using SingleTileImageryProvider.fromUrl

##### Properties:

| Name      | Type                          | Attributes | Default              | Description                                                     |
| --------- | ----------------------------- | ---------- | -------------------- | --------------------------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html)   | <optional> | Rectangle.MAX\_VALUE | The rectangle, in radians, covered by the image.                |
| credit    | [Credit](Credit.html)\|String | <optional> |                      | A credit for the data source, which is displayed on the canvas. |
| ellipsoid | [Ellipsoid](Ellipsoid.html)   | <optional> |                      | The ellipsoid. If not specified, the WGS84 ellipsoid is used.   |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

