# [![](Images/CesiumLogo.png)](index.html) CorridorOutlineGeometry 

#### [](#CorridorOutlineGeometry) new Cesium.CorridorOutlineGeometry(options) 

[engine/Source/Core/CorridorOutlineGeometry.js 378](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CorridorOutlineGeometry.js#L378) 

 A description of a corridor outline.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of positions that define the center of the corridor outline. width number  The distance between the edges of the corridor outline. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid to be used as a reference. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The distance, in radians, between each latitude and longitude. Determines the number of positions in the buffer. height number 0 optional The distance in meters between the positions and the ellipsoid surface. extrudedHeight number optional The distance in meters between the extruded face and the ellipsoid surface. cornerType [CornerType](global.html#CornerType) CornerType.ROUNDED optional Determines the style of the corners. |

##### Example:

```javascript
const corridor = new Cesium.CorridorOutlineGeometry({
  positions : Cesium.Cartesian3.fromDegreesArray([-72.0, 40.0, -70.0, 35.0]),
  width : 100000
});
```

##### See:

* [CorridorOutlineGeometry.createGeometry](CorridorOutlineGeometry.html#.createGeometry)

### Members

#### [](#packedLength) packedLength : number 

[engine/Source/Core/CorridorOutlineGeometry.js 410](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CorridorOutlineGeometry.js#L410) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.CorridorOutlineGeometry.createGeometry(corridorOutlineGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/CorridorOutlineGeometry.js 527](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CorridorOutlineGeometry.js#L527) 

 Computes the geometric representation of a corridor, including its vertices, indices, and a bounding sphere.

| Name                    | Type                                                    | Description                    |
| ----------------------- | ------------------------------------------------------- | ------------------------------ |
| corridorOutlineGeometry | [CorridorOutlineGeometry](CorridorOutlineGeometry.html) | A description of the corridor. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.CorridorOutlineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/CorridorOutlineGeometry.js 423](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CorridorOutlineGeometry.js#L423) 

 Stores the provided instance into the provided array.

| Name          | Type                                                    | Default | Description                                                               |
| ------------- | ------------------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [CorridorOutlineGeometry](CorridorOutlineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                          |         | The array to pack into.                                                   |
| startingIndex | number                                                  | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.CorridorOutlineGeometry.unpack(array, startingIndex, result) → [CorridorOutlineGeometry](CorridorOutlineGeometry.html) 

[engine/Source/Core/CorridorOutlineGeometry.js 472](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CorridorOutlineGeometry.js#L472) 

 Retrieves an instance from a packed array.

| Name          | Type                                                    | Default | Description                                                |
| ------------- | ------------------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                          |         | The packed array.                                          |
| startingIndex | number                                                  | 0       | optional The starting index of the element to be unpacked. |
| result        | [CorridorOutlineGeometry](CorridorOutlineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new CorridorOutlineGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

