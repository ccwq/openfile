# [![](Images/CesiumLogo.png)](index.html) OrthographicFrustum 

#### [](#OrthographicFrustum) new Cesium.OrthographicFrustum(options) 

[engine/Source/Core/OrthographicFrustum.js 30](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L30) 

 The viewing frustum is defined by 6 planes. Each plane is represented by a [Cartesian4](Cartesian4.html) object, where the x, y, and z components define the unit vector normal to the plane, and the w component is the distance of the plane from the origin/camera position.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                           |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional An object with the following properties: Name Type Default Description width number optional The width of the frustum in meters. aspectRatio number optional The aspect ratio of the frustum's width to it's height. near number 1.0 optional The distance of the near plane. far number 500000000.0 optional The distance of the far plane. |

##### Example:

```javascript
const maxRadii = ellipsoid.maximumRadius;

const frustum = new Cesium.OrthographicFrustum();
frustum.near = 0.01 * maxRadii;
frustum.far = 50.0 * maxRadii;
```

### Members

#### [](#.packedLength) static Cesium.OrthographicFrustum.packedLength : number 

[engine/Source/Core/OrthographicFrustum.js 72](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L72) 

 The number of elements used to pack the object into an array.

#### [](#aspectRatio) aspectRatio : number|undefined 

[engine/Source/Core/OrthographicFrustum.js 48](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L48) 

 The aspect ratio of the frustum's width to it's height.

Default Value: `undefined` 

#### [](#far) far : number 

[engine/Source/Core/OrthographicFrustum.js 64](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L64) 

 The distance of the far plane.

Default Value: `500000000.0;` 

#### [](#near) near : number 

[engine/Source/Core/OrthographicFrustum.js 56](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L56) 

 The distance of the near plane.

Default Value: `1.0` 

#### [](#projectionMatrix) readonly projectionMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Core/OrthographicFrustum.js 181](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L181) 

 Gets the orthographic projection matrix computed from the view frustum.

#### [](#width) width : number|undefined 

[engine/Source/Core/OrthographicFrustum.js 40](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L40) 

 The horizontal width of the frustum in meters.

Default Value: `undefined` 

### Methods

#### [](#.pack) static Cesium.OrthographicFrustum.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/OrthographicFrustum.js 83](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L83) 

 Stores the provided instance into the provided array.

| Name          | Type                                            | Default | Description                                                               |
| ------------- | ----------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [OrthographicFrustum](OrthographicFrustum.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                  |         | The array to pack into.                                                   |
| startingIndex | number                                          | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.OrthographicFrustum.unpack(array, startingIndex, result) → [OrthographicFrustum](OrthographicFrustum.html) 

[engine/Source/Core/OrthographicFrustum.js 107](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L107) 

 Retrieves an instance from a packed array.

| Name          | Type                                            | Default | Description                                                |
| ------------- | ----------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                  |         | The packed array.                                          |
| startingIndex | number                                          | 0       | optional The starting index of the element to be unpacked. |
| result        | [OrthographicFrustum](OrthographicFrustum.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new OrthographicFrustum instance if one was not provided.

#### [](#clone) clone(result) → [OrthographicFrustum](OrthographicFrustum.html) 

[engine/Source/Core/OrthographicFrustum.js 266](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L266) 

 Returns a duplicate of a OrthographicFrustum instance.

| Name   | Type                                            | Description                                         |
| ------ | ----------------------------------------------- | --------------------------------------------------- |
| result | [OrthographicFrustum](OrthographicFrustum.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new OrthographicFrustum instance if one was not provided.

#### [](#computeCullingVolume) computeCullingVolume(position, direction, up) → [CullingVolume](CullingVolume.html) 

[engine/Source/Core/OrthographicFrustum.js 215](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L215) 

 Creates a culling volume for this frustum.

| Name      | Type                          | Description         |
| --------- | ----------------------------- | ------------------- |
| position  | [Cartesian3](Cartesian3.html) | The eye position.   |
| direction | [Cartesian3](Cartesian3.html) | The view direction. |
| up        | [Cartesian3](Cartesian3.html) | The up direction.   |

##### Returns:

 A culling volume at the given position and orientation.

##### Example:

```javascript
// Check if a bounding volume intersects the frustum.
const cullingVolume = frustum.computeCullingVolume(cameraPosition, cameraDirection, cameraUp);
const intersect = cullingVolume.computeVisibility(boundingVolume);
```

#### [](#equals) equals(other) → boolean 

[engine/Source/Core/OrthographicFrustum.js 294](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L294) 

 Compares the provided OrthographicFrustum componentwise and returns`true` if they are equal, `false` otherwise.

| Name  | Type                                            | Description                                       |
| ----- | ----------------------------------------------- | ------------------------------------------------- |
| other | [OrthographicFrustum](OrthographicFrustum.html) | optional The right hand side OrthographicFrustum. |

##### Returns:

`true` if they are equal, `false` otherwise.

#### [](#equalsEpsilon) equalsEpsilon(other, relativeEpsilon, absoluteEpsilon) → boolean 

[engine/Source/Core/OrthographicFrustum.js 319](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L319) 

 Compares the provided OrthographicFrustum componentwise and returns`true` if they pass an absolute or relative tolerance test,`false` otherwise.

| Name            | Type                                            | Default         | Description                                                          |
| --------------- | ----------------------------------------------- | --------------- | -------------------------------------------------------------------- |
| other           | [OrthographicFrustum](OrthographicFrustum.html) |                 | The right hand side OrthographicFrustum.                             |
| relativeEpsilon | number                                          |                 | The relative epsilon tolerance to use for equality testing.          |
| absoluteEpsilon | number                                          | relativeEpsilon | optional The absolute epsilon tolerance to use for equality testing. |

##### Returns:

`true` if this and other are within the provided epsilon, `false` otherwise.

#### [](#getPixelDimensions) getPixelDimensions(drawingBufferWidth, drawingBufferHeight, distance, pixelRatio, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/OrthographicFrustum.js 243](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/OrthographicFrustum.js#L243) 

 Returns the pixel's width and height in meters.

| Name                | Type                          | Description                                              |
| ------------------- | ----------------------------- | -------------------------------------------------------- |
| drawingBufferWidth  | number                        | The width of the drawing buffer.                         |
| drawingBufferHeight | number                        | The height of the drawing buffer.                        |
| distance            | number                        | The distance to the near plane in meters.                |
| pixelRatio          | number                        | The scaling factor from pixel space to coordinate space. |
| result              | [Cartesian2](Cartesian2.html) | The object onto which to store the result.               |

##### Returns:

 The modified result parameter or a new instance of [Cartesian2](Cartesian2.html) with the pixel's width and height in the x and y properties, respectively.

##### Throws:

* [DeveloperError](DeveloperError.html): drawingBufferWidth must be greater than zero.
* [DeveloperError](DeveloperError.html): drawingBufferHeight must be greater than zero.
* [DeveloperError](DeveloperError.html): pixelRatio must be greater than zero.

##### Example:

```javascript
// Example 1
// Get the width and height of a pixel.
const pixelSize = camera.frustum.getPixelDimensions(scene.drawingBufferWidth, scene.drawingBufferHeight, 0.0, scene.pixelRatio, new Cesium.Cartesian2());
```

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

