# [![](Images/CesiumLogo.png)](index.html) CylinderOutlineGeometry 

#### [](#CylinderOutlineGeometry) new Cesium.CylinderOutlineGeometry(options) 

[engine/Source/Core/CylinderOutlineGeometry.js 49](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CylinderOutlineGeometry.js#L49) 

 A description of the outline of a cylinder.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description length number  The length of the cylinder. topRadius number  The radius of the top of the cylinder. bottomRadius number  The radius of the bottom of the cylinder. slices number 128 optional The number of edges around the perimeter of the cylinder. numberOfVerticalLines number 16 optional Number of lines to draw between the top and bottom surfaces of the cylinder. |

##### Throws:

* [DeveloperError](DeveloperError.html): options.length must be greater than 0.
* [DeveloperError](DeveloperError.html): options.topRadius must be greater than 0.
* [DeveloperError](DeveloperError.html): options.bottomRadius must be greater than 0.
* [DeveloperError](DeveloperError.html): bottomRadius and topRadius cannot both equal 0.
* [DeveloperError](DeveloperError.html): options.slices must be greater than or equal to 3.

##### Example:

```javascript
// create cylinder geometry
const cylinder = new Cesium.CylinderOutlineGeometry({
    length: 200000,
    topRadius: 80000,
    bottomRadius: 200000,
});
const geometry = Cesium.CylinderOutlineGeometry.createGeometry(cylinder);
```

##### See:

* [CylinderOutlineGeometry.createGeometry](CylinderOutlineGeometry.html#.createGeometry)

### Members

#### [](#.packedLength) static Cesium.CylinderOutlineGeometry.packedLength : number 

[engine/Source/Core/CylinderOutlineGeometry.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CylinderOutlineGeometry.js#L89) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.CylinderOutlineGeometry.createGeometry(cylinderGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/CylinderOutlineGeometry.js 177](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CylinderOutlineGeometry.js#L177) 

 Computes the geometric representation of an outline of a cylinder, including its vertices, indices, and a bounding sphere.

| Name             | Type                                                    | Description                            |
| ---------------- | ------------------------------------------------------- | -------------------------------------- |
| cylinderGeometry | [CylinderOutlineGeometry](CylinderOutlineGeometry.html) | A description of the cylinder outline. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.CylinderOutlineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/CylinderOutlineGeometry.js 100](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CylinderOutlineGeometry.js#L100) 

 Stores the provided instance into the provided array.

| Name          | Type                                                    | Default | Description                                                               |
| ------------- | ------------------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [CylinderOutlineGeometry](CylinderOutlineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                          |         | The array to pack into.                                                   |
| startingIndex | number                                                  | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.CylinderOutlineGeometry.unpack(array, startingIndex, result) → [CylinderOutlineGeometry](CylinderOutlineGeometry.html) 

[engine/Source/Core/CylinderOutlineGeometry.js 135](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/CylinderOutlineGeometry.js#L135) 

 Retrieves an instance from a packed array.

| Name          | Type                                                    | Default | Description                                                |
| ------------- | ------------------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                          |         | The packed array.                                          |
| startingIndex | number                                                  | 0       | optional The starting index of the element to be unpacked. |
| result        | [CylinderOutlineGeometry](CylinderOutlineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new CylinderOutlineGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

