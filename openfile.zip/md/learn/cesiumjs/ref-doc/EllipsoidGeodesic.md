# [![](Images/CesiumLogo.png)](index.html) EllipsoidGeodesic 

#### [](#EllipsoidGeodesic) new Cesium.EllipsoidGeodesic(start, end, ellipsoid) 

[engine/Source/Core/EllipsoidGeodesic.js 286](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeodesic.js#L286) 

 Initializes a geodesic on the ellipsoid connecting the two provided planetodetic points.

| Name      | Type                              | Default           | Description                                          |
| --------- | --------------------------------- | ----------------- | ---------------------------------------------------- |
| start     | [Cartographic](Cartographic.html) |                   | optional The initial planetodetic point on the path. |
| end       | [Cartographic](Cartographic.html) |                   | optional The final planetodetic point on the path.   |
| ellipsoid | [Ellipsoid](Ellipsoid.html)       | Ellipsoid.default | optional The ellipsoid on which the geodesic lies.   |

### Members

#### [](#ellipsoid) readonly ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/EllipsoidGeodesic.js 310](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeodesic.js#L310) 

 Gets the ellipsoid.

#### [](#end) readonly end : [Cartographic](Cartographic.html) 

[engine/Source/Core/EllipsoidGeodesic.js 350](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeodesic.js#L350) 

 Gets the final planetodetic point on the path.

#### [](#endHeading) readonly endHeading : number 

[engine/Source/Core/EllipsoidGeodesic.js 378](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeodesic.js#L378) 

 Gets the heading at the final point.

#### [](#start) readonly start : [Cartographic](Cartographic.html) 

[engine/Source/Core/EllipsoidGeodesic.js 338](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeodesic.js#L338) 

 Gets the initial planetodetic point on the path.

#### [](#startHeading) readonly startHeading : number 

[engine/Source/Core/EllipsoidGeodesic.js 362](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeodesic.js#L362) 

 Gets the heading at the initial point.

#### [](#surfaceDistance) readonly surfaceDistance : number 

[engine/Source/Core/EllipsoidGeodesic.js 322](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeodesic.js#L322) 

 Gets the surface distance between the start and end point

### Methods

#### [](#interpolateUsingFraction) interpolateUsingFraction(fraction, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/EllipsoidGeodesic.js 411](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeodesic.js#L411) 

 Provides the location of a point at the indicated portion along the geodesic.

| Name     | Type                              | Description                                                       |
| -------- | --------------------------------- | ----------------------------------------------------------------- |
| fraction | number                            | The portion of the distance between the initial and final points. |
| result   | [Cartographic](Cartographic.html) | optional The object in which to store the result.                 |

##### Returns:

 The location of the point along the geodesic.

#### [](#interpolateUsingSurfaceDistance) interpolateUsingSurfaceDistance(distance, result) → [Cartographic](Cartographic.html) 

[engine/Source/Core/EllipsoidGeodesic.js 430](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeodesic.js#L430) 

 Provides the location of a point at the indicated distance along the geodesic.

| Name     | Type                              | Description                                                                     |
| -------- | --------------------------------- | ------------------------------------------------------------------------------- |
| distance | number                            | The distance from the initial point to the point of interest along the geodesic |
| result   | [Cartographic](Cartographic.html) | optional The object in which to store the result.                               |

##### Returns:

 The location of the point along the geodesic.

##### Throws:

* [DeveloperError](DeveloperError.html): start and end must be set before calling function interpolateUsingSurfaceDistance

#### [](#setEndPoints) setEndPoints(start, end) 

[engine/Source/Core/EllipsoidGeodesic.js 395](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/EllipsoidGeodesic.js#L395) 

 Sets the start and end points of the geodesic

| Name  | Type                              | Description                                 |
| ----- | --------------------------------- | ------------------------------------------- |
| start | [Cartographic](Cartographic.html) | The initial planetodetic point on the path. |
| end   | [Cartographic](Cartographic.html) | The final planetodetic point on the path.   |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

