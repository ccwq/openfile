# [![](Images/CesiumLogo.png)](index.html) VoxelPrimitive 

#### [](#VoxelPrimitive) new Cesium.VoxelPrimitive(options) 

[engine/Source/Scene/VoxelPrimitive.js 51](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L51) 

 A primitive that renders voxel data from a [VoxelProvider](VoxelProvider.html).

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description provider [VoxelProvider](VoxelProvider.html) optional The voxel provider that supplies the primitive with tile data. modelMatrix [Matrix4](Matrix4.html) Matrix4.IDENTITY optional The model matrix used to transform the primitive. customShader [CustomShader](CustomShader.html) optional The custom shader used to style the primitive. clock [Clock](Clock.html) optional The clock used to control time dynamic behavior. calculateStatistics Boolean optional Generate statistics for performance profile. |

##### Experimental

This feature is not final and is subject to change without Cesium's standard deprecation policy.

##### See:

* [VoxelProvider](VoxelProvider.html)
* [Cesium3DTilesVoxelProvider](Cesium3DTilesVoxelProvider.html)
* [VoxelShapeType](global.html#VoxelShapeType)

### Members

#### [](#allTilesLoaded) allTilesLoaded : [Event](Event.html) 

[engine/Source/Scene/VoxelPrimitive.js 583](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L583) 

 The event fired to indicate that all tiles that meet the screen space error this frame are loaded. The voxel primitive is completely loaded for this view.

This event is fired at the end of the frame after the scene is rendered.

##### Example:

```javascript
voxelPrimitive.allTilesLoaded.addEventListener(function() {
    console.log('All tiles are loaded');
});
```

#### [](#boundingSphere) readonly boundingSphere : [BoundingSphere](BoundingSphere.html) 

[engine/Source/Scene/VoxelPrimitive.js 681](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L681) 

 Gets the bounding sphere.

#### [](#clippingPlanes) clippingPlanes : [ClippingPlaneCollection](ClippingPlaneCollection.html) 

[engine/Source/Scene/VoxelPrimitive.js 1070](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L1070) 

 The [ClippingPlaneCollection](ClippingPlaneCollection.html) used to selectively disable rendering the primitive.

#### [](#customShader) customShader : [CustomShader](CustomShader.html) 

[engine/Source/Scene/VoxelPrimitive.js 1086](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L1086) 

 Gets or sets the custom shader. If undefined, `VoxelPrimitive.DefaultCustomShader` is set.

#### [](#customShaderCompilationEvent) readonly customShaderCompilationEvent : [Event](Event.html) 

[engine/Source/Scene/VoxelPrimitive.js 1123](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L1123) 

 Gets an event that is raised whenever a custom shader is compiled.

#### [](#debugDraw) debugDraw : boolean 

[engine/Source/Scene/VoxelPrimitive.js 856](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L856) 

 Gets or sets whether or not to render debug visualizations.

#### [](#depthTest) depthTest : boolean 

[engine/Source/Scene/VoxelPrimitive.js 875](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L875) 

 Gets or sets whether or not to test against depth when rendering.

#### [](#dimensions) readonly dimensions : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/VoxelPrimitive.js 741](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L741) 

 Gets the dimensions of each voxel tile, in z-up orientation. Does not include padding.

#### [](#disableUpdate) disableUpdate : boolean 

[engine/Source/Scene/VoxelPrimitive.js 837](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L837) 

 Gets or sets whether or not the primitive should update when the view changes.

#### [](#initialTilesLoaded) initialTilesLoaded : [Event](Event.html) 

[engine/Source/Scene/VoxelPrimitive.js 601](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L601) 

 The event fired to indicate that all tiles that meet the screen space error this frame are loaded. This event is fired once when all tiles in the initial view are loaded.

This event is fired at the end of the frame after the scene is rendered.

##### Example:

```javascript
voxelPrimitive.initialTilesLoaded.addEventListener(function() {
    console.log('Initial tiles are loaded');
});
```

##### See:

* [Cesium3DTileset#allTilesLoaded](Cesium3DTileset.html#allTilesLoaded)

#### [](#inputDimensions) readonly inputDimensions : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/VoxelPrimitive.js 754](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L754) 

 Gets the dimensions of one tile of the input voxel data, in the input orientation. Includes padding.

#### [](#loadProgress) loadProgress : [Event](Event.html) 

[engine/Source/Scene/VoxelPrimitive.js 567](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L567) 

 The event fired to indicate progress of loading new tiles. This event is fired when a new tile is requested, when a requested tile is finished downloading, and when a downloaded tile has been processed and is ready to render.

The number of pending tile requests, `numberOfPendingRequests`, and number of tiles processing, `numberOfTilesProcessing` are passed to the event listener.

This event is fired at the end of the frame after the scene is rendered.

##### Example:

```javascript
voxelPrimitive.loadProgress.addEventListener(function(numberOfPendingRequests, numberOfTilesProcessing) {
    if ((numberOfPendingRequests === 0) && (numberOfTilesProcessing === 0)) {
        console.log('Finished loading');
        return;
    }

    console.log(`Loading: requests: ${numberOfPendingRequests}, processing: ${numberOfTilesProcessing}`);
});
```

#### [](#maxBounds) maxBounds : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/VoxelPrimitive.js 1005](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L1005) 

 Gets or sets the maximum bounds in the shape's local coordinate system. Voxel data is stretched or squashed to fit the bounds.

#### [](#maxClippingBounds) maxClippingBounds : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/VoxelPrimitive.js 1048](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L1048) 

 Gets or sets the maximum clipping location in the shape's local coordinate system. Any voxel content outside the range is clipped.

#### [](#maximumValues) readonly maximumValues : Array.<Array.<number>> 

[engine/Source/Scene/VoxelPrimitive.js 806](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L806) 

 Gets the maximum value per channel of the voxel data.

#### [](#minBounds) minBounds : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/VoxelPrimitive.js 985](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L985) 

 Gets or sets the minimum bounds in the shape's local coordinate system. Voxel data is stretched or squashed to fit the bounds.

#### [](#minClippingBounds) minClippingBounds : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/VoxelPrimitive.js 1025](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L1025) 

 Gets or sets the minimum clipping location in the shape's local coordinate system. Any voxel content outside the range is clipped.

#### [](#minimumValues) readonly minimumValues : Array.<Array.<number>> 

[engine/Source/Scene/VoxelPrimitive.js 793](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L793) 

 Gets the minimum value per channel of the voxel data.

#### [](#modelMatrix) readonly modelMatrix : [Matrix4](Matrix4.html) 

[engine/Source/Scene/VoxelPrimitive.js 707](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L707) 

 Gets the model matrix.

#### [](#nearestSampling) nearestSampling : boolean 

[engine/Source/Scene/VoxelPrimitive.js 897](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L897) 

 Gets or sets the nearest sampling.

#### [](#orientedBoundingBox) readonly orientedBoundingBox : [OrientedBoundingBox](OrientedBoundingBox.html) 

[engine/Source/Scene/VoxelPrimitive.js 694](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L694) 

 Gets the oriented bounding box.

#### [](#paddingAfter) readonly paddingAfter : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/VoxelPrimitive.js 780](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L780) 

 Gets the padding after the voxel data.

#### [](#paddingBefore) readonly paddingBefore : [Cartesian3](Cartesian3.html) 

[engine/Source/Scene/VoxelPrimitive.js 767](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L767) 

 Gets the padding before the voxel data.

#### [](#provider) readonly provider : [VoxelProvider](VoxelProvider.html) 

[engine/Source/Scene/VoxelPrimitive.js 668](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L668) 

 Gets the [VoxelProvider](VoxelProvider.html) associated with this primitive.

#### [](#ready) readonly ready : boolean 

[engine/Source/Scene/VoxelPrimitive.js 655](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L655) 

 Gets a value indicating whether or not the primitive is ready for use.

#### [](#screenSpaceError) screenSpaceError : number 

[engine/Source/Scene/VoxelPrimitive.js 944](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L944) 

 Gets or sets the screen space error in pixels. If the screen space size of a voxel is greater than the screen space error, the tile is subdivided. Lower screen space error corresponds with higher detail rendering, but could result in worse performance and higher memory consumption.

#### [](#shape) readonly shape : [VoxelShapeType](global.html#VoxelShapeType) 

[engine/Source/Scene/VoxelPrimitive.js 727](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L727) 

 Gets the shape type.

#### [](#show) show : boolean 

[engine/Source/Scene/VoxelPrimitive.js 818](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L818) 

 Gets or sets whether or not this primitive should be displayed.

#### [](#stepSize) stepSize : number 

[engine/Source/Scene/VoxelPrimitive.js 965](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L965) 

 Gets or sets the step size multiplier used during raymarching. The lower the value, the higher the rendering quality, but also the worse the performance.

#### [](#tileFailed) tileFailed : [Event](Event.html) 

[engine/Source/Scene/VoxelPrimitive.js 528](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L528) 

 The event fired to indicate that a tile's content failed to load.

##### Example:

```javascript
voxelPrimitive.tileFailed.addEventListener(function() {
    console.log('An error occurred loading tile.');
});
```

#### [](#tileLoad) tileLoad : [Event](Event.html) 

[engine/Source/Scene/VoxelPrimitive.js 501](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L501) 

 The event fired to indicate that a tile's content was loaded.

This event is fired during the tileset traversal while the frame is being rendered so that updates to the tile take effect in the same frame. Do not create or modify Cesium entities or primitives during the event listener.

##### Example:

```javascript
voxelPrimitive.tileLoad.addEventListener(function() {
    console.log('A tile was loaded.');
});
```

#### [](#tileUnload) tileUnload : [Event](Event.html) 

[engine/Source/Scene/VoxelPrimitive.js 541](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L541) 

 The event fired to indicate that a tile's content was unloaded.

##### Example:

```javascript
voxelPrimitive.tileUnload.addEventListener(function() {
    console.log('A tile was unloaded from the cache.');
});
```

#### [](#tileVisible) tileVisible : [Event](Event.html) 

[engine/Source/Scene/VoxelPrimitive.js 516](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L516) 

 This event fires once for each visible tile in a frame.

This event is fired during the traversal while the frame is being rendered.

##### Example:

```javascript
voxelPrimitive.tileVisible.addEventListener(function() {
    console.log('A tile is visible.');
});
```

### Methods

#### [](#destroy) destroy() 

[engine/Source/Scene/VoxelPrimitive.js 1853](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L1853) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
voxelPrimitive = voxelPrimitive && voxelPrimitive.destroy();
```

##### See:

* [VoxelPrimitive#isDestroyed](VoxelPrimitive.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/VoxelPrimitive.js 1834](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/VoxelPrimitive.js#L1834) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

`true` if this object was destroyed; otherwise, `false`.

##### See:

* [VoxelPrimitive#destroy](VoxelPrimitive.html#destroy)

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

