# [![](Images/CesiumLogo.png)](index.html) EllipseGraphics 

#### [](#EllipseGraphics) new Cesium.EllipseGraphics(options) 

[engine/Source/DataSources/EllipseGraphics.js 48](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L48) 

 Describes an ellipse defined by a center point and semi-major and semi-minor axes. The ellipse conforms to the curvature of the globe and can be placed on the surface or at altitude and can optionally be extruded into a volume. The center point is determined by the containing [Entity](Entity.html).

| Name    | Type                                                                           | Description                                       |
| ------- | ------------------------------------------------------------------------------ | ------------------------------------------------- |
| options | [EllipseGraphics.ConstructorOptions](EllipseGraphics.html#.ConstructorOptions) | optional Object describing initialization options |

##### Demo:

* [Cesium Sandcastle Circles and Ellipses Demo](https://sandcastle.cesium.com/index.html?src=Circles%20and%20Ellipses.html)

### Members

#### [](#classificationType) classificationType : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 261](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L261) 

 Gets or sets the [ClassificationType](global.html#ClassificationType) Property specifying whether this ellipse will classify terrain, 3D Tiles, or both when on the ground.

Default Value: `ClassificationType.BOTH` 

#### [](#definitionChanged) readonly definitionChanged : [Event](Event.html) 

[engine/Source/DataSources/EllipseGraphics.js 102](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L102) 

 Gets the event that is raised whenever a property or sub-property is changed or modified.

#### [](#distanceDisplayCondition) distanceDisplayCondition : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 251](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L251) 

 Gets or sets the [DistanceDisplayCondition](DistanceDisplayCondition.html) Property specifying at what distance from the camera that this ellipse will be displayed.

#### [](#extrudedHeight) extrudedHeight : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 152](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L152) 

 Gets or sets the numeric Property specifying the altitude of the ellipse extrusion. Setting this property creates volume starting at height and ending at this altitude.

#### [](#extrudedHeightReference) extrudedHeightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 160](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L160) 

 Gets or sets the Property specifying the extruded [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#fill) fill : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 192](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L192) 

 Gets or sets the boolean Property specifying whether the ellipse is filled with the provided material.

Default Value: `true` 

#### [](#granularity) granularity : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 184](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L184) 

 Gets or sets the numeric Property specifying the angular distance between points on the ellipse.

Default Value: `{CesiumMath.RADIANS_PER_DEGREE}` 

#### [](#height) height : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 136](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L136) 

 Gets or sets the numeric Property specifying the altitude of the ellipse.

Default Value: `0.0` 

#### [](#heightReference) heightReference : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 144](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L144) 

 Gets or sets the Property specifying the [HeightReference](global.html#HeightReference).

Default Value: `HeightReference.NONE` 

#### [](#material) material : [MaterialProperty](MaterialProperty.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 200](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L200) 

 Gets or sets the Property specifying the material used to fill the ellipse.

Default Value: `Color.WHITE` 

#### [](#numberOfVerticalLines) numberOfVerticalLines : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 235](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L235) 

 Gets or sets the numeric Property specifying the number of vertical lines to draw along the perimeter for the outline.

Default Value: `16` 

#### [](#outline) outline : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 208](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L208) 

 Gets or sets the Property specifying whether the ellipse is outlined.

Default Value: `false` 

#### [](#outlineColor) outlineColor : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 216](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L216) 

 Gets or sets the Property specifying the [Color](Color.html) of the outline.

Default Value: `Color.BLACK` 

#### [](#outlineWidth) outlineWidth : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 227](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L227) 

 Gets or sets the numeric Property specifying the width of the outline.

Note: This property will be ignored on all major browsers on Windows platforms. For details, see (@link https://github.com/CesiumGS/cesium/issues/40}.

Default Value: `1.0` 

#### [](#rotation) rotation : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 168](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L168) 

 Gets or sets the numeric property specifying the rotation of the ellipse counter-clockwise from north.

Default Value: `0` 

#### [](#semiMajorAxis) semiMajorAxis : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 121](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L121) 

 Gets or sets the numeric Property specifying the semi-major axis.

#### [](#semiMinorAxis) semiMinorAxis : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 128](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L128) 

 Gets or sets the numeric Property specifying the semi-minor axis.

#### [](#shadows) shadows : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 244](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L244) 

 Get or sets the enum Property specifying whether the ellipse casts or receives shadows from light sources.

Default Value: `ShadowMode.DISABLED` 

#### [](#show) show : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 114](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L114) 

 Gets or sets the boolean Property specifying the visibility of the ellipse.

Default Value: `true` 

#### [](#stRotation) stRotation : [Property](Property.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 176](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L176) 

 Gets or sets the numeric property specifying the rotation of the ellipse texture counter-clockwise from north.

Default Value: `0` 

#### [](#zIndex) zIndex : [ConstantProperty](ConstantProperty.html)|undefined 

[engine/Source/DataSources/EllipseGraphics.js 269](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L269) 

 Gets or sets the zIndex Property specifying the ellipse ordering. Only has an effect if the ellipse is constant and neither height or extrudedHeight are specified

Default Value: `0` 

### Methods

#### [](#clone) clone(result) → [EllipseGraphics](EllipseGraphics.html) 

[engine/Source/DataSources/EllipseGraphics.js 278](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L278) 

 Duplicates this instance.

| Name   | Type                                    | Description                                         |
| ------ | --------------------------------------- | --------------------------------------------------- |
| result | [EllipseGraphics](EllipseGraphics.html) | optional The object onto which to store the result. |

##### Returns:

 The modified result parameter or a new instance if one was not provided.

#### [](#merge) merge(source) 

[engine/Source/DataSources/EllipseGraphics.js 311](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L311) 

 Assigns each unassigned property on this object to the value of the same property on the provided source object.

| Name   | Type                                    | Description                               |
| ------ | --------------------------------------- | ----------------------------------------- |
| source | [EllipseGraphics](EllipseGraphics.html) | The object to be merged into this object. |

### Type Definitions

#### [](#.ConstructorOptions) Cesium.EllipseGraphics.ConstructorOptions

[engine/Source/DataSources/EllipseGraphics.js 8](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/DataSources/EllipseGraphics.js#L8) 

 Initialization options for the EllipseGraphics constructor

##### Properties:

| Name                     | Type                                                                                 | Attributes | Default                          | Description                                                                                                                                                                           |
| ------------------------ | ------------------------------------------------------------------------------------ | ---------- | -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| show                     | [Property](Property.html)\|boolean                                                   | <optional> | true                             | A boolean Property specifying the visibility of the ellipse.                                                                                                                          |
| semiMajorAxis            | [Property](Property.html)\|number                                                    | <optional> |                                  | The numeric Property specifying the semi-major axis.                                                                                                                                  |
| semiMinorAxis            | [Property](Property.html)\|number                                                    | <optional> |                                  | The numeric Property specifying the semi-minor axis.                                                                                                                                  |
| height                   | [Property](Property.html)\|number                                                    | <optional> | 0                                | A numeric Property specifying the altitude of the ellipse relative to the ellipsoid surface.                                                                                          |
| heightReference          | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE             | A Property specifying what the height is relative to.                                                                                                                                 |
| extrudedHeight           | [Property](Property.html)\|number                                                    | <optional> |                                  | A numeric Property specifying the altitude of the ellipse's extruded face relative to the ellipsoid surface.                                                                          |
| extrudedHeightReference  | [Property](Property.html)\|[HeightReference](global.html#HeightReference)            | <optional> | HeightReference.NONE             | A Property specifying what the extrudedHeight is relative to.                                                                                                                         |
| rotation                 | [Property](Property.html)\|number                                                    | <optional> | 0.0                              | A numeric property specifying the rotation of the ellipse counter-clockwise from north.                                                                                               |
| stRotation               | [Property](Property.html)\|number                                                    | <optional> | 0.0                              | A numeric property specifying the rotation of the ellipse texture counter-clockwise from north.                                                                                       |
| granularity              | [Property](Property.html)\|number                                                    | <optional> | Cesium.Math.RADIANS\_PER\_DEGREE | A numeric Property specifying the angular distance between points on the ellipse.                                                                                                     |
| fill                     | [Property](Property.html)\|boolean                                                   | <optional> | true                             | A boolean Property specifying whether the ellipse is filled with the provided material.                                                                                               |
| material                 | [MaterialProperty](MaterialProperty.html)\|[Color](Color.html)                       | <optional> | Color.WHITE                      | A Property specifying the material used to fill the ellipse.                                                                                                                          |
| outline                  | [Property](Property.html)\|boolean                                                   | <optional> | false                            | A boolean Property specifying whether the ellipse is outlined.                                                                                                                        |
| outlineColor             | [Property](Property.html)\|[Color](Color.html)                                       | <optional> | Color.BLACK                      | A Property specifying the [Color](Color.html) of the outline.                                                                                                                         |
| outlineWidth             | [Property](Property.html)\|number                                                    | <optional> | 1.0                              | A numeric Property specifying the width of the outline.                                                                                                                               |
| numberOfVerticalLines    | [Property](Property.html)\|number                                                    | <optional> | 16                               | A numeric Property specifying the number of vertical lines to draw along the perimeter for the outline.                                                                               |
| shadows                  | [Property](Property.html)\|[ShadowMode](global.html#ShadowMode)                      | <optional> | ShadowMode.DISABLED              | An enum Property specifying whether the ellipse casts or receives shadows from light sources.                                                                                         |
| distanceDisplayCondition | [Property](Property.html)\|[DistanceDisplayCondition](DistanceDisplayCondition.html) | <optional> |                                  | A Property specifying at what distance from the camera that this ellipse will be displayed.                                                                                           |
| classificationType       | [Property](Property.html)\|[ClassificationType](global.html#ClassificationType)      | <optional> | ClassificationType.BOTH          | An enum Property specifying whether this ellipse will classify terrain, 3D Tiles, or both when on the ground.                                                                         |
| zIndex                   | [ConstantProperty](ConstantProperty.html)\|number                                    | <optional> | 0                                | A property specifying the zIndex of the Ellipse. Used for ordering ground geometry. Only has an effect if the ellipse is constant and neither height or exturdedHeight are specified. |

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

