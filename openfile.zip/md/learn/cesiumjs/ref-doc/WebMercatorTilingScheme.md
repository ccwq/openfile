# [![](Images/CesiumLogo.png)](index.html) WebMercatorTilingScheme 

#### [](#WebMercatorTilingScheme) new Cesium.WebMercatorTilingScheme(options) 

[engine/Source/Core/WebMercatorTilingScheme.js 31](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorTilingScheme.js#L31) 

 A tiling scheme for geometry referenced to a [WebMercatorProjection](WebMercatorProjection.html), EPSG:3857\. This is the tiling scheme used by Google Maps, Microsoft Bing Maps, and most of ESRI ArcGIS Online.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| ------- | ------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid whose surface is being tiled. Defaults to the default ellipsoid. numberOfLevelZeroTilesX number 1 optional The number of tiles in the X direction at level zero of the tile tree. numberOfLevelZeroTilesY number 1 optional The number of tiles in the Y direction at level zero of the tile tree. rectangleSouthwestInMeters [Cartesian2](Cartesian2.html) optional The southwest corner of the rectangle covered by the tiling scheme, in meters. If this parameter or rectangleNortheastInMeters is not specified, the entire globe is covered in the longitude direction and an equal distance is covered in the latitude direction, resulting in a square projection. rectangleNortheastInMeters [Cartesian2](Cartesian2.html) optional The northeast corner of the rectangle covered by the tiling scheme, in meters. If this parameter or rectangleSouthwestInMeters is not specified, the entire globe is covered in the longitude direction and an equal distance is covered in the latitude direction, resulting in a square projection. |

### Members

#### [](#ellipsoid) ellipsoid : [Ellipsoid](Ellipsoid.html) 

[engine/Source/Core/WebMercatorTilingScheme.js 84](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorTilingScheme.js#L84) 

 Gets the ellipsoid that is tiled by this tiling scheme.

#### [](#projection) projection : [MapProjection](MapProjection.html) 

[engine/Source/Core/WebMercatorTilingScheme.js 106](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorTilingScheme.js#L106) 

 Gets the map projection used by this tiling scheme.

#### [](#rectangle) rectangle : [Rectangle](Rectangle.html) 

[engine/Source/Core/WebMercatorTilingScheme.js 95](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorTilingScheme.js#L95) 

 Gets the rectangle, in radians, covered by this tiling scheme.

### Methods

#### [](#getNumberOfXTilesAtLevel) getNumberOfXTilesAtLevel(level) → number 

[engine/Source/Core/WebMercatorTilingScheme.js 119](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorTilingScheme.js#L119) 

 Gets the total number of tiles in the X direction at a specified level-of-detail.

| Name  | Type   | Description          |
| ----- | ------ | -------------------- |
| level | number | The level-of-detail. |

##### Returns:

 The number of tiles in the X direction at the given level.

#### [](#getNumberOfYTilesAtLevel) getNumberOfYTilesAtLevel(level) → number 

[engine/Source/Core/WebMercatorTilingScheme.js 129](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorTilingScheme.js#L129) 

 Gets the total number of tiles in the Y direction at a specified level-of-detail.

| Name  | Type   | Description          |
| ----- | ------ | -------------------- |
| level | number | The level-of-detail. |

##### Returns:

 The number of tiles in the Y direction at the given level.

#### [](#positionToTileXY) positionToTileXY(position, level, result) → [Cartesian2](Cartesian2.html) 

[engine/Source/Core/WebMercatorTilingScheme.js 251](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorTilingScheme.js#L251) 

 Calculates the tile x, y coordinates of the tile containing a given cartographic position.

| Name     | Type                              | Description                                                                                          |
| -------- | --------------------------------- | ---------------------------------------------------------------------------------------------------- |
| position | [Cartographic](Cartographic.html) | The position.                                                                                        |
| level    | number                            | The tile level-of-detail. Zero is the least detailed.                                                |
| result   | [Cartesian2](Cartesian2.html)     | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the tile x, y coordinates if 'result' is undefined.

#### [](#rectangleToNativeRectangle) rectangleToNativeRectangle(rectangle, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/WebMercatorTilingScheme.js 143](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorTilingScheme.js#L143) 

 Transforms a rectangle specified in geodetic radians to the native coordinate system of this tiling scheme.

| Name      | Type                        | Description                                                                                          |
| --------- | --------------------------- | ---------------------------------------------------------------------------------------------------- |
| rectangle | [Rectangle](Rectangle.html) | The rectangle to transform.                                                                          |
| result    | [Rectangle](Rectangle.html) | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the native rectangle if 'result' is undefined.

#### [](#tileXYToNativeRectangle) tileXYToNativeRectangle(x, y, level, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/WebMercatorTilingScheme.js 174](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorTilingScheme.js#L174) 

 Converts tile x, y coordinates and level to a rectangle expressed in the native coordinates of the tiling scheme.

| Name   | Type   | Description                                                                                          |
| ------ | ------ | ---------------------------------------------------------------------------------------------------- |
| x      | number | The integer x coordinate of the tile.                                                                |
| y      | number | The integer y coordinate of the tile.                                                                |
| level  | number | The tile level-of-detail. Zero is the least detailed.                                                |
| result | object | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the rectangle if 'result' is undefined.

#### [](#tileXYToRectangle) tileXYToRectangle(x, y, level, result) → [Rectangle](Rectangle.html) 

[engine/Source/Core/WebMercatorTilingScheme.js 217](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/WebMercatorTilingScheme.js#L217) 

 Converts tile x, y coordinates and level to a cartographic rectangle in radians.

| Name   | Type   | Description                                                                                          |
| ------ | ------ | ---------------------------------------------------------------------------------------------------- |
| x      | number | The integer x coordinate of the tile.                                                                |
| y      | number | The integer y coordinate of the tile.                                                                |
| level  | number | The tile level-of-detail. Zero is the least detailed.                                                |
| result | object | optional The instance to which to copy the result, or undefined if a new instance should be created. |

##### Returns:

 The specified 'result', or a new object containing the rectangle if 'result' is undefined.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

