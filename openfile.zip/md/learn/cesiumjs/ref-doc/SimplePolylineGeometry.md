# [![](Images/CesiumLogo.png)](index.html) SimplePolylineGeometry 

#### [](#SimplePolylineGeometry) new Cesium.SimplePolylineGeometry(options) 

[engine/Source/Core/SimplePolylineGeometry.js 89](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SimplePolylineGeometry.js#L89) 

 A description of a polyline modeled as a line strip; the first two positions define a line segment, and each additional position defines a line segment from the previous position.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | Object with the following properties: Name Type Default Description positions Array.<[Cartesian3](Cartesian3.html)\>  An array of [Cartesian3](Cartesian3.html) defining the positions in the polyline as a line strip. colors Array.<[Color](Color.html)\> optional An Array of [Color](Color.html) defining the per vertex or per segment colors. colorsPerVertex boolean false optional A boolean that determines whether the colors will be flat across each segment of the line or interpolated across the vertices. arcType [ArcType](global.html#ArcType) ArcType.GEODESIC optional The type of line the polyline segments must follow. granularity number CesiumMath.RADIANS\_PER\_DEGREE optional The distance, in radians, between each latitude and longitude if options.arcType is not ArcType.NONE. Determines the number of positions in the buffer. ellipsoid [Ellipsoid](Ellipsoid.html) Ellipsoid.default optional The ellipsoid to be used as a reference. |

##### Throws:

* [DeveloperError](DeveloperError.html): At least two positions are required.
* [DeveloperError](DeveloperError.html): colors has an invalid length.

##### Example:

```javascript
// A polyline with two connected line segments
const polyline = new Cesium.SimplePolylineGeometry({
  positions : Cesium.Cartesian3.fromDegreesArray([
    0.0, 0.0,
    5.0, 0.0,
    5.0, 5.0
  ])
});
const geometry = Cesium.SimplePolylineGeometry.createGeometry(polyline);
```

##### See:

* SimplePolylineGeometry#createGeometry

### Members

#### [](#packedLength) packedLength : number 

[engine/Source/Core/SimplePolylineGeometry.js 127](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SimplePolylineGeometry.js#L127) 

 The number of elements used to pack the object into an array.

### Methods

#### [](#.createGeometry) static Cesium.SimplePolylineGeometry.createGeometry(simplePolylineGeometry) → [Geometry](Geometry.html)|undefined 

[engine/Source/Core/SimplePolylineGeometry.js 256](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SimplePolylineGeometry.js#L256) 

 Computes the geometric representation of a simple polyline, including its vertices, indices, and a bounding sphere.

| Name                   | Type                                                  | Description                    |
| ---------------------- | ----------------------------------------------------- | ------------------------------ |
| simplePolylineGeometry | [SimplePolylineGeometry](SimplePolylineGeometry.html) | A description of the polyline. |

##### Returns:

 The computed vertices and indices.

#### [](#.pack) static Cesium.SimplePolylineGeometry.pack(value, array, startingIndex) → Array.<number> 

[engine/Source/Core/SimplePolylineGeometry.js 139](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SimplePolylineGeometry.js#L139) 

 Stores the provided instance into the provided array.

| Name          | Type                                                  | Default | Description                                                               |
| ------------- | ----------------------------------------------------- | ------- | ------------------------------------------------------------------------- |
| value         | [SimplePolylineGeometry](SimplePolylineGeometry.html) |         | The value to pack.                                                        |
| array         | Array.<number>                                        |         | The array to pack into.                                                   |
| startingIndex | number                                                | 0       | optional The index into the array at which to start packing the elements. |

##### Returns:

 The array that was packed into

#### [](#.unpack) static Cesium.SimplePolylineGeometry.unpack(array, startingIndex, result) → [SimplePolylineGeometry](SimplePolylineGeometry.html) 

[engine/Source/Core/SimplePolylineGeometry.js 187](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Core/SimplePolylineGeometry.js#L187) 

 Retrieves an instance from a packed array.

| Name          | Type                                                  | Default | Description                                                |
| ------------- | ----------------------------------------------------- | ------- | ---------------------------------------------------------- |
| array         | Array.<number>                                        |         | The packed array.                                          |
| startingIndex | number                                                | 0       | optional The starting index of the element to be unpacked. |
| result        | [SimplePolylineGeometry](SimplePolylineGeometry.html) |         | optional The object into which to store the result.        |

##### Returns:

 The modified result parameter or a new SimplePolylineGeometry instance if one was not provided.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

