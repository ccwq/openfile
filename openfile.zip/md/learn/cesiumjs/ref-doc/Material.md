# [![](Images/CesiumLogo.png)](index.html) Material 

#### [](#Material) new Cesium.Material(options) 

[engine/Source/Scene/Material.js 273](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L273) 

 A Material defines surface appearance through a combination of diffuse, specular, normal, emission, and alpha components. These values are specified using a JSON schema called Fabric which gets parsed and assembled into glsl shader code behind-the-scenes. Check out the [wiki page](https://github.com/CesiumGS/cesium/wiki/Fabric)for more details on Fabric.  
  
Base material types and their uniforms:

* Color
   * `color`: rgba color object.
* Image
   * `image`: path to image.
   * `repeat`: Object with x and y values specifying the number of times to repeat the image.
* DiffuseMap
   * `image`: path to image.
   * `channels`: Three character string containing any combination of r, g, b, and a for selecting the desired image channels.
   * `repeat`: Object with x and y values specifying the number of times to repeat the image.
* AlphaMap
   * `image`: path to image.
   * `channel`: One character string containing r, g, b, or a for selecting the desired image channel.
   * `repeat`: Object with x and y values specifying the number of times to repeat the image.
* SpecularMap
   * `image`: path to image.
   * `channel`: One character string containing r, g, b, or a for selecting the desired image channel.
   * `repeat`: Object with x and y values specifying the number of times to repeat the image.
* EmissionMap
   * `image`: path to image.
   * `channels`: Three character string containing any combination of r, g, b, and a for selecting the desired image channels.
   * `repeat`: Object with x and y values specifying the number of times to repeat the image.
* BumpMap
   * `image`: path to image.
   * `channel`: One character string containing r, g, b, or a for selecting the desired image channel.
   * `repeat`: Object with x and y values specifying the number of times to repeat the image.
   * `strength`: Bump strength value between 0.0 and 1.0 where 0.0 is small bumps and 1.0 is large bumps.
* NormalMap
   * `image`: path to image.
   * `channels`: Three character string containing any combination of r, g, b, and a for selecting the desired image channels.
   * `repeat`: Object with x and y values specifying the number of times to repeat the image.
   * `strength`: Bump strength value between 0.0 and 1.0 where 0.0 is small bumps and 1.0 is large bumps.
* Grid
   * `color`: rgba color object for the whole material.
   * `cellAlpha`: Alpha value for the cells between grid lines. This will be combined with color.alpha.
   * `lineCount`: Object with x and y values specifying the number of columns and rows respectively.
   * `lineThickness`: Object with x and y values specifying the thickness of grid lines (in pixels where available).
   * `lineOffset`: Object with x and y values specifying the offset of grid lines (range is 0 to 1).
* Stripe
   * `horizontal`: Boolean that determines if the stripes are horizontal or vertical.
   * `evenColor`: rgba color object for the stripe's first color.
   * `oddColor`: rgba color object for the stripe's second color.
   * `offset`: Number that controls at which point into the pattern to begin drawing; with 0.0 being the beginning of the even color, 1.0 the beginning of the odd color, 2.0 being the even color again, and any multiple or fractional values being in between.
   * `repeat`: Number that controls the total number of stripes, half light and half dark.
* Checkerboard
   * `lightColor`: rgba color object for the checkerboard's light alternating color.
   * `darkColor`: rgba color object for the checkerboard's dark alternating color.
   * `repeat`: Object with x and y values specifying the number of columns and rows respectively.
* Dot
   * `lightColor`: rgba color object for the dot color.
   * `darkColor`: rgba color object for the background color.
   * `repeat`: Object with x and y values specifying the number of columns and rows of dots respectively.
* Water
   * `baseWaterColor`: rgba color object base color of the water.
   * `blendColor`: rgba color object used when blending from water to non-water areas.
   * `specularMap`: Single channel texture used to indicate areas of water.
   * `normalMap`: Normal map for water normal perturbation.
   * `frequency`: Number that controls the number of waves.
   * `animationSpeed`: Number that controls the animations speed of the water.
   * `amplitude`: Number that controls the amplitude of water waves.
   * `specularIntensity`: Number that controls the intensity of specular reflections.
* RimLighting
   * `color`: diffuse color and alpha.
   * `rimColor`: diffuse color and alpha of the rim.
   * `width`: Number that determines the rim's width.
* Fade
   * `fadeInColor`: diffuse color and alpha at `time`
   * `fadeOutColor`: diffuse color and alpha at `maximumDistance` from `time`
   * `maximumDistance`: Number between 0.0 and 1.0 where the `fadeInColor` becomes the `fadeOutColor`. A value of 0.0 gives the entire material a color of `fadeOutColor` and a value of 1.0 gives the the entire material a color of `fadeInColor`
   * `repeat`: true if the fade should wrap around the texture coodinates.
   * `fadeDirection`: Object with x and y values specifying if the fade should be in the x and y directions.
   * `time`: Object with x and y values between 0.0 and 1.0 of the `fadeInColor` position
* PolylineArrow
   * `color`: diffuse color and alpha.
* PolylineDash
   * `color`: color for the line.
   * `gapColor`: color for the gaps in the line.
   * `dashLength`: Dash length in pixels.
   * `dashPattern`: The 16 bit stipple pattern for the line..
* PolylineGlow
   * `color`: color and maximum alpha for the glow on the line.
   * `glowPower`: strength of the glow, as a percentage of the total line width (less than 1.0).
   * `taperPower`: strength of the tapering effect, as a percentage of the total line length. If 1.0 or higher, no taper effect is used.
* PolylineOutline
   * `color`: diffuse color and alpha for the interior of the line.
   * `outlineColor`: diffuse color and alpha for the outline.
   * `outlineWidth`: width of the outline in pixels.
* ElevationContour
   * `color`: color and alpha for the contour line.
   * `spacing`: spacing for contour lines in meters.
   * `width`: Number specifying the width of the grid lines in pixels.
* ElevationRamp
   * `image`: color ramp image to use for coloring the terrain.
   * `minimumHeight`: minimum height for the ramp.
   * `maximumHeight`: maximum height for the ramp.
* SlopeRamp
   * `image`: color ramp image to use for coloring the terrain by slope.
* AspectRamp
   * `image`: color ramp image to use for color the terrain by aspect.
* ElevationBand
   * `heights`: image of heights sorted from lowest to highest.
   * `colors`: image of colors at the corresponding heights.
* WaterMask
   * `waterColor`: diffuse color and alpha for the areas covered by water.
   * `landColor`: diffuse color and alpha for the areas covered by land.

| Name    | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| options | object | optional Object with the following properties: Name Type Default Description strict boolean false optional Throws errors for issues that would normally be ignored, including unused uniforms or materials. translucent boolean\|function true optional When true or a function that returns true, the geometry with this material is expected to appear translucent. minificationFilter [TextureMinificationFilter](global.html#TextureMinificationFilter) TextureMinificationFilter.LINEAR optional The [TextureMinificationFilter](global.html#TextureMinificationFilter) to apply to this material's textures. magnificationFilter [TextureMagnificationFilter](global.html#TextureMagnificationFilter) TextureMagnificationFilter.LINEAR optional The [TextureMagnificationFilter](global.html#TextureMagnificationFilter) to apply to this material's textures. fabric object  The fabric JSON used to generate the material. |

##### Throws:

* [DeveloperError](DeveloperError.html): fabric: uniform has invalid type.
* [DeveloperError](DeveloperError.html): fabric: uniforms and materials cannot share the same property.
* [DeveloperError](DeveloperError.html): fabric: cannot have source and components in the same section.
* [DeveloperError](DeveloperError.html): fabric: property name is not valid. It should be 'type', 'materials', 'uniforms', 'components', or 'source'.
* [DeveloperError](DeveloperError.html): fabric: property name is not valid. It should be 'diffuse', 'specular', 'shininess', 'normal', 'emission', or 'alpha'.
* [DeveloperError](DeveloperError.html): strict: shader source does not use string.
* [DeveloperError](DeveloperError.html): strict: shader source does not use uniform.
* [DeveloperError](DeveloperError.html): strict: shader source does not use material.

##### Example:

```javascript
// Create a color material with fromType:
polygon.material = Cesium.Material.fromType('Color');
polygon.material.uniforms.color = new Cesium.Color(1.0, 1.0, 0.0, 1.0);

// Create the default material:
polygon.material = new Cesium.Material();

// Create a color material with full Fabric notation:
polygon.material = new Cesium.Material({
  fabric: {
    type: 'Color',
    uniforms: {
      color: new Cesium.Color(1.0, 1.0, 0.0, 1.0)
    }
  }
});
```

##### Demo:

* [Cesium Sandcastle Materials Demo](https://sandcastle.cesium.com/index.html?src=Materials.html)

##### See:

* [Fabric wiki page](https://github.com/CesiumGS/cesium/wiki/Fabric) for a more detailed options of Fabric.

### Members

#### [](#.AlphaMapType) static readonly Cesium.Material.AlphaMapType : string 

[engine/Source/Scene/Material.js 1305](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1305) 

 Gets the name of the alpha map material.

#### [](#.AspectRampMaterialType) static readonly Cesium.Material.AspectRampMaterialType : string 

[engine/Source/Scene/Material.js 1715](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1715) 

 Gets the name of the aspect ramp material.

#### [](#.BumpMapType) static readonly Cesium.Material.BumpMapType : string 

[engine/Source/Scene/Material.js 1368](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1368) 

 Gets the name of the bump map material.

#### [](#.CheckerboardType) static readonly Cesium.Material.CheckerboardType : string 

[engine/Source/Scene/Material.js 1456](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1456) 

 Gets the name of the checkerboard material.

#### [](#.ColorType) static readonly Cesium.Material.ColorType : string 

[engine/Source/Scene/Material.js 1237](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1237) 

 Gets the name of the color material.

#### [](#.DefaultCubeMapId) static Cesium.Material.DefaultCubeMapId : string 

[engine/Source/Scene/Material.js 1230](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1230) 

 Gets or sets the default cube map texture uniform value.

#### [](#.DefaultImageId) static Cesium.Material.DefaultImageId : string 

[engine/Source/Scene/Material.js 1224](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1224) 

 Gets or sets the default texture uniform value.

#### [](#.DiffuseMapType) static readonly Cesium.Material.DiffuseMapType : string 

[engine/Source/Scene/Material.js 1284](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1284) 

 Gets the name of the diffuce map material.

#### [](#.DotType) static readonly Cesium.Material.DotType : string 

[engine/Source/Scene/Material.js 1478](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1478) 

 Gets the name of the dot material.

#### [](#.ElevationBandType) static readonly Cesium.Material.ElevationBandType : string 

[engine/Source/Scene/Material.js 1732](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1732) 

 Gets the name of the elevation band material.

#### [](#.ElevationContourType) static readonly Cesium.Material.ElevationContourType : string 

[engine/Source/Scene/Material.js 1660](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1660) 

 Gets the name of the elevation contour material.

#### [](#.ElevationRampType) static readonly Cesium.Material.ElevationRampType : string 

[engine/Source/Scene/Material.js 1679](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1679) 

 Gets the name of the elevation contour material.

#### [](#.EmissionMapType) static readonly Cesium.Material.EmissionMapType : string 

[engine/Source/Scene/Material.js 1347](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1347) 

 Gets the name of the emmision map material.

#### [](#.FadeType) static readonly Cesium.Material.FadeType : string 

[engine/Source/Scene/Material.js 1552](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1552) 

 Gets the name of the fade material.

#### [](#.GridType) static readonly Cesium.Material.GridType : string 

[engine/Source/Scene/Material.js 1408](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1408) 

 Gets the name of the grid material.

#### [](#.ImageType) static readonly Cesium.Material.ImageType : string 

[engine/Source/Scene/Material.js 1259](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1259) 

 Gets the name of the image material.

#### [](#.NormalMapType) static readonly Cesium.Material.NormalMapType : string 

[engine/Source/Scene/Material.js 1388](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1388) 

 Gets the name of the normal map material.

#### [](#.PolylineArrowType) static readonly Cesium.Material.PolylineArrowType : string 

[engine/Source/Scene/Material.js 1582](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1582) 

 Gets the name of the polyline arrow material.

#### [](#.PolylineDashType) static readonly Cesium.Material.PolylineDashType : string 

[engine/Source/Scene/Material.js 1599](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1599) 

 Gets the name of the polyline glow material.

#### [](#.PolylineGlowType) static readonly Cesium.Material.PolylineGlowType : string 

[engine/Source/Scene/Material.js 1619](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1619) 

 Gets the name of the polyline glow material.

#### [](#.PolylineOutlineType) static readonly Cesium.Material.PolylineOutlineType : string 

[engine/Source/Scene/Material.js 1638](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1638) 

 Gets the name of the polyline outline material.

#### [](#.RimLightingType) static readonly Cesium.Material.RimLightingType : string 

[engine/Source/Scene/Material.js 1530](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1530) 

 Gets the name of the rim lighting material.

#### [](#.SlopeRampMaterialType) static readonly Cesium.Material.SlopeRampMaterialType : string 

[engine/Source/Scene/Material.js 1698](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1698) 

 Gets the name of the slope ramp material.

#### [](#.SpecularMapType) static readonly Cesium.Material.SpecularMapType : string 

[engine/Source/Scene/Material.js 1326](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1326) 

 Gets the name of the specular map material.

#### [](#.StripeType) static readonly Cesium.Material.StripeType : string 

[engine/Source/Scene/Material.js 1432](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1432) 

 Gets the name of the stripe material.

#### [](#.WaterMaskType) static readonly Cesium.Material.WaterMaskType : string 

[engine/Source/Scene/Material.js 1750](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1750) 

 Gets the name of the water mask material.

#### [](#.WaterType) static readonly Cesium.Material.WaterType : string 

[engine/Source/Scene/Material.js 1500](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L1500) 

 Gets the name of the water material.

#### [](#materials) materials : object 

[engine/Source/Scene/Material.js 293](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L293) 

 Maps sub-material names to Material objects.

Default Value: `undefined` 

#### [](#shaderSource) shaderSource : string 

[engine/Source/Scene/Material.js 286](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L286) 

 The glsl shader source for this material.

Default Value: `undefined` 

#### [](#translucent) translucent : boolean|function 

[engine/Source/Scene/Material.js 309](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L309) 

 When `true` or a function that returns `true`, the geometry is expected to appear translucent.

Default Value: `undefined` 

#### [](#type) type : string 

[engine/Source/Scene/Material.js 279](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L279) 

 The material type. Can be an existing type or a new type. If no type is specified in fabric, type is a GUID.

Default Value: `undefined` 

#### [](#uniforms) uniforms : object 

[engine/Source/Scene/Material.js 300](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L300) 

 Maps uniform names to their values.

Default Value: `undefined` 

### Methods

#### [](#.fromType) static Cesium.Material.fromType(type, uniforms) → [Material](Material.html) 

[engine/Source/Scene/Material.js 367](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L367) 

 Creates a new material using an existing material type.  
  
Shorthand for: new Material({fabric : {type : type}});

| Name     | Type   | Description                                  |
| -------- | ------ | -------------------------------------------- |
| type     | string | The base material type.                      |
| uniforms | object | optional Overrides for the default uniforms. |

##### Returns:

 New material object.

##### Throws:

* [DeveloperError](DeveloperError.html): material with that type does not exist.

##### Example:

```javascript
const material = Cesium.Material.fromType('Color', {
  color: new Cesium.Color(1.0, 0.0, 0.0, 1.0)
});
```

#### [](#destroy) destroy() 

[engine/Source/Scene/Material.js 568](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L568) 

 Destroys the WebGL resources held by this object. Destroying an object allows for deterministic release of WebGL resources, instead of relying on the garbage collector to destroy this object.  
  
Once an object is destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception. Therefore, assign the return value (`undefined`) to the object as done in the example.

##### Throws:

* [DeveloperError](DeveloperError.html): This object was destroyed, i.e., destroy() was called.

##### Example:

```javascript
material = material && material.destroy();
```

##### See:

* [Material#isDestroyed](Material.html#isDestroyed)

#### [](#isDestroyed) isDestroyed() → boolean 

[engine/Source/Scene/Material.js 548](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L548) 

 Returns true if this object was destroyed; otherwise, false.  
  
If this object was destroyed, it should not be used; calling any function other than`isDestroyed` will result in a [DeveloperError](DeveloperError.html) exception.

##### Returns:

 True if this object was destroyed; otherwise, false.

##### See:

* [Material#destroy](Material.html#destroy)

#### [](#isTranslucent) isTranslucent() → boolean 

[engine/Source/Scene/Material.js 395](https://github.com/CesiumGS/cesium/blob/1.127/packages/engine/Source/Scene/Material.js#L395) 

 Gets whether or not this material is translucent.

##### Returns:

`true` if this material is translucent, `false` otherwise.

 Need help? The fastest way to get answers is from the community and team on the [Cesium Forum](https://community.cesium.com/).

 Documentation generated by [JSDoc 3.6.11](https://github.com/jsdoc3/jsdoc) 

CtrlK

